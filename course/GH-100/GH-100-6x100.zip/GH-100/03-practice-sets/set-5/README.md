# Full-Length Mock Exam 5 — GH-100: GitHub Enterprise Administrator

**Theme:** Sovereign Data Residency & Audit Compliance — GHE.com + EMUs, Audit Log Streaming, Fine-Grained PAT Policies, GitHub Apps & ARC Runners

## Set Summary

- **Questions:** `100` (`84` `multiple-choice` balanced `21 A / 21 B / 21 C / 21 D` + `16` `multi-select`)
- **Ordered 4-step sequences (`→`):** `8`
- **CLI / API / YAML / policy completions (`____`):** `21`
- **`Proposed solution:` evaluations:** `8`
- **Case studies:** `0` (matching the published GH-100 GitHub Administration exam format)
- **Recommended timer:** `100 minutes` (matching live GH-100 exam duration; **closed-book**)

## Domain Breakdown

| # | Official GH-100 Domain | Official Weight | Set Count |
|---:|---|---:|---:|
| 1 | Manage GitHub identities and access | 15–20% | 19 |
| 2 | Administer GitHub Enterprise environment | 10–15% | 14 |
| 3 | Implement secure software development and compliance | 25–30% | 29 |
| 4 | Manage GitHub Actions | 20–25% | 24 |
| 5 | Monitor and optimize GitHub usage | 10–15% | 14 |

## Files in This Folder

- `practice-set-5.csv` — 17-column UTF-8-BOM CSV ready for Udemy Bulk Question Upload
- `practice-set-5.md` — Full human-readable question & explanation review key
