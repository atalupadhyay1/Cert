# PCEP – Certified Entry-Level Python Programmer (PCEP-30-02) — Full-Length Mock Exam 4

Entry-Level Python Programmer · 60 questions · 80 minutes · 70% cumulative passing score

Blueprint-weighted expanded mock exam. Item mix: 45 multiple-choice (including 15 single-blank `____` code-fill / gap-fill items) and 15 multiple-response items (the selection count is stated in each multi-response stem). The live PCEP-30-02 exam has 30 items in 40 minutes (plus a 5-minute NDA and tutorial), so this 60-item set is an expanded 2x bank timed at 80 minutes to preserve the live pace of about 80 seconds per item. The Python Institute publishes no fixed split between single-select, multiple-select, and interactive items, so the 45 / 15 mix and single-blank `____` approximations are authoring choices within the 17-column CSV contract; interactive drag-and-drop, sort, and multi-slot code-insertion widgets are excluded and disclosed. The published format has no case-study component, so no case-study item appears here. Version note: PCEP-30-03 is scheduled for release on October 31, 2026; PCEP-30-02 remains active and earned credentials retain their five-year validity. See the README for the exact fidelity boundary.

Original educational content verified on CPython 3.11, not actual, recalled, or copied OpenEDG exam items.

## Questions

---

## Block 1 — Computer Programming and Python Fundamentals (18%) — Execution model, keywords, literals, numeral bases, operators, precedence, and console I/O

### 1. A field engineer deploys a Python telemetry poller onto both Linux gateways and Windows laptops. Which two statements accurately describe how standard CPython runs that `.py` script? Select two.

- A. CPython compiles source to bytecode and executes it in a virtual machine line by line at runtime
- B. Compiled native binaries require every end user to keep the original C compiler installed to launch the binary
- C. An interpreter executes source cross-platform wherever a compatible Python runtime is installed without recompiling per CPU
- D. CPython links source directly into a standalone machine-code binary before the user runs the script
- E. Standard `.py` interpretation encrypts source code into irreversible machine instructions so users cannot read it

### 2. A sensor calibration file accidentally includes the characters `@$` on an active code line and fails immediately during tokenization. Which language layer rejected `@$`?

- A. The `else` branch of `try` runs only when the `try` suite finishes with no exception raised
- B. Style formatting comments automatically bypass syntax checking during parsing
- C. Writing `@$` as an expression violates lexis because `@$` is not a valid token in Python vocabulary
- D. Semantics determines whether a syntactically valid statement makes sense and what it computes

### 3. While naming variables for a pressure-sensor reader, which two names are reserved Python keywords that cannot be assigned as variable identifiers? Select two.

- A. `list`
- B. `nonlocal`
- C. `item_price_usd`
- D. `none`
- E. `yield`

### 4. A register decoder evaluates `combined = 0b110 + 0xA` and prints `combined`. Which decimal integer is printed?

- A. `16`
- B. `10.0`
- C. `100`
- D. Raises `SyntaxError`

### 5. Which two identifiers are legal PEP-8-style variable names for holding a temperature threshold in Python 3? Select two.

- A. `raw score`
- B. `item_price_usd`
- C. `total_count_2`
- D. `user-count`
- E. `2nd_total`

### 6. A cyclic ring-buffer index in a sensor script evaluates `slot = -7 % 3`. What integer does Python 3 assign to `slot`?

- A. `1`
- B. `2`
- C. `-1`
- D. `-2`

### 7. A scaling expression evaluates `reading = 16 // 3 * 2`. Which value is bound to `reading`?

- A. `2`
- B. `10.0`
- C. `11`
- D. `10`

### 8. A bit-inversion check runs `inverted = ~4` and prints `inverted`. What integer does bitwise NOT `~4` produce in Python 3?

- A. `4`
- B. `-5`
- C. `-4`
- D. `3`

### 9. A status bar helper computes `bar = '#' * -2` when a sensor delta is negative. What value does `bar` receive?

- A. Raises `TypeError`
- B. `''` (multiplying a string by `0` or a negative integer returns an empty string)
- C. `'py'`
- D. Raises `ValueError`

### 10. A telemetry logger runs `print('A', 'B', 'C', sep='*')`. What exact text does it write to standard output?

- A. `a-b-c!`
- B. `A*B*C`
- C. `a b`
- D. Raises `TypeError`

### 11. Complete `voltage = ____(input('Volts: '))` so entering `2.5` at the prompt parses into floating-point `2.5` without raising `ValueError`. Which built-in callable fills the blank?

- A. `len()`
- B. `int()`
- C. `float()`
- D. `bool()`

---

## Block 2 — Control Flow – Conditional Blocks and Loops (29%) — Conditional branching, nested conditions, while/for/range loops, loop-else, break/continue/pass

### 12. Complete `if celsius ____ 0:` so a freeze warning triggers strictly below `0` degrees and stays off at `0`. Which relational operator fills the blank?

- A. `<=`
- B. `>`
- C. `<`
- D. `=`

### 13. A thermal alert evaluates `res = 'A' if temp > 30 else ('B' if temp == 20 else 'C')` when `temp = 20`. Which string is bound to `res`?

- A. `D`
- B. `A`
- C. `C`
- D. `B`

### 14. In a sensor health check `if reading:`, which two values of `reading` evaluate to `False`? Select two.

- A. `0.0`
- B. `[0]`
- C. `-1`
- D. `None`
- E. `'0'`

### 15. A drift monitor sets `delta = -1` and runs `if delta: print('A')` / `else: print('B')`. What does it print?

- A. Raises `TypeError`
- B. `B`
- C. `A`
- D. Nothing is printed (zero iterations)

### 16. Complete `if ____ sensor_ready:` so the calibration wait branch runs whenever `sensor_ready` is falsy. Which logical operator fills the blank?

- A. `not`
- B. `~`
- C. `!=`
- D. `is`

### 17. An actuator engages only when neither `over_temp` (`a`) nor `door_open` (`b`) is active. Which two conditions evaluate to `True` solely when both `a` and `b` are falsy? Select two.

- A. `not a or b`
- B. `(not a) or (not b)`
- C. `(not a) and (not b)`
- D. `not (a or b)`
- E. `(x >= 10) or (x <= 20)`

### 18. A decay tracker sets `lvl = 32; ticks = 0` and runs `while lvl > 1: lvl //= 2; ticks += 1`. What is `ticks` after termination?

- A. `6`
- B. `4`
- C. `5`
- D. `16`

### 19. Complete `span = 16` / `while span > 1:` / `    span ____ 2` so `span` is halved as an integer on every iteration (`16 -> 8 -> 4 -> 2 -> 1`). Which augmented operator fills the blank?

- A. `=`
- B. `//=`
- C. `-=`
- D. `/`

### 20. A cooling schedule evaluates `sum(range(10, 4, -2))`. What integer does `sum()` return?

- A. `24`
- B. `30`
- C. `18`
- D. `28`

### 21. Which two `range()` expressions visit exactly three values during a `for` loop? Select two.

- A. `range(0, 3, -1)`
- B. `range(1, 6)`
- C. `range(1, 3)`
- D. `range(3, 0, -1)`
- E. `range(0, 3)`

### 22. A peak detector sets `peak = 0` and runs `for r in [4, 19, 11, 7]:` / `    if r > peak: peak = r`. What is `peak` afterward?

- A. `7`
- B. `4`
- C. `19`
- D. `40`

### 23. A noise filter sets `valid = 0` and runs `for s in [12, -1, 8, -5, 4]:` / `    if s < 0: continue` / `    valid += s`. What is `valid` when the loop finishes?

- A. `12`
- B. `18`
- C. `30`
- D. `24`

### 24. Complete `for v in stream:` / `    if v > 999: ____` / `    record(v)` so an emergency spike above `999` halts the loop immediately without recording `v` or reading later samples. Which keyword fills the blank?

- A. `continue`
- B. `break`
- C. `pass`
- D. `return`

### 25. While polling sensor ports inside a `while ... else` loop, which two events abort the loop *without* executing its `else:` clause? Select two.

- A. The `else` branch of `try` runs only when the `try` suite finishes with no exception raised
- B. When an unhandled exception aborts the loop body
- C. When a `while` condition initially or eventually evaluates to `False` without `break`
- D. When `return` exits the enclosing function from inside the loop body
- E. When a `for` loop consumes every item in its iterable without hitting `break`

### 26. Complete `for reading in window:` / `    if reading > max_safe: break` / `____:` / `    mark_window_safe()` so `mark_window_safe()` runs only when no reading triggered `break`. Which keyword fills the blank?

- A. `finally`
- B. `else`
- C. `except`
- D. `elif`

### 27. A zone monitor runs `alarms = 0` / `for zone in [[2, 9], [8, 3]]:` / `    for reading in zone:` / `        if reading >= 8: alarms += 1`. What is `alarms` afterward?

- A. `4`
- B. `3`
- C. `1`
- D. `2`

### 28. How many iterations does the inner statement run in `for g in range(4):` / `    for ch in range(2): count += 1`?

- A. `8`
- B. `6`
- C. `4`
- D. `16`

---

## Block 3 — Data Collections – Tuples, Dictionaries, Lists, and Strings (25%) — List indexing/slicing/methods/comprehensions/aliasing, tuples, dictionaries, and string operations

### 29. A five-point window stores `temps = [15, 18, 21, 24, 27]`. What value does `temps[-2]` return?

- A. Raises `IndexError`
- B. `24`
- C. `21`
- D. `27`

### 30. With `temps = [15, 18, 21, 24, 27]`, what does `temps[1:4:2]` return?

- A. Raises `IndexError`
- B. `[1, 2, 3]`
- C. `[20, 30, 40]`
- D. `[18, 24]`

### 31. Complete `probe = [10, 30]; probe.____(1, 20)` so `20` is placed right before index `1`, mutating `probe` into `[10, 20, 30]`. Which `list` method fills the blank?

- A. `remove()`
- B. `extend()`
- C. `append()`
- D. `insert()`

### 32. When maintaining a rolling list of sensor samples, which two behaviours of Python `list` operations are accurate? Select two.

- A. `items.pop()` removes the final element in place and returns that removed element
- B. `items.append(x)` mutates `items` in place and evaluates to `None`
- C. `sorted(items)` mutates `items` in place and returns `None`
- D. `items.insert(0, x)` appends `x` after the last element of `items`
- E. `items.remove(x)` deletes every occurrence of `x` across the entire list in one call

### 33. A cleanup step sets `items = [10, 20, 30, 40, 50]`, runs `del items[1:3]`, and prints `items`. What is printed?

- A. `None`
- B. `[10, 40, 50]`
- C. `[20, 30]`
- D. Raises `SyntaxError`

### 34. A script runs `a = [1, 2, 3]; b = a; b[1] = 99; print(a)`. What is printed?

- A. `[1, 99, 3]`
- B. Raises `TypeError`
- C. `[1, 2, 3]` (unchanged, because `a[:]` creates a shallow copy)
- D. `None`

### 35. What does `[n * n for n in range(6) if n % 2 == 1]` evaluate to?

- A. Raises `SyntaxError`
- B. `[0, 4, 16]`
- C. `[1, 9, 25]`
- D. `[1, 2, 3]`

### 36. Complete `if sensor_id ____ offline_ids:` so polling runs only when `sensor_id` is absent from the `offline_ids` collection. Which membership operator fills the blank?

- A. `!=`
- B. `in`
- C. `is`
- D. `not in`

### 37. Which two facts hold for `tuple` values storing fixed sensor coordinates in Python 3? Select two.

- A. `(7)`
- B. Assigning `t[0] = 9` on a tuple raises `TypeError` because tuple slot bindings are immutable
- C. Calling `t.append(9)` adds an element to the end of tuple `t` in place
- D. Running `del t[0]` removes the first element while keeping the same tuple object
- E. `(7,)`

### 38. A baseline tuple initializes `zeros = (0,) * 3`. What value does `zeros` hold?

- A. `0`
- B. `(7,)`
- C. Raises `TypeError`
- D. `(0, 0, 0)`

### 39. Complete `____ sensors['old_probe']` so key `'old_probe'` and its value are removed in place from dictionary `sensors`. Which statement keyword fills the blank?

- A. `del`
- B. `keys()`
- C. `remove()`
- D. `get()`

### 40. When inspecting a sensor map `cfg = {'gain': 2, 'port': 4}`, which two dictionary usages are valid and accurate in Python 3? Select two.

- A. `'host' in cfg`
- B. Iterating `for k, v in d:` unpacks keys and values directly without calling `.items()`
- C. Iterating `for k, v in d.items():` unpacks each `(key, value)` pair cleanly
- D. `'host' in cfg.values()`
- E. Iterating `for k, v in d.values():` yields `(key, value)` tuples for every entry

### 41. A header defines a triple-quoted string across two lines (`'A'`, a newline, `'B'`, with no spaces) and checks `len(hdr)`. What integer does `len(hdr)` return?

- A. `2`
- B. Raises `SyntaxError`
- C. `3`
- D. `4`

### 42. Which two properties apply to unit-label strings in Python 3? Select two.

- A. Running `del s[0]` deletes the first character from `s` in place
- B. Every string transformation method returns a brand-new `str` object and leaves the original string unchanged
- C. `sorted(items)` mutates `items` in place and returns `None`
- D. Out-of-range string slice bounds such as `s[2:99]` clamp silently instead of raising `IndexError`
- E. Assigning `s[0] = "X"` mutates the first character of `s` in place

### 43. Complete `if packet.____('CRC_OK'):` so a telemetry frame check returns `True` when string `packet` finishes with the suffix `'CRC_OK'`. Which `str` method fills the blank?

- A. `endswith()`
- B. `startswith()`
- C. `isdigit()`
- D. `pop()`

---

## Block 4 — Functions and Exceptions (28%) — User-defined functions, generators, recursion, argument passing, scope/global, and exception handling

### 44. Which two statements accurately describe `return` in Python user-defined functions? Select two.

- A. Calling `t.append(9)` adds an element to the end of tuple `t` in place
- B. Function parameter names are automatically registered in module-level global scope when the function returns
- C. Writing `return a, b` returns a single `tuple` `(a, b)` that the caller can unpack
- D. Multiple `return` lines in the same branch all execute sequentially and concatenate their results
- E. A function executing a bare `return` statement evaluates to `None` at the call site

### 45. Complete `def clamp_high(val, ceiling):` / `    if val > ceiling: ____ ceiling` / `    return val` so values above `ceiling` immediately send `ceiling` back to the caller. Which keyword fills the blank?

- A. `return`
- B. `pass`
- C. `yield`
- D. `break`

### 46. Complete `def sample_pulses(limit):` / `    n = 0` / `    while n < limit:` / `        ____ n` / `        n += 1` so calling `sample_pulses(4)` returns a lazy generator iterator. Which keyword fills the blank?

- A. `break`
- B. `global`
- C. `return`
- D. `yield`

### 47. In a Fibonacci sensor-backoff timer defined by `def fib(n): return n if n < 2 else fib(n - 1) + fib(n - 2)`, which value is produced for step `n = 6`?

- A. `8`
- B. `13`
- C. `6`
- D. `5`

### 48. Complete `def countdown_sum(n):` / `    if n <= 0: return 0` / `    ____ n + countdown_sum(n - 1)` so each recursive frame hands its accumulated total back up the call stack. Which keyword fills the blank?

- A. `return`
- B. `yield`
- C. `global`
- D. `continue`

### 49. Given `def linear(m, x, b): return m * x + b`, what does `linear(3, b=2, x=4)` return?

- A. `14`
- B. Raises `TypeError`
- C. `10`
- D. Raises `SyntaxError`

### 50. For `def calc(base, rate): return base * rate`, which two function invocations obey Python's argument-passing rules? Select two.

- A. `calc(10, rate=2)`
- B. `calc(rate=2, base=10)`
- C. `calc(10, base=5)`
- D. `calc(base=10, 2)`
- E. `calc(10, tax=2)`

### 51. A calibration helper defines `def offset(v, bias=10): return v + bias` and evaluates `offset(7)`. What integer does it return?

- A. Raises `TypeError`
- B. `17`
- C. `10`
- D. `7`

### 52. Complete `def read_port(timeout____5):` / `    return timeout` so parameter `timeout` defaults to `5` when omitted by callers. Which symbol fills the blank?

- A. `==`
- B. `in`
- C. `+=`
- D. `=`

### 53. A module sets `gain = 4`, defines `def preview(): gain = 9; return gain`, calls `preview()`, and then prints module-level `gain`. What is printed?

- A. `9`
- B. Raises `UnboundLocalError`
- C. `4`
- D. Raises `NameError`

### 54. Complete `alarm_trips = 0` / `def trip():` / `    ____ alarm_trips` / `    alarm_trips += 1` so `trip()` updates module-level `alarm_trips`. Which keyword fills the blank?

- A. `nonlocal`
- B. `from`
- C. `def` (reserved keyword)
- D. `global`

### 55. When catching sensor-processing exceptions by abstract parent class, which two subclass relationships hold in Python 3? Select two.

- A. `ZeroDivisionError` is a direct subclass of `ArithmeticError`
- B. Calling `t.append(9)` adds an element to the end of tuple `t` in place
- C. Compiled native binaries require every end user to keep the original C compiler installed to launch the binary
- D. Place `except Exception:` first and `except ValueError:` second so `ValueError` overrides the general handler
- E. `IndexError` is a direct subclass of `LookupError`

### 56. A telemetry script wraps `val = table[idx]` in `except LookupError:`. Which pair of concrete built-in errors will that single clause catch?

- A. `ArithmeticError` is the abstract parent class of `ZeroDivisionError` and `OverflowError`
- B. `LookupError` is the abstract parent class of both `IndexError` and `KeyError`
- C. `BaseException` sits at the root, with `SystemExit` and `KeyboardInterrupt` inheriting directly from `BaseException` rather than `Exception`
- D. `TypeError` inherits directly from `Exception`

### 57. A developer stores fixed calibration points in a tuple `pts = (10, 20)` and mistakenly calls `pts.append(30)`. Which exception does Python raise?

- A. Raises `AttributeError`
- B. Raises `ValueError`
- C. Raises `TypeError`
- D. Raises `KeyError`

### 58. A threshold check misspells `threshold` as `thresold` on a module-level `print(thresold)` line where `thresold` was never defined. Which exception is raised?

- A. Raises `UnboundLocalError`
- B. Raises `ValueError`
- C. Raises `NameError`
- D. `None`

### 59. Which two statements accurately describe `except` handler matching when a sensor routine divides readings? Select two.

- A. Place a bare `except:` clause above `except TypeError:` as a fallback default
- B. Place `except Exception:` first and `except ValueError:` second so `ValueError` overrides the general handler
- C. Only the first matching `except` branch runs, so a leading broad superclass handler swallows subclass exceptions before later branches are checked
- D. Python runs every `except` clause whose class matches the raised exception from top to bottom
- E. Place `except ZeroDivisionError:` above `except ArithmeticError:` so division by zero reaches the specific handler

### 60. A sensor divider runs `try: x = 10 // 0` / `except ArithmeticError: print('A')` / `except ZeroDivisionError: print('B')`. What does it print?

- A. `B`
- B. Raises `ZeroDivisionError`
- C. `A`
- D. `A B`

---

## Answer key and explanations

### Question 1 — A, C

Answers: CPython compiles source to bytecode and executes it in a virtual machine line by line at runtime; An interpreter executes source cross-platform wherever a compatible Python runtime is installed without recompiling per CPU. CPython compiles `.py` source to bytecode for its virtual machine at runtime and runs unchanged across platforms that provide a compatible Python runtime. An interpreter translates and executes source through bytecode at runtime without producing a standalone native executable. Interpreted Python scripts run unchanged across operating systems that provide the matching Python interpreter. Local study-map skill 1.1 (Compilation vs Interpretation and Execution Model), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 1 (Computer Programming and Python Fundamentals, 18 percent): https://pythoninstitute.org/pcep-exam-syllabus#block1 — and Python 3 documentation, Built-in Types and Functions: https://docs.python.org/3/library/stdtypes.html.

- **A:** Correct. An interpreter translates and executes source through bytecode at runtime without producing a standalone native executable. In this case: CPython compiles `.py` source to bytecode for its virtual machine at runtime and runs unchanged across platforms that provide a compatible Python runtime.
- **B:** Incorrect for this question. A compiled standalone executable runs directly on the target OS without shipping the compiler. Why the correct answer wins: CPython compiles `.py` source to bytecode for its virtual machine at runtime and runs unchanged across platforms that provide a compatible Python runtime.
- **C:** Correct. Interpreted Python scripts run unchanged across operating systems that provide the matching Python interpreter. In this case: CPython compiles `.py` source to bytecode for its virtual machine at runtime and runs unchanged across platforms that provide a compatible Python runtime.
- **D:** Incorrect for this question. Ahead-of-time native machine-code compilation is what a C or Rust compiler performs, not standard CPython. Why the correct answer wins: CPython compiles `.py` source to bytecode for its virtual machine at runtime and runs unchanged across platforms that provide a compatible Python runtime.
- **E:** Incorrect for this question. `.py` files are plain text and `.pyc` bytecode can be disassembled; interpretation does not encrypt source. Why the correct answer wins: CPython compiles `.py` source to bytecode for its virtual machine at runtime and runs unchanged across platforms that provide a compatible Python runtime.

### Question 2 — C

Answer: Writing `@$` as an expression violates lexis because `@$` is not a valid token in Python vocabulary. Lexis defines the legal token vocabulary of Python; character combinations that form no valid token fail lexical analysis before grammar or runtime steps. When characters cannot be grouped into legal Python tokens, lexical analysis rejects the source. Local study-map skill 1.2 (Lexis, Syntax, and Semantics Distinctions), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 1 (Computer Programming and Python Fundamentals, 18 percent): https://pythoninstitute.org/pcep-exam-syllabus#block1 — and Python 3 documentation, Built-in Types and Functions: https://docs.python.org/3/library/stdtypes.html.

- **A:** Incorrect for this question. In `try ... except ... else ... finally`, `else` executes when no exception occurred and `finally` executes unconditionally. Why the correct answer wins: Lexis defines the legal token vocabulary of Python; character combinations that form no valid token fail lexical analysis before grammar or runtime steps.
- **B:** Incorrect for this question. Comments are ignored by the parser and never disable syntax checking on surrounding code. Why the correct answer wins: Lexis defines the legal token vocabulary of Python; character combinations that form no valid token fail lexical analysis before grammar or runtime steps.
- **C:** Correct. When characters cannot be grouped into legal Python tokens, lexical analysis rejects the source. In this case: Lexis defines the legal token vocabulary of Python; character combinations that form no valid token fail lexical analysis before grammar or runtime steps.
- **D:** Incorrect for this question. Semantics governs runtime meaning, so dividing a number by zero is syntactically legal yet fails semantically at runtime. Why the correct answer wins: Lexis defines the legal token vocabulary of Python; character combinations that form no valid token fail lexical analysis before grammar or runtime steps.

### Question 3 — B, E

Answers: `nonlocal`; `yield`. `nonlocal` and `yield` are reserved keywords in Python 3, whereas `list` is a built-in name, `none` is lowercase, and `item_price_usd` is a regular identifier. `nonlocal` is a reserved Python keyword and cannot name an ordinary variable. `yield` is a reserved Python keyword that turns a function into a generator. Local study-map skill 1.3 (Keywords, Instructions, Indentation, and Comments), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 1 (Computer Programming and Python Fundamentals, 18 percent): https://pythoninstitute.org/pcep-exam-syllabus#block1 — and Python 3 documentation, Built-in Types and Functions: https://docs.python.org/3/library/stdtypes.html.

- **A:** Incorrect for this question. `list` names a built-in type rather than a reserved keyword, so Python permits (but discourages) rebinding it. Why the correct answer wins: `nonlocal` and `yield` are reserved keywords in Python 3, whereas `list` is a built-in name, `none` is lowercase, and `item_price_usd` is a regular identifier.
- **B:** Correct. `nonlocal` is a reserved Python keyword and cannot name an ordinary variable. In this case: `nonlocal` and `yield` are reserved keywords in Python 3, whereas `list` is a built-in name, `none` is lowercase, and `item_price_usd` is a regular identifier.
- **C:** Incorrect for this question. Lowercase words separated by underscores (`snake_case`) follow PEP-8 variable naming recommendations. Why the correct answer wins: `nonlocal` and `yield` are reserved keywords in Python 3, whereas `list` is a built-in name, `none` is lowercase, and `item_price_usd` is a regular identifier.
- **D:** Incorrect for this question. Only capitalized `None` is a keyword; lowercase `none` is not reserved by Python. Why the correct answer wins: `nonlocal` and `yield` are reserved keywords in Python 3, whereas `list` is a built-in name, `none` is lowercase, and `item_price_usd` is a regular identifier.
- **E:** Correct. `yield` is a reserved Python keyword that turns a function into a generator. In this case: `nonlocal` and `yield` are reserved keywords in Python 3, whereas `list` is a built-in name, `none` is lowercase, and `item_price_usd` is a regular identifier.

### Question 4 — A

Answer: `16`. Binary `0b110` equals `6` and hexadecimal `0xA` equals `10`, so `6 + 10` prints the integer `16`. Evaluates to the integer `16`. Local study-map skill 1.4 (Literals, Numeral Systems, and Scientific Notation), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 1 (Computer Programming and Python Fundamentals, 18 percent): https://pythoninstitute.org/pcep-exam-syllabus#block1 — and Python 3 documentation, Built-in Types and Functions: https://docs.python.org/3/library/stdtypes.html.

- **A:** Correct. Evaluates to the integer `16`. In this case: Binary `0b110` equals `6` and hexadecimal `0xA` equals `10`, so `6 + 10` prints the integer `16`.
- **B:** Incorrect for this question. Evaluates to the floating-point value `10.0`. Why the correct answer wins: Binary `0b110` equals `6` and hexadecimal `0xA` equals `10`, so `6 + 10` prints the integer `16`.
- **C:** Incorrect for this question. Evaluates to the integer `100`. Why the correct answer wins: Binary `0b110` equals `6` and hexadecimal `0xA` equals `10`, so `6 + 10` prints the integer `16`.
- **D:** Incorrect for this question. `SyntaxError` is raised by the parser before execution starts when tokens violate Python grammar. Why the correct answer wins: Binary `0b110` equals `6` and hexadecimal `0xA` equals `10`, so `6 + 10` prints the integer `16`.

### Question 5 — B, C

Answers: `total_count_2`; `item_price_usd`. `total_count_2` and `item_price_usd` use letters, digits (not leading), and underscores; leading digits, hyphens, and spaces all fail parsing. Identifiers may contain letters, digits, and underscores provided they do not start with a digit or match a keyword. Lowercase words separated by underscores (`snake_case`) follow PEP-8 variable naming recommendations. Local study-map skill 1.5 (Variable Naming Rules and PEP-8 Conventions), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 1 (Computer Programming and Python Fundamentals, 18 percent): https://pythoninstitute.org/pcep-exam-syllabus#block1 — and Python 3 documentation, Built-in Types and Functions: https://docs.python.org/3/library/stdtypes.html.

- **A:** Incorrect for this question. Whitespace separates tokens and is illegal inside a Python variable name. Why the correct answer wins: `total_count_2` and `item_price_usd` use letters, digits (not leading), and underscores; leading digits, hyphens, and spaces all fail parsing.
- **B:** Correct. Lowercase words separated by underscores (`snake_case`) follow PEP-8 variable naming recommendations. In this case: `total_count_2` and `item_price_usd` use letters, digits (not leading), and underscores; leading digits, hyphens, and spaces all fail parsing.
- **C:** Correct. Identifiers may contain letters, digits, and underscores provided they do not start with a digit or match a keyword. In this case: `total_count_2` and `item_price_usd` use letters, digits (not leading), and underscores; leading digits, hyphens, and spaces all fail parsing.
- **D:** Incorrect for this question. A hyphen is parsed as the subtraction operator rather than part of an identifier. Why the correct answer wins: `total_count_2` and `item_price_usd` use letters, digits (not leading), and underscores; leading digits, hyphens, and spaces all fail parsing.
- **E:** Incorrect for this question. An identifier cannot begin with a decimal digit, so `2nd_total` fails lexical analysis with `SyntaxError`. Why the correct answer wins: `total_count_2` and `item_price_usd` use letters, digits (not leading), and underscores; leading digits, hyphens, and spaces all fail parsing.

### Question 6 — B

Answer: `2`. In Python, `a % b` satisfies `a == (a // b) * b + (a % b)` and takes the sign of divisor `3`: since `-7 // 3 == -3`, `-7 - (-9)` equals `2`. Evaluates to the integer `2`. Local study-map skill 1.6 (Arithmetic Operators, Floor Division, Modulo, and Exponentiation), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 1 (Computer Programming and Python Fundamentals, 18 percent): https://pythoninstitute.org/pcep-exam-syllabus#block1 — and Python 3 documentation, Built-in Types and Functions: https://docs.python.org/3/library/stdtypes.html.

- **A:** Incorrect for this question. Evaluates to the integer `1`. Why the correct answer wins: In Python, `a % b` satisfies `a == (a // b) * b + (a % b)` and takes the sign of divisor `3`: since `-7 // 3 == -3`, `-7 - (-9)` equals `2`.
- **B:** Correct. Evaluates to the integer `2`. In this case: In Python, `a % b` satisfies `a == (a // b) * b + (a % b)` and takes the sign of divisor `3`: since `-7 // 3 == -3`, `-7 - (-9)` equals `2`.
- **C:** Incorrect for this question. Evaluates to the negative integer `-1`. Why the correct answer wins: In Python, `a % b` satisfies `a == (a // b) * b + (a % b)` and takes the sign of divisor `3`: since `-7 // 3 == -3`, `-7 - (-9)` equals `2`.
- **D:** Incorrect for this question. Evaluates to the negative integer `-2`. Why the correct answer wins: In Python, `a % b` satisfies `a == (a // b) * b + (a % b)` and takes the sign of divisor `3`: since `-7 // 3 == -3`, `-7 - (-9)` equals `2`.

### Question 7 — D

Answer: `10`. Floor division `//` and multiplication `*` share the same precedence tier and bind left-to-right, computing `(16 // 3) * 2 == 5 * 2 == 10`. Evaluates to the integer `10`. Local study-map skill 1.7 (Operator Precedence, Unary Signs, and Right-Sided Binding), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 1 (Computer Programming and Python Fundamentals, 18 percent): https://pythoninstitute.org/pcep-exam-syllabus#block1 — and Python 3 documentation, Built-in Types and Functions: https://docs.python.org/3/library/stdtypes.html.

- **A:** Incorrect for this question. Evaluates to the integer `2`. Why the correct answer wins: Floor division `//` and multiplication `*` share the same precedence tier and bind left-to-right, computing `(16 // 3) * 2 == 5 * 2 == 10`.
- **B:** Incorrect for this question. Evaluates to the floating-point value `10.0`. Why the correct answer wins: Floor division `//` and multiplication `*` share the same precedence tier and bind left-to-right, computing `(16 // 3) * 2 == 5 * 2 == 10`.
- **C:** Incorrect for this question. Evaluates to the integer `11`. Why the correct answer wins: Floor division `//` and multiplication `*` share the same precedence tier and bind left-to-right, computing `(16 // 3) * 2 == 5 * 2 == 10`.
- **D:** Correct. Evaluates to the integer `10`. In this case: Floor division `//` and multiplication `*` share the same precedence tier and bind left-to-right, computing `(16 // 3) * 2 == 5 * 2 == 10`.

### Question 8 — B

Answer: `-5`. Bitwise inversion in two's-complement integer arithmetic always equals `-(x + 1)`, so `~4` evaluates to `-5`. Evaluates to the negative integer `-5`. Local study-map skill 1.8 (Bitwise, Relational, Boolean Operators, and Short-Circuiting), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 1 (Computer Programming and Python Fundamentals, 18 percent): https://pythoninstitute.org/pcep-exam-syllabus#block1 — and Python 3 documentation, Built-in Types and Functions: https://docs.python.org/3/library/stdtypes.html.

- **A:** Incorrect for this question. Evaluates to the integer `4`. Why the correct answer wins: Bitwise inversion in two's-complement integer arithmetic always equals `-(x + 1)`, so `~4` evaluates to `-5`.
- **B:** Correct. Evaluates to the negative integer `-5`. In this case: Bitwise inversion in two's-complement integer arithmetic always equals `-(x + 1)`, so `~4` evaluates to `-5`.
- **C:** Incorrect for this question. Evaluates to the negative integer `-4`. Why the correct answer wins: Bitwise inversion in two's-complement integer arithmetic always equals `-(x + 1)`, so `~4` evaluates to `-5`.
- **D:** Incorrect for this question. Evaluates to the integer `3`. Why the correct answer wins: Bitwise inversion in two's-complement integer arithmetic always equals `-(x + 1)`, so `~4` evaluates to `-5`.

### Question 9 — B

Answer: `''` (multiplying a string by `0` or a negative integer returns an empty string). Multiplying any string by `0` or a negative integer returns the empty string `''` cleanly without raising an exception. Repeating any string `s * n` with `n <= 0` yields `""` without raising an error. Local study-map skill 1.9 (Floating-Point Accuracy, String Operators, and Shortcut Assignments), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 1 (Computer Programming and Python Fundamentals, 18 percent): https://pythoninstitute.org/pcep-exam-syllabus#block1 — and Python 3 documentation, Built-in Types and Functions: https://docs.python.org/3/library/stdtypes.html.

- **A:** Incorrect for this question. `TypeError` is raised when an operation or function is applied to an object of an inappropriate type, or argument counts mismatch. Why the correct answer wins: Multiplying any string by `0` or a negative integer returns the empty string `''` cleanly without raising an exception.
- **B:** Correct. Repeating any string `s * n` with `n <= 0` yields `""` without raising an error. In this case: Multiplying any string by `0` or a negative integer returns the empty string `''` cleanly without raising an exception.
- **C:** Incorrect for this question. Evaluates to the two-character string `'py'`. Why the correct answer wins: Multiplying any string by `0` or a negative integer returns the empty string `''` cleanly without raising an exception.
- **D:** Incorrect for this question. `ValueError` is raised when an argument has the right type (such as `str`) but an invalid content (such as `int("abc")` or `[].index(9)`). Why the correct answer wins: Multiplying any string by `0` or a negative integer returns the empty string `''` cleanly without raising an exception.

### Question 10 — B

Answer: `A*B*C`. Passing `sep='*'` places an asterisk between consecutive positional arguments in `print()`, outputting `A*B*C`. Local study-map skill 1.10 (Console Output with print(), sep=, and end=), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 1 (Computer Programming and Python Fundamentals, 18 percent): https://pythoninstitute.org/pcep-exam-syllabus#block1 — and Python 3 documentation, Built-in Types and Functions: https://docs.python.org/3/library/stdtypes.html.

- **A:** Incorrect for this question. Joining three arguments with `-` and ending with `!` prints `a-b-c!`. Why the correct answer wins: Passing `sep='*'` places an asterisk between consecutive positional arguments in `print()`, outputting `A*B*C`.
- **B:** Correct. In this case: Passing `sep='*'` places an asterisk between consecutive positional arguments in `print()`, outputting `A*B*C`.
- **C:** Incorrect for this question. Default `sep` in `print()` is a single space and default `end` is `\n`. Why the correct answer wins: Passing `sep='*'` places an asterisk between consecutive positional arguments in `print()`, outputting `A*B*C`.
- **D:** Incorrect for this question. `TypeError` is raised when an operation or function is applied to an object of an inappropriate type, or argument counts mismatch. Why the correct answer wins: Passing `sep='*'` places an asterisk between consecutive positional arguments in `print()`, outputting `A*B*C`.

### Question 11 — C

Answer: `float()`. `float()` parses decimal strings such as `'2.5'` into a `float`, whereas `int('2.5')` raises `ValueError`. `float()` parses numeric strings (including decimal points or scientific notation) into `float`. Local study-map skill 1.11 (Console Input with input() and Type Casting (int, float, str, bool)), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 1 (Computer Programming and Python Fundamentals, 18 percent): https://pythoninstitute.org/pcep-exam-syllabus#block1 — and Python 3 documentation, Built-in Types and Functions: https://docs.python.org/3/library/stdtypes.html.

- **A:** Incorrect for this question. `len(obj)` returns the item or character count of a sequence or collection. Why the correct answer wins: `float()` parses decimal strings such as `'2.5'` into a `float`, whereas `int('2.5')` raises `ValueError`.
- **B:** Incorrect for this question. `int()` converts a base-10 integer string or truncates a `float` toward zero (`int(-3.9) == -3`). Why the correct answer wins: `float()` parses decimal strings such as `'2.5'` into a `float`, whereas `int('2.5')` raises `ValueError`.
- **C:** Correct. `float()` parses numeric strings (including decimal points or scientific notation) into `float`. In this case: `float()` parses decimal strings such as `'2.5'` into a `float`, whereas `int('2.5')` raises `ValueError`.
- **D:** Incorrect for this question. `bool()` returns `False` only for `0`, `0.0`, empty collections/strings, and `None`; non-empty strings like `"False"` or `"0"` are `True`. Why the correct answer wins: `float()` parses decimal strings such as `'2.5'` into a `float`, whereas `int('2.5')` raises `ValueError`.

### Question 12 — C

Answer: `<`. `<` tests strict less-than, excluding `0` itself, whereas `<=` would trigger at `0`. Strictly-less-than relational operator. Local study-map skill 2.1 (Single and Chained Branching with if, elif, and else), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. Less-than-or-equal relational operator. Why the correct answer wins: `<` tests strict less-than, excluding `0` itself, whereas `<=` would trigger at `0`.
- **B:** Incorrect for this question. Strictly-greater-than relational operator. Why the correct answer wins: `<` tests strict less-than, excluding `0` itself, whereas `<=` would trigger at `0`.
- **C:** Correct. Strictly-less-than relational operator. In this case: `<` tests strict less-than, excluding `0` itself, whereas `<=` would trigger at `0`.
- **D:** Incorrect for this question. A single `=` performs assignment rather than equality comparison (`==`), and is invalid as a plain condition in `if x = 5:`. Why the correct answer wins: `<` tests strict less-than, excluding `0` itself, whereas `<=` would trigger at `0`.

### Question 13 — D

Answer: `B`. `20 > 30` is `False`, so the outer conditional expression evaluates its `else` subexpression where `20 == 20` is `True`, selecting `'B'`. Prints `B` when the `if` condition is `False` and the first `elif` condition is `True`. Local study-map skill 2.1 (Single and Chained Branching with if, elif, and else), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. Prints `D` via the final `else` fallback when every preceding condition is `False`. Why the correct answer wins: `20 > 30` is `False`, so the outer conditional expression evaluates its `else` subexpression where `20 == 20` is `True`, selecting `'B'`.
- **B:** Incorrect for this question. Prints `A` because the first matching `if`/`elif` branch runs and skips all remaining `elif`/`else` clauses. Why the correct answer wins: `20 > 30` is `False`, so the outer conditional expression evaluates its `else` subexpression where `20 == 20` is `True`, selecting `'B'`.
- **C:** Incorrect for this question. Prints `C` when earlier branches evaluate to `False` and execution reaches the matching clause. Why the correct answer wins: `20 > 30` is `False`, so the outer conditional expression evaluates its `else` subexpression where `20 == 20` is `True`, selecting `'B'`.
- **D:** Correct. Prints `B` when the `if` condition is `False` and the first `elif` condition is `True`. In this case: `20 > 30` is `False`, so the outer conditional expression evaluates its `else` subexpression where `20 == 20` is `True`, selecting `'B'`.

### Question 14 — A, D

Answers: `0.0`; `None`. Floating-point zero `0.0` and `None` are falsy, whereas negative non-zero `-1`, non-empty `'0'`, and one-element `[0]` are all truthy. Evaluates to the floating-point value `0.0`; true division `/` and scientific notation always yield `float`. Evaluates to `None`, the singleton returned by functions and in-place mutator methods that return no explicit value. Local study-map skill 2.2 (Nested Conditionals and Truthiness of Built-In Values), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Correct. Evaluates to the floating-point value `0.0`; true division `/` and scientific notation always yield `float`. In this case: Floating-point zero `0.0` and `None` are falsy, whereas negative non-zero `-1`, non-empty `'0'`, and one-element `[0]` are all truthy.
- **B:** Incorrect for this question. A one-element list `[0]` has length `1` and is truthy even though its element `0` is falsy. Why the correct answer wins: Floating-point zero `0.0` and `None` are falsy, whereas negative non-zero `-1`, non-empty `'0'`, and one-element `[0]` are all truthy.
- **C:** Incorrect for this question. Evaluates to the negative integer `-1`. Why the correct answer wins: Floating-point zero `0.0` and `None` are falsy, whereas negative non-zero `-1`, non-empty `'0'`, and one-element `[0]` are all truthy.
- **D:** Correct. Evaluates to `None`, the singleton returned by functions and in-place mutator methods that return no explicit value. In this case: Floating-point zero `0.0` and `None` are falsy, whereas negative non-zero `-1`, non-empty `'0'`, and one-element `[0]` are all truthy.
- **E:** Incorrect for this question. A non-empty string `'0'` has length `1` and therefore evaluates to `True` in Boolean contexts. Why the correct answer wins: Floating-point zero `0.0` and `None` are falsy, whereas negative non-zero `-1`, non-empty `'0'`, and one-element `[0]` are all truthy.

### Question 15 — C

Answer: `A`. Every non-zero numeric value—including negative integers like `-1`—is truthy in Python, so `if delta:` runs and prints `A`. Prints `A` because the first matching `if`/`elif` branch runs and skips all remaining `elif`/`else` clauses. Local study-map skill 2.2 (Nested Conditionals and Truthiness of Built-In Values), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. `TypeError` is raised when an operation or function is applied to an object of an inappropriate type, or argument counts mismatch. Why the correct answer wins: Every non-zero numeric value—including negative integers like `-1`—is truthy in Python, so `if delta:` runs and prints `A`.
- **B:** Incorrect for this question. Prints `B` when the `if` condition is `False` and the first `elif` condition is `True`. Why the correct answer wins: Every non-zero numeric value—including negative integers like `-1`—is truthy in Python, so `if delta:` runs and prints `A`.
- **C:** Correct. Prints `A` because the first matching `if`/`elif` branch runs and skips all remaining `elif`/`else` clauses. In this case: Every non-zero numeric value—including negative integers like `-1`—is truthy in Python, so `if delta:` runs and prints `A`.
- **D:** Incorrect for this question. When the loop condition is initially `False` (or `range` is empty) and there is no `else` print, the body never runs. Why the correct answer wins: Every non-zero numeric value—including negative integers like `-1`—is truthy in Python, so `if delta:` runs and prints `A`.

### Question 16 — A

Answer: `not`. Logical `not` inverts truthiness and returns `True` when `sensor_ready` is falsy, whereas `~` performs integer bit inversion (`~False == -1`, which is truthy!). Logical `not` always returns a `bool` (`True` or `False`) and has lower precedence than relational operators. Local study-map skill 2.3 (Compound Boolean Conditions and Chained Comparisons), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Correct. Logical `not` always returns a `bool` (`True` or `False`) and has lower precedence than relational operators. In this case: Logical `not` inverts truthiness and returns `True` when `sensor_ready` is falsy, whereas `~` performs integer bit inversion (`~False == -1`, which is truthy!).
- **B:** Incorrect for this question. Bitwise inversion computes `-(x + 1)` in two-complement integer arithmetic. Why the correct answer wins: Logical `not` inverts truthiness and returns `True` when `sensor_ready` is falsy, whereas `~` performs integer bit inversion (`~False == -1`, which is truthy!).
- **C:** Incorrect for this question. `!=` evaluates to `True` when two operands do not compare equal. Why the correct answer wins: Logical `not` inverts truthiness and returns `True` when `sensor_ready` is falsy, whereas `~` performs integer bit inversion (`~False == -1`, which is truthy!).
- **D:** Incorrect for this question. `is` compares object identity rather than value equality. Why the correct answer wins: Logical `not` inverts truthiness and returns `True` when `sensor_ready` is falsy, whereas `~` performs integer bit inversion (`~False == -1`, which is truthy!).

### Question 17 — C, D

Answers: `not (a or b)`; `(not a) and (not b)`. `not (a or b)` and `(not a) and (not b)` are equivalent De Morgan forms requiring both flags to be falsy. By De Morgan law, `not (a or b)` is True exactly when both `a` and `b` are falsy. Requiring both `not a` and `not b` is logically equivalent to `not (a or b)`. Local study-map skill 2.3 (Compound Boolean Conditions and Chained Comparisons), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. Because `not` binds tighter than `or`, `not a or b` parses as `(not a) or b`. Why the correct answer wins: `not (a or b)` and `(not a) and (not b)` are equivalent De Morgan forms requiring both flags to be falsy.
- **B:** Incorrect for this question. `(not a) or (not b)` is equivalent to `not (a and b)`, which still allows one operand to be truthy. Why the correct answer wins: `not (a or b)` and `(not a) and (not b)` are equivalent De Morgan forms requiring both flags to be falsy.
- **C:** Correct. Requiring both `not a` and `not b` is logically equivalent to `not (a or b)`. In this case: `not (a or b)` and `(not a) and (not b)` are equivalent De Morgan forms requiring both flags to be falsy.
- **D:** Correct. By De Morgan law, `not (a or b)` is True exactly when both `a` and `b` are falsy. In this case: `not (a or b)` and `(not a) and (not b)` are equivalent De Morgan forms requiring both flags to be falsy.
- **E:** Incorrect for this question. Using `or` here is `True` for *every* number (for example `x = 99` satisfies `x >= 10`). Why the correct answer wins: `not (a or b)` and `(not a) and (not b)` are equivalent De Morgan forms requiring both flags to be falsy.

### Question 18 — C

Answer: `5`. Halving `32` produces `16, 8, 4, 2, 1` across `5` iterations before `1 > 1` becomes `False`. Evaluates to the integer `5`. Local study-map skill 2.4 (Counting and Accumulator Loops with while), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. Evaluates to the integer `6`. Why the correct answer wins: Halving `32` produces `16, 8, 4, 2, 1` across `5` iterations before `1 > 1` becomes `False`.
- **B:** Incorrect for this question. Evaluates to the integer `4`. Why the correct answer wins: Halving `32` produces `16, 8, 4, 2, 1` across `5` iterations before `1 > 1` becomes `False`.
- **C:** Correct. Evaluates to the integer `5`. In this case: Halving `32` produces `16, 8, 4, 2, 1` across `5` iterations before `1 > 1` becomes `False`.
- **D:** Incorrect for this question. Evaluates to the integer `16`. Why the correct answer wins: Halving `32` produces `16, 8, 4, 2, 1` across `5` iterations before `1 > 1` becomes `False`.

### Question 19 — B

Answer: `//=`. `//=` performs augmented integer floor division on `span`. Augmented floor division replaces the variable with its floored quotient. Local study-map skill 2.4 (Counting and Accumulator Loops with while), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. A single `=` performs assignment rather than equality comparison (`==`), and is invalid as a plain condition in `if x = 5:`. Why the correct answer wins: `//=` performs augmented integer floor division on `span`.
- **B:** Correct. Augmented floor division replaces the variable with its floored quotient. In this case: `//=` performs augmented integer floor division on `span`.
- **C:** Incorrect for this question. Augmented subtraction subtracts the right-hand expression from the target variable. Why the correct answer wins: `//=` performs augmented integer floor division on `span`.
- **D:** Incorrect for this question. True division always returns a `float`, even when the numerator is an exact multiple of the denominator. Why the correct answer wins: `//=` performs augmented integer floor division on `span`.

### Question 20 — A

Answer: `24`. Starting at `10` with step `-2` and exclusive stop `4`, `range(10, 4, -2)` yields `10, 8, 6`, summing to `24`. Evaluates to the integer `24`. Local study-map skill 2.5 (Definite Iteration with for and range(start, stop, step)), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Correct. Evaluates to the integer `24`. In this case: Starting at `10` with step `-2` and exclusive stop `4`, `range(10, 4, -2)` yields `10, 8, 6`, summing to `24`.
- **B:** Incorrect for this question. Evaluates to the integer `30`. Why the correct answer wins: Starting at `10` with step `-2` and exclusive stop `4`, `range(10, 4, -2)` yields `10, 8, 6`, summing to `24`.
- **C:** Incorrect for this question. Evaluates to the integer `18`. Why the correct answer wins: Starting at `10` with step `-2` and exclusive stop `4`, `range(10, 4, -2)` yields `10, 8, 6`, summing to `24`.
- **D:** Incorrect for this question. Evaluates to the integer `28`. Why the correct answer wins: Starting at `10` with step `-2` and exclusive stop `4`, `range(10, 4, -2)` yields `10, 8, 6`, summing to `24`.

### Question 21 — D, E

Answers: `range(0, 3)`; `range(3, 0, -1)`. `range(0, 3)` yields `0, 1, 2` and `range(3, 0, -1)` yields `3, 2, 1`; `range(1, 3)` yields two, `range(0, 3, -1)` yields zero, and `range(1, 6)` yields five. `range(0, 3)` produces `0, 1, 2` (three iterations). `range(3, 0, -1)` counts down `3, 2, 1` (three iterations). Local study-map skill 2.5 (Definite Iteration with for and range(start, stop, step)), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. Starting at `0` with stop `3` and step `-1` moves away from `3` and yields zero iterations. Why the correct answer wins: `range(0, 3)` yields `0, 1, 2` and `range(3, 0, -1)` yields `3, 2, 1`; `range(1, 3)` yields two, `range(0, 3, -1)` yields zero, and `range(1, 6)` yields five.
- **B:** Incorrect for this question. `range(1, 6)` yields the five integers `1, 2, 3, 4, 5` because the stop bound is exclusive. Why the correct answer wins: `range(0, 3)` yields `0, 1, 2` and `range(3, 0, -1)` yields `3, 2, 1`; `range(1, 3)` yields two, `range(0, 3, -1)` yields zero, and `range(1, 6)` yields five.
- **C:** Incorrect for this question. `range(1, 3)` stops before `3` and yields only `1, 2` (two iterations, not three). Why the correct answer wins: `range(0, 3)` yields `0, 1, 2` and `range(3, 0, -1)` yields `3, 2, 1`; `range(1, 3)` yields two, `range(0, 3, -1)` yields zero, and `range(1, 6)` yields five.
- **D:** Correct. `range(3, 0, -1)` counts down `3, 2, 1` (three iterations). In this case: `range(0, 3)` yields `0, 1, 2` and `range(3, 0, -1)` yields `3, 2, 1`; `range(1, 3)` yields two, `range(0, 3, -1)` yields zero, and `range(1, 6)` yields five.
- **E:** Correct. `range(0, 3)` produces `0, 1, 2` (three iterations). In this case: `range(0, 3)` yields `0, 1, 2` and `range(3, 0, -1)` yields `3, 2, 1`; `range(1, 3)` yields two, `range(0, 3, -1)` yields zero, and `range(1, 6)` yields five.

### Question 22 — C

Answer: `19`. Iterating directly over `[4, 19, 11, 7]` updates `peak` from `0` to `4` and then `19`, ignoring smaller trailing values `11` and `7`. Evaluates to the integer `19`. Local study-map skill 2.6 (Iterating Directly Over Sequences and Enumerated Values), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. Evaluates to the integer `7`. Why the correct answer wins: Iterating directly over `[4, 19, 11, 7]` updates `peak` from `0` to `4` and then `19`, ignoring smaller trailing values `11` and `7`.
- **B:** Incorrect for this question. Evaluates to the integer `4`. Why the correct answer wins: Iterating directly over `[4, 19, 11, 7]` updates `peak` from `0` to `4` and then `19`, ignoring smaller trailing values `11` and `7`.
- **C:** Correct. Evaluates to the integer `19`. In this case: Iterating directly over `[4, 19, 11, 7]` updates `peak` from `0` to `4` and then `19`, ignoring smaller trailing values `11` and `7`.
- **D:** Incorrect for this question. Evaluates to the integer `40`. Why the correct answer wins: Iterating directly over `[4, 19, 11, 7]` updates `peak` from `0` to `4` and then `19`, ignoring smaller trailing values `11` and `7`.

### Question 23 — D

Answer: `24`. `continue` skips `-1` and `-5` while summing the non-negative readings `12 + 8 + 4 == 24`. Evaluates to the integer `24`. Local study-map skill 2.7 (Controlling Loops with break, continue, and pass), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. Evaluates to the integer `12`. Why the correct answer wins: `continue` skips `-1` and `-5` while summing the non-negative readings `12 + 8 + 4 == 24`.
- **B:** Incorrect for this question. Evaluates to the integer `18`. Why the correct answer wins: `continue` skips `-1` and `-5` while summing the non-negative readings `12 + 8 + 4 == 24`.
- **C:** Incorrect for this question. Evaluates to the integer `30`. Why the correct answer wins: `continue` skips `-1` and `-5` while summing the non-negative readings `12 + 8 + 4 == 24`.
- **D:** Correct. Evaluates to the integer `24`. In this case: `continue` skips `-1` and `-5` while summing the non-negative readings `12 + 8 + 4 == 24`.

### Question 24 — B

Answer: `break`. `break` exits the enclosing `for` loop immediately. `break` exits the innermost enclosing `for` or `while` loop immediately and skips its `else` branch. Local study-map skill 2.7 (Controlling Loops with break, continue, and pass), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. `continue` abandons the rest of the current iteration and jumps to the next cycle of the enclosing loop. Why the correct answer wins: `break` exits the enclosing `for` loop immediately.
- **B:** Correct. `break` exits the innermost enclosing `for` or `while` loop immediately and skips its `else` branch. In this case: `break` exits the enclosing `for` loop immediately.
- **C:** Incorrect for this question. `pass` is a reserved null-operation keyword required where syntax expects an indented suite. Why the correct answer wins: `break` exits the enclosing `for` loop immediately.
- **D:** Incorrect for this question. `return` exits the current function immediately and sends a value back to the caller. Why the correct answer wins: `break` exits the enclosing `for` loop immediately.

### Question 25 — B, D

Answers: When `return` exits the enclosing function from inside the loop body; When an unhandled exception aborts the loop body. Exiting the enclosing function via `return` or raising an unhandled exception bypasses the loop `else:` suite, whereas normal `False` termination runs `else:`. Returning out of the function exits both the loop and any attached `else` suite. An unhandled exception unwinds the stack rather than running the loop `else` clause. Local study-map skill 2.8 (Post-Loop Execution with while-else and for-else Clauses), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. In `try ... except ... else ... finally`, `else` executes when no exception occurred and `finally` executes unconditionally. Why the correct answer wins: Exiting the enclosing function via `return` or raising an unhandled exception bypasses the loop `else:` suite, whereas normal `False` termination runs `else:`.
- **B:** Correct. An unhandled exception unwinds the stack rather than running the loop `else` clause. In this case: Exiting the enclosing function via `return` or raising an unhandled exception bypasses the loop `else:` suite, whereas normal `False` termination runs `else:`.
- **C:** Incorrect for this question. A `while` loop whose condition turns `False` (even on the very first check) executes its `else` suite. Why the correct answer wins: Exiting the enclosing function via `return` or raising an unhandled exception bypasses the loop `else:` suite, whereas normal `False` termination runs `else:`.
- **D:** Correct. Returning out of the function exits both the loop and any attached `else` suite. In this case: Exiting the enclosing function via `return` or raising an unhandled exception bypasses the loop `else:` suite, whereas normal `False` termination runs `else:`.
- **E:** Incorrect for this question. Normal exhaustion of a `for` iterable runs the attached `else` suite. Why the correct answer wins: Exiting the enclosing function via `return` or raising an unhandled exception bypasses the loop `else:` suite, whereas normal `False` termination runs `else:`.

### Question 26 — B

Answer: `else`. A `for ... else` clause runs its suite only if the loop exhausts `window` without hitting `break`. `else` introduces the fallback suite on `if`, `for`, `while`, or `try` blocks. Local study-map skill 2.8 (Post-Loop Execution with while-else and for-else Clauses), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. `finally` introduces cleanup code that runs whether or not an exception was raised or returned. Why the correct answer wins: A `for ... else` clause runs its suite only if the loop exhausts `window` without hitting `break`.
- **B:** Correct. `else` introduces the fallback suite on `if`, `for`, `while`, or `try` blocks. In this case: A `for ... else` clause runs its suite only if the loop exhausts `window` without hitting `break`.
- **C:** Incorrect for this question. `except` introduces an exception-handling branch after a `try` suite (Python does not use `catch`). Why the correct answer wins: A `for ... else` clause runs its suite only if the loop exhausts `window` without hitting `break`.
- **D:** Incorrect for this question. `elif` is a reserved Python keyword that introduces an additional conditional branch. Why the correct answer wins: A `for ... else` clause runs its suite only if the loop exhausts `window` without hitting `break`.

### Question 27 — D

Answer: `2`. Readings `9` in zone 0 and `8` in zone 1 satisfy `>= 8`, giving `alarms == 2`. Evaluates to the integer `2`. Local study-map skill 2.9 (Nested Loops Over 2D Grids and Pairwise Combinations), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Incorrect for this question. Evaluates to the integer `4`. Why the correct answer wins: Readings `9` in zone 0 and `8` in zone 1 satisfy `>= 8`, giving `alarms == 2`.
- **B:** Incorrect for this question. Evaluates to the integer `3`. Why the correct answer wins: Readings `9` in zone 0 and `8` in zone 1 satisfy `>= 8`, giving `alarms == 2`.
- **C:** Incorrect for this question. Evaluates to the integer `1`. Why the correct answer wins: Readings `9` in zone 0 and `8` in zone 1 satisfy `>= 8`, giving `alarms == 2`.
- **D:** Correct. Evaluates to the integer `2`. In this case: Readings `9` in zone 0 and `8` in zone 1 satisfy `>= 8`, giving `alarms == 2`.

### Question 28 — A

Answer: `8`. Four outer passes times two inner passes execute `count += 1` exactly `4 * 2 == 8` times. Evaluates to the integer `8`. Local study-map skill 2.9 (Nested Loops Over 2D Grids and Pairwise Combinations), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 2 (Control Flow - Conditional Blocks and Loops, 29 percent): https://pythoninstitute.org/pcep-exam-syllabus#block2 — and Python 3 tutorial, More Control Flow Tools: https://docs.python.org/3/tutorial/controlflow.html.

- **A:** Correct. Evaluates to the integer `8`. In this case: Four outer passes times two inner passes execute `count += 1` exactly `4 * 2 == 8` times.
- **B:** Incorrect for this question. Evaluates to the integer `6`. Why the correct answer wins: Four outer passes times two inner passes execute `count += 1` exactly `4 * 2 == 8` times.
- **C:** Incorrect for this question. Evaluates to the integer `4`. Why the correct answer wins: Four outer passes times two inner passes execute `count += 1` exactly `4 * 2 == 8` times.
- **D:** Incorrect for this question. Evaluates to the integer `16`. Why the correct answer wins: Four outer passes times two inner passes execute `count += 1` exactly `4 * 2 == 8` times.

### Question 29 — B

Answer: `24`. Negative index `-1` is the last element (`27`), so `-2` selects the second-to-last element `24`. Evaluates to the integer `24`. Local study-map skill 3.1 (List Indexing, Negative Indices, and Slicing Rules), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Incorrect for this question. `IndexError` (a subclass of `LookupError`) is raised when a sequence subscript is out of range (note that slicing out of range never raises `IndexError`). Why the correct answer wins: Negative index `-1` is the last element (`27`), so `-2` selects the second-to-last element `24`.
- **B:** Correct. Evaluates to the integer `24`. In this case: Negative index `-1` is the last element (`27`), so `-2` selects the second-to-last element `24`.
- **C:** Incorrect for this question. Evaluates to the integer `21`. Why the correct answer wins: Negative index `-1` is the last element (`27`), so `-2` selects the second-to-last element `24`.
- **D:** Incorrect for this question. Evaluates to the integer `27`. Why the correct answer wins: Negative index `-1` is the last element (`27`), so `-2` selects the second-to-last element `24`.

### Question 30 — D

Answer: `[18, 24]`. Starting at index `1` (`18`) and stepping by `2` while `< 4` selects indices `1` and `3`, returning `[18, 24]`. Slicing `temps[1:4:2]` selects index `1` (`18`) and index `3` (`24`). Local study-map skill 3.1 (List Indexing, Negative Indices, and Slicing Rules), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Incorrect for this question. `IndexError` (a subclass of `LookupError`) is raised when a sequence subscript is out of range (note that slicing out of range never raises `IndexError`). Why the correct answer wins: Starting at index `1` (`18`) and stepping by `2` while `< 4` selects indices `1` and `3`, returning `[18, 24]`.
- **B:** Incorrect for this question. Produces the three-element list `[1, 2, 3]`. Why the correct answer wins: Starting at index `1` (`18`) and stepping by `2` while `< 4` selects indices `1` and `3`, returning `[18, 24]`.
- **C:** Incorrect for this question. Produces the three-element slice `[20, 30, 40]`. Why the correct answer wins: Starting at index `1` (`18`) and stepping by `2` while `< 4` selects indices `1` and `3`, returning `[18, 24]`.
- **D:** Correct. Slicing `temps[1:4:2]` selects index `1` (`18`) and index `3` (`24`). In this case: Starting at index `1` (`18`) and stepping by `2` while `< 4` selects indices `1` and `3`, returning `[18, 24]`.

### Question 31 — D

Answer: `insert()`. `list.insert(index, value)` inserts `20` at position `1` and shifts `30` to index `2`. `list.insert(i, x)` places `x` before index `i` in place and returns `None`. Local study-map skill 3.2 (List Mutation Methods (append, insert, remove, pop, sort, index)), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Incorrect for this question. `list.remove(x)` deletes the first occurrence of value `x` and raises `ValueError` if `x` is absent. Why the correct answer wins: `list.insert(index, value)` inserts `20` at position `1` and shifts `30` to index `2`.
- **B:** Incorrect for this question. `list.extend(iterable)` appends each element from `iterable` individually and returns `None`. Why the correct answer wins: `list.insert(index, value)` inserts `20` at position `1` and shifts `30` to index `2`.
- **C:** Incorrect for this question. `list.append(x)` adds `x` as a single element at the end of the list in place and returns `None`. Why the correct answer wins: `list.insert(index, value)` inserts `20` at position `1` and shifts `30` to index `2`.
- **D:** Correct. `list.insert(i, x)` places `x` before index `i` in place and returns `None`. In this case: `list.insert(index, value)` inserts `20` at position `1` and shifts `30` to index `2`.

### Question 32 — A, B

Answers: `items.append(x)` mutates `items` in place and evaluates to `None`; `items.pop()` removes the final element in place and returns that removed element. `append()` mutates in place and returns `None`, and `pop()` removes and returns the tail item; `sorted()` is non-mutating, `remove()` deletes only the first match, and `insert(0, x)` inserts at index `0`. In-place list mutators (`append`, `extend`, `insert`, `remove`, `sort`, `reverse`) return `None` except `pop()`. `pop()` both mutates the list and returns the removed value so callers can inspect it. Local study-map skill 3.2 (List Mutation Methods (append, insert, remove, pop, sort, index)), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Correct. `pop()` both mutates the list and returns the removed value so callers can inspect it. In this case: `append()` mutates in place and returns `None`, and `pop()` removes and returns the tail item; `sorted()` is non-mutating, `remove()` deletes only the first match, and `insert(0, x)` inserts at index `0`.
- **B:** Correct. In-place list mutators (`append`, `extend`, `insert`, `remove`, `sort`, `reverse`) return `None` except `pop()`. In this case: `append()` mutates in place and returns `None`, and `pop()` removes and returns the tail item; `sorted()` is non-mutating, `remove()` deletes only the first match, and `insert(0, x)` inserts at index `0`.
- **C:** Incorrect for this question. `sorted()` is a built-in function that returns a *new* sorted list without modifying `items`. Why the correct answer wins: `append()` mutates in place and returns `None`, and `pop()` removes and returns the tail item; `sorted()` is non-mutating, `remove()` deletes only the first match, and `insert(0, x)` inserts at index `0`.
- **D:** Incorrect for this question. `insert(0, x)` places `x` at the *front* (index `0`), shifting existing elements right. Why the correct answer wins: `append()` mutates in place and returns `None`, and `pop()` removes and returns the tail item; `sorted()` is non-mutating, `remove()` deletes only the first match, and `insert(0, x)` inserts at index `0`.
- **E:** Incorrect for this question. `list.remove(x)` deletes only the *first* matching occurrence of `x`. Why the correct answer wins: `append()` mutates in place and returns `None`, and `pop()` removes and returns the tail item; `sorted()` is non-mutating, `remove()` deletes only the first match, and `insert(0, x)` inserts at index `0`.

### Question 33 — B

Answer: `[10, 40, 50]`. `del items[1:3]` deletes indices `1` (`20`) and `2` (`30`) from `items` in place, leaving `[10, 40, 50]`. `del items[1:3]` removes indices `1` and `2` in place, leaving `[10, 40, 50]`. Local study-map skill 3.3 (Deleting Elements or Slices with del, len(), and sorted()), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Incorrect for this question. Evaluates to `None`, the singleton returned by functions and in-place mutator methods that return no explicit value. Why the correct answer wins: `del items[1:3]` deletes indices `1` (`20`) and `2` (`30`) from `items` in place, leaving `[10, 40, 50]`.
- **B:** Correct. `del items[1:3]` removes indices `1` and `2` in place, leaving `[10, 40, 50]`. In this case: `del items[1:3]` deletes indices `1` (`20`) and `2` (`30`) from `items` in place, leaving `[10, 40, 50]`.
- **C:** Incorrect for this question. Slicing `items[1:3]` starts at index `1` and stops before index `3`. Why the correct answer wins: `del items[1:3]` deletes indices `1` (`20`) and `2` (`30`) from `items` in place, leaving `[10, 40, 50]`.
- **D:** Incorrect for this question. `SyntaxError` is raised by the parser before execution starts when tokens violate Python grammar. Why the correct answer wins: `del items[1:3]` deletes indices `1` (`20`) and `2` (`30`) from `items` in place, leaving `[10, 40, 50]`.

### Question 34 — A

Answer: `[1, 99, 3]`. Plain assignment `b = a` copies the object reference rather than cloning the list, so mutating `b[1]` mutates `a` to `[1, 99, 3]`. Assigning `b = a` binds both names to the same list object, so mutating `b` mutates `a`. Local study-map skill 3.4 (List Aliasing vs Shallow Slicing/Copying and Nested Matrices), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Correct. Assigning `b = a` binds both names to the same list object, so mutating `b` mutates `a`. In this case: Plain assignment `b = a` copies the object reference rather than cloning the list, so mutating `b[1]` mutates `a` to `[1, 99, 3]`.
- **B:** Incorrect for this question. `TypeError` is raised when an operation or function is applied to an object of an inappropriate type, or argument counts mismatch. Why the correct answer wins: Plain assignment `b = a` copies the object reference rather than cloning the list, so mutating `b[1]` mutates `a` to `[1, 99, 3]`.
- **C:** Incorrect for this question. Slicing `a[:]` or calling `a.copy()` allocates a new outer list so reassigning an element in the copy leaves `a` untouched. Why the correct answer wins: Plain assignment `b = a` copies the object reference rather than cloning the list, so mutating `b[1]` mutates `a` to `[1, 99, 3]`.
- **D:** Incorrect for this question. Evaluates to `None`, the singleton returned by functions and in-place mutator methods that return no explicit value. Why the correct answer wins: Plain assignment `b = a` copies the object reference rather than cloning the list, so mutating `b[1]` mutates `a` to `[1, 99, 3]`.

### Question 35 — C

Answer: `[1, 9, 25]`. Odd integers below `6` are `1, 3, 5`, and squaring each inside the comprehension produces `[1, 9, 25]`. Squares only the odd elements selected by the comprehension filter. Local study-map skill 3.5 (List Comprehensions with Filtering and Expressions), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Incorrect for this question. `SyntaxError` is raised by the parser before execution starts when tokens violate Python grammar. Why the correct answer wins: Odd integers below `6` are `1, 3, 5`, and squaring each inside the comprehension produces `[1, 9, 25]`.
- **B:** Incorrect for this question. Squares only the even elements selected by the comprehension filter. Why the correct answer wins: Odd integers below `6` are `1, 3, 5`, and squaring each inside the comprehension produces `[1, 9, 25]`.
- **C:** Correct. Squares only the odd elements selected by the comprehension filter. In this case: Odd integers below `6` are `1, 3, 5`, and squaring each inside the comprehension produces `[1, 9, 25]`.
- **D:** Incorrect for this question. Produces the three-element list `[1, 2, 3]`. Why the correct answer wins: Odd integers below `6` are `1, 3, 5`, and squaring each inside the comprehension produces `[1, 9, 25]`.

### Question 36 — D

Answer: `not in`. `not in` returns `True` when `sensor_id` is not a member of `offline_ids`. `not in` evaluates to `True` when the left operand is absent from the right-hand container. Local study-map skill 3.6 (Membership Testing with in and not in Across Collections), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Incorrect for this question. `!=` evaluates to `True` when two operands do not compare equal. Why the correct answer wins: `not in` returns `True` when `sensor_id` is not a member of `offline_ids`.
- **B:** Incorrect for this question. `in` tests element or substring membership and also binds loop targets in `for` headers. Why the correct answer wins: `not in` returns `True` when `sensor_id` is not a member of `offline_ids`.
- **C:** Incorrect for this question. `is` compares object identity rather than value equality. Why the correct answer wins: `not in` returns `True` when `sensor_id` is not a member of `offline_ids`.
- **D:** Correct. `not in` evaluates to `True` when the left operand is absent from the right-hand container. In this case: `not in` returns `True` when `sensor_id` is not a member of `offline_ids`.

### Question 37 — B, E

Answers: Assigning `t[0] = 9` on a tuple raises `TypeError` because tuple slot bindings are immutable; `(7,)`. Rebinding `t[0] = 9` raises `TypeError` and `(7,)` with a trailing comma creates a one-element tuple, whereas `(7)` is an `int` and `.append()` / `del t[0]` fail. Tuples do not support item assignment or item deletion. A trailing comma is what constructs a one-element tuple; `(7)` without a comma is just the integer `7` in parentheses. Local study-map skill 3.7 (Tuple Construction, Single-Element Syntax, Unpacking, and Immutability), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Incorrect for this question. Parentheses without a comma group an arithmetic expression rather than building a tuple. Why the correct answer wins: Rebinding `t[0] = 9` raises `TypeError` and `(7,)` with a trailing comma creates a one-element tuple, whereas `(7)` is an `int` and `.append()` / `del t[0]` fail.
- **B:** Correct. Tuples do not support item assignment or item deletion. In this case: Rebinding `t[0] = 9` raises `TypeError` and `(7,)` with a trailing comma creates a one-element tuple, whereas `(7)` is an `int` and `.append()` / `del t[0]` fail.
- **C:** Incorrect for this question. `tuple` has no `.append()` method; calling it raises `AttributeError`. Why the correct answer wins: Rebinding `t[0] = 9` raises `TypeError` and `(7,)` with a trailing comma creates a one-element tuple, whereas `(7)` is an `int` and `.append()` / `del t[0]` fail.
- **D:** Incorrect for this question. `del t[0]` raises `TypeError` because tuples are immutable; only `del t` (unbinding the whole variable) is legal. Why the correct answer wins: Rebinding `t[0] = 9` raises `TypeError` and `(7,)` with a trailing comma creates a one-element tuple, whereas `(7)` is an `int` and `.append()` / `del t[0]` fail.
- **E:** Correct. A trailing comma is what constructs a one-element tuple; `(7)` without a comma is just the integer `7` in parentheses. In this case: Rebinding `t[0] = 9` raises `TypeError` and `(7,)` with a trailing comma creates a one-element tuple, whereas `(7)` is an `int` and `.append()` / `del t[0]` fail.

### Question 38 — D

Answer: `(0, 0, 0)`. Multiplying one-element tuple `(0,)` by `3` repeats its element into the three-element tuple `(0, 0, 0)`. Repeating a single-element tuple `(0,) * 3` produces `(0, 0, 0)`. Local study-map skill 3.8 (Mutable Lists Inside Tuples vs Tuples Inside Lists), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Incorrect for this question. Evaluates to the integer zero. Why the correct answer wins: Multiplying one-element tuple `(0,)` by `3` repeats its element into the three-element tuple `(0, 0, 0)`.
- **B:** Incorrect for this question. A trailing comma is what constructs a one-element tuple; `(7)` without a comma is just the integer `7` in parentheses. Why the correct answer wins: Multiplying one-element tuple `(0,)` by `3` repeats its element into the three-element tuple `(0, 0, 0)`.
- **C:** Incorrect for this question. `TypeError` is raised when an operation or function is applied to an object of an inappropriate type, or argument counts mismatch. Why the correct answer wins: Multiplying one-element tuple `(0,)` by `3` repeats its element into the three-element tuple `(0, 0, 0)`.
- **D:** Correct. Repeating a single-element tuple `(0,) * 3` produces `(0, 0, 0)`. In this case: Multiplying one-element tuple `(0,)` by `3` repeats its element into the three-element tuple `(0, 0, 0)`.

### Question 39 — A

Answer: `del`. `del sensors['old_probe']` deletes the key-value entry from `sensors` (raising `KeyError` if absent). `del` is a statement keyword (not a function) that unbinds a name, slice, index, or dictionary key. Local study-map skill 3.9 (Dictionary Creation, Key Lookup, Insertion, Update, and Deletion), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Correct. `del` is a statement keyword (not a function) that unbinds a name, slice, index, or dictionary key. In this case: `del sensors['old_probe']` deletes the key-value entry from `sensors` (raising `KeyError` if absent).
- **B:** Incorrect for this question. `dict.keys()` returns a dynamic view of the dictionary keys. Why the correct answer wins: `del sensors['old_probe']` deletes the key-value entry from `sensors` (raising `KeyError` if absent).
- **C:** Incorrect for this question. `list.remove(x)` deletes the first occurrence of value `x` and raises `ValueError` if `x` is absent. Why the correct answer wins: `del sensors['old_probe']` deletes the key-value entry from `sensors` (raising `KeyError` if absent).
- **D:** Incorrect for this question. `dict.get(key, default=None)` returns `default` instead of raising `KeyError` when `key` is missing. Why the correct answer wins: `del sensors['old_probe']` deletes the key-value entry from `sensors` (raising `KeyError` if absent).

### Question 40 — A, C

Answers: `'host' in cfg`; Iterating `for k, v in d.items():` unpacks each `(key, value)` pair cleanly. `'host' in cfg` checks key existence safely and `for k, v in cfg.items():` unpacks `(key, value)` pairs; bare iteration yields keys only and `.values()` inspects values only. The `in` operator on a dictionary checks membership among its *keys* in O(1) average time. `d.items()` yields 2-tuples pairing each key with its mapped value. Local study-map skill 3.10 (Dictionary Iteration with keys(), values(), items(), and get()), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Correct. The `in` operator on a dictionary checks membership among its *keys* in O(1) average time. In this case: `'host' in cfg` checks key existence safely and `for k, v in cfg.items():` unpacks `(key, value)` pairs; bare iteration yields keys only and `.values()` inspects values only.
- **B:** Incorrect for this question. Iterating bare `d` yields keys alone, so `for k, v in d:` fails unless the keys themselves happen to be 2-element iterables. Why the correct answer wins: `'host' in cfg` checks key existence safely and `for k, v in cfg.items():` unpacks `(key, value)` pairs; bare iteration yields keys only and `.values()` inspects values only.
- **C:** Correct. `d.items()` yields 2-tuples pairing each key with its mapped value. In this case: `'host' in cfg` checks key existence safely and `for k, v in cfg.items():` unpacks `(key, value)` pairs; bare iteration yields keys only and `.values()` inspects values only.
- **D:** Incorrect for this question. `cfg.values()` searches dictionary *values*, not dictionary keys. Why the correct answer wins: `'host' in cfg` checks key existence safely and `for k, v in cfg.items():` unpacks `(key, value)` pairs; bare iteration yields keys only and `.values()` inspects values only.
- **E:** Incorrect for this question. `d.values()` yields only the mapped values, not `(key, value)` pairs. Why the correct answer wins: `'host' in cfg` checks key existence safely and `for k, v in cfg.items():` unpacks `(key, value)` pairs; bare iteration yields keys only and `.values()` inspects values only.

### Question 41 — C

Answer: `3`. A literal newline inside triple quotes is stored as one `\n` character between `'A'` and `'B'`, giving length `3`. Evaluates to the integer `3`. Local study-map skill 3.11 (String Literals, Escape Sequences, Quotes, and Multiline Strings), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Incorrect for this question. Evaluates to the integer `2`. Why the correct answer wins: A literal newline inside triple quotes is stored as one `\n` character between `'A'` and `'B'`, giving length `3`.
- **B:** Incorrect for this question. `SyntaxError` is raised by the parser before execution starts when tokens violate Python grammar. Why the correct answer wins: A literal newline inside triple quotes is stored as one `\n` character between `'A'` and `'B'`, giving length `3`.
- **C:** Correct. Evaluates to the integer `3`. In this case: A literal newline inside triple quotes is stored as one `\n` character between `'A'` and `'B'`, giving length `3`.
- **D:** Incorrect for this question. Evaluates to the integer `4`. Why the correct answer wins: A literal newline inside triple quotes is stored as one `\n` character between `'A'` and `'B'`, giving length `3`.

### Question 42 — B, D

Answers: Out-of-range string slice bounds such as `s[2:99]` clamp silently instead of raising `IndexError`; Every string transformation method returns a brand-new `str` object and leaves the original string unchanged. Out-of-range slices such as `s[2:99]` clamp without raising `IndexError`, and every string method returns a new `str` without mutating the original. Slicing clamps start and stop indices to valid string bounds, whereas out-of-range single-index `s[99]` raises `IndexError`. Because `str` is immutable in Python, methods like `.upper()`, `.replace()`, and `.strip()` never mutate in place. Local study-map skill 3.12 (String Indexing, Slicing, Immutability, and Common String Methods), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Incorrect for this question. `str` is immutable, so `del s[0]` raises `TypeError`. Why the correct answer wins: Out-of-range slices such as `s[2:99]` clamp without raising `IndexError`, and every string method returns a new `str` without mutating the original.
- **B:** Correct. Because `str` is immutable in Python, methods like `.upper()`, `.replace()`, and `.strip()` never mutate in place. In this case: Out-of-range slices such as `s[2:99]` clamp without raising `IndexError`, and every string method returns a new `str` without mutating the original.
- **C:** Incorrect for this question. `sorted()` is a built-in function that returns a *new* sorted list without modifying `items`. Why the correct answer wins: Out-of-range slices such as `s[2:99]` clamp without raising `IndexError`, and every string method returns a new `str` without mutating the original.
- **D:** Correct. Slicing clamps start and stop indices to valid string bounds, whereas out-of-range single-index `s[99]` raises `IndexError`. In this case: Out-of-range slices such as `s[2:99]` clamp without raising `IndexError`, and every string method returns a new `str` without mutating the original.
- **E:** Incorrect for this question. `str` does not support item assignment; `s[0] = "X"` raises `TypeError`. Why the correct answer wins: Out-of-range slices such as `s[2:99]` clamp without raising `IndexError`, and every string method returns a new `str` without mutating the original.

### Question 43 — A

Answer: `endswith()`. `str.endswith('CRC_OK')` checks the trailing characters of `packet` cleanly without manual index arithmetic. `str.endswith(suffix)` checks whether a string ends with `suffix`. Local study-map skill 3.12 (String Indexing, Slicing, Immutability, and Common String Methods), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 3 (Data Collections - Tuples, Dictionaries, Lists, and Strings, 25 percent): https://pythoninstitute.org/pcep-exam-syllabus#block3 — and Python 3 tutorial, Data Structures: https://docs.python.org/3/tutorial/datastructures.html.

- **A:** Correct. `str.endswith(suffix)` checks whether a string ends with `suffix`. In this case: `str.endswith('CRC_OK')` checks the trailing characters of `packet` cleanly without manual index arithmetic.
- **B:** Incorrect for this question. `str.startswith(prefix)` checks whether a string begins with `prefix` without manual slicing. Why the correct answer wins: `str.endswith('CRC_OK')` checks the trailing characters of `packet` cleanly without manual index arithmetic.
- **C:** Incorrect for this question. `str.isdigit()` returns `True` when the string is non-empty and every character is a digit. Why the correct answer wins: `str.endswith('CRC_OK')` checks the trailing characters of `packet` cleanly without manual index arithmetic.
- **D:** Incorrect for this question. `list.pop(i=-1)` removes and returns the element at index `i` (defaulting to the last item). Why the correct answer wins: `str.endswith('CRC_OK')` checks the trailing characters of `packet` cleanly without manual index arithmetic.

### Question 44 — C, E

Answers: A function executing a bare `return` statement evaluates to `None` at the call site; Writing `return a, b` returns a single `tuple` `(a, b)` that the caller can unpack. A bare `return` returns `None`, and `return a, b` packs and returns a single `tuple` `(a, b)`. Bare `return` exits immediately and returns the singleton `None`. Comma-separated expressions after `return` pack a `tuple` object. Local study-map skill 4.1 (Defining Functions, Invoking Them, return Paths, and Implicit None), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Incorrect for this question. `tuple` has no `.append()` method; calling it raises `AttributeError`. Why the correct answer wins: A bare `return` returns `None`, and `return a, b` packs and returns a single `tuple` `(a, b)`.
- **B:** Incorrect for this question. Parameters are local variables of the function call frame and disappear when the frame exits. Why the correct answer wins: A bare `return` returns `None`, and `return a, b` packs and returns a single `tuple` `(a, b)`.
- **C:** Correct. Comma-separated expressions after `return` pack a `tuple` object. In this case: A bare `return` returns `None`, and `return a, b` packs and returns a single `tuple` `(a, b)`.
- **D:** Incorrect for this question. The first `return` executed exits the function immediately; subsequent statements in that block are unreachable. Why the correct answer wins: A bare `return` returns `None`, and `return a, b` packs and returns a single `tuple` `(a, b)`.
- **E:** Correct. Bare `return` exits immediately and returns the singleton `None`. In this case: A bare `return` returns `None`, and `return a, b` packs and returns a single `tuple` `(a, b)`.

### Question 45 — A

Answer: `return`. `return` exits `clamp_high` with `ceiling` as its result. `return` exits the current function immediately and sends a value back to the caller. Local study-map skill 4.1 (Defining Functions, Invoking Them, return Paths, and Implicit None), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Correct. `return` exits the current function immediately and sends a value back to the caller. In this case: `return` exits `clamp_high` with `ceiling` as its result.
- **B:** Incorrect for this question. `pass` is a reserved null-operation keyword required where syntax expects an indented suite. Why the correct answer wins: `return` exits `clamp_high` with `ceiling` as its result.
- **C:** Incorrect for this question. `yield` is a reserved Python keyword that turns a function into a generator. Why the correct answer wins: `return` exits `clamp_high` with `ceiling` as its result.
- **D:** Incorrect for this question. `break` exits the innermost enclosing `for` or `while` loop immediately and skips its `else` branch. Why the correct answer wins: `return` exits `clamp_high` with `ceiling` as its result.

### Question 46 — D

Answer: `yield`. `yield` pauses execution on each pulse and turns `sample_pulses` into a generator function. `yield` is a reserved Python keyword that turns a function into a generator. Local study-map skill 4.2 (Generator Functions Using yield and Lazy Iteration), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Incorrect for this question. `break` exits the innermost enclosing `for` or `while` loop immediately and skips its `else` branch. Why the correct answer wins: `yield` pauses execution on each pulse and turns `sample_pulses` into a generator function.
- **B:** Incorrect for this question. `global` is a reserved Python keyword that binds a name inside a function to module scope. Why the correct answer wins: `yield` pauses execution on each pulse and turns `sample_pulses` into a generator function.
- **C:** Incorrect for this question. `return` exits the current function immediately and sends a value back to the caller. Why the correct answer wins: `yield` pauses execution on each pulse and turns `sample_pulses` into a generator function.
- **D:** Correct. `yield` is a reserved Python keyword that turns a function into a generator. In this case: `yield` pauses execution on each pulse and turns `sample_pulses` into a generator function.

### Question 47 — A

Answer: `8`. Computing Fibonacci terms `0, 1, 1, 2, 3, 5, 8` from `0` through `6` produces `8`. Evaluates to the integer `8`. Local study-map skill 4.3 (Recursive Functions, Base Cases, and Call-Stack Termination), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Correct. Evaluates to the integer `8`. In this case: Computing Fibonacci terms `0, 1, 1, 2, 3, 5, 8` from `0` through `6` produces `8`.
- **B:** Incorrect for this question. Evaluates to the integer `13`. Why the correct answer wins: Computing Fibonacci terms `0, 1, 1, 2, 3, 5, 8` from `0` through `6` produces `8`.
- **C:** Incorrect for this question. Evaluates to the integer `6`. Why the correct answer wins: Computing Fibonacci terms `0, 1, 1, 2, 3, 5, 8` from `0` through `6` produces `8`.
- **D:** Incorrect for this question. Evaluates to the integer `5`. Why the correct answer wins: Computing Fibonacci terms `0, 1, 1, 2, 3, 5, 8` from `0` through `6` produces `8`.

### Question 48 — A

Answer: `return`. Without `return` in front of the recursive expression, the caller frame receives `None` and `n + None` raises `TypeError`. `return` exits the current function immediately and sends a value back to the caller. Local study-map skill 4.3 (Recursive Functions, Base Cases, and Call-Stack Termination), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Correct. `return` exits the current function immediately and sends a value back to the caller. In this case: Without `return` in front of the recursive expression, the caller frame receives `None` and `n + None` raises `TypeError`.
- **B:** Incorrect for this question. `yield` is a reserved Python keyword that turns a function into a generator. Why the correct answer wins: Without `return` in front of the recursive expression, the caller frame receives `None` and `n + None` raises `TypeError`.
- **C:** Incorrect for this question. `global` is a reserved Python keyword that binds a name inside a function to module scope. Why the correct answer wins: Without `return` in front of the recursive expression, the caller frame receives `None` and `n + None` raises `TypeError`.
- **D:** Incorrect for this question. `continue` abandons the rest of the current iteration and jumps to the next cycle of the enclosing loop. Why the correct answer wins: Without `return` in front of the recursive expression, the caller frame receives `None` and `n + None` raises `TypeError`.

### Question 49 — A

Answer: `14`. Positional `3` binds `m`, and keyword arguments bind `x=4` and `b=2`, computing `3 * 4 + 2 == 14`. Evaluates to the integer `14`. Local study-map skill 4.4 (Positional, Keyword, and Mixed Argument Passing Rules), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Correct. Evaluates to the integer `14`. In this case: Positional `3` binds `m`, and keyword arguments bind `x=4` and `b=2`, computing `3 * 4 + 2 == 14`.
- **B:** Incorrect for this question. `TypeError` is raised when an operation or function is applied to an object of an inappropriate type, or argument counts mismatch. Why the correct answer wins: Positional `3` binds `m`, and keyword arguments bind `x=4` and `b=2`, computing `3 * 4 + 2 == 14`.
- **C:** Incorrect for this question. Evaluates to the integer `10`. Why the correct answer wins: Positional `3` binds `m`, and keyword arguments bind `x=4` and `b=2`, computing `3 * 4 + 2 == 14`.
- **D:** Incorrect for this question. `SyntaxError` is raised by the parser before execution starts when tokens violate Python grammar. Why the correct answer wins: Positional `3` binds `m`, and keyword arguments bind `x=4` and `b=2`, computing `3 * 4 + 2 == 14`.

### Question 50 — A, B

Answers: `calc(10, rate=2)`; `calc(rate=2, base=10)`. `calc(10, rate=2)` and `calc(rate=2, base=10)` pass each parameter once with positional arguments preceding keyword arguments. Positional arguments precede keyword arguments and bind each parameter once. Keyword arguments may appear in any order as long as parameter names match and none are duplicated. Local study-map skill 4.4 (Positional, Keyword, and Mixed Argument Passing Rules), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Correct. Positional arguments precede keyword arguments and bind each parameter once. In this case: `calc(10, rate=2)` and `calc(rate=2, base=10)` pass each parameter once with positional arguments preceding keyword arguments.
- **B:** Correct. Keyword arguments may appear in any order as long as parameter names match and none are duplicated. In this case: `calc(10, rate=2)` and `calc(rate=2, base=10)` pass each parameter once with positional arguments preceding keyword arguments.
- **C:** Incorrect for this question. Passing `base` both positionally and by keyword raises `TypeError: got multiple values for argument`. Why the correct answer wins: `calc(10, rate=2)` and `calc(rate=2, base=10)` pass each parameter once with positional arguments preceding keyword arguments.
- **D:** Incorrect for this question. A positional argument after a keyword argument is a `SyntaxError`. Why the correct answer wins: `calc(10, rate=2)` and `calc(rate=2, base=10)` pass each parameter once with positional arguments preceding keyword arguments.
- **E:** Incorrect for this question. Passing an unexpected keyword argument raises `TypeError` when the function has no `**kwargs`. Why the correct answer wins: `calc(10, rate=2)` and `calc(rate=2, base=10)` pass each parameter once with positional arguments preceding keyword arguments.

### Question 51 — B

Answer: `17`. Omitting `bias` supplies its default value `10`, so `7 + 10` returns `17`. Evaluates to the integer `17`. Local study-map skill 4.5 (Default Parameter Values and Shared-Default Pitfalls), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Incorrect for this question. `TypeError` is raised when an operation or function is applied to an object of an inappropriate type, or argument counts mismatch. Why the correct answer wins: Omitting `bias` supplies its default value `10`, so `7 + 10` returns `17`.
- **B:** Correct. Evaluates to the integer `17`. In this case: Omitting `bias` supplies its default value `10`, so `7 + 10` returns `17`.
- **C:** Incorrect for this question. Evaluates to the integer `10`. Why the correct answer wins: Omitting `bias` supplies its default value `10`, so `7 + 10` returns `17`.
- **D:** Incorrect for this question. Evaluates to the integer `7`. Why the correct answer wins: Omitting `bias` supplies its default value `10`, so `7 + 10` returns `17`.

### Question 52 — D

Answer: `=`. Single `=` inside a `def` parameter list attaches a default value to that parameter. A single `=` performs assignment rather than equality comparison (`==`), and is invalid as a plain condition in `if x = 5:`. Local study-map skill 4.5 (Default Parameter Values and Shared-Default Pitfalls), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Incorrect for this question. `==` tests value equality rather than assignment (`=`) or object identity (`is`). Why the correct answer wins: Single `=` inside a `def` parameter list attaches a default value to that parameter.
- **B:** Incorrect for this question. `in` tests element or substring membership and also binds loop targets in `for` headers. Why the correct answer wins: Single `=` inside a `def` parameter list attaches a default value to that parameter.
- **C:** Incorrect for this question. Augmented addition adds the right-hand value (moving a list in-place or rebinding immutable numbers/strings). Why the correct answer wins: Single `=` inside a `def` parameter list attaches a default value to that parameter.
- **D:** Correct. A single `=` performs assignment rather than equality comparison (`==`), and is invalid as a plain condition in `if x = 5:`. In this case: Single `=` inside a `def` parameter list attaches a default value to that parameter.

### Question 53 — C

Answer: `4`. Assigning `gain = 9` inside `preview()` without `global gain` binds only a local variable, leaving module-level `gain` at `4`. Evaluates to the integer `4`. Local study-map skill 4.6 (Name Scopes, Shadowing, and Modifying Globals with global), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Incorrect for this question. Evaluates to the integer `9`. Why the correct answer wins: Assigning `gain = 9` inside `preview()` without `global gain` binds only a local variable, leaving module-level `gain` at `4`.
- **B:** Incorrect for this question. Assigning to a name anywhere in a function makes it local across the whole function, so reading it earlier raises `UnboundLocalError`. Why the correct answer wins: Assigning `gain = 9` inside `preview()` without `global gain` binds only a local variable, leaving module-level `gain` at `4`.
- **C:** Correct. Evaluates to the integer `4`. In this case: Assigning `gain = 9` inside `preview()` without `global gain` binds only a local variable, leaving module-level `gain` at `4`.
- **D:** Incorrect for this question. `NameError` is raised when code references an identifier that has not been bound in local, enclosing, global, or built-in scope. Why the correct answer wins: Assigning `gain = 9` inside `preview()` without `global gain` binds only a local variable, leaving module-level `gain` at `4`.

### Question 54 — D

Answer: `global`. `global alarm_trips` binds assignments inside `trip()` to the module-level variable instead of raising `UnboundLocalError`. `global` is a reserved Python keyword that binds a name inside a function to module scope. Local study-map skill 4.6 (Name Scopes, Shadowing, and Modifying Globals with global), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Incorrect for this question. `nonlocal` is a reserved Python keyword and cannot name an ordinary variable. Why the correct answer wins: `global alarm_trips` binds assignments inside `trip()` to the module-level variable instead of raising `UnboundLocalError`.
- **B:** Incorrect for this question. `from` is a reserved keyword used in `from module import name` and `raise ... from ...`. Why the correct answer wins: `global alarm_trips` binds assignments inside `trip()` to the module-level variable instead of raising `UnboundLocalError`.
- **C:** Incorrect for this question. `def` is a reserved Python keyword and raises `SyntaxError` if used as a variable name. Why the correct answer wins: `global alarm_trips` binds assignments inside `trip()` to the module-level variable instead of raising `UnboundLocalError`.
- **D:** Correct. `global` is a reserved Python keyword that binds a name inside a function to module scope. In this case: `global alarm_trips` binds assignments inside `trip()` to the module-level variable instead of raising `UnboundLocalError`.

### Question 55 — A, E

Answers: `ZeroDivisionError` is a direct subclass of `ArithmeticError`; `IndexError` is a direct subclass of `LookupError`. `ZeroDivisionError` inherits directly from `ArithmeticError`, and `IndexError` inherits directly from `LookupError`. `ArithmeticError` is the parent class of `ZeroDivisionError`, `OverflowError`, and `FloatingPointError`. `LookupError` groups `IndexError` and `KeyError` under `Exception`. Local study-map skill 4.7 (Built-In Exception Hierarchy (BaseException, LookupError, ArithmeticError)), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Correct. `ArithmeticError` is the parent class of `ZeroDivisionError`, `OverflowError`, and `FloatingPointError`. In this case: `ZeroDivisionError` inherits directly from `ArithmeticError`, and `IndexError` inherits directly from `LookupError`.
- **B:** Incorrect for this question. `tuple` has no `.append()` method; calling it raises `AttributeError`. Why the correct answer wins: `ZeroDivisionError` inherits directly from `ArithmeticError`, and `IndexError` inherits directly from `LookupError`.
- **C:** Incorrect for this question. A compiled standalone executable runs directly on the target OS without shipping the compiler. Why the correct answer wins: `ZeroDivisionError` inherits directly from `ArithmeticError`, and `IndexError` inherits directly from `LookupError`.
- **D:** Incorrect for this question. Putting `except Exception:` first catches `ValueError` immediately and makes the later `except ValueError:` dead code. Why the correct answer wins: `ZeroDivisionError` inherits directly from `ArithmeticError`, and `IndexError` inherits directly from `LookupError`.
- **E:** Correct. `LookupError` groups `IndexError` and `KeyError` under `Exception`. In this case: `ZeroDivisionError` inherits directly from `ArithmeticError`, and `IndexError` inherits directly from `LookupError`.

### Question 56 — B

Answer: `LookupError` is the abstract parent class of both `IndexError` and `KeyError`. `LookupError` is the parent class of both `IndexError` (bad list/tuple subscript) and `KeyError` (missing dict key). Catching `LookupError` intercepts both out-of-range sequence subscripts (`IndexError`) and missing dictionary keys (`KeyError`). Local study-map skill 4.7 (Built-In Exception Hierarchy (BaseException, LookupError, ArithmeticError)), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Incorrect for this question. `ZeroDivisionError` inherits from `ArithmeticError`, which in turn inherits from `Exception` and `BaseException`. Why the correct answer wins: `LookupError` is the parent class of both `IndexError` (bad list/tuple subscript) and `KeyError` (missing dict key).
- **B:** Correct. Catching `LookupError` intercepts both out-of-range sequence subscripts (`IndexError`) and missing dictionary keys (`KeyError`). In this case: `LookupError` is the parent class of both `IndexError` (bad list/tuple subscript) and `KeyError` (missing dict key).
- **C:** Incorrect for this question. `except Exception:` catches normal runtime errors while allowing `SystemExit` and `KeyboardInterrupt` to propagate cleanly. Why the correct answer wins: `LookupError` is the parent class of both `IndexError` (bad list/tuple subscript) and `KeyError` (missing dict key).
- **D:** Incorrect for this question. `TypeError` sits under `Exception` rather than under `LookupError` or `SyntaxError`. Why the correct answer wins: `LookupError` is the parent class of both `IndexError` (bad list/tuple subscript) and `KeyError` (missing dict key).

### Question 57 — A

Answer: Raises `AttributeError`. Because `tuple` objects have no `.append` attribute, Python raises `AttributeError` when looking up the method. `AttributeError` is raised when accessing or calling a method that does not exist on that type (such as `tuple.append`). Local study-map skill 4.8 (Raising and Diagnosing Concrete Built-In Exceptions (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError)), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Correct. `AttributeError` is raised when accessing or calling a method that does not exist on that type (such as `tuple.append`). In this case: Because `tuple` objects have no `.append` attribute, Python raises `AttributeError` when looking up the method.
- **B:** Incorrect for this question. `ValueError` is raised when an argument has the right type (such as `str`) but an invalid content (such as `int("abc")` or `[].index(9)`). Why the correct answer wins: Because `tuple` objects have no `.append` attribute, Python raises `AttributeError` when looking up the method.
- **C:** Incorrect for this question. `TypeError` is raised when an operation or function is applied to an object of an inappropriate type, or argument counts mismatch. Why the correct answer wins: Because `tuple` objects have no `.append` attribute, Python raises `AttributeError` when looking up the method.
- **D:** Incorrect for this question. `KeyError` (a subclass of `LookupError`) is raised when `d[k]` looks up a missing dictionary key. Why the correct answer wins: Because `tuple` objects have no `.append` attribute, Python raises `AttributeError` when looking up the method.

### Question 58 — C

Answer: Raises `NameError`. Referencing an identifier that has never been bound in local, enclosing, global, or built-in scope raises `NameError`. Local study-map skill 4.8 (Raising and Diagnosing Concrete Built-In Exceptions (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError)), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Incorrect for this question. Assigning to a name anywhere in a function makes it local across the whole function, so reading it earlier raises `UnboundLocalError`. Why the correct answer wins: Referencing an identifier that has never been bound in local, enclosing, global, or built-in scope raises `NameError`.
- **B:** Incorrect for this question. `ValueError` is raised when an argument has the right type (such as `str`) but an invalid content (such as `int("abc")` or `[].index(9)`). Why the correct answer wins: Referencing an identifier that has never been bound in local, enclosing, global, or built-in scope raises `NameError`.
- **C:** Correct. In this case: Referencing an identifier that has never been bound in local, enclosing, global, or built-in scope raises `NameError`.
- **D:** Incorrect for this question. Evaluates to `None`, the singleton returned by functions and in-place mutator methods that return no explicit value. Why the correct answer wins: Referencing an identifier that has never been bound in local, enclosing, global, or built-in scope raises `NameError`.

### Question 59 — C, E

Answers: Place `except ZeroDivisionError:` above `except ArithmeticError:` so division by zero reaches the specific handler; Only the first matching `except` branch runs, so a leading broad superclass handler swallows subclass exceptions before later branches are checked. Placing `except ZeroDivisionError:` before `except ArithmeticError:` keeps the specific branch reachable, because only the first matching `except` branch runs. Because `ZeroDivisionError` is a subclass of `ArithmeticError`, putting `ZeroDivisionError` first lets both handlers stay reachable. Python executes at most one `except` suite per `try` statement, matched in source order. Local study-map skill 4.9 (Handling and Propagating Exceptions with Ordered try-except Branches), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Incorrect for this question. A bare `except:` must always be the *last* `except` clause in Python 3; placing it earlier is a `SyntaxError`. Why the correct answer wins: Placing `except ZeroDivisionError:` before `except ArithmeticError:` keeps the specific branch reachable, because only the first matching `except` branch runs.
- **B:** Incorrect for this question. Putting `except Exception:` first catches `ValueError` immediately and makes the later `except ValueError:` dead code. Why the correct answer wins: Placing `except ZeroDivisionError:` before `except ArithmeticError:` keeps the specific branch reachable, because only the first matching `except` branch runs.
- **C:** Correct. Python executes at most one `except` suite per `try` statement, matched in source order. In this case: Placing `except ZeroDivisionError:` before `except ArithmeticError:` keeps the specific branch reachable, because only the first matching `except` branch runs.
- **D:** Incorrect for this question. At most *one* `except` branch executes for a single raised exception. Why the correct answer wins: Placing `except ZeroDivisionError:` before `except ArithmeticError:` keeps the specific branch reachable, because only the first matching `except` branch runs.
- **E:** Correct. Because `ZeroDivisionError` is a subclass of `ArithmeticError`, putting `ZeroDivisionError` first lets both handlers stay reachable. In this case: Placing `except ZeroDivisionError:` before `except ArithmeticError:` keeps the specific branch reachable, because only the first matching `except` branch runs.

### Question 60 — C

Answer: `A`. Because `ZeroDivisionError` is a subclass of `ArithmeticError` and `ArithmeticError` is listed first, the first handler matches and prints `A`, leaving `except ZeroDivisionError:` unreachable. Prints `A` because the first matching `if`/`elif` branch runs and skips all remaining `elif`/`else` clauses. Local study-map skill 4.9 (Handling and Propagating Exceptions with Ordered try-except Branches), mapped to the official syllabus: PCEP-30-02 exam syllabus (OpenEDG Python Institute). Primary reference: PCEP-30-02 exam syllabus, Block 4 (Functions and Exceptions, 28 percent): https://pythoninstitute.org/pcep-exam-syllabus#block4 — and Python 3 tutorial, Errors and Exceptions: https://docs.python.org/3/tutorial/errors.html.

- **A:** Incorrect for this question. Prints `B` when the `if` condition is `False` and the first `elif` condition is `True`. Why the correct answer wins: Because `ZeroDivisionError` is a subclass of `ArithmeticError` and `ArithmeticError` is listed first, the first handler matches and prints `A`, leaving `except ZeroDivisionError:` unreachable.
- **B:** Incorrect for this question. `ZeroDivisionError` (a subclass of `ArithmeticError`) is raised by `/`, `//`, or `%` when the right operand is `0` or `0.0`. Why the correct answer wins: Because `ZeroDivisionError` is a subclass of `ArithmeticError` and `ArithmeticError` is listed first, the first handler matches and prints `A`, leaving `except ZeroDivisionError:` unreachable.
- **C:** Correct. Prints `A` because the first matching `if`/`elif` branch runs and skips all remaining `elif`/`else` clauses. In this case: Because `ZeroDivisionError` is a subclass of `ArithmeticError` and `ArithmeticError` is listed first, the first handler matches and prints `A`, leaving `except ZeroDivisionError:` unreachable.
- **D:** Incorrect for this question. Prints `A B` when two independent `if` statements (rather than `if`/`elif`) both evaluate to `True`. Why the correct answer wins: Because `ZeroDivisionError` is a subclass of `ArithmeticError` and `ArithmeticError` is listed first, the first handler matches and prints `A`, leaving `except ZeroDivisionError:` unreachable.
