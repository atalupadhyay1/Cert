# Full-Length Mock Exam 4: Dimensional Modelling, History, and Multi-Workspace Governance

100 original items · passing target 700/1000 · blueprint-weighted.

| Official domain | Questions |
|---|---:|
| Implement and manage an analytics solution | 33 |
| Ingest and transform data | 33 |
| Monitor and optimize an analytics solution | 34 |

Item mix: 84 multiple-choice (including 8 sequencing items), 16 multi-select; 4 case studies of 3 questions. Microsoft publishes a 100-minute duration but no item count for this exam; this practice set is 100, an expanded bank for broader coverage. Drag-and-drop, live labs, interactive portal components, and adaptive problem-solution sets are not reproduced.

Upload `practice-set-4.csv`; use `practice-set-4.md` for offline review.

Practice target 700/1000 mirrors the published passing score, but a practice percentage is not a scaled exam score.
