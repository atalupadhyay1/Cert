# Microsoft Exam DP-300: Administering Microsoft Azure SQL Solutions — Full-Length Mock Exam 5

Exam DP-300 (SaaS Multi-Tenant Platforms, Sharded Elastic Pools, and Query Store Tuning) · 100 questions · 100-minute recommended timing · Microsoft scaled passing score 700 / 1000

> **Blueprint & Credential Notice:** Aligned to the official **October 27, 2026** DP-300 study guide (`Microsoft Certified: Azure Database Administrator Associate`). Associate-level certification with **no prerequisite exam required**, free online annual renewal on Microsoft Learn, split-screen `learn.microsoft.com` access during non-lab exam sections, and hands-on coverage across **T-SQL**, **Azure PowerShell**, **Azure CLI**, **Bicep**, and **KQL**.

Blueprint-weighted mock exam: 84 `multiple-choice` items (including 8 four-step `→` sequence items, `____` T-SQL/PowerShell/CLI/Bicep/KQL completion items, and `Proposed solution:` evaluations), 16 `multi-select` items (`Select two.` / `Select three.`), and 4 original 3-question enterprise Azure SQL case studies (12 case items).

Platform fidelity note: Udemy CSV imports support `multiple-choice` and `multi-select` only. Interactive Microsoft exam widgets (drag-and-drop sequence tiles, inline hot-area T-SQL/CLI dropdowns, split-pane tabbed case exhibits, live labs, and locked non-returnable Yes/No problem-solution series) are adapted into text-complete stems and explicit candidate options. Raw practice percentages do not convert to Microsoft scaled scores (`100–1000`, pass `700`).

100% original educational content authored from official Microsoft Learn Azure SQL and SQL Server documentation — never recalled live items or copied Microsoft sample case studies.

## Questions

### 1. A SaaS billing legacy monolith uses `msdb` SQL Server Agent schedules, `OPENQUERY` Linked Servers to another SQL instance, and global temporary tables shared across five databases. Which PaaS offering requires minimal refactoring?

Domain: Plan and implement data platform resources

- A. Azure SQL Database Hyperscale tier with compute-isolated Named Replicas
- B. Azure SQL Database vCore Serverless compute tier with Auto-pause delay enabled
- C. SQL database in Microsoft Fabric (`Database` workload with automatic OneLake Delta mirroring)
- D. Azure SQL Managed Instance (Next-gen General Purpose) with decoupled IOPS and storage sliders

### 2. Your SaaS Terraform/Bicep module provisions networking for a new regional Azure SQL Managed Instance inside `vnet-saas-apj`. Which two subnet rules are mandatory? Select two.

Domain: Plan and implement data platform resources

- A. Place SQL Server `.mdf`, `.ldf`, and `tempdb` files together on the Azure VM OS disk (`C:`) with `ReadWrite` host caching
- B. Create a dedicated VNet subnet (`/28` or larger) with no other cloud resources and delegate it to `Microsoft.Sql/managedInstances`
- C. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- D. Associate a User-Defined Route (`UDR`) table (`0.0.0.0/0` -> `Internet` for management plane) and required NSG rules with the SQL MI subnet
- E. Switch eligible hybrid SQL Server instances to hourly Azure Arc pay-as-you-go billing instead of upfront core licenses

### 3. SaaS developers spin up local integration databases on Linux build agents and tune max dump/memory settings via `/opt/mssql/bin/____ set memory.memorylimitmb 16384`. Which Linux configuration utility manages SQL Server 2022 settings?

Domain: Plan and implement data platform resources

- A. SQL Server on Linux configured via `mssql-conf` or Linux container images for consistent CI/CD dev-test parity
- B. SQL Server enabled by Azure Arc (`Microsoft.AzureArcData/sqlServerInstances`)
- C. Azure SQL Database Hyperscale tier with compute-isolated Named Replicas
- D. Azure SQL Managed Instance Business Critical tier with local SSD storage and built-in read-scale replica

### 4. An enterprise SaaS vendor manages 70 single-tenant SQL Server 2022 appliances hosted inside customer-owned AWS and VMware datacenters via Azure Arc. Which three capabilities does Azure Arc provide? Select three.

Domain: Plan and implement data platform resources

- A. Enable automated SQL Best Practices Assessments and Microsoft Defender for SQL via the Azure Arc SQL Server extension
- B. Configure SQL Server password logins (`CREATE LOGIN ... WITH PASSWORD`) and T-SQL `BACKUP DATABASE ... TO DISK` inside SQL database in Microsoft Fabric
- C. Query fleet-wide SQL Server version, edition, and backup status across hybrid servers via Azure Resource Graph Explorer
- D. Download and run standalone Microsoft Data Migration Assistant (`DMA`) with Stretch Database enabled for warm archive tables
- E. Switch eligible hybrid SQL Server instances to hourly Azure Arc pay-as-you-go billing instead of upfront core licenses
- F. Place SQL Server `.mdf`, `.ldf`, and `tempdb` files together on the Azure VM OS disk (`C:`) with `ReadWrite` host caching

### 5. A product-led-growth squad creates a `SQL database` inside Microsoft Fabric for SaaS onboarding telemetry so Power BI Direct Lake reports reflect new signups within seconds. Which two native behaviors apply? Select two.

Domain: Plan and implement data platform resources

- A. Place `tempdb` data and log files (8 equal-sized `.mdf`/`.ndf` files) on the ephemeral local NVMe SSD volume with a startup folder-creation script
- B. Configure SQL Server password logins (`CREATE LOGIN ... WITH PASSWORD`) and T-SQL `BACKUP DATABASE ... TO DISK` inside SQL database in Microsoft Fabric
- C. Authenticate applications and users exclusively with Microsoft Entra ID identities, service principals, or workspace roles
- D. Query automatically replicated OneLake Delta Parquet tables and the read-only SQL analytics endpoint from Spark and Direct Lake
- E. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`

### 6. A multi-tenant `WebhookDeliveries` table stores 12 weekly partitions on `QueuedAtUTC`. Every Sunday night you must add a new incoming week partition and purge the 13th-week partition via metadata swap without blocking live webhooks. Which four-step sequence applies?

Domain: Plan and implement data platform resources

- A. ALTER TABLE ... SWITCH oldest partition directly to Azure Blob Storage → SPLIT partition function → Rebuild entire table offline → MERGE all boundaries
- B. MERGE oldest partition boundary first → Run row-by-row DELETE on 80M rows → Create unindexed staging table on a different filegroup → SPLIT partition function
- C. Create staging table without matching CHECK constraints → SWITCH partition across two separate Azure SQL Databases → MERGE future boundary → Truncate production table
- D. SPLIT partition function for incoming future boundary → Create empty staging table on same filegroup with matching schema/indexes → ALTER TABLE ... SWITCH oldest partition to staging → Archive staging data & MERGE retired boundary

### 7. Eight dedicated enterprise-tier SQL Server 2022 VMs in Azure must report license compliance, run Automated Backup, and install security updates only during Thursdays 03:00–05:00 UTC. Which VM extension and service pair achieves this?

Domain: Plan and implement data platform resources

- A. Azure SQL Database vCore Serverless compute tier with Auto-pause delay enabled
- B. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- C. SQL IaaS Agent Extension in Full management mode paired with Azure Update Manager / Automated Patching
- D. SQL database in Microsoft Fabric (`Database` workload with automatic OneLake Delta mirroring)

### 8. For hybrid customer-premises SQL Server 2022 appliances connected via Azure Arc, how can DBAs execute a standardized compliance T-SQL query across 70 appliances without opening inbound port `1433` across customer firewalls?

Domain: Plan and implement data platform resources

- A. Download and run standalone Microsoft Data Migration Assistant (`DMA`) with Stretch Database enabled for warm archive tables
- B. Azure SQL Database vCore Elastic Pool with per-database min and max vCore limits
- C. SQL Server enabled by Azure Arc (`Microsoft.AzureArcData/sqlServerInstances`)
- D. SQL database in Microsoft Fabric (`Database` workload with automatic OneLake Delta mirroring)

### 9. A SaaS audit-event store in Azure SQL Database reaches 22 TB (`exceeding the 4 TB/16 TB General Purpose/Business Critical max size`) and needs two compute-isolated replicas for customer CSV exports. Which tier is required?

Domain: Plan and implement data platform resources

- A. Azure SQL Database DTU `Basic` or `Standard S0` tier with a single shared primary replica
- B. Azure SQL Database Hyperscale tier with compute-isolated Named Replicas
- C. SQL Server on Azure Virtual Machines (`Ebdsv5` series) with full OS and engine version control
- D. Azure SQL Database vCore Serverless compute tier with Auto-pause delay enabled

### 10. A high-frequency SaaS metering engine on Azure SQL Managed Instance requires `1–2 ms` local SSD log write latency, highest IOPS-per-vCore ratio, and an included read-only secondary replica. Which SQL MI service tier should you select?

Domain: Plan and implement data platform resources

- A. Azure SQL Managed Instance Business Critical tier with local SSD storage and built-in read-scale replica
- B. Azure SQL Database vCore Serverless compute tier with Auto-pause delay enabled
- C. Azure SQL Managed Instance (Next-gen General Purpose) with decoupled IOPS and storage sliders
- D. Azure SQL Database DTU `Basic` or `Standard S0` tier with a single shared primary replica

### 11. You provision an `E32bds_v5` Azure VM for a dedicated customer SQL Server 2022 instance using striped Premium SSD disks (`Storage Spaces` `64 KB` interleave, `1024` bytes -> `64 KB` NTFS allocation unit size). How should host caching be set across data vs log pools?

Domain: Plan and implement data platform resources

- A. Place SQL Server `.mdf`, `.ldf`, and `tempdb` files together on the Azure VM OS disk (`C:`) with `ReadWrite` host caching
- B. No — transaction log managed disks on SQL Server Azure VMs must use host caching `None`, never `ReadOnly` or `ReadWrite`
- C. Premium SSD v2 / striped Premium SSD with `ReadOnly` host caching for data disks, `None` for log disks, and `tempdb` on local NVMe
- D. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases

### 12. A cloud engineer configures Terraform for a SQL Server 2022 Azure VM and sets `caching = "ReadOnly"` on the managed disk dedicated exclusively to `TenantLogs.ldf`. Proposed solution: Deploy the `.ldf` log disk with `ReadOnly` host caching to boost transaction throughput. Does the solution meet Microsoft best practices?

Domain: Plan and implement data platform resources

- A. No — transaction log managed disks on SQL Server Azure VMs must use host caching `None`, never `ReadOnly` or `ReadWrite`
- B. No — exporting a `.bacpac` directly from an active OLTP database without copying first is not transactionally consistent
- C. No — Resource Governor is supported on SQL Server and Azure SQL Managed Instance, not single Azure SQL Databases
- D. Yes — the proposed configuration satisfies every stated technical, security, and availability requirement

### 13. A multi-tenant `CustomFields` B-tree table contains wide `CHAR(200)` and repeating prefix strings (`'https://api.tenanthive.io/v2/...'`) across millions of rows. Which B-tree compression level (`ALTER TABLE ... REBUILD WITH (DATA_COMPRESSION = ____)`) adds dictionary and column-prefix compression on top of variable-length storage?

Domain: Plan and implement data platform resources

- A. Create 25 overlapping single-column nonclustered indexes on every table column and rebuild all indexes with `ONLINE = OFF` at noon
- B. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- C. Evaluate `sp_estimate_data_compression_savings` and apply `ROW`, `PAGE`, or `COLUMNSTORE_ARCHIVE` compression per partition
- D. Replace set-based `JOIN` queries with nested `FAST_FORWARD` T-SQL cursors calling multi-statement table-valued functions per row under compat `100`

### 14. A newly acquired CRM competitor runs 22 on-premises SQL Server 2016–2019 instances. Which supported Microsoft toolset assesses migration blockers and recommends cost-optimized Elastic Pool / SQL MI vCore targets after DMA's retirement?

Domain: Plan and implement data platform resources

- A. Azure Migrate (`Azure SQL` assessment) and the Azure SQL Migration extension for Azure Data Studio / VS Code
- B. Download and run standalone Microsoft Data Migration Assistant (`DMA`) with Stretch Database enabled for warm archive tables
- C. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7
- D. Back up the TDE encryption certificate and private key (`BACKUP CERTIFICATE ... WITH PRIVATE KEY`) from `master` before restoring onto another SQL Server

### 15. An enterprise tenant outgrows `sqlmi-shared-01` and must have its 950 GB database moved online to dedicated `sqlmi-vip-09` in a peered VNet with zero data loss, removing the source database upon cutover. Which four-step sequence applies?

Domain: Plan and implement data platform resources

- A. Start online Database Move → Wait 72 hours in Ready for completion state → Open TCP 5022 + 11000-11999 rules → Expect PITR backups from source MI to transfer automatically
- B. Verify VNet peering & TCP 5022 + 11000-11999 rules → Start online Database Move from source to target SQL MI → Wait for seeding to reach Ready for completion → Complete move within 24 hours so target comes online
- C. Export `.bacpac` to Azure Table storage → Import `.bacpac` onto target SQL MI → Complete move after 48 hours → Retain source database online automatically
- D. Stop source SQL Managed Instance compute → Detach user database via sp_detach_db → Copy files over port 1433 → Reattach database on target SQL MI

### 16. SOC 2 Type II auditors require proving that SQL password authentication (`sa` and `CREATE LOGIN ... WITH PASSWORD`) is technically impossible across all 12 SaaS logical SQL servers (`az sql server ad-only-auth ____ -g rg-saas -n sql-saas`). Which server configuration enforces this?

Domain: Implement a secure environment

- A. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- B. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas
- C. Database-level IP firewall rules (`sys.sp_set_database_firewall_rule`) stored inside the user database
- D. Enable Microsoft Entra-only authentication (`azuread_authentication_only`) on the logical SQL server or SQL Managed Instance

### 17. Your SaaS Kubernetes pods use Azure Workload Identity mapped to User-Assigned Managed Identity `id-billing-api`. Which T-SQL command inside `BillingDB` creates its passwordless principal: `CREATE USER [id-billing-api] FROM ____;`?

Domain: Implement a secure environment

- A. Database-level IP firewall rules (`sys.sp_set_database_firewall_rule`) stored inside the user database
- B. Back up the TDE encryption certificate and private key (`BACKUP CERTIFICATE ... WITH PRIVATE KEY`) from `master` before restoring onto another SQL Server
- C. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- D. Contained database user mapped to a Microsoft Entra security group (`CREATE USER [Group] FROM EXTERNAL PROVIDER`)

### 18. Internal finance analysts run a legacy Windows desktop reconciliation tool requiring Kerberos authentication against an Azure SQL Managed Instance, without any customer-managed AD DS VMs in Azure. Which capability enables this?

Domain: Implement a secure environment

- A. Windows Authentication for Azure SQL Managed Instance backed by Microsoft Entra Kerberos (`Incoming Trust`-based or `Entra Kerberos`)
- B. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- C. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- D. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas

### 19. When onboarding 30 new SaaS support engineers, why should you create a single contained database user for Entra security group `[SG-SaaS-Support]` (`FROM EXTERNAL PROVIDER`) instead of individual SQL logins?

Domain: Implement a secure environment

- A. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- B. Contained database user mapped to a Microsoft Entra security group (`CREATE USER [Group] FROM EXTERNAL PROVIDER`)
- C. Remap orphaned database users (`ALTER USER [u] WITH LOGIN = [u]`) and inspect explicit `DENY` permissions via `sys.database_permissions`
- D. Database-level IP firewall rules (`sys.sp_set_database_firewall_rule`) stored inside the user database

### 20. A SaaS observability agent needs to read `sys.dm_db_resource_stats` and `sys.dm_os_wait_stats` across every tenant database on a logical SQL server while being strictly blocked from querying customer CRM tables. Which built-in server role fits best?

Domain: Implement a secure environment

- A. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- B. Row-Level Security (`CREATE SECURITY POLICY`) binding a `SCHEMABINDING` inline TVF as both `FILTER PREDICATE` and `BLOCK PREDICATE`
- C. Built-in granular server-level roles (`##MS_ServerStateReader##`, `##MS_DefinitionReader##`) or `GRANT VIEW DATABASE PERFORMANCE STATE`
- D. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas

### 21. A webhook processor calls `Billing.usp_RecordInvoice`, which executes `TRUNCATE TABLE Billing.StagingLines` (`ALTER` permission required on `Billing.StagingLines`, which ownership chaining does **not** cover). How do you let `usp_RecordInvoice` truncate `StagingLines` without granting `ALTER` to the webhook login?

Domain: Implement a secure environment

- A. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- B. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- C. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking
- D. Stored procedure encapsulation using schema ownership chaining, `EXECUTE AS OWNER`, or certificate module signing

### 22. Junior support reps have ad-hoc SQL read access to `Invoices` and must be prevented from inferring exact enterprise contract discounts via binary-search `WHERE DiscountPct > 40` predicates. Proposed solution: Apply `ADD MASKED WITH (FUNCTION = 'default()')` on `DiscountPct` only. Does the solution meet the goal?

Domain: Implement a secure environment

- A. No — exporting a `.bacpac` directly from an active OLTP database without copying first is not transactionally consistent
- B. Yes — the proposed configuration satisfies every stated technical, security, and availability requirement
- C. No — Dynamic Data Masking only obfuscates query output and does not encrypt data on disk or block brute-force inference
- D. No — server-level firewall rules live in `master` and do not replicate automatically to a failover secondary server

### 23. User `[billing_qa]` belongs to `[RoleReaders]` (`GRANT SELECT ON SCHEMA::Billing`) and also belongs to `[RoleTempFreeze]` (`DENY SELECT ON OBJECT::Billing.CreditCards`). Why does `SELECT * FROM Billing.CreditCards` fail for `[billing_qa]`?

Domain: Implement a secure environment

- A. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- B. Remap orphaned database users (`ALTER USER [u] WITH LOGIN = [u]`) and inspect explicit `DENY` permissions via `sys.database_permissions`
- C. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas
- D. Change Tracking (`CHANGETABLE(CHANGES ...)`) for lightweight net PK sync; Change Data Capture (`sys.sp_cdc_enable_table`) for full intermediate before/after history

### 24. Enterprise SaaS customers require BYOK Customer-Managed Key (`CMK`) TDE stored in Azure Key Vault on dedicated logical SQL server `sql-tenanthive-byok`. Which four-step configuration sequence applies?

Domain: Implement a secure environment

- A. Enable Soft Delete & Purge Protection on Key Vault → Assign Managed Identity to SQL server → Grant Key Vault Crypto Service Encryption User (`get`/`wrapKey`/`unwrapKey`) → Set server TDE protector to Key Vault key
- B. Upload plaintext `.pfx` directly to Azure Table storage → Grant anonymous public read on container → Point TDE protector to Table URL → Disable TLS 1.2
- C. Create symmetric key inside tempdb → Grant db_datareader in Key Vault → Set database compatibility level to 100 → Restart Azure SQL Database service
- D. Set server TDE protector to Key Vault key → Disable Soft Delete and Purge Protection on Key Vault → Assign Managed Identity after encryption starts → Export DEK plaintext to Blob storage

### 25. You enable Auto-Rotation of Customer-Managed TDE keys on an Azure SQL logical server using Azure Key Vault. Which two Key Vault configurations must remain active so automated key rotation succeeds? Select two.

Domain: Implement a secure environment

- A. Grant the SQL server Managed Identity `Key Vault Crypto Service Encryption User` (`get`, `wrapKey`, `unwrapKey`) on the Key Vault
- B. Enable both `Soft Delete` and `Purge Protection` on the Azure Key Vault or Managed HSM storing the TDE protector key
- C. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- D. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- E. Configure `None` Azure host caching on dedicated managed disks hosting `.ldf` SQL Server transaction log files

### 26. You inspect active client connections on Azure SQL Database to verify every microservice connects using TLS 1.2 or higher via `SELECT session_id, encrypt_option FROM sys.____`. Which DMV exposes per-connection transport encryption attributes?

Domain: Implement a secure environment

- A. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas
- B. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- C. Database-level IP firewall rules (`sys.sp_set_database_firewall_rule`) stored inside the user database
- D. Column-level encryption (`CREATE MASTER KEY` -> `CREATE CERTIFICATE` -> `CREATE SYMMETRIC KEY` -> `EncryptByKey`) plus `Minimal TLS version = 1.2`

### 27. A SaaS webhook partner at IP `198.51.100.210` connects exclusively to `Tenant042DB` on `sql-saas-primary`, which fails over to `sql-saas-secondary`. Proposed solution: Add `198.51.100.210` via `sp_set_firewall_rule` in `master` on `sql-saas-primary` only and expect it to grant access to `Tenant042DB` only and fail over automatically. Does the solution meet both goals?

Domain: Implement a secure environment

- A. No — exporting a `.bacpac` directly from an active OLTP database without copying first is not transactionally consistent
- B. Yes — the proposed configuration satisfies every stated technical, security, and availability requirement
- C. No — server-level firewall rules live in `master` and do not replicate automatically to a failover secondary server
- D. No — Dynamic Data Masking only obfuscates query output and does not encrypt data on disk or block brute-force inference

### 28. An HR SaaS module stores `TaxId` and `AnnualBonus` using Always Encrypted with VBS secure enclaves so payroll APIs can run `WHERE AnnualBonus > 50000` and `ORDER BY AnnualBonus DESC`. Which two configurations are mandatory? Select two.

Domain: Implement a secure environment

- A. Provision a Column Master Key in Key Vault and create a Column Encryption Key with `ENCLAVE_COMPUTATIONS` enabled
- B. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking
- C. Configure `ReadOnly` Azure host caching on Premium SSD data disks hosting `.mdf` and `.ndf` database files
- D. Enable `Column Encryption Setting=Enabled` and pass the `Enclave Attestation Url` (or VBS zero-attestation setting) in client drivers
- E. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections

### 29. In Azure SQL Database, how does a **VBS (Virtualization-based Security) secure enclave** differ operationally from an older **Intel SGX (`DC-series` hardware) enclave** for Always Encrypted?

Domain: Implement a secure environment

- A. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas
- B. Always Encrypted with VBS or Intel SGX secure enclaves (`ALLOW_ENCLAVE_COMPUTATIONS` + `Column Encryption Setting=Enabled`)
- C. Transparent Data Encryption (TDE) with a Customer-Managed Key (`CMK`) in Azure Key Vault (`Soft Delete` + `Purge Protection`)
- D. Always Encrypted (`Randomized` for maximum security with zero equality leakage; `Deterministic` only when `=` joins or `GROUP BY` are required)

### 30. Your SaaS AKS cluster in `vnet-saas-prod` must reach `sql-cloudslate.database.windows.net` exclusively over Private Link with zero public internet attack surface. Which two configurations complete this setup? Select two.

Domain: Implement a secure environment

- A. Place `tempdb` data and log files (8 equal-sized `.mdf`/`.ndf` files) on the ephemeral local NVMe SSD volume with a startup folder-creation script
- B. Switch eligible hybrid SQL Server instances to hourly Azure Arc pay-as-you-go billing instead of upfront core licenses
- C. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- D. Set `Public network access = Disabled` (`publicNetworkAccess: Disabled`) on the logical SQL server so internet connections are rejected
- E. Link Private DNS Zone `privatelink.database.windows.net` (or forward on-premises DNS) to resolve `<server>.database.windows.net` to the private IP

### 31. Why do enterprise security architects choose **Azure Private Link** over **VNet Service Endpoints** (`Microsoft.Sql`) when preventing malicious insiders inside a VNet from exfiltrating SQL rows to a rogue Azure SQL server in a personal Azure tenant?

Domain: Implement a secure environment

- A. Virtual Network Service Endpoints (`Microsoft.Sql`) with outbound storage firewall rules, or dedicated `/28+` delegated subnet for SQL MI
- B. Database-level IP firewall rules (`sys.sp_set_database_firewall_rule`) stored inside the user database
- C. Azure Private Endpoint (`Microsoft.Network/privateEndpoints`) paired with `privatelink.database.windows.net` Private DNS and `publicNetworkAccess = Disabled`
- D. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections

### 32. If you configure **both** server-level Auditing (to Log Analytics for SecOps) and database-level Auditing (to a Storage Account for a specific tenant's compliance team) on Azure SQL Database, which policies run?

Domain: Implement a secure environment

- A. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- B. SQL Data Discovery & Classification (`ADD SENSITIVITY CLASSIFICATION`) integrated with Azure SQL Auditing to Log Analytics / immutable Storage
- C. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- D. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`

### 33. What happens if a low-privilege reporting user **without** `UNMASK` runs `SELECT MaskedCreditCard INTO #TempCards FROM Billing.Cards; SELECT * FROM #TempCards;`?

Domain: Implement a secure environment

- A. Row-Level Security (`CREATE SECURITY POLICY`) binding a `SCHEMABINDING` inline TVF as both `FILTER PREDICATE` and `BLOCK PREDICATE`
- B. Transparent Data Encryption (TDE) with a Customer-Managed Key (`CMK`) in Azure Key Vault (`Soft Delete` + `Purge Protection`)
- C. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas
- D. Always Encrypted with VBS or Intel SGX secure enclaves (`ALLOW_ENCLAVE_COMPUTATIONS` + `Column Encryption Setting=Enabled`)

### 34. You are implementing multi-tenant Row-Level Security on `Billing.Subscriptions` for a Go microservice pool using `sp_set_session_context`. Which four-step implementation sequence follows Microsoft best practices?

Domain: Implement a secure environment

- A. Create `SECURITY POLICY` with `STATE = ON` first → Create multi-statement TVF without `SCHEMABINDING` → Grant tenants `ALTER ANY SECURITY POLICY` → Store `TenantId` in a global temp table
- B. Create dedicated `Security` schema → Create `SCHEMABINDING` inline TVF reading `SESSION_CONTEXT(N'TenantId')` → Create `SECURITY POLICY` with `FILTER` & `BLOCK` predicates (`STATE = ON`) → Set read-only `sp_set_session_context` on connect
- C. Apply `ADD MASKED WITH (FUNCTION = 'default()')` on `TenantId` → Create `AFTER INSERT` trigger → Grant `UNMASK` to shared app login → Expect row filtering
- D. Create non-schema-bound scalar UDF → Attach UDF to `sys.sp_set_firewall_rule` → Enable Change Tracking → Set `SESSION_CONTEXT` with `@read_only = 0` so users can switch tenants

### 35. Across a 480-database SaaS Elastic Pool, you need to identify which five individual tenant databases consumed the highest peak `avg_cpu_percent` and `avg_data_io_percent` over the last hour from `master` without connecting to 480 databases one by one. Which `master` view provides per-database 1-minute/5-minute rollups: `sys.____`?

Domain: Monitor, configure, and optimize database resources

- A. Azure Monitor metrics paired with `sys.dm_db_resource_stats` (single DB) or `sys.server_resource_stats` (SQL MI) for 15-second CPU, data I/O, log write, and memory baselines
- B. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7
- C. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- D. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database

### 36. In Azure SQL Database, `sys.dm_os_wait_stats` shows server/instance-wide waits whereas `SELECT * FROM sys.____` returns wait statistics scoped strictly to the **current user database**. Which DMV is database-scoped in Azure SQL Database?

Domain: Monitor, configure, and optimize database resources

- A. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- B. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking
- C. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas
- D. Query `sys.dm_os_wait_stats` / `sys.dm_db_wait_stats`, `sys.dm_exec_requests`, `sys.dm_tran_locks`, and `sys.dm_db_tempdb_space_usage`

### 37. You deploy `database watcher` to monitor SaaS Elastic Pools and SQL Managed Instances into an Azure Data Explorer cluster. Which four-step setup sequence completes deployment?

Domain: Monitor, configure, and optimize database resources

- A. Provision Azure Data Explorer or Fabric Eventhouse store → Create database watcher with Managed Identity → Add SQL targets & grant `VIEW SERVER PERFORMANCE STATE` + ingest roles → Start watcher & open portal dashboards
- B. Start database watcher before selecting data store or SQL targets → Grant `sysadmin` via blank-password `sa` login → Store time-series telemetry in Azure Queue Storage → Enable SQL Profiler trace
- C. Create database watcher targeting Azure Cosmos DB for Gremlin → Store metrics in Azure Table storage → Authenticate via anonymous public SAS → Query dashboards via Gremlin
- D. Install third-party kernel drivers inside Azure SQL Database PaaS OS → Configure SMB share on domain controller → Export `.trc` files via `sp_trace_create` → Query via MDX

### 38. Your SRE team audits permissions for `database watcher` monitoring SaaS Elastic Pools into Fabric Eventhouse (and documents the upcoming transition to Database Hub in Fabric before April 30, 2027). Which two grants are required? Select two.

Domain: Monitor, configure, and optimize database resources

- A. Grant the database watcher Managed Identity `VIEW SERVER PERFORMANCE STATE` (or `VIEW DATABASE PERFORMANCE STATE`) on SQL targets
- B. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7
- C. Place `tempdb` data and log files (8 equal-sized `.mdf`/`.ndf` files) on the ephemeral local NVMe SSD volume with a startup folder-creation script
- D. Grant the database watcher Managed Identity database `Admin` / ingest permissions on the Azure Data Explorer or Fabric Eventhouse store
- E. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`

### 39. You want to capture persistent Extended Events `.xel` files for `blocked_process_report` / lock timeout events on a multi-tenant Azure SQL Database. Which two steps are required? Select two.

Domain: Monitor, configure, and optimize database resources

- A. Define `CREATE EVENT SESSION ... ON DATABASE ADD TARGET package0.event_file(SET filename = N'https://...xel')` and start the session
- B. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- C. Create a `DATABASE SCOPED CREDENTIAL` (`Managed Identity` or `SHARED ACCESS SIGNATURE` with `rwl` permissions) for the Azure Blob container
- D. Enable both `Soft Delete` and `Purge Protection` on the Azure Key Vault or Managed HSM storing the TDE protector key
- E. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7

### 40. Which system DMV in Azure SQL Database confirms whether your `ON DATABASE` Extended Events session is currently active and inspects dropped buffer counts: `SELECT s.name, t.target_name FROM sys.dm_xe_database_sessions s JOIN sys.____ t ...`?

Domain: Monitor, configure, and optimize database resources

- A. Extended Events (`CREATE EVENT SESSION ... ON DATABASE` in SQL DB or `ON SERVER` in SQL MI/VMs) writing to an `event_file` target in Azure Blob Storage
- B. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7
- C. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- D. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database

### 41. An ORM framework generates a multi-join SaaS dashboard query that regresses whenever a massive enterprise tenant runs first after deployment. Which two Query Store procedures let you stabilize the query immediately without ORM code changes? Select two.

Domain: Monitor, configure, and optimize database resources

- A. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- B. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- C. Execute `sys.sp_query_store_force_plan @query_id, @plan_id` to pin the historical low-latency execution plan immediately
- D. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking
- E. Execute `sys.sp_query_store_set_hints @query_id, N'OPTION (RECOMPILE)'` (or `MAXDOP` / memory grant hints) without redeploying code

### 42. A multi-tenant search query regresses from 6 ms (`plan_id = 104`) to 2,200 ms (`plan_id = 311`) after an atypical tenant batch. Which four-step Query Store procedure restores 6 ms latency safely?

Domain: Monitor, configure, and optimize database resources

- A. Set Query Store `OPERATION_MODE = READ_ONLY` → Modify `sys.query_store_plan` system catalog via `UPDATE` → Run `DBCC FREEPROCCACHE` every minute → Disable statistics
- B. Restart SQL Server production instance during peak traffic → Rebuild every index with `ONLINE = OFF` → Enable `AUTO_CLOSE = ON` → Check Query Store
- C. Confirm Query Store is `READ_WRITE` with wait capture → Compare plan IDs in Regressed Queries (`sys.query_store_runtime_stats`) → Force prior plan via `sp_query_store_force_plan` → Monitor `force_failure_count` & latency
- D. Run `ALTER DATABASE ... SET QUERY_STORE CLEAR ALL` first → Inspect Regressed Queries history → Force new regressed plan ID → Set `OPERATION_MODE = OFF`

### 43. In Azure SQL Database with **Optimized Locking** active, Transaction T1 runs `UPDATE Tickets SET Priority = 1 WHERE TenantId = 99 AND Status = 'Escalated'` on an unindexed `Status` column. Under Lock After Qualification (`LAQ`) under `RCSI`, does T1 block concurrent `UPDATE`s on rows where `Status = 'Closed'`?

Domain: Monitor, configure, and optimize database resources

- A. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- B. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking
- C. Read Committed Snapshot Isolation (`READ_COMMITTED_SNAPSHOT = ON`) combined with Optimized Locking (`TID` locking + Lock After Qualification `LAQ`)
- D. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases

### 44. On a single Azure SQL Database, a tenant reports sporadic Error `1205` deadlocks at 03:15 UTC, and you haven't created a custom Extended Events session yet. Which built-in catalog view in `master` already retains deadlock events (`event_type = 'deadlock'`): `SELECT * FROM sys.____ WHERE database_name = 'Tenant088'`?

Domain: Monitor, configure, and optimize database resources

- A. Create 25 overlapping single-column nonclustered indexes on every table column and rebuild all indexes with `ONLINE = OFF` at noon
- B. Capture `xml_deadlock_report` via Extended Events or `sys.event_log`, align table modification order across transactions, and add covering indexes
- C. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- D. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking

### 45. You want to find nonclustered indexes on `Contacts` that incur millions of expensive `user_updates` every day while having `user_seeks = 0`, `user_scans = 0`, and `user_lookups = 0` since last startup. Which DMV provides these counters: `sys.____`?

Domain: Monitor, configure, and optimize database resources

- A. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- B. Query `sys.dm_os_wait_stats` / `sys.dm_db_wait_stats`, `sys.dm_exec_requests`, `sys.dm_tran_locks`, and `sys.dm_db_tempdb_space_usage`
- C. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking
- D. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database

### 46. A multi-tenant query `SELECT TicketId, Subject, CreatedAt FROM Tickets WHERE TenantId = @tid AND Status = 'Open' ORDER BY CreatedAt DESC` currently sorts 300,000 rows in `tempdb`. Which single composite nonclustered index satisfies the filter, sort order, and projection with **zero** Sort operator and **zero** Key Lookups?

Domain: Monitor, configure, and optimize database resources

- A. Replace set-based `JOIN` queries with nested `FAST_FORWARD` T-SQL cursors calling multi-statement table-valued functions per row under compat `100`
- B. Create 25 overlapping single-column nonclustered indexes on every table column and rebuild all indexes with `ONLINE = OFF` at noon
- C. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking
- D. Create a selective nonclustered covering index (`CREATE NONCLUSTERED INDEX ... INCLUDE (...)`) and rewrite predicates to be SARGable without implicit type conversions

### 47. An API filter writes `WHERE ISNULL(AssignedAgentId, -1) = @agent_id`, causing a full index scan on `IX_AssignedAgentId`. How do you rewrite this predicate so it stays SARGable when `@agent_id` may represent unassigned (`NULL`) rows?

Domain: Monitor, configure, and optimize database resources

- A. Create a selective nonclustered covering index (`CREATE NONCLUSTERED INDEX ... INCLUDE (...)`) and rewrite predicates to be SARGable without implicit type conversions
- B. Replace set-based `JOIN` queries with nested `FAST_FORWARD` T-SQL cursors calling multi-statement table-valued functions per row under compat `100`
- C. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- D. Create 25 overlapping single-column nonclustered indexes on every table column and rebuild all indexes with `ONLINE = OFF` at noon

### 48. In Query Store's **Top Resource Consuming Queries** pane, why should you inspect **Wait Statistics** alongside **Logical Reads** and **CPU Time** when diagnosing a slow stored procedure whose CPU time is only `3 ms` yet total duration is `4,500 ms`?

Domain: Monitor, configure, and optimize database resources

- A. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- B. Inspect Actual Execution Plans (`Key Lookup`, `TempDB` sort/hash spill warnings, cardinality skew) alongside SQL Intelligent Insights (`SQLInsights`)
- C. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking
- D. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7

### 49. A slow reporting query spends 94% of its duration in wait type `ASYNC_NETWORK_IO` while CPU and disk reads finish in 20 ms. What is the actual bottleneck behind `ASYNC_NETWORK_IO`?

Domain: Monitor, configure, and optimize database resources

- A. Download and run standalone Microsoft Data Migration Assistant (`DMA`) with Stretch Database enabled for warm archive tables
- B. Transparent Data Encryption (TDE) with a Customer-Managed Key (`CMK`) in Azure Key Vault (`Soft Delete` + `Purge Protection`)
- C. Inspect Actual Execution Plans (`Key Lookup`, `TempDB` sort/hash spill warnings, cardinality skew) alongside SQL Intelligent Insights (`SQLInsights`)
- D. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7

### 50. An online resumable index rebuild (`RESUMABLE = ON`) on `BillingEvents` was paused yesterday at 68% completion. Proposed solution: Check `percent_complete` in `sys.index_resumable_operations` and run `ALTER INDEX IX_BillingEvents ON dbo.BillingEvents ____;` to finish the remaining 32%. Does `RESUME` complete the rebuild without restarting from 0%?

Domain: Monitor, configure, and optimize database resources

- A. No — Dynamic Data Masking only obfuscates query output and does not encrypt data on disk or block brute-force inference
- B. No — transaction log managed disks on SQL Server Azure VMs must use host caching `None`, never `ReadOnly` or `ReadWrite`
- C. Yes — the proposed configuration satisfies every stated technical, security, and availability requirement
- D. No — exporting a `.bacpac` directly from an active OLTP database without copying first is not transactionally consistent

### 51. After Azure SQL Database Automatic Tuning (`CREATE_INDEX = ON`) automatically creates a missing nonclustered index on `Deals`, how does Automatic Tuning verify the change was actually beneficial?

Domain: Monitor, configure, and optimize database resources

- A. Create 25 overlapping single-column nonclustered indexes on every table column and rebuild all indexes with `ONLINE = OFF` at noon
- B. Azure SQL Database Automatic Tuning (`FORCE_LAST_GOOD_PLAN = ON`, `CREATE_INDEX = ON`, `DROP_INDEX = ON`)
- C. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- D. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases

### 52. A noisy SaaS tenant runs complex CSV exports on a shared single Azure SQL Database (`BC_Gen5_16`). Proposed solution: Configure SQL Server Resource Governor inside that single Azure SQL Database to throttle that tenant's `SESSION_CONTEXT` to 10% CPU. Does the solution meet the goal?

Domain: Monitor, configure, and optimize database resources

- A. No — Dynamic Data Masking only obfuscates query output and does not encrypt data on disk or block brute-force inference
- B. Yes — the proposed configuration satisfies every stated technical, security, and availability requirement
- C. No — Resource Governor is supported on SQL Server and Azure SQL Managed Instance, not single Azure SQL Databases
- D. No — exporting a `.bacpac` directly from an active OLTP database without copying first is not transactionally consistent

### 53. In compatibility level `160` on Azure SQL Database, which database-scoped configuration (`ALTER DATABASE SCOPED CONFIGURATION SET ____ = ON;`) automatically learns and lowers excessive degree-of-parallelism for repeating queries while keeping CPU/elapsed time optimal?

Domain: Monitor, configure, and optimize database resources

- A. Use `ALTER DATABASE SCOPED CONFIGURATION` (`MAXDOP`, `LEGACY_CARDINALITY_ESTIMATION`, `PARAMETER_SNIFFING`, `OPTIMIZED_PLAN_FORCING`) per database
- B. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- C. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking
- D. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases

### 54. A legacy SaaS T-SQL batch declares a table variable `DECLARE @StageIds TABLE (Id INT PRIMARY KEY)` populated with 250,000 rows and joins it to `Contacts`. Under compatibility level `150+`, why does it no longer default to a blind `1-row` Nested Loops estimate?

Domain: Monitor, configure, and optimize database resources

- A. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking
- B. Replace set-based `JOIN` queries with nested `FAST_FORWARD` T-SQL cursors calling multi-statement table-valued functions per row under compat `100`
- C. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- D. Enable compatibility level `160` Intelligent Query Processing (`Parameter Sensitive Plan` optimization, `Memory Grant Feedback` persistence, `Scalar UDF Inlining`, `DOP Feedback`)

### 55. On dedicated enterprise SQL Server 2022 Azure VMs, you must run Agent PowerShell steps without `sysadmin` rights and page SREs immediately on fatal Severity `19–25` / I/O `823–825` errors. Which two SQL Agent configurations are required? Select two.

Domain: Configure and manage automation of tasks

- A. Create a Windows/SQL Credential and map it to a SQL Server Agent Subsystem Proxy (`CmdExec` / `PowerShell`) instead of granting `sysadmin`
- B. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- C. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- D. Configure Database Mail, define an Agent Operator, and create SQL Server Agent Alerts for Severity `19–25` and Errors `823`, `824`, and `825`
- E. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections

### 56. In SQL Server Agent job history on a busy SQL Server VM running 1-minute polling jobs, older weekly maintenance job logs get evicted within hours because `Maximum job history log size` defaults to `1,000` rows (`100` per job). Where do you adjust retention?

Domain: Configure and manage automation of tasks

- A. Start the built-in `SQLServerAgent` Windows service inside a single Azure SQL Database and store target server passwords in a public GitHub repo
- B. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- C. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- D. SQL Server Agent multi-step jobs using Credentials + Subsystem Proxies, Severity `19–25` / Error `823–825` Alerts, and Database Mail Operators

### 57. Which SQL Server Agent alert type uses a WQL query (`SELECT * FROM DEADLOCK_GRAPH`) against the SQL Server WMI Provider on Windows VMs to trigger an automated response job whenever a deadlock occurs?

Domain: Configure and manage automation of tasks

- A. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- B. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- C. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7
- D. SQL Server Agent multi-step jobs using Credentials + Subsystem Proxies, Severity `19–25` / Error `823–825` Alerts, and Database Mail Operators

### 58. A developer granted `SQLAgentUserRole` in `msdb` creates a SQL Agent job on SQL Managed Instance, yet cannot view or edit a shared nightly ETL job created by a colleague. Which `msdb` fixed role lets operators view all Agent jobs and start/stop any job without holding `sysadmin`?

Domain: Configure and manage automation of tasks

- A. Inspect `msdb.dbo.sysjobhistory` / `sp_help_jobhistory`, verify proxy/credential permissions, and account for SQL Managed Instance Agent subsystem boundaries
- B. Start the built-in `SQLServerAgent` Windows service inside a single Azure SQL Database and store target server passwords in a public GitHub repo
- C. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- D. Download and run standalone Microsoft Data Migration Assistant (`DMA`) with Stretch Database enabled for warm archive tables

### 59. A SQL Server Agent T-SQL step fails with `Quoted identifier error: UPDATE failed because the following SET options have incorrect settings: 'QUOTED_IDENTIFIER'` when updating a table that has a filtered index or indexed view. Why did it work in SSMS yet fail in SQL Agent?

Domain: Configure and manage automation of tasks

- A. Inspect `msdb.dbo.sysjobhistory` / `sp_help_jobhistory`, verify proxy/credential permissions, and account for SQL Managed Instance Agent subsystem boundaries
- B. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- C. Transparent Data Encryption (TDE) with a Customer-Managed Key (`CMK`) in Azure Key Vault (`Soft Delete` + `Purge Protection`)
- D. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases

### 60. Your SaaS platform engineering team deploys multi-region Elastic Pools via Bicep in Azure Pipelines. Which two controls protect secrets in ARM deployments and catch destructive drift before applying? Select two.

Domain: Configure and manage automation of tasks

- A. Run `az deployment group what-if` (or `New-AzResourceGroupDeployment -WhatIf`) as a pull-request gate before applying template changes
- B. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- C. Mark sensitive parameters with `@secure()` in Bicep and pass Key Vault secret references from the parameter file rather than cleartext values
- D. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- E. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections

### 61. You want six SaaS regional logical SQL servers (`eastus`, `westeurope`, `southeastasia`, etc.) deployed from a single concise Bicep resource block iterating over `param regions array`. Which Bicep loop syntax provisions all six servers cleanly?

Domain: Configure and manage automation of tasks

- A. Download and run standalone Microsoft Data Migration Assistant (`DMA`) with Stretch Database enabled for warm archive tables
- B. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- C. Declarative Bicep / ARM templates (`Microsoft.Sql/servers`) referencing Azure Key Vault secrets via `@secure()` parameters and validated with `az deployment group what-if`
- D. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections

### 62. You automate moving 20 tenant databases from `pool-standard` into `pool-premium` on the same logical SQL server using Azure CLI: `az sql db ____ -g rg-saas -s sql-saas -n Tenant01 --elastic-pool pool-premium`. Which CLI verb moves an existing database into another Elastic Pool on the same server?

Domain: Configure and manage automation of tasks

- A. Download and run standalone Microsoft Data Migration Assistant (`DMA`) with Stretch Database enabled for warm archive tables
- B. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7
- C. Back up the TDE encryption certificate and private key (`BACKUP CERTIFICATE ... WITH PRIVATE KEY`) from `master` before restoring onto another SQL Server
- D. Idempotent day-2 scripting with Azure PowerShell (`New-AzSqlDatabase`, `Set-AzSqlElasticPool`) or Azure CLI (`az sql db update`, `az sql mi update`)

### 63. Which Azure PowerShell cmdlet creates a new vCore Elastic Pool with per-database min `0.5` and max `4` vCore limits: `____ -ResourceGroupName "rg-saas" -ServerName "sql-saas" -ElasticPoolName "pool-crm" -Edition "GeneralPurpose" -VCore 16 -DatabaseVCoreMin 0.5 -DatabaseVCoreMax 4`?

Domain: Configure and manage automation of tasks

- A. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- B. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- C. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- D. Idempotent day-2 scripting with Azure PowerShell (`New-AzSqlDatabase`, `Set-AzSqlElasticPool`) or Azure CLI (`az sql db update`, `az sql mi update`)

### 64. An ARM deployment provisioning Private Link + Key Vault CMK TDE on a new logical SQL server fails with `KeyVaultAccessDenied` even though the Bicep file contains both the server (`identity: { type: 'SystemAssigned' }`) and the Key Vault role assignment. Why can a **System-Assigned** Managed Identity hit race conditions on initial server creation compared to a **User-Assigned** Managed Identity (`UAMI`)?

Domain: Configure and manage automation of tasks

- A. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- B. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas
- C. Diagnose deployment failures via `Get-AzResourceGroupDeploymentOperation` / Activity Log `CorrelationId`, checking regional vCore quotas and SQL MI subnet delegation/NSG/UDR rules
- D. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database

### 65. Which Azure CLI command retrieves failed operation error JSON messages for a failed resource-group Bicep deployment `deploy-saas-20261101`: `az deployment operation group ____ -g rg-saas -n deploy-saas-20261101 --query "[?properties.provisioningState=='Failed']"`?

Domain: Configure and manage automation of tasks

- A. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- B. Diagnose deployment failures via `Get-AzResourceGroupDeploymentOperation` / Activity Log `CorrelationId`, checking regional vCore quotas and SQL MI subnet delegation/NSG/UDR rules
- C. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking
- D. Back up the TDE encryption certificate and private key (`BACKUP CERTIFICATE ... WITH PRIVATE KEY`) from `master` before restoring onto another SQL Server

### 66. You are provisioning `StackBeacon`'s Elastic Job Agent from scratch using User-Assigned Managed Identity authentication. Which four-step setup sequence is required?

Domain: Configure and manage automation of tasks

- A. Enable SQL Server Agent inside single Azure SQL Database → Create linked servers to 480 tenant DBs → Loop synchronously inside a scalar UDF → Grant `CONTROL SERVER` to `guest`
- B. Provision Elastic Job Agent inside Azure Blob Storage → Store plaintext admin password in Git repo → Add Cosmos DB containers to Target Group → Trigger via `DBCC SHRINKDATABASE`
- C. Create Elastic Job Agent on Basic tier DB → Run `jobs.sp_add_job` before creating Target Group → Authenticate across servers with Windows NTLM local accounts → Schedule via `msdb.dbo.sp_add_job`
- D. Create S1+ Job Database & Elastic Job Agent with UAMI → Create contained UAMI user on target DBs with needed permissions → Define Target Group (`jobs.sp_add_target_group_member`) → Add T-SQL steps & schedule (`jobs.sp_add_job`)

### 67. When an Elastic Job needs to aggregate a single summary result table from all 480 tenant databases into one central reporting Azure SQL Database (`OutputDatabase`), which built-in `jobs.sp_add_jobstep` capability handles fan-in collection natively?

Domain: Configure and manage automation of tasks

- A. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- B. Back up the TDE encryption certificate and private key (`BACKUP CERTIFICATE ... WITH PRIVATE KEY`) from `master` before restoring onto another SQL Server
- C. Azure Automation PowerShell / Python runbooks (or Azure Functions / Logic Apps) using a System-Assigned Managed Identity on a recurring schedule
- D. Download and run standalone Microsoft Data Migration Assistant (`DMA`) with Stretch Database enabled for warm archive tables

### 68. To avoid alert storms during a planned Sunday 02:00–04:00 maintenance window across 120 SaaS Azure SQL Databases without deleting your Azure Monitor Metric Alert rules, which native Azure Monitor feature suppresses notifications temporarily?

Domain: Configure and manage automation of tasks

- A. Configure Azure Monitor Metric / Log Alert rules routed to Action Groups and query `jobs.job_executions` in the Elastic Job database to diagnose step failures
- B. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7
- C. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- D. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections

### 69. A SaaS enterprise SLA guarantees `RPO <= 5 seconds` and `RTO <= 1 hour` during a complete Azure regional outage. Proposed solution: Rely solely on default `RA-GRS` Geo-Restore backups without configuring Active Geo-Replication or a Failover Group. Does the solution meet the SLA?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. No — server-level firewall rules live in `master` and do not replicate automatically to a failover secondary server
- B. No — exporting a `.bacpac` directly from an active OLTP database without copying first is not transactionally consistent
- C. Yes — the proposed configuration satisfies every stated technical, security, and availability requirement
- D. No — Dynamic Data Masking only obfuscates query output and does not encrypt data on disk or block brute-force inference

### 70. When comparing `Zone Redundant` HA on Azure SQL Database General Purpose versus Business Critical, how does failover speed (`RTO`) compare during an unexpected compute node or Availability Zone failure?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Align tiers to RPO/RTO: `Zone Redundant` (`RPO = 0` intra-region HA), `Failover Groups` (`RPO = 5s`, `RTO = 1h` SLA cross-region DR), vs `Geo-Restore` (`RPO = 1h`, `RTO = 12h`)
- B. Rely solely on Geo-Restore from `RA-GRS` automated backups to meet a 5-second RPO and 60-second automatic failover RTO SLA
- C. Azure SQL Database DTU `Basic` or `Standard S0` tier with a single shared primary replica
- D. Azure SQL Database vCore Serverless compute tier with Auto-pause delay enabled

### 71. A newly acquired European SaaS subsidiary runs SQL Server 2022 on-premises and links it via Managed Instance link to Azure SQL Managed Instance for cloud DR. Which T-SQL / SSMS capability allows failing over to SQL MI during datacenter maintenance and failing back to SQL Server 2022 afterward without rebuilding?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Create a transactionally consistent database copy (`CREATE DATABASE ... AS COPY OF`), export `.bacpac` via `SqlPackage`, then remove the copy
- B. Download and run standalone Microsoft Data Migration Assistant (`DMA`) with Stretch Database enabled for warm archive tables
- C. Expect online bidirectional planned failback from Azure SQL Managed Instance directly back to on-premises SQL Server 2016 without downtime
- D. Hybrid DR using Managed Instance link with bidirectional online failover between SQL Server 2022 and Azure SQL Managed Instance

### 72. Can an Azure SQL Database **Serverless** vCore database enable `Zone Redundant` high availability across Availability Zones in supported regions?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- B. Align tiers to RPO/RTO: `Zone Redundant` (`RPO = 0` intra-region HA), `Failover Groups` (`RPO = 5s`, `RTO = 1h` SLA cross-region DR), vs `Geo-Restore` (`RPO = 1h`, `RTO = 12h`)
- C. Deploy a 2-node Always On Availability Group in a single Availability Set without any quorum witness and block TCP `59999` on the NSG
- D. Place SQL Server `.mdf`, `.ldf`, and `tempdb` files together on the Azure VM OS disk (`C:`) with `ReadWrite` host caching

### 73. SOC 2 auditors ask your team to run a live zero-data-loss regional failover drill for an Elastic Pool of 60 SaaS databases in `fog-tenanthive` without breaking customer API traffic. Which four-step workflow applies?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Execute unplanned `AllowDataLoss` forced failover during peak checkout → Create secondary logical SQL server afterward → Hardcode regional server names in app connection strings → Skip firewall rules on secondary
- B. Create Failover Group between two servers in the exact same datacenter rack → Add `tempdb` and `master` to Failover Group → Point OLTP writes to `.secondary.database.windows.net` → Disable Geo-Replication
- C. Export nightly `.bacpac` to local laptop → Delete production database to test restore → Manually edit 50 microservice connection strings → Re-enable TDE after 6 hours
- D. Provision secondary SQL server with matching firewall/Private Link & Entra admin → Create Failover Group with coupled DBs → Point apps to `<fog>.database.windows.net` & `.secondary` → Run planned `Switch-AzSqlDatabaseFailoverGroup` drill

### 74. If you want to rehearse your disaster-recovery runbook and schema upgrade scripts on an exact isolated copy of a Geo-Replicated secondary (`____ -ResourceGroupName "rg-dr" -ServerName "sql-dr" -DatabaseName "ProdDB" -CopyDatabaseName "ProdDB_Drill"`) without failing over production, what non-disruptive method can you use?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Non-disruptive DR readiness drill executing a planned zero-data-loss Failover Group switch (`Switch-AzSqlDatabaseFailoverGroup`), validating app listeners, and failing back
- B. Rely solely on Geo-Restore from `RA-GRS` automated backups to meet a 5-second RPO and 60-second automatic failover RTO SLA
- C. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- D. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections

### 75. A SaaS support engineer exports an ad-hoc `.bak` from a dedicated SQL Server 2022 VM (`BACKUP DATABASE [CRM_VIP] TO URL = '...'`) on Thursday afternoon **without** specifying `WITH COPY_ONLY`. Proposed solution: Use Friday morning's scheduled Differential backup directly on top of Sunday's Full backup during a DR test. Does the restore succeed?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. No — taking an ad-hoc non-`COPY_ONLY` full backup resets the differential base and breaks downstream differential restores
- B. No — server-level firewall rules live in `master` and do not replicate automatically to a failover secondary server
- C. No — Dynamic Data Masking only obfuscates query output and does not encrypt data on disk or block brute-force inference
- D. Yes — the proposed configuration satisfies every stated technical, security, and availability requirement

### 76. What is the default automated backup frequency inside Azure SQL Database and Azure SQL Managed Instance (which Azure manages automatically on your behalf)?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- B. Use `BACKUP DATABASE ... WITH COPY_ONLY` for ad-hoc exports on SQL MI / AGs, and Azure Backup Recovery Services Vault SQL-aware policies (`15-min` log RPO) on SQL VMs
- C. Place SQL Server `.mdf`, `.ldf`, and `tempdb` files together on the Azure VM OS disk (`C:`) with `ReadWrite` host caching
- D. Back up a 6 TB database to a single unstriped Azure Page Blob URL (`WITH CREDENTIAL` omitted) using anonymous public container access

### 77. If a rogue script deletes an entire **logical Azure SQL Server** (`az sql server delete`), what happens to the short-term Point-in-Time Restore (`PITR`) backups of all databases that were on that server (versus locked `LTR` backups)?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Automated Point-in-Time Restore (`1–35` days PITR), Deleted-Database restore from the logical server, and Accelerated Database Recovery (`ADR`) instant rollback
- B. Set Short-Term PITR retention to `3,650` days (`10 years`) and grant developers Subscription Contributor to prevent backup deletion
- C. Create a transactionally consistent database copy (`CREATE DATABASE ... AS COPY OF`), export `.bacpac` via `SqlPackage`, then remove the copy
- D. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases

### 78. You complete an online Database Move of `TenantVIP` across two SQL Managed Instances at `10:00 UTC`. At `11:00 UTC` the tenant asks to recover accidentally deleted rows from `08:00 UTC` that morning. Proposed solution: Run Point-in-Time Restore on the destination SQL Managed Instance targeting `08:00 UTC`. Does the solution meet the goal?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. No — moving a database across SQL Managed Instances starts a fresh backup chain and does not carry over prior PITR backups
- B. Yes — the proposed configuration satisfies every stated technical, security, and availability requirement
- C. No — server-level firewall rules live in `master` and do not replicate automatically to a failover secondary server
- D. No — Dynamic Data Masking only obfuscates query output and does not encrypt data on disk or block brute-force inference

### 79. Enterprise FinServ tenants on `CloudSlate Billing` require 7-year monthly backup archives locked against ransomware or admin deletion. Which two Azure SQL backup settings meet this requirement? Select two.

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- B. Set Short-Term PITR retention to `3,650` days (`10 years`) and grant developers Subscription Contributor to prevent backup deletion
- C. Configure an Azure SQL Long-Term Retention (`LTR`) policy (`WeeklyRetention`, `MonthlyRetention`, `YearlyRetention`, `WeekOfYear`) up to 10 years
- D. Enable and lock time-based immutability (`WORM`) on the LTR backup policy so nobody can shorten retention or delete compliance backups early
- E. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases

### 80. You reduce an Azure SQL Database's Differential backup interval from `24 hours` to `12 hours` (`Set-AzSqlDatabaseBackupShortTermRetentionPolicy -DiffBackupIntervalInHours 12`). What operational trade-off does `12 hours` versus `24 hours` optimize?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Azure SQL Database vCore Serverless compute tier with Auto-pause delay enabled
- B. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas
- C. Long-Term Retention (`LTR`) weekly/monthly/yearly backups up to `10 years` protected by a locked time-based immutable (`WORM`) policy and `RA-GRS` / `ZRS` backup storage
- D. Set Short-Term PITR retention to `3,650` days (`10 years`) and grant developers Subscription Contributor to prevent backup deletion

### 81. You script T-SQL `BACKUP DATABASE` on a dedicated 4.5 TB SQL Server 2022 Azure VM directly to Azure Blob Storage without SAS secrets. Which two configurations are required? Select two.

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Place `tempdb` data and log files (8 equal-sized `.mdf`/`.ndf` files) on the ephemeral local NVMe SSD volume with a startup folder-creation script
- B. Create a SQL Server `CREDENTIAL` (`IDENTITY = 'Managed Identity'` or `'SHARED ACCESS SIGNATURE'`) matching the Azure Blob container URL
- C. Stripe `BACKUP DATABASE` across multiple `TO URL = 'https://...bak'` block blob targets with `COMPRESSION` and `MAXTRANSFERSIZE = 4194304`
- D. Back up a 6 TB database to a single unstriped Azure Page Blob URL (`WITH CREDENTIAL` omitted) using anonymous public container access
- E. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections

### 82. In SQL Server 2022 (`16.x`), in addition to Azure Blob Storage (`https://<account>.blob.core.windows.net/...`), which new `s3://` URL prefix protocol does `BACKUP DATABASE ... TO URL` natively support for hybrid/multicloud object storage?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Download and run standalone Microsoft Data Migration Assistant (`DMA`) with Stretch Database enabled for warm archive tables
- B. Back up a 6 TB database to a single unstriped Azure Page Blob URL (`WITH CREDENTIAL` omitted) using anonymous public container access
- C. Striped T-SQL `BACKUP DATABASE ... TO URL = ...` across up to 64 block blobs (`MAXTRANSFERSIZE`, `COMPRESSION`) authenticated via `Managed Identity` or `SHARED ACCESS SIGNATURE` Credential
- D. Create a transactionally consistent database copy (`CREATE DATABASE ... AS COPY OF`), export `.bacpac` via `SqlPackage`, then remove the copy

### 83. You place `StackBeacon`'s primary North America server and Europe DR server into Failover Group `fog-stackbeacon`. Which two settings ensure automatic connection redirection and safe automatic failover timing? Select two.

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Connect OLTP write traffic to `<fog>.database.windows.net` and read-only analytics to `<fog>.secondary.database.windows.net`
- B. Place `tempdb` data and log files (8 equal-sized `.mdf`/`.ndf` files) on the ephemeral local NVMe SSD volume with a startup folder-creation script
- C. Configure `ReadWriteFailoverPolicy = Automatic` with `GracePeriodWithDataLossHours >= 1` so transient blips do not trigger premature lossy failover
- D. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- E. Rely solely on Geo-Restore from `RA-GRS` automated backups to meet a 5-second RPO and 60-second automatic failover RTO SLA

### 84. Why do many cloud DBAs prefer a **Distributed Network Name (`DNN`)** listener (port `6789` / custom port or multi-subnet IPs) over an **Azure Internal Load Balancer (`ILB`)** listener for Always On Availability Groups on SQL Server Azure VMs?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Azure SQL Database vCore Serverless compute tier with Auto-pause delay enabled
- B. Always On Availability Group on Azure VMs using WSFC with Azure Cloud Witness, Distributed Network Name (`DNN`) or Internal Load Balancer (`ILB` port `59999`), and `MultiSubnetFailover=True`
- C. Deploy a 2-node Always On Availability Group in a single Availability Set without any quorum witness and block TCP `59999` on the NSG
- D. SQL database in Microsoft Fabric (`Database` workload with automatic OneLake Delta mirroring)

### 85. On a 3-replica Always On Availability Group (`Node1` Primary, `Node2` Sync Secondary, `Node3` Read-Only Reporting Secondary), which AG configuration routes `ApplicationIntent=ReadOnly` connections to `Node3` normally and automatically falls back to `Node2` if `Node3` goes offline?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Place SQL Server `.mdf`, `.ldf`, and `tempdb` files together on the Azure VM OS disk (`C:`) with `ReadWrite` host caching
- B. Always On Availability Group on Azure VMs using WSFC with Azure Cloud Witness, Distributed Network Name (`DNN`) or Internal Load Balancer (`ILB` port `59999`), and `MultiSubnetFailover=True`
- C. Deploy a 2-node Always On Availability Group in a single Availability Set without any quorum witness and block TCP `59999` on the NSG
- D. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections

### 86. When deploying an Always On Failover Cluster Instance (`FCI`) on Azure VMs using **Azure Premium Files (`SMB`)** instead of Azure Shared Disks, where must `tempdb` be placed if local ephemeral `D:` is used?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Azure SQL Database Hyperscale tier with compute-isolated Named Replicas
- B. Always On Failover Cluster Instance (`FCI`) on Azure VMs backed by `ZRS` Premium SSD Azure Shared Disks (or `S2D`), or Log Shipping (`BACKUP LOG` -> copy -> `RESTORE LOG WITH NORECOVERY`/`STANDBY`)
- C. Place SQL Server `.mdf`, `.ldf`, and `tempdb` files together on the Azure VM OS disk (`C:`) with `ReadWrite` host caching
- D. SQL database in Microsoft Fabric (`Database` workload with automatic OneLake Delta mirroring)

### 87. In T-SQL Log Shipping, which stored procedure on the **Monitor** or **Secondary** server raises Error `14421` whenever the time since the last restored `.trn` log exceeds `@restore_threshold` (e.g., 45 minutes): `sys.sp_check_log_shipping_monitor_alert`?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Azure SQL Database vCore Serverless compute tier with Auto-pause delay enabled
- B. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- C. Rely solely on Geo-Restore from `RA-GRS` automated backups to meet a 5-second RPO and 60-second automatic failover RTO SLA
- D. Always On Failover Cluster Instance (`FCI`) on Azure VMs backed by `ZRS` Premium SSD Azure Shared Disks (or `S2D`), or Log Shipping (`BACKUP LOG` -> copy -> `RESTORE LOG WITH NORECOVERY`/`STANDBY`)

### 88. On an Always On Availability Group spanning East US and West Europe over a 90 ms WAN link, `sys.dm_hadr_database_replica_states` shows `log_send_queue_size` climbing steadily to `12 GB` while `redo_queue_size = 0 KB`. What is causing the lag?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Deploy a 2-node Always On Availability Group in a single Availability Set without any quorum witness and block TCP `59999` on the NSG
- B. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- C. Query `sys.dm_hadr_database_replica_states` (`synchronization_state_desc`, `log_send_queue_size`, `redo_queue_size`) and `sys.dm_geo_replication_link_status`, plus verify NSG probe port `59999`
- D. Add `WITH (NOLOCK)` or `READ UNCOMMITTED` table hints to every financial and clinical `SELECT` query to eliminate blocking

---

## Case study — CloudSlate Billing

CloudSlate Billing consolidates smaller SaaS tenants into a shared Azure SQL Database table keyed by `TenantId`. Application queries use a shared Managed Identity connection pool yet must never read or insert another tenant's rows, and a billing microservice needs lightweight incremental row-change sync.

The next 3 questions refer to **CloudSlate Billing**. Read the scenario brief once, then answer each item independently.

### 89. You classify `TenantBankRouting` and `TaxVatNumber` with `ADD SENSITIVITY CLASSIFICATION` and stream Azure SQL Auditing to Log Analytics. Which column in `AzureDiagnostics` lets KQL queries filter specifically for touches on classified columns?

Domain: Implement a secure environment

- A. SQL Data Discovery & Classification (`ADD SENSITIVITY CLASSIFICATION`) integrated with Azure SQL Auditing to Log Analytics / immutable Storage
- B. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7
- C. Change Tracking (`CHANGETABLE(CHANGES ...)`) for lightweight net PK sync; Change Data Capture (`sys.sp_cdc_enable_table`) for full intermediate before/after history
- D. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas

### 90. Which feature (`SELECT * FROM ____(CHANGES Billing.Invoices, @last_version) AS CT`) gives the billing microservice lightweight incremental primary-key row-change synchronization with minimal storage and log overhead?

Domain: Implement a secure environment

- A. Enable Change Data Capture (`CDC`) on DTU `Basic`/`S0–S2` databases or expect Change Tracking (`CT`) to retain every intermediate `UPDATE` value
- B. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas
- C. Change Tracking (`CHANGETABLE(CHANGES ...)`) for lightweight net PK sync; Change Data Capture (`sys.sp_cdc_enable_table`) for full intermediate before/after history
- D. Database-level IP firewall rules (`sys.sp_set_database_firewall_rule`) stored inside the user database

### 91. Shared Managed Identity connections pool across tenants in `Invoices` (`TenantId`). Which three Row-Level Security components prevent any session from reading or inserting another tenant's rows? Select three.

Domain: Implement a secure environment

- A. Add a `FILTER PREDICATE` in `CREATE SECURITY POLICY` to hide non-matching rows silently from `SELECT`, `UPDATE`, and `DELETE`
- B. Add `AFTER INSERT` and `AFTER UPDATE` / `BEFORE UPDATE` `BLOCK PREDICATE` clauses in `CREATE SECURITY POLICY` (`STATE = ON`)
- C. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas
- D. Create an inline table-valued function `WITH SCHEMABINDING` evaluating `SESSION_CONTEXT()` or `DATABASE_PRINCIPAL_ID()`
- E. Add server-level firewall rule `0.0.0.0` to `255.255.255.255` and disable TLS encryption on client connections
- F. Truncate or `DELETE` historical rows from an append-only Ledger table (`LEDGER = ON (APPEND_ONLY = ON)`) to purge audit history in place

---

## Case study — MetricLoom SaaS

MetricLoom SaaS monitors 120 Azure SQL Databases centrally in Log Analytics. Automated AI anomaly detection must pinpoint query regressions and locking storms, parallel OLTP queries suffer heavy `CXPACKET` waits on a 32-vCore database, and weekly corruption checks must avoid production I/O spikes.

The next 3 questions refer to **MetricLoom SaaS**. Read the scenario brief once, then answer each item independently.

### 92. Which Azure Monitor Diagnostic Settings category must be streamed to Log Analytics so automated AI anomaly detection pinpoints query regressions, locking storms, and `MAXDOP` pressure across all 120 databases?

Domain: Monitor, configure, and optimize database resources

- A. Back up the TDE encryption certificate and private key (`BACKUP CERTIFICATE ... WITH PRIVATE KEY`) from `master` before restoring onto another SQL Server
- B. Database-level IP firewall rules (`sys.sp_set_database_firewall_rule`) stored inside the user database
- C. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7
- D. Azure Monitor Diagnostic Settings streaming `SQLInsights`, `QueryStoreRuntimeStatistics`, `Errors`, and `Blocks` to a Log Analytics workspace (`KQL`)

### 93. Parallel OLTP point-lookup queries on the 32-vCore database suffer heavy `CXPACKET` and `CXCONSUMER` waits. Which DMV confirms top wait types and which configuration mitigates excessive OLTP parallelism?

Domain: Monitor, configure, and optimize database resources

- A. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- B. Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas
- C. Attach legacy SQL Server Profiler GUI (`sp_trace_create`) interactively against peak production OLTP servers 24x7
- D. Query `sys.dm_os_wait_stats` / `sys.dm_db_wait_stats`, `sys.dm_exec_requests`, `sys.dm_tran_locks`, and `sys.dm_db_tempdb_space_usage`

### 94. You standardize automated maintenance across all 120 SaaS databases so index rebuilds pause gracefully, stats updates never stall OLTP compiles, and weekly corruption checks avoid production I/O storms. Which three practices should you enforce? Select three.

Domain: Monitor, configure, and optimize database resources

- A. Run `DBCC FREEPROCCACHE` every 5 minutes via a cron job and disable `AUTO_CREATE_STATISTICS` across the database
- B. Enable `AUTO_UPDATE_STATISTICS_ASYNC = ON` and schedule targeted `UPDATE STATISTICS` jobs so user queries do not stall waiting on sampling
- C. Create 25 overlapping single-column nonclustered indexes on every table column and rebuild all indexes with `ONLINE = OFF` at noon
- D. Run `ALTER INDEX ... REBUILD WITH (ONLINE = ON, RESUMABLE = ON, MAX_DURATION = 90 MINUTES)` for heavily fragmented (`>30%`) indexes
- E. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- F. Run `DBCC CHECKDB WITH PHYSICAL_ONLY` during off-peak windows or offload full `DBCC CHECKDB` onto a restored backup replica

---

## Case study — StackBeacon Ops

StackBeacon Ops executes T-SQL schema rollouts and index maintenance across 480 Azure SQL Databases without storing SQL passwords, scales Elastic Pool vCores up at 07:00 UTC and down at 20:00 UTC via serverless runbooks, and serves low-latency read replicas in four global continents.

The next 3 questions refer to **StackBeacon Ops**. Read the scenario brief once, then answer each item independently.

### 95. Which native Azure SQL feature executes T-SQL schema rollouts and index maintenance across all 480 tenant databases passwordlessly without storing SQL logins?

Domain: Configure and manage automation of tasks

- A. Start the built-in `SQLServerAgent` Windows service inside a single Azure SQL Database and store target server passwords in a public GitHub repo
- B. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- C. Download and run standalone Microsoft Data Migration Assistant (`DMA`) with Stretch Database enabled for warm archive tables
- D. Azure SQL Database Elastic Job Agent (`jobs.sp_add_job`) authenticating to Target Groups across servers/pools via a User-Assigned Managed Identity (`UAMI`)

### 96. Which serverless Azure automation pattern (`Connect-AzAccount -____; Set-AzSqlElasticPool ...`) scales Elastic Pool vCores up at 07:00 UTC and down at 20:00 UTC daily without managing VMs or storing client secrets?

Domain: Configure and manage automation of tasks

- A. Enable Mixed Mode, share the `sa` login password in plaintext pipeline variables, and add monitoring users to `sysadmin`
- B. Azure Automation PowerShell / Python runbooks (or Azure Functions / Logic Apps) using a System-Assigned Managed Identity on a recurring schedule
- C. Schedule nightly `DBCC SHRINKDATABASE` and `AUTO_SHRINK = ON` across all production OLTP databases
- D. Start the built-in `SQLServerAgent` Windows service inside a single Azure SQL Database and store target server passwords in a public GitHub repo

### 97. Which Azure SQL Database replication feature provides low-latency read-only replicas simultaneously across **four** global continents (`North America`, `Europe`, `Asia`, `Australia`)?

Domain: Plan and configure a high availability and disaster recovery (HA/DR) environment

- A. Rely solely on Geo-Restore from `RA-GRS` automated backups to meet a 5-second RPO and 60-second automatic failover RTO SLA
- B. Failover Groups for automatic multi-database failover behind stable `<fog>.database.windows.net` / `.secondary` listeners vs Active Geo-Replication for up to 4 readable secondaries
- C. Azure SQL Database DTU `Basic` or `Standard S0` tier with a single shared primary replica
- D. Azure SQL Database vCore Serverless compute tier with Auto-pause delay enabled

---

## Case study — TenantHive CRM

TenantHive CRM hosts 480 customer databases with staggered regional peak hours in Azure SQL Database. No single noisy tenant may monopolize compute, an application routing directory must map `TenantId` keys to individual shards, and large enterprise tenants are migrating online from SQL Server VMs via blob logs.

The next 3 questions refer to **TenantHive CRM**. Read the scenario brief once, then answer each item independently.

### 98. Which Azure SQL Database deployment model shares compute efficiently across the 480 staggered customer databases while enforcing strict per-tenant max vCore ceilings against noisy neighbors?

Domain: Plan and implement data platform resources

- A. SQL Server on Azure Virtual Machines (`Ebdsv5` series) with full OS and engine version control
- B. Azure SQL Database vCore Serverless compute tier with Auto-pause delay enabled
- C. Azure SQL Database DTU `Basic` or `Standard S0` tier with a single shared primary replica
- D. Azure SQL Database vCore Elastic Pool with per-database min and max vCore limits

### 99. Which Elastic Database component maintains the application routing directory mapping discrete `TenantId` GUIDs (`ListShardMap`) to individual shard connection strings across the 480 databases?

Domain: Plan and implement data platform resources

- A. Horizontal sharding using the Elastic Database Client Library (`ShardMapManager` with `ListShardMap` or `RangeShardMap`)
- B. Evaluate `sp_estimate_data_compression_savings` and apply `ROW`, `PAGE`, or `COLUMNSTORE_ARCHIVE` compression per partition
- C. Azure SQL Database DTU `Basic` or `Standard S0` tier with a single shared primary replica
- D. Table partitioning using `CREATE PARTITION FUNCTION ... AS RANGE RIGHT` with aligned indexes and `ALTER TABLE ... SWITCH`

### 100. Enterprise tenants are migrating online from SQL Server VMs into SQL Managed Instance by continuously staging `.bak` and `.trn` log files in Azure Blob Storage via `Start-AzSqlInstanceDatabase____`. Which online migration service replays those Blob logs until final cutover?

Domain: Plan and implement data platform resources

- A. Expect online bidirectional planned failback from Azure SQL Managed Instance directly back to on-premises SQL Server 2016 without downtime
- B. Log Replay Service (`LRS`) streaming Full, Differential, and Tail-Log backups from Azure Blob Storage into SQL Managed Instance
- C. Download and run standalone Microsoft Data Migration Assistant (`DMA`) with Stretch Database enabled for warm archive tables
- D. Create a transactionally consistent database copy (`CREATE DATABASE ... AS COPY OF`), export `.bacpac` via `SqlPackage`, then remove the copy

---

## Answer key and explanations

### Question 1 — D

Answer: Azure SQL Managed Instance (Next-gen General Purpose) with decoupled IOPS and storage sliders. Azure SQL Managed Instance supports `msdb` SQL Agent, SQL-to-SQL Linked Servers, and instance-scoped cross-database objects without guest OS management. SQL Managed Instance provides near-100% SQL Server engine compatibility (cross-DB queries, SQL Agent, CLR, Service Broker), and Next-gen GP scales IOPS independently of storage up to 500 DBs. Local study-map skill 1.1 (Recommend an Azure SQL Offering (SQL Database, SQL Managed Instance, or SQL Server on Azure VMs)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Compare Azure SQL Database, Azure SQL Managed Instance, and SQL Server on Azure VMs (https://learn.microsoft.com/en-us/azure/azure-sql/azure-sql-iaas-vs-paas-what-is-overview).

- **A:** Incorrect for this requirement. Hyperscale scales up to 100 TB via distributed page servers, performs constant-time log restores, and attaches up to 30 Named Replicas with independent vCore compute over shared storage. Why the keyed choice wins: Azure SQL Managed Instance supports `msdb` SQL Agent, SQL-to-SQL Linked Servers, and instance-scoped cross-database objects without guest OS management.
- **B:** Incorrect for this requirement. Serverless auto-scales compute between configured min and max vCores per second and pauses compute billing during idle periods (minimum 1-hour auto-pause delay), charging only storage. Why the keyed choice wins: Azure SQL Managed Instance supports `msdb` SQL Agent, SQL-to-SQL Linked Servers, and instance-scoped cross-database objects without guest OS management.
- **C:** Incorrect for this requirement. SQL database in Microsoft Fabric runs the Azure SQL engine for OLTP with Microsoft Entra-only auth, automatic near-real-time OneLake Delta Parquet replication, and a read-only SQL analytics endpoint. Why the keyed choice wins: Azure SQL Managed Instance supports `msdb` SQL Agent, SQL-to-SQL Linked Servers, and instance-scoped cross-database objects without guest OS management.
- **D:** Correct. SQL Managed Instance provides near-100% SQL Server engine compatibility (cross-DB queries, SQL Agent, CLR, Service Broker), and Next-gen GP scales IOPS independently of storage up to 500 DBs. In this scenario: Azure SQL Managed Instance supports `msdb` SQL Agent, SQL-to-SQL Linked Servers, and instance-scoped cross-database objects without guest OS management.

### Question 2 — B, D

Answers: Create a dedicated VNet subnet (`/28` or larger) with no other cloud resources and delegate it to `Microsoft.Sql/managedInstances`; Associate a User-Defined Route (`UDR`) table (`0.0.0.0/0` -> `Internet` for management plane) and required NSG rules with the SQL MI subnet. Provision a dedicated empty `/28+` subnet delegated to `Microsoft.Sql/managedInstances`, and attach a compliant User-Defined Route (`UDR`) table and NSG. Local study-map skill 1.2 (Choose Automated Deployment Methods and Deploy SQL Offerings Across Windows, Linux, and Containers), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Automated deployment options for Azure SQL and SQL Server on Linux/containers (https://learn.microsoft.com/en-us/azure/azure-sql/database/arm-templates-content-guide).

- **A:** Incorrect for this requirement. Placing database or log files on `C:` or enabling `ReadWrite` caching risks data corruption during host crashes and exhausts OS disk IOPS caps. Why the keyed choice wins: Provision a dedicated empty `/28+` subnet delegated to `Microsoft.Sql/managedInstances`, and attach a compliant User-Defined Route (`UDR`) table and NSG.
- **B:** Correct. Azure SQL Managed Instance requires an exclusive subnet delegated to `Microsoft.Sql/managedInstances` sized for current and future instance vCore/node counts. In this scenario: Provision a dedicated empty `/28+` subnet delegated to `Microsoft.Sql/managedInstances`, and attach a compliant User-Defined Route (`UDR`) table and NSG.
- **C:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Provision a dedicated empty `/28+` subnet delegated to `Microsoft.Sql/managedInstances`, and attach a compliant User-Defined Route (`UDR`) table and NSG.
- **D:** Correct. SQL Managed Instance requires an explicit route table and NSG bound to its delegated subnet so Azure management traffic is never blackholed by forced tunneling. In this scenario: Provision a dedicated empty `/28+` subnet delegated to `Microsoft.Sql/managedInstances`, and attach a compliant User-Defined Route (`UDR`) table and NSG.
- **E:** Incorrect for this requirement. Azure Arc allows variable-workload or seasonal SQL Server hosts outside Azure to be billed hourly through an Azure subscription. Why the keyed choice wins: Provision a dedicated empty `/28+` subnet delegated to `Microsoft.Sql/managedInstances`, and attach a compliant User-Defined Route (`UDR`) table and NSG.

### Question 3 — A

Answer: SQL Server on Linux configured via `mssql-conf` or Linux container images for consistent CI/CD dev-test parity. On Linux hosts and container derivatives, `mssql-conf` configures SQL Server engine memory, network ports, trace flags, Entra auth, and Agent status. `mssql-conf` configures memory, trace flags, Entra auth, and HA on Linux SQL Server VMs, while official Linux container images spin up fast disposable SQL instances in CI pipelines. Local study-map skill 1.2 (Choose Automated Deployment Methods and Deploy SQL Offerings Across Windows, Linux, and Containers), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Automated deployment options for Azure SQL and SQL Server on Linux/containers (https://learn.microsoft.com/en-us/azure/azure-sql/database/arm-templates-content-guide).

- **A:** Correct. `mssql-conf` configures memory, trace flags, Entra auth, and HA on Linux SQL Server VMs, while official Linux container images spin up fast disposable SQL instances in CI pipelines. In this scenario: On Linux hosts and container derivatives, `mssql-conf` configures SQL Server engine memory, network ports, trace flags, Entra auth, and Agent status.
- **B:** Incorrect for this requirement. Azure Arc projects on-premises and multicloud SQL Server instances into Azure for Resource Graph inventory, automated Best Practices Assessments, Entra auth (SQL 2022+), Defender, and PAYG billing. Why the keyed choice wins: On Linux hosts and container derivatives, `mssql-conf` configures SQL Server engine memory, network ports, trace flags, Entra auth, and Agent status.
- **C:** Incorrect for this requirement. Hyperscale scales up to 100 TB via distributed page servers, performs constant-time log restores, and attaches up to 30 Named Replicas with independent vCore compute over shared storage. Why the keyed choice wins: On Linux hosts and container derivatives, `mssql-conf` configures SQL Server engine memory, network ports, trace flags, Entra auth, and Agent status.
- **D:** Incorrect for this requirement. Business Critical SQL MI uses local NVMe SSDs on an Always On availability group quorum for lowest I/O latency, highest IOPS, and one free readable secondary replica. Why the keyed choice wins: On Linux hosts and container derivatives, `mssql-conf` configures SQL Server engine memory, network ports, trace flags, Entra auth, and Agent status.

### Question 4 — A, C, E

Answers: Query fleet-wide SQL Server version, edition, and backup status across hybrid servers via Azure Resource Graph Explorer; Enable automated SQL Best Practices Assessments and Microsoft Defender for SQL via the Azure Arc SQL Server extension; Switch eligible hybrid SQL Server instances to hourly Azure Arc pay-as-you-go billing instead of upfront core licenses. SQL Server enabled by Azure Arc delivers cross-cloud KQL inventory in Azure Resource Graph, automated SQL Best Practices Assessments + Defender for SQL, and hourly pay-as-you-go billing. Local study-map skill 1.3 (Identify Use Cases for SQL Server Enabled by Azure Arc and SQL Database in Microsoft Fabric), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Server enabled by Azure Arc and SQL database in Microsoft Fabric (https://learn.microsoft.com/en-us/fabric/database/sql/overview).

- **A:** Correct. The Azure Extension for SQL Server runs recurring configuration assessments against Microsoft Support rules and integrates Defender vulnerability/threat detection. In this scenario: SQL Server enabled by Azure Arc delivers cross-cloud KQL inventory in Azure Resource Graph, automated SQL Best Practices Assessments + Defender for SQL, and hourly pay-as-you-go billing.
- **B:** Incorrect for this requirement. SQL database in Microsoft Fabric enforces Microsoft Entra authentication exclusively (SQL logins are unsupported) and manages backups/OneLake mirroring automatically as SaaS. Why the keyed choice wins: SQL Server enabled by Azure Arc delivers cross-cloud KQL inventory in Azure Resource Graph, automated SQL Best Practices Assessments + Defender for SQL, and hourly pay-as-you-go billing.
- **C:** Correct. SQL Server enabled by Azure Arc projects on-premises and multicloud instance metadata into Azure Resource Manager for KQL-based Azure Resource Graph inventory queries. In this scenario: SQL Server enabled by Azure Arc delivers cross-cloud KQL inventory in Azure Resource Graph, automated SQL Best Practices Assessments + Defender for SQL, and hourly pay-as-you-go billing.
- **D:** Incorrect for this requirement. Both standalone Data Migration Assistant (retired July 2025) and SQL Server Stretch Database (retired) are deprecated; use Azure Migrate / Azure SQL Migration extension and partitioning/Fabric/Blob tiering. Why the keyed choice wins: SQL Server enabled by Azure Arc delivers cross-cloud KQL inventory in Azure Resource Graph, automated SQL Best Practices Assessments + Defender for SQL, and hourly pay-as-you-go billing.
- **E:** Correct. Azure Arc allows variable-workload or seasonal SQL Server hosts outside Azure to be billed hourly through an Azure subscription. In this scenario: SQL Server enabled by Azure Arc delivers cross-cloud KQL inventory in Azure Resource Graph, automated SQL Best Practices Assessments + Defender for SQL, and hourly pay-as-you-go billing.
- **F:** Incorrect for this requirement. Placing database or log files on `C:` or enabling `ReadWrite` caching risks data corruption during host crashes and exhausts OS disk IOPS caps. Why the keyed choice wins: SQL Server enabled by Azure Arc delivers cross-cloud KQL inventory in Azure Resource Graph, automated SQL Best Practices Assessments + Defender for SQL, and hourly pay-as-you-go billing.

### Question 5 — C, D

Answers: Authenticate applications and users exclusively with Microsoft Entra ID identities, service principals, or workspace roles; Query automatically replicated OneLake Delta Parquet tables and the read-only SQL analytics endpoint from Spark and Direct Lake. SQL database in Microsoft Fabric enforces Microsoft Entra-only authentication and automatically replicates operational tables into OneLake as Delta Parquet with a SQL analytics endpoint. Local study-map skill 1.3 (Identify Use Cases for SQL Server Enabled by Azure Arc and SQL Database in Microsoft Fabric), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Server enabled by Azure Arc and SQL database in Microsoft Fabric (https://learn.microsoft.com/en-us/fabric/database/sql/overview).

- **A:** Incorrect for this requirement. Local ephemeral NVMe storage delivers ultra-low latency for `tempdb` spills and version stores without consuming remote disk IOPS bandwidth. Why the keyed choice wins: SQL database in Microsoft Fabric enforces Microsoft Entra-only authentication and automatically replicates operational tables into OneLake as Delta Parquet with a SQL analytics endpoint.
- **B:** Incorrect for this requirement. SQL database in Microsoft Fabric enforces Microsoft Entra authentication exclusively (SQL logins are unsupported) and manages backups/OneLake mirroring automatically as SaaS. Why the keyed choice wins: SQL database in Microsoft Fabric enforces Microsoft Entra-only authentication and automatically replicates operational tables into OneLake as Delta Parquet with a SQL analytics endpoint.
- **C:** Correct. SQL database in Microsoft Fabric relies exclusively on Microsoft Entra authentication and workspace/item permissions rather than SQL logins. In this scenario: SQL database in Microsoft Fabric enforces Microsoft Entra-only authentication and automatically replicates operational tables into OneLake as Delta Parquet with a SQL analytics endpoint.
- **D:** Correct. Every SQL database in Microsoft Fabric automatically mirrors operational tables into OneLake in Delta Parquet format and exposes a SQL analytics endpoint. In this scenario: SQL database in Microsoft Fabric enforces Microsoft Entra-only authentication and automatically replicates operational tables into OneLake as Delta Parquet with a SQL analytics endpoint.
- **E:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: SQL database in Microsoft Fabric enforces Microsoft Entra-only authentication and automatically replicates operational tables into OneLake as Delta Parquet with a SQL analytics endpoint.

### Question 6 — D

Answer: SPLIT partition function for incoming future boundary → Create empty staging table on same filegroup with matching schema/indexes → ALTER TABLE ... SWITCH oldest partition to staging → Archive staging data & MERGE retired boundary. Split the incoming future boundary first, create an index- and filegroup-aligned empty staging table, run metadata-only `ALTER TABLE ... SWITCH`, and merge the retired oldest boundary. Sliding-window partitioning splits a new empty future range first, performs a metadata-only `ALTER TABLE ... SWITCH` into an aligned staging table, and merges the retired boundary. Local study-map skill 1.4 (Plan for Table Partitioning (`RANGE RIGHT` / `SWITCH`) and Horizontal Database Sharding (`ShardMapManager`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Table partitioning and scaling out with Azure SQL Database sharding (https://learn.microsoft.com/en-us/azure/azure-sql/database/elastic-scale-introduction).

- **A:** Incorrect for this requirement. Incorrect workflow: `ALTER TABLE ... SWITCH` swaps metadata between two tables in the same database/filegroup rather than writing directly to Azure Blob Storage. Why the keyed choice wins: Split the incoming future boundary first, create an index- and filegroup-aligned empty staging table, run metadata-only `ALTER TABLE ... SWITCH`, and merge the retired oldest boundary.
- **B:** Incorrect for this requirement. Incorrect workflow: row-by-row `DELETE` bloats the transaction log and locks tables, and `SWITCH` fails if the staging table resides on a different filegroup or lacks aligned indexes. Why the keyed choice wins: Split the incoming future boundary first, create an index- and filegroup-aligned empty staging table, run metadata-only `ALTER TABLE ... SWITCH`, and merge the retired oldest boundary.
- **C:** Incorrect for this requirement. Incorrect workflow: `SWITCH` is strictly an intra-database metadata operation requiring identical schema, filegroup alignment, and trusted constraints—never cross-database. Why the keyed choice wins: Split the incoming future boundary first, create an index- and filegroup-aligned empty staging table, run metadata-only `ALTER TABLE ... SWITCH`, and merge the retired oldest boundary.
- **D:** Correct. Sliding-window partitioning splits a new empty future range first, performs a metadata-only `ALTER TABLE ... SWITCH` into an aligned staging table, and merges the retired boundary. In this scenario: Split the incoming future boundary first, create an index- and filegroup-aligned empty staging table, run metadata-only `ALTER TABLE ... SWITCH`, and merge the retired oldest boundary.

### Question 7 — C

Answer: SQL IaaS Agent Extension in Full management mode paired with Azure Update Manager / Automated Patching. Registering the VMs with the SQL IaaS Agent Extension (`Full` mode) paired with Azure Update Manager / Automated Patching manages licensing, backups, and maintenance-window patching. The SQL IaaS Agent Extension unlocks portal license conversion (AHB/PAYG), Automated Backup, Automated Patching windows, Key Vault integration, and storage pool management on SQL VMs. Local study-map skill 1.5 (Deploy Hybrid SQL Server Solutions and Manage Patching (`SQL IaaS Agent Extension` & `Azure Update Manager`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Server IaaS Agent Extension, Automated Patching, and Azure Update Manager (https://learn.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/sql-agent-extension-manually-register-single-vm).

- **A:** Incorrect for this requirement. Serverless auto-scales compute between configured min and max vCores per second and pauses compute billing during idle periods (minimum 1-hour auto-pause delay), charging only storage. Why the keyed choice wins: Registering the VMs with the SQL IaaS Agent Extension (`Full` mode) paired with Azure Update Manager / Automated Patching manages licensing, backups, and maintenance-window patching.
- **B:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Registering the VMs with the SQL IaaS Agent Extension (`Full` mode) paired with Azure Update Manager / Automated Patching manages licensing, backups, and maintenance-window patching.
- **C:** Correct. The SQL IaaS Agent Extension unlocks portal license conversion (AHB/PAYG), Automated Backup, Automated Patching windows, Key Vault integration, and storage pool management on SQL VMs. In this scenario: Registering the VMs with the SQL IaaS Agent Extension (`Full` mode) paired with Azure Update Manager / Automated Patching manages licensing, backups, and maintenance-window patching.
- **D:** Incorrect for this requirement. SQL database in Microsoft Fabric runs the Azure SQL engine for OLTP with Microsoft Entra-only auth, automatic near-real-time OneLake Delta Parquet replication, and a read-only SQL analytics endpoint. Why the keyed choice wins: Registering the VMs with the SQL IaaS Agent Extension (`Full` mode) paired with Azure Update Manager / Automated Patching manages licensing, backups, and maintenance-window patching.

### Question 8 — C

Answer: SQL Server enabled by Azure Arc (`Microsoft.AzureArcData/sqlServerInstances`). Use Azure Arc-enabled servers `Run Command` (over outbound HTTPS `443` via the Connected Machine agent) alongside Azure Resource Graph inventory to gather compliance telemetry centrally. Azure Arc projects on-premises and multicloud SQL Server instances into Azure for Resource Graph inventory, automated Best Practices Assessments, Entra auth (SQL 2022+), Defender, and PAYG billing. Local study-map skill 1.5 (Deploy Hybrid SQL Server Solutions and Manage Patching (`SQL IaaS Agent Extension` & `Azure Update Manager`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Server IaaS Agent Extension, Automated Patching, and Azure Update Manager (https://learn.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/sql-agent-extension-manually-register-single-vm).

- **A:** Incorrect for this requirement. Both standalone Data Migration Assistant (retired July 2025) and SQL Server Stretch Database (retired) are deprecated; use Azure Migrate / Azure SQL Migration extension and partitioning/Fabric/Blob tiering. Why the keyed choice wins: Use Azure Arc-enabled servers `Run Command` (over outbound HTTPS `443` via the Connected Machine agent) alongside Azure Resource Graph inventory to gather compliance telemetry centrally.
- **B:** Incorrect for this requirement. Elastic Pools share a pooled vCore/storage envelope across many multi-tenant databases with staggered peaks while capping per-database max vCores to stop noisy-neighbor starvation. Why the keyed choice wins: Use Azure Arc-enabled servers `Run Command` (over outbound HTTPS `443` via the Connected Machine agent) alongside Azure Resource Graph inventory to gather compliance telemetry centrally.
- **C:** Correct. Azure Arc projects on-premises and multicloud SQL Server instances into Azure for Resource Graph inventory, automated Best Practices Assessments, Entra auth (SQL 2022+), Defender, and PAYG billing. In this scenario: Use Azure Arc-enabled servers `Run Command` (over outbound HTTPS `443` via the Connected Machine agent) alongside Azure Resource Graph inventory to gather compliance telemetry centrally.
- **D:** Incorrect for this requirement. SQL database in Microsoft Fabric runs the Azure SQL engine for OLTP with Microsoft Entra-only auth, automatic near-real-time OneLake Delta Parquet replication, and a read-only SQL analytics endpoint. Why the keyed choice wins: Use Azure Arc-enabled servers `Run Command` (over outbound HTTPS `443` via the Connected Machine agent) alongside Azure Resource Graph inventory to gather compliance telemetry centrally.

### Question 9 — B

Answer: Azure SQL Database Hyperscale tier with compute-isolated Named Replicas. Azure SQL Database Hyperscale scales to 100 TB and attaches compute-isolated Named Replicas sharing page-server storage without impacting primary OLTP compute. Hyperscale scales up to 100 TB via distributed page servers, performs constant-time log restores, and attaches up to 30 Named Replicas with independent vCore compute over shared storage. Local study-map skill 1.6 (Configure Azure SQL Database for Scale and Performance (`Serverless`, `Hyperscale` Named Replicas, `Elastic Pools`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Azure SQL Database vCore, Serverless, Hyperscale, and Elastic Pools (https://learn.microsoft.com/en-us/azure/azure-sql/database/service-tiers-vcore).

- **A:** Incorrect for this requirement. DTU Basic supports max 2 GB and Standard S0–S2 max 250 GB without compute-isolated read replicas, making them incapable of hosting multi-TB OLTP workloads. Why the keyed choice wins: Azure SQL Database Hyperscale scales to 100 TB and attaches compute-isolated Named Replicas sharing page-server storage without impacting primary OLTP compute.
- **B:** Correct. Hyperscale scales up to 100 TB via distributed page servers, performs constant-time log restores, and attaches up to 30 Named Replicas with independent vCore compute over shared storage. In this scenario: Azure SQL Database Hyperscale scales to 100 TB and attaches compute-isolated Named Replicas sharing page-server storage without impacting primary OLTP compute.
- **C:** Incorrect for this requirement. SQL Server on Azure VMs (IaaS) provides full OS access, custom third-party drivers, legacy SQL Server version pinning, SSIS/SSRS/SSAS co-hosting, and `Ebdsv5` high remote storage throughput. Why the keyed choice wins: Azure SQL Database Hyperscale scales to 100 TB and attaches compute-isolated Named Replicas sharing page-server storage without impacting primary OLTP compute.
- **D:** Incorrect for this requirement. Serverless auto-scales compute between configured min and max vCores per second and pauses compute billing during idle periods (minimum 1-hour auto-pause delay), charging only storage. Why the keyed choice wins: Azure SQL Database Hyperscale scales to 100 TB and attaches compute-isolated Named Replicas sharing page-server storage without impacting primary OLTP compute.

### Question 10 — A

Answer: Azure SQL Managed Instance Business Critical tier with local SSD storage and built-in read-scale replica. The Business Critical tier of Azure SQL Managed Instance runs on local NVMe SSD storage across a 4-node Always On availability group quorum with one free readable secondary. Business Critical SQL MI uses local NVMe SSDs on an Always On availability group quorum for lowest I/O latency, highest IOPS, and one free readable secondary replica. Local study-map skill 1.7 (Configure Azure SQL Managed Instance for Scale and Performance (`Next-gen GP` Sliders & `Business Critical`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Azure SQL Managed Instance service tiers and Next-gen General Purpose scaling (https://learn.microsoft.com/en-us/azure/azure-sql/managed-instance/sql-managed-instance-paas-overview).

- **A:** Correct. Business Critical SQL MI uses local NVMe SSDs on an Always On availability group quorum for lowest I/O latency, highest IOPS, and one free readable secondary replica. In this scenario: The Business Critical tier of Azure SQL Managed Instance runs on local NVMe SSD storage across a 4-node Always On availability group quorum with one free readable secondary.
- **B:** Incorrect for this requirement. Serverless auto-scales compute between configured min and max vCores per second and pauses compute billing during idle periods (minimum 1-hour auto-pause delay), charging only storage. Why the keyed choice wins: The Business Critical tier of Azure SQL Managed Instance runs on local NVMe SSD storage across a 4-node Always On availability group quorum with one free readable secondary.
- **C:** Incorrect for this requirement. SQL Managed Instance provides near-100% SQL Server engine compatibility (cross-DB queries, SQL Agent, CLR, Service Broker), and Next-gen GP scales IOPS independently of storage up to 500 DBs. Why the keyed choice wins: The Business Critical tier of Azure SQL Managed Instance runs on local NVMe SSD storage across a 4-node Always On availability group quorum with one free readable secondary.
- **D:** Incorrect for this requirement. DTU Basic supports max 2 GB and Standard S0–S2 max 250 GB without compute-isolated read replicas, making them incapable of hosting multi-TB OLTP workloads. Why the keyed choice wins: The Business Critical tier of Azure SQL Managed Instance runs on local NVMe SSD storage across a 4-node Always On availability group quorum with one free readable secondary.

### Question 11 — C

Answer: Premium SSD v2 / striped Premium SSD with `ReadOnly` host caching for data disks, `None` for log disks, and `tempdb` on local NVMe. Set `ReadOnly` host caching on the striped data-disk pool (`.mdf`/`.ndf`), `None` host caching on the transaction log disk (`.ldf`), and place `tempdb` on the ephemeral local NVMe volume. SQL Server Azure VM best practices use `ReadOnly` host caching on `.mdf`/`.ndf` data disks, `None` caching on `.ldf` transaction log disks, and ephemeral NVMe/`D:` storage for `tempdb`. Local study-map skill 1.8 (Configure SQL Server on Azure VMs for Scale and Performance (`ReadOnly`/`None` Host Caching, `tempdb` NVMe, `IFI`/`LPIM`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Performance best practices for SQL Server on Azure Virtual Machines (https://learn.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/performance-guidelines-best-practices-checklist).

- **A:** Incorrect for this requirement. Placing database or log files on `C:` or enabling `ReadWrite` caching risks data corruption during host crashes and exhausts OS disk IOPS caps. Why the keyed choice wins: Set `ReadOnly` host caching on the striped data-disk pool (`.mdf`/`.ndf`), `None` host caching on the transaction log disk (`.ldf`), and place `tempdb` on the ephemeral local NVMe volume.
- **B:** Incorrect for this requirement. SQL Server write-ahead logging performs sequential unbuffered writes; enabling `ReadOnly` or `ReadWrite` host caching on `.ldf` disks degrades throughput or risks corruption. Why the keyed choice wins: Set `ReadOnly` host caching on the striped data-disk pool (`.mdf`/`.ndf`), `None` host caching on the transaction log disk (`.ldf`), and place `tempdb` on the ephemeral local NVMe volume.
- **C:** Correct. SQL Server Azure VM best practices use `ReadOnly` host caching on `.mdf`/`.ndf` data disks, `None` caching on `.ldf` transaction log disks, and ephemeral NVMe/`D:` storage for `tempdb`. In this scenario: Set `ReadOnly` host caching on the striped data-disk pool (`.mdf`/`.ndf`), `None` host caching on the transaction log disk (`.ldf`), and place `tempdb` on the ephemeral local NVMe volume.
- **D:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Set `ReadOnly` host caching on the striped data-disk pool (`.mdf`/`.ndf`), `None` host caching on the transaction log disk (`.ldf`), and place `tempdb` on the ephemeral local NVMe volume.

### Question 12 — A

Answer: No — transaction log managed disks on SQL Server Azure VMs must use host caching `None`, never `ReadOnly` or `ReadWrite`. No — transaction log disks perform sequential write-ahead flushes and do not benefit from read caching; `.ldf` managed disks must always use `caching = "None"`. SQL Server write-ahead logging performs sequential unbuffered writes; enabling `ReadOnly` or `ReadWrite` host caching on `.ldf` disks degrades throughput or risks corruption. Local study-map skill 1.8 (Configure SQL Server on Azure VMs for Scale and Performance (`ReadOnly`/`None` Host Caching, `tempdb` NVMe, `IFI`/`LPIM`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Performance best practices for SQL Server on Azure Virtual Machines (https://learn.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/performance-guidelines-best-practices-checklist).

- **A:** Correct. SQL Server write-ahead logging performs sequential unbuffered writes; enabling `ReadOnly` or `ReadWrite` host caching on `.ldf` disks degrades throughput or risks corruption. In this scenario: No — transaction log disks perform sequential write-ahead flushes and do not benefit from read caching; `.ldf` managed disks must always use `caching = "None"`.
- **B:** Incorrect for this requirement. `SqlPackage` exports tables sequentially rather than at a single LSN, so exporting a live write-heavy database without creating a point-in-time copy produces torn foreign-key state. Why the keyed choice wins: No — transaction log disks perform sequential write-ahead flushes and do not benefit from read caching; `.ldf` managed disks must always use `caching = "None"`.
- **C:** Incorrect for this requirement. Single Azure SQL Databases do not expose `CREATE WORKLOAD GROUP` or Resource Governor; compute isolation in SQL Database uses Elastic Pools, Hyperscale named replicas, or separate DBs. Why the keyed choice wins: No — transaction log disks perform sequential write-ahead flushes and do not benefit from read caching; `.ldf` managed disks must always use `caching = "None"`.
- **D:** Incorrect for this requirement. The proposed solution fails at least one stated technical, security, or availability requirement. Why the keyed choice wins: No — transaction log disks perform sequential write-ahead flushes and do not benefit from read caching; `.ldf` managed disks must always use `caching = "None"`.

### Question 13 — C

Answer: Evaluate `sp_estimate_data_compression_savings` and apply `ROW`, `PAGE`, or `COLUMNSTORE_ARCHIVE` compression per partition. `PAGE` compression includes `ROW` compression plus page-level prefix compression and dictionary compression, dramatically shrinking repeating string prefixes inside OLTP B-tree pages. `sp_estimate_data_compression_savings` models space gains before compressing; `ROW`/`PAGE` shrink OLTP B-trees while `COLUMNSTORE` / `COLUMNSTORE_ARCHIVE` achieves up to 10x analytics compression. Local study-map skill 1.9 (Configure Table Partitioning Alignment and Data Compression (`ROW`, `PAGE`, `COLUMNSTORE`, `COLUMNSTORE_ARCHIVE`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Configure table partitioning and row/page/columnstore data compression (https://learn.microsoft.com/en-us/sql/relational-databases/data-compression/data-compression).

- **A:** Incorrect for this requirement. Over-indexing inflates every `INSERT`/`UPDATE`/`DELETE` write and log flush, while `ONLINE = OFF` holds exclusive schema/table locks that block production traffic. Why the keyed choice wins: `PAGE` compression includes `ROW` compression plus page-level prefix compression and dictionary compression, dramatically shrinking repeating string prefixes inside OLTP B-tree pages.
- **B:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: `PAGE` compression includes `ROW` compression plus page-level prefix compression and dictionary compression, dramatically shrinking repeating string prefixes inside OLTP B-tree pages.
- **C:** Correct. `sp_estimate_data_compression_savings` models space gains before compressing; `ROW`/`PAGE` shrink OLTP B-trees while `COLUMNSTORE` / `COLUMNSTORE_ARCHIVE` achieves up to 10x analytics compression. In this scenario: `PAGE` compression includes `ROW` compression plus page-level prefix compression and dictionary compression, dramatically shrinking repeating string prefixes inside OLTP B-tree pages.
- **D:** Incorrect for this requirement. Row-by-row cursors and multi-statement TVFs under legacy compatibility levels execute thousands of iterative context switches and 1-row cardinality guesses. Why the keyed choice wins: `PAGE` compression includes `ROW` compression plus page-level prefix compression and dictionary compression, dramatically shrinking repeating string prefixes inside OLTP B-tree pages.

### Question 14 — A

Answer: Azure Migrate (`Azure SQL` assessment) and the Azure SQL Migration extension for Azure Data Studio / VS Code. Azure Migrate (`Azure SQL` assessment) and the Azure SQL Migration extension for Azure Data Studio / VS Code replace retired DMA for compatibility and SKU right-sizing. Following Data Migration Assistant (DMA) retirement, Azure Migrate and the Azure SQL Migration extension assess compatibility blockers, feature parity, and performance-based vCore SKU right-sizing. Local study-map skill 1.10 (Evaluate Migration Requirements, Offline vs Online Strategies, and SKU Sizing via Azure Migrate & ADS), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Assess and plan SQL Server migrations using Azure Migrate and Azure SQL Migration extension (https://learn.microsoft.com/en-us/data-migration/sql-server/managed-instance/overview).

- **A:** Correct. Following Data Migration Assistant (DMA) retirement, Azure Migrate and the Azure SQL Migration extension assess compatibility blockers, feature parity, and performance-based vCore SKU right-sizing. In this scenario: Azure Migrate (`Azure SQL` assessment) and the Azure SQL Migration extension for Azure Data Studio / VS Code replace retired DMA for compatibility and SKU right-sizing.
- **B:** Incorrect for this requirement. Both standalone Data Migration Assistant (retired July 2025) and SQL Server Stretch Database (retired) are deprecated; use Azure Migrate / Azure SQL Migration extension and partitioning/Fabric/Blob tiering. Why the keyed choice wins: Azure Migrate (`Azure SQL` assessment) and the Azure SQL Migration extension for Azure Data Studio / VS Code replace retired DMA for compatibility and SKU right-sizing.
- **C:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: Azure Migrate (`Azure SQL` assessment) and the Azure SQL Migration extension for Azure Data Studio / VS Code replace retired DMA for compatibility and SKU right-sizing.
- **D:** Incorrect for this requirement. Without the original TDE certificate and private key restored into the target SQL Server `master` database, a TDE-encrypted `.bak` or detached `.mdf` cannot be decrypted anywhere. Why the keyed choice wins: Azure Migrate (`Azure SQL` assessment) and the Azure SQL Migration extension for Azure Data Studio / VS Code replace retired DMA for compatibility and SKU right-sizing.

### Question 15 — B

Answer: Verify VNet peering & TCP 5022 + 11000-11999 rules → Start online Database Move from source to target SQL MI → Wait for seeding to reach Ready for completion → Complete move within 24 hours so target comes online. Verify VNet peering and TCP `5022` + `11000–11999` NSG rules, start the online Database Move, wait for `Ready for completion`, and manually complete the move within 24 hours. Online SQL MI database move requires bidirectional TCP 5022 and 11000–11999 connectivity, seeds asynchronously until Ready for completion, and must be manually completed within 24 hours. Local study-map skill 1.12 (Implement Azure SQL Managed Instance Online Database Copy and Move (`24h` Completion, `TCP 5022`/`11000-11999`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Copy or move a database online across Azure SQL Managed Instances (https://learn.microsoft.com/en-us/azure/azure-sql/managed-instance/database-copy-move-how-to).

- **A:** Incorrect for this requirement. Incorrect workflow: network ports must be open before seeding, operations uncompleted after 24 hours auto-cancel, and source PITR history never transfers with a moved database. Why the keyed choice wins: Verify VNet peering and TCP `5022` + `11000–11999` NSG rules, start the online Database Move, wait for `Ready for completion`, and manually complete the move within 24 hours.
- **B:** Correct. Online SQL MI database move requires bidirectional TCP 5022 and 11000–11999 connectivity, seeds asynchronously until Ready for completion, and must be manually completed within 24 hours. In this scenario: Verify VNet peering and TCP `5022` + `11000–11999` NSG rules, start the online Database Move, wait for `Ready for completion`, and manually complete the move within 24 hours.
- **C:** Incorrect for this requirement. Incorrect workflow: `.bacpac` files are stored in Blob storage rather than Table storage, the completion window is 24 hours, and Move removes the source DB upon completion. Why the keyed choice wins: Verify VNet peering and TCP `5022` + `11000–11999` NSG rules, start the online Database Move, wait for `Ready for completion`, and manually complete the move within 24 hours.
- **D:** Incorrect for this requirement. Incorrect workflow: `sp_detach_db` is unsupported in Azure SQL Managed Instance and online Database Move replicates via Always On availability group seeding without stopping compute. Why the keyed choice wins: Verify VNet peering and TCP `5022` + `11000–11999` NSG rules, start the online Database Move, wait for `Ready for completion`, and manually complete the move within 24 hours.

### Question 16 — D

Answer: Enable Microsoft Entra-only authentication (`azuread_authentication_only`) on the logical SQL server or SQL Managed Instance. Enabling Microsoft Entra-only authentication (`az sql server ad-only-auth enable` / `azuread_authentication_only`) disables all SQL password logins across the logical SQL server and its databases. Microsoft Entra-only authentication disables legacy SQL Server logins (`sa` and password auth) completely, enforcing centralized MFA, Conditional Access, and token-based Managed Identities. Local study-map skill 2.1 (Configure Microsoft Entra ID and Microsoft Entra-Only Authentication Across SQL DB, SQL MI, and SQL Server), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Configure and manage Microsoft Entra authentication with Azure SQL and SQL Server (https://learn.microsoft.com/en-us/azure/azure-sql/database/authentication-aad-overview).

- **A:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: Enabling Microsoft Entra-only authentication (`az sql server ad-only-auth enable` / `azuread_authentication_only`) disables all SQL password logins across the logical SQL server and its databases.
- **B:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: Enabling Microsoft Entra-only authentication (`az sql server ad-only-auth enable` / `azuread_authentication_only`) disables all SQL password logins across the logical SQL server and its databases.
- **C:** Incorrect for this requirement. Unlike server-level rules stored in `master`, database-level IP firewall rules travel inside the user database across Active Geo-Replication and Failover Group failovers. Why the keyed choice wins: Enabling Microsoft Entra-only authentication (`az sql server ad-only-auth enable` / `azuread_authentication_only`) disables all SQL password logins across the logical SQL server and its databases.
- **D:** Correct. Microsoft Entra-only authentication disables legacy SQL Server logins (`sa` and password auth) completely, enforcing centralized MFA, Conditional Access, and token-based Managed Identities. In this scenario: Enabling Microsoft Entra-only authentication (`az sql server ad-only-auth enable` / `azuread_authentication_only`) disables all SQL password logins across the logical SQL server and its databases.

### Question 17 — D

Answer: Contained database user mapped to a Microsoft Entra security group (`CREATE USER [Group] FROM EXTERNAL PROVIDER`). Running `CREATE USER [id-billing-api] FROM EXTERNAL PROVIDER` creates a contained database user bound to the Workload Identity / Managed Identity in Microsoft Entra ID. Contained Entra group users authenticate directly at the user database without `master` SID mappings, automatically surviving Failover Group / Geo-Replication failovers and onboarding group members. Local study-map skill 2.1 (Configure Microsoft Entra ID and Microsoft Entra-Only Authentication Across SQL DB, SQL MI, and SQL Server), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Configure and manage Microsoft Entra authentication with Azure SQL and SQL Server (https://learn.microsoft.com/en-us/azure/azure-sql/database/authentication-aad-overview).

- **A:** Incorrect for this requirement. Unlike server-level rules stored in `master`, database-level IP firewall rules travel inside the user database across Active Geo-Replication and Failover Group failovers. Why the keyed choice wins: Running `CREATE USER [id-billing-api] FROM EXTERNAL PROVIDER` creates a contained database user bound to the Workload Identity / Managed Identity in Microsoft Entra ID.
- **B:** Incorrect for this requirement. Without the original TDE certificate and private key restored into the target SQL Server `master` database, a TDE-encrypted `.bak` or detached `.mdf` cannot be decrypted anywhere. Why the keyed choice wins: Running `CREATE USER [id-billing-api] FROM EXTERNAL PROVIDER` creates a contained database user bound to the Workload Identity / Managed Identity in Microsoft Entra ID.
- **C:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: Running `CREATE USER [id-billing-api] FROM EXTERNAL PROVIDER` creates a contained database user bound to the Workload Identity / Managed Identity in Microsoft Entra ID.
- **D:** Correct. Contained Entra group users authenticate directly at the user database without `master` SID mappings, automatically surviving Failover Group / Geo-Replication failovers and onboarding group members. In this scenario: Running `CREATE USER [id-billing-api] FROM EXTERNAL PROVIDER` creates a contained database user bound to the Workload Identity / Managed Identity in Microsoft Entra ID.

### Question 18 — A

Answer: Windows Authentication for Azure SQL Managed Instance backed by Microsoft Entra Kerberos (`Incoming Trust`-based or `Entra Kerberos`). Windows Authentication for Azure SQL Managed Instance backed by Microsoft Entra Kerberos issues Kerberos tickets directly from Entra ID. Microsoft Entra Kerberos issues Kerberos tickets for SQL Managed Instance without requiring customer-managed Active Directory Domain Services domain controllers inside Azure. Local study-map skill 2.2 (Configure Authentication for SQL Server on Azure VMs and SQL MI (`Microsoft Entra Kerberos` & AD Trusts)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Windows Authentication for Azure SQL Managed Instance using Microsoft Entra Kerberos and AD (https://learn.microsoft.com/en-us/azure/azure-sql/managed-instance/winauth-azuread-overview).

- **A:** Correct. Microsoft Entra Kerberos issues Kerberos tickets for SQL Managed Instance without requiring customer-managed Active Directory Domain Services domain controllers inside Azure. In this scenario: Windows Authentication for Azure SQL Managed Instance backed by Microsoft Entra Kerberos issues Kerberos tickets directly from Entra ID.
- **B:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Windows Authentication for Azure SQL Managed Instance backed by Microsoft Entra Kerberos issues Kerberos tickets directly from Entra ID.
- **C:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: Windows Authentication for Azure SQL Managed Instance backed by Microsoft Entra Kerberos issues Kerberos tickets directly from Entra ID.
- **D:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: Windows Authentication for Azure SQL Managed Instance backed by Microsoft Entra Kerberos issues Kerberos tickets directly from Entra ID.

### Question 19 — B

Answer: Contained database user mapped to a Microsoft Entra security group (`CREATE USER [Group] FROM EXTERNAL PROVIDER`). Group membership changes in Microsoft Entra ID (including Conditional Access and PIM activation) take effect automatically without running DDL across 480 databases, and contained users survive geo-failovers cleanly. Contained Entra group users authenticate directly at the user database without `master` SID mappings, automatically surviving Failover Group / Geo-Replication failovers and onboarding group members. Local study-map skill 2.3 (Configure Security Principals and Portable Contained Microsoft Entra Users (`FROM EXTERNAL PROVIDER`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Contained database users and Microsoft Entra security principals in Azure SQL (https://learn.microsoft.com/en-us/azure/azure-sql/database/logins-create-manage).

- **A:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: Group membership changes in Microsoft Entra ID (including Conditional Access and PIM activation) take effect automatically without running DDL across 480 databases, and contained users survive geo-failovers cleanly.
- **B:** Correct. Contained Entra group users authenticate directly at the user database without `master` SID mappings, automatically surviving Failover Group / Geo-Replication failovers and onboarding group members. In this scenario: Group membership changes in Microsoft Entra ID (including Conditional Access and PIM activation) take effect automatically without running DDL across 480 databases, and contained users survive geo-failovers cleanly.
- **C:** Incorrect for this requirement. Restoring a `.bak` onto another instance mismatches login SIDs (fixed via `ALTER USER ... WITH LOGIN`), while an explicit table/schema `DENY` always overrides `db_datareader` role `GRANT`s. Why the keyed choice wins: Group membership changes in Microsoft Entra ID (including Conditional Access and PIM activation) take effect automatically without running DDL across 480 databases, and contained users survive geo-failovers cleanly.
- **D:** Incorrect for this requirement. Unlike server-level rules stored in `master`, database-level IP firewall rules travel inside the user database across Active Geo-Replication and Failover Group failovers. Why the keyed choice wins: Group membership changes in Microsoft Entra ID (including Conditional Access and PIM activation) take effect automatically without running DDL across 480 databases, and contained users survive geo-failovers cleanly.

### Question 20 — C

Answer: Built-in granular server-level roles (`##MS_ServerStateReader##`, `##MS_DefinitionReader##`) or `GRANT VIEW DATABASE PERFORMANCE STATE`. Adding the observability Managed Identity to `##MS_ServerStateReader##` grants server-wide performance DMV read access with zero table data `SELECT` rights. Modern granular server roles and state permissions let monitoring accounts inspect DMVs and metadata without granting `sysadmin`, `db_owner`, or `SELECT` access to user tables. Local study-map skill 2.3 (Configure Security Principals and Portable Contained Microsoft Entra Users (`FROM EXTERNAL PROVIDER`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Contained database users and Microsoft Entra security principals in Azure SQL (https://learn.microsoft.com/en-us/azure/azure-sql/database/logins-create-manage).

- **A:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: Adding the observability Managed Identity to `##MS_ServerStateReader##` grants server-wide performance DMV read access with zero table data `SELECT` rights.
- **B:** Incorrect for this requirement. RLS transparently filters `SELECT`/`UPDATE`/`DELETE` rows via `FILTER PREDICATE` and blocks unauthorized cross-tenant `INSERT`/`UPDATE` writes via `BLOCK PREDICATE` inside the engine. Why the keyed choice wins: Adding the observability Managed Identity to `##MS_ServerStateReader##` grants server-wide performance DMV read access with zero table data `SELECT` rights.
- **C:** Correct. Modern granular server roles and state permissions let monitoring accounts inspect DMVs and metadata without granting `sysadmin`, `db_owner`, or `SELECT` access to user tables. In this scenario: Adding the observability Managed Identity to `##MS_ServerStateReader##` grants server-wide performance DMV read access with zero table data `SELECT` rights.
- **D:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: Adding the observability Managed Identity to `##MS_ServerStateReader##` grants server-wide performance DMV read access with zero table data `SELECT` rights.

### Question 21 — D

Answer: Stored procedure encapsulation using schema ownership chaining, `EXECUTE AS OWNER`, or certificate module signing. Sign `Billing.usp_RecordInvoice` with a certificate mapped to a certificate user granted `ALTER ON OBJECT::Billing.StagingLines` (or use `WITH EXECUTE AS OWNER`), granting the webhook login only `EXECUTE`. Granting `EXECUTE` on a schema-owned or certificate-signed stored procedure lets callers run controlled DML/DDL workflows without direct table-level `SELECT`, `UPDATE`, or `IMPERSONATE` rights. Local study-map skill 2.4 (Apply Least Privilege Using Granular Server/Database Roles, Schema Chaining, `EXECUTE AS`, and T-SQL/GUI Tools), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Permissions hierarchy, server-level roles, and principle of least privilege in SQL (https://learn.microsoft.com/en-us/azure/azure-sql/database/security-server-roles).

- **A:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: Sign `Billing.usp_RecordInvoice` with a certificate mapped to a certificate user granted `ALTER ON OBJECT::Billing.StagingLines` (or use `WITH EXECUTE AS OWNER`), granting the webhook login only `EXECUTE`.
- **B:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Sign `Billing.usp_RecordInvoice` with a certificate mapped to a certificate user granted `ALTER ON OBJECT::Billing.StagingLines` (or use `WITH EXECUTE AS OWNER`), granting the webhook login only `EXECUTE`.
- **C:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: Sign `Billing.usp_RecordInvoice` with a certificate mapped to a certificate user granted `ALTER ON OBJECT::Billing.StagingLines` (or use `WITH EXECUTE AS OWNER`), granting the webhook login only `EXECUTE`.
- **D:** Correct. Granting `EXECUTE` on a schema-owned or certificate-signed stored procedure lets callers run controlled DML/DDL workflows without direct table-level `SELECT`, `UPDATE`, or `IMPERSONATE` rights. In this scenario: Sign `Billing.usp_RecordInvoice` with a certificate mapped to a certificate user granted `ALTER ON OBJECT::Billing.StagingLines` (or use `WITH EXECUTE AS OWNER`), granting the webhook login only `EXECUTE`.

### Question 22 — C

Answer: No — Dynamic Data Masking only obfuscates query output and does not encrypt data on disk or block brute-force inference. No — Dynamic Data Masking formats output result cells only and never blocks `WHERE` predicate probing by ad-hoc `SELECT` users; revoke column `SELECT` or use RLS/views instead. Dynamic Data Masking is not encryption at rest or row-level access control; users with ad-hoc `WHERE` privileges can still infer masked values unless RLS or encryption is applied. Local study-map skill 2.4 (Apply Least Privilege Using Granular Server/Database Roles, Schema Chaining, `EXECUTE AS`, and T-SQL/GUI Tools), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Permissions hierarchy, server-level roles, and principle of least privilege in SQL (https://learn.microsoft.com/en-us/azure/azure-sql/database/security-server-roles).

- **A:** Incorrect for this requirement. `SqlPackage` exports tables sequentially rather than at a single LSN, so exporting a live write-heavy database without creating a point-in-time copy produces torn foreign-key state. Why the keyed choice wins: No — Dynamic Data Masking formats output result cells only and never blocks `WHERE` predicate probing by ad-hoc `SELECT` users; revoke column `SELECT` or use RLS/views instead.
- **B:** Incorrect for this requirement. The proposed solution fails at least one stated technical, security, or availability requirement. Why the keyed choice wins: No — Dynamic Data Masking formats output result cells only and never blocks `WHERE` predicate probing by ad-hoc `SELECT` users; revoke column `SELECT` or use RLS/views instead.
- **C:** Correct. Dynamic Data Masking is not encryption at rest or row-level access control; users with ad-hoc `WHERE` privileges can still infer masked values unless RLS or encryption is applied. In this scenario: No — Dynamic Data Masking formats output result cells only and never blocks `WHERE` predicate probing by ad-hoc `SELECT` users; revoke column `SELECT` or use RLS/views instead.
- **D:** Incorrect for this requirement. Server-level IP firewall rules reside in the logical `master` database and must either be recreated on the DR logical server or replaced with portable database-level rules where appropriate. Why the keyed choice wins: No — Dynamic Data Masking formats output result cells only and never blocks `WHERE` predicate probing by ad-hoc `SELECT` users; revoke column `SELECT` or use RLS/views instead.

### Question 23 — B

Answer: Remap orphaned database users (`ALTER USER [u] WITH LOGIN = [u]`) and inspect explicit `DENY` permissions via `sys.database_permissions`. In SQL Server and Azure SQL permission evaluation (outside `sysadmin`/`db_owner`), an explicit `DENY` on any role membership always overrides `GRANT` permissions from other roles. Restoring a `.bak` onto another instance mismatches login SIDs (fixed via `ALTER USER ... WITH LOGIN`), while an explicit table/schema `DENY` always overrides `db_datareader` role `GRANT`s. Local study-map skill 2.5 (Troubleshoot Authentication and Authorization Issues (Orphaned Users `ALTER USER WITH LOGIN` & `DENY` Precedence)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Troubleshoot SQL login, orphaned user, and Microsoft Entra authorization issues (https://learn.microsoft.com/en-us/sql/sql-server/failover-clusters/troubleshoot-orphaned-users-sql-server).

- **A:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: In SQL Server and Azure SQL permission evaluation (outside `sysadmin`/`db_owner`), an explicit `DENY` on any role membership always overrides `GRANT` permissions from other roles.
- **B:** Correct. Restoring a `.bak` onto another instance mismatches login SIDs (fixed via `ALTER USER ... WITH LOGIN`), while an explicit table/schema `DENY` always overrides `db_datareader` role `GRANT`s. In this scenario: In SQL Server and Azure SQL permission evaluation (outside `sysadmin`/`db_owner`), an explicit `DENY` on any role membership always overrides `GRANT` permissions from other roles.
- **C:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: In SQL Server and Azure SQL permission evaluation (outside `sysadmin`/`db_owner`), an explicit `DENY` on any role membership always overrides `GRANT` permissions from other roles.
- **D:** Incorrect for this requirement. Change Tracking records only which primary keys changed with minimal overhead, whereas CDC reads the transaction log asynchronously to retain every intermediate `INSERT`/`UPDATE`/`DELETE` payload. Why the keyed choice wins: In SQL Server and Azure SQL permission evaluation (outside `sysadmin`/`db_owner`), an explicit `DENY` on any role membership always overrides `GRANT` permissions from other roles.

### Question 24 — A

Answer: Enable Soft Delete & Purge Protection on Key Vault → Assign Managed Identity to SQL server → Grant Key Vault Crypto Service Encryption User (`get`/`wrapKey`/`unwrapKey`) → Set server TDE protector to Key Vault key. Enable Soft Delete and Purge Protection on Key Vault, assign a Managed Identity to the logical SQL server, grant `get`/`wrapKey`/`unwrapKey` Crypto RBAC, and set the server TDE protector to the Key Vault key. Customer-Managed TDE requires Soft Delete and Purge Protection on Key Vault, a server Managed Identity granted `get`/`wrapKey`/`unwrapKey` permissions, and assigning the Key Vault key as TDE protector. Local study-map skill 2.6 (Implement Transparent Data Encryption (`TDE`) with Service-Managed Keys, Key Vault `CMK`, and VM Cert Backups), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Transparent Data Encryption (TDE) with service-managed and customer-managed keys in Key Vault (https://learn.microsoft.com/en-us/azure/azure-sql/database/transparent-data-encryption-byok-overview).

- **A:** Correct. Customer-Managed TDE requires Soft Delete and Purge Protection on Key Vault, a server Managed Identity granted `get`/`wrapKey`/`unwrapKey` permissions, and assigning the Key Vault key as TDE protector. In this scenario: Enable Soft Delete and Purge Protection on Key Vault, assign a Managed Identity to the logical SQL server, grant `get`/`wrapKey`/`unwrapKey` Crypto RBAC, and set the server TDE protector to the Key Vault key.
- **B:** Incorrect for this requirement. Incorrect workflow: Azure SQL CMK TDE integrates exclusively with Azure Key Vault or Azure Key Vault Managed HSM using Managed Identity, never anonymous storage URLs. Why the keyed choice wins: Enable Soft Delete and Purge Protection on Key Vault, assign a Managed Identity to the logical SQL server, grant `get`/`wrapKey`/`unwrapKey` Crypto RBAC, and set the server TDE protector to the Key Vault key.
- **C:** Incorrect for this requirement. Incorrect workflow: TDE CMK wraps the Database Encryption Key via asymmetric RSA keys in Azure Key Vault or Managed HSM, not `tempdb` symmetric keys. Why the keyed choice wins: Enable Soft Delete and Purge Protection on Key Vault, assign a Managed Identity to the logical SQL server, grant `get`/`wrapKey`/`unwrapKey` Crypto RBAC, and set the server TDE protector to the Key Vault key.
- **D:** Incorrect for this requirement. Incorrect workflow: Azure SQL refuses Key Vault TDE protectors unless Soft Delete and Purge Protection are enabled and key-wrapping permissions are granted beforehand. Why the keyed choice wins: Enable Soft Delete and Purge Protection on Key Vault, assign a Managed Identity to the logical SQL server, grant `get`/`wrapKey`/`unwrapKey` Crypto RBAC, and set the server TDE protector to the Key Vault key.

### Question 25 — A, B

Answers: Enable both `Soft Delete` and `Purge Protection` on the Azure Key Vault or Managed HSM storing the TDE protector key; Grant the SQL server Managed Identity `Key Vault Crypto Service Encryption User` (`get`, `wrapKey`, `unwrapKey`) on the Key Vault. Maintain `Soft Delete` and `Purge Protection` on the Key Vault, and retain `Key Vault Crypto Service Encryption User` (`get`, `wrapKey`, `unwrapKey`) for the SQL server's Managed Identity. Local study-map skill 2.6 (Implement Transparent Data Encryption (`TDE`) with Service-Managed Keys, Key Vault `CMK`, and VM Cert Backups), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Transparent Data Encryption (TDE) with service-managed and customer-managed keys in Key Vault (https://learn.microsoft.com/en-us/azure/azure-sql/database/transparent-data-encryption-byok-overview).

- **A:** Correct. The logical SQL server or SQL MI Managed Identity requires `get`, `wrapKey`, and `unwrapKey` permissions to wrap and unwrap the Database Encryption Key (`DEK`). In this scenario: Maintain `Soft Delete` and `Purge Protection` on the Key Vault, and retain `Key Vault Crypto Service Encryption User` (`get`, `wrapKey`, `unwrapKey`) for the SQL server's Managed Identity.
- **B:** Correct. Azure SQL requires both Soft Delete and Purge Protection on Key Vault so accidental or malicious key deletion can never permanently brick encrypted databases. In this scenario: Maintain `Soft Delete` and `Purge Protection` on the Key Vault, and retain `Key Vault Crypto Service Encryption User` (`get`, `wrapKey`, `unwrapKey`) for the SQL server's Managed Identity.
- **C:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Maintain `Soft Delete` and `Purge Protection` on the Key Vault, and retain `Key Vault Crypto Service Encryption User` (`get`, `wrapKey`, `unwrapKey`) for the SQL server's Managed Identity.
- **D:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: Maintain `Soft Delete` and `Purge Protection` on the Key Vault, and retain `Key Vault Crypto Service Encryption User` (`get`, `wrapKey`, `unwrapKey`) for the SQL server's Managed Identity.
- **E:** Incorrect for this requirement. Transaction log files perform sequential write-through flushes that do not benefit from read caching and must use `None` host caching. Why the keyed choice wins: Maintain `Soft Delete` and `Purge Protection` on the Key Vault, and retain `Key Vault Crypto Service Encryption User` (`get`, `wrapKey`, `unwrapKey`) for the SQL server's Managed Identity.

### Question 26 — D

Answer: Column-level encryption (`CREATE MASTER KEY` -> `CREATE CERTIFICATE` -> `CREATE SYMMETRIC KEY` -> `EncryptByKey`) plus `Minimal TLS version = 1.2`. `sys.dm_exec_connections` exposes `encrypt_option`, `protocol_version`, `client_net_address`, and `auth_scheme` (`FEDERATED_SERVICE` / `SQL`) for active TDS connections. T-SQL cell-level symmetric key encryption protects specific columns inside the engine while enforcing TLS 1.2+ encrypts all TDS client traffic in transit. Local study-map skill 2.7 (Implement Object/Column-Level Encryption (`Symmetric Keys` / `Certificates`) and Enforce `Minimal TLS 1.2`), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Column-level symmetric key encryption and TLS 1.2 in-transit encryption (https://learn.microsoft.com/en-us/sql/relational-databases/security/encryption/encrypt-a-column-of-data).

- **A:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: `sys.dm_exec_connections` exposes `encrypt_option`, `protocol_version`, `client_net_address`, and `auth_scheme` (`FEDERATED_SERVICE` / `SQL`) for active TDS connections.
- **B:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: `sys.dm_exec_connections` exposes `encrypt_option`, `protocol_version`, `client_net_address`, and `auth_scheme` (`FEDERATED_SERVICE` / `SQL`) for active TDS connections.
- **C:** Incorrect for this requirement. Unlike server-level rules stored in `master`, database-level IP firewall rules travel inside the user database across Active Geo-Replication and Failover Group failovers. Why the keyed choice wins: `sys.dm_exec_connections` exposes `encrypt_option`, `protocol_version`, `client_net_address`, and `auth_scheme` (`FEDERATED_SERVICE` / `SQL`) for active TDS connections.
- **D:** Correct. T-SQL cell-level symmetric key encryption protects specific columns inside the engine while enforcing TLS 1.2+ encrypts all TDS client traffic in transit. In this scenario: `sys.dm_exec_connections` exposes `encrypt_option`, `protocol_version`, `client_net_address`, and `auth_scheme` (`FEDERATED_SERVICE` / `SQL`) for active TDS connections.

### Question 27 — C

Answer: No — server-level firewall rules live in `master` and do not replicate automatically to a failover secondary server. No — server-level rules in `master` expose **all** databases on `sql-saas-primary` to that IP and do **not** replicate automatically to `sql-saas-secondary`; use `sp_set_database_firewall_rule` inside `Tenant042DB`. Server-level IP firewall rules reside in the logical `master` database and must either be recreated on the DR logical server or replaced with portable database-level rules where appropriate. Local study-map skill 2.8 (Configure Server-Level (`master`) vs Portable Database-Level IP Firewall Rules (`sp_set_database_firewall_rule`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Server-level and database-level IP firewall rules in Azure SQL Database (https://learn.microsoft.com/en-us/azure/azure-sql/database/firewall-configure).

- **A:** Incorrect for this requirement. `SqlPackage` exports tables sequentially rather than at a single LSN, so exporting a live write-heavy database without creating a point-in-time copy produces torn foreign-key state. Why the keyed choice wins: No — server-level rules in `master` expose **all** databases on `sql-saas-primary` to that IP and do **not** replicate automatically to `sql-saas-secondary`; use `sp_set_database_firewall_rule` inside `Tenant042DB`.
- **B:** Incorrect for this requirement. The proposed solution fails at least one stated technical, security, or availability requirement. Why the keyed choice wins: No — server-level rules in `master` expose **all** databases on `sql-saas-primary` to that IP and do **not** replicate automatically to `sql-saas-secondary`; use `sp_set_database_firewall_rule` inside `Tenant042DB`.
- **C:** Correct. Server-level IP firewall rules reside in the logical `master` database and must either be recreated on the DR logical server or replaced with portable database-level rules where appropriate. In this scenario: No — server-level rules in `master` expose **all** databases on `sql-saas-primary` to that IP and do **not** replicate automatically to `sql-saas-secondary`; use `sp_set_database_firewall_rule` inside `Tenant042DB`.
- **D:** Incorrect for this requirement. Dynamic Data Masking is not encryption at rest or row-level access control; users with ad-hoc `WHERE` privileges can still infer masked values unless RLS or encryption is applied. Why the keyed choice wins: No — server-level rules in `master` expose **all** databases on `sql-saas-primary` to that IP and do **not** replicate automatically to `sql-saas-secondary`; use `sp_set_database_firewall_rule` inside `Tenant042DB`.

### Question 28 — A, D

Answers: Provision a Column Master Key in Key Vault and create a Column Encryption Key with `ENCLAVE_COMPUTATIONS` enabled; Enable `Column Encryption Setting=Enabled` and pass the `Enclave Attestation Url` (or VBS zero-attestation setting) in client drivers. Create an enclave-enabled CEK (`ENCLAVE_COMPUTATIONS`) wrapped by a Key Vault CMK, and set `Column Encryption Setting=Enabled` (plus enclave attestation settings) in client connection strings. Local study-map skill 2.9 (Implement Always Encrypted (`Deterministic` vs `Randomized`) and Always Encrypted with VBS/SGX Secure Enclaves), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Always Encrypted and Always Encrypted with secure enclaves (https://learn.microsoft.com/en-us/sql/relational-databases/security/encryption/always-encrypted-enclaves).

- **A:** Correct. Rich confidential queries (`LIKE`, `<`, `>`, sorting) and in-place encryption require a CEK explicitly marked to permit enclave computations. In this scenario: Create an enclave-enabled CEK (`ENCLAVE_COMPUTATIONS`) wrapped by a Key Vault CMK, and set `Column Encryption Setting=Enabled` (plus enclave attestation settings) in client connection strings.
- **B:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: Create an enclave-enabled CEK (`ENCLAVE_COMPUTATIONS`) wrapped by a Key Vault CMK, and set `Column Encryption Setting=Enabled` (plus enclave attestation settings) in client connection strings.
- **C:** Incorrect for this requirement. `ReadOnly` host caching serves random OLTP data-page reads directly from Azure hypervisor RAM/SSD cache without consuming disk IOPS. Why the keyed choice wins: Create an enclave-enabled CEK (`ENCLAVE_COMPUTATIONS`) wrapped by a Key Vault CMK, and set `Column Encryption Setting=Enabled` (plus enclave attestation settings) in client connection strings.
- **D:** Correct. Client drivers must enable Always Encrypted and verify enclave attestation before transmitting CEKs over TLS into the SQL secure enclave. In this scenario: Create an enclave-enabled CEK (`ENCLAVE_COMPUTATIONS`) wrapped by a Key Vault CMK, and set `Column Encryption Setting=Enabled` (plus enclave attestation settings) in client connection strings.
- **E:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Create an enclave-enabled CEK (`ENCLAVE_COMPUTATIONS`) wrapped by a Key Vault CMK, and set `Column Encryption Setting=Enabled` (plus enclave attestation settings) in client connection strings.

### Question 29 — B

Answer: Always Encrypted with VBS or Intel SGX secure enclaves (`ALLOW_ENCLAVE_COMPUTATIONS` + `Column Encryption Setting=Enabled`). VBS enclaves are software-isolated hypervisor memory enclaves available across standard General Purpose / Business Critical / Hyperscale compute generations (`Gen5`, etc.) without requiring specialized DC-series SGX hardware or external Microsoft Azure Attestation URLs when zero-attestation is used. Secure enclaves delegate column decryption into an isolated memory region inside SQL, unlocking `LIKE`, `<`, `>`, `ORDER BY`, and fast in-place initial encryption without exposing plaintext to DBAs. Local study-map skill 2.9 (Implement Always Encrypted (`Deterministic` vs `Randomized`) and Always Encrypted with VBS/SGX Secure Enclaves), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Always Encrypted and Always Encrypted with secure enclaves (https://learn.microsoft.com/en-us/sql/relational-databases/security/encryption/always-encrypted-enclaves).

- **A:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: VBS enclaves are software-isolated hypervisor memory enclaves available across standard General Purpose / Business Critical / Hyperscale compute generations (`Gen5`, etc.) without requiring specialized DC-series SGX hardware or external Microsoft Azure Attestation URLs when zero-attestation is used.
- **B:** Correct. Secure enclaves delegate column decryption into an isolated memory region inside SQL, unlocking `LIKE`, `<`, `>`, `ORDER BY`, and fast in-place initial encryption without exposing plaintext to DBAs. In this scenario: VBS enclaves are software-isolated hypervisor memory enclaves available across standard General Purpose / Business Critical / Hyperscale compute generations (`Gen5`, etc.) without requiring specialized DC-series SGX hardware or external Microsoft Azure Attestation URLs when zero-attestation is used.
- **C:** Incorrect for this requirement. BYOK TDE wraps the symmetric Database Encryption Key (`DEK`) with an asymmetric RSA key in Key Vault or Managed HSM so security admins control key rotation and instant revocation. Why the keyed choice wins: VBS enclaves are software-isolated hypervisor memory enclaves available across standard General Purpose / Business Critical / Hyperscale compute generations (`Gen5`, etc.) without requiring specialized DC-series SGX hardware or external Microsoft Azure Attestation URLs when zero-attestation is used.
- **D:** Incorrect for this requirement. Always Encrypted keeps Column Master Keys on trusted clients/Key Vault; `Randomized` produces distinct ciphertexts for identical plaintexts while `Deterministic` enables equality lookups. Why the keyed choice wins: VBS enclaves are software-isolated hypervisor memory enclaves available across standard General Purpose / Business Critical / Hyperscale compute generations (`Gen5`, etc.) without requiring specialized DC-series SGX hardware or external Microsoft Azure Attestation URLs when zero-attestation is used.

### Question 30 — D, E

Answers: Link Private DNS Zone `privatelink.database.windows.net` (or forward on-premises DNS) to resolve `<server>.database.windows.net` to the private IP; Set `Public network access = Disabled` (`publicNetworkAccess: Disabled`) on the logical SQL server so internet connections are rejected. Link Private DNS Zone `privatelink.database.windows.net` to `vnet-saas-prod`, and set `Public network access = Disabled` on `sql-cloudslate`. Local study-map skill 2.10 (Configure Azure Private Link (`privatelink.database.windows.net`), Service Endpoints, and SQL MI Subnet Security), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Azure Private Link, Virtual Network service endpoints, and SQL MI VNet security (https://learn.microsoft.com/en-us/azure/azure-sql/database/private-endpoint-overview).

- **A:** Incorrect for this requirement. Local ephemeral NVMe storage delivers ultra-low latency for `tempdb` spills and version stores without consuming remote disk IOPS bandwidth. Why the keyed choice wins: Link Private DNS Zone `privatelink.database.windows.net` to `vnet-saas-prod`, and set `Public network access = Disabled` on `sql-cloudslate`.
- **B:** Incorrect for this requirement. Azure Arc allows variable-workload or seasonal SQL Server hosts outside Azure to be billed hourly through an Azure subscription. Why the keyed choice wins: Link Private DNS Zone `privatelink.database.windows.net` to `vnet-saas-prod`, and set `Public network access = Disabled` on `sql-cloudslate`.
- **C:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Link Private DNS Zone `privatelink.database.windows.net` to `vnet-saas-prod`, and set `Public network access = Disabled` on `sql-cloudslate`.
- **D:** Correct. Creating a Private Endpoint alone leaves the public endpoint reachable unless `Public network access` is explicitly disabled on the server. In this scenario: Link Private DNS Zone `privatelink.database.windows.net` to `vnet-saas-prod`, and set `Public network access = Disabled` on `sql-cloudslate`.
- **E:** Correct. Clients still validate the TLS certificate for `<server>.database.windows.net`, so split-brain DNS must map the canonical FQDN via CNAME to `privatelink.database.windows.net`. In this scenario: Link Private DNS Zone `privatelink.database.windows.net` to `vnet-saas-prod`, and set `Public network access = Disabled` on `sql-cloudslate`.

### Question 31 — C

Answer: Azure Private Endpoint (`Microsoft.Network/privateEndpoints`) paired with `privatelink.database.windows.net` Private DNS and `publicNetworkAccess = Disabled`. A Private Endpoint binds to one **specific** SQL server resource instance (`resourceId`), whereas a `Microsoft.Sql` Service Endpoint routes traffic to any Azure SQL public endpoint in the region unless paired with VNet Service Endpoint Policies / outbound firewalls. Private Link maps the SQL server to a private RFC 1918 IP inside your VNet accessible over VPN/ExpressRoute, blocking public internet exposure and cross-tenant data exfiltration. Local study-map skill 2.10 (Configure Azure Private Link (`privatelink.database.windows.net`), Service Endpoints, and SQL MI Subnet Security), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Azure Private Link, Virtual Network service endpoints, and SQL MI VNet security (https://learn.microsoft.com/en-us/azure/azure-sql/database/private-endpoint-overview).

- **A:** Incorrect for this requirement. VNet Service Endpoints restrict Azure SQL public endpoint traffic to a specific VNet subnet without private IPs, whereas SQL Managed Instance deploys directly into a dedicated delegated VNet subnet. Why the keyed choice wins: A Private Endpoint binds to one **specific** SQL server resource instance (`resourceId`), whereas a `Microsoft.Sql` Service Endpoint routes traffic to any Azure SQL public endpoint in the region unless paired with VNet Service Endpoint Policies / outbound firewalls.
- **B:** Incorrect for this requirement. Unlike server-level rules stored in `master`, database-level IP firewall rules travel inside the user database across Active Geo-Replication and Failover Group failovers. Why the keyed choice wins: A Private Endpoint binds to one **specific** SQL server resource instance (`resourceId`), whereas a `Microsoft.Sql` Service Endpoint routes traffic to any Azure SQL public endpoint in the region unless paired with VNet Service Endpoint Policies / outbound firewalls.
- **C:** Correct. Private Link maps the SQL server to a private RFC 1918 IP inside your VNet accessible over VPN/ExpressRoute, blocking public internet exposure and cross-tenant data exfiltration. In this scenario: A Private Endpoint binds to one **specific** SQL server resource instance (`resourceId`), whereas a `Microsoft.Sql` Service Endpoint routes traffic to any Azure SQL public endpoint in the region unless paired with VNet Service Endpoint Policies / outbound firewalls.
- **D:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: A Private Endpoint binds to one **specific** SQL server resource instance (`resourceId`), whereas a `Microsoft.Sql` Service Endpoint routes traffic to any Azure SQL public endpoint in the region unless paired with VNet Service Endpoint Policies / outbound firewalls.

### Question 32 — B

Answer: SQL Data Discovery & Classification (`ADD SENSITIVITY CLASSIFICATION`) integrated with Azure SQL Auditing to Log Analytics / immutable Storage. Both policies operate **simultaneously and independently**—server-level auditing applies to every database on the logical server regardless of any additional database-level audit policies. `ADD SENSITIVITY CLASSIFICATION` tags columns with `LABEL` and `INFORMATION_TYPE`, populating `data_sensitivity_information` in SQL Audit logs whenever classified columns are queried. Local study-map skill 2.11 (Apply SQL Data Discovery & Classification (`ADD SENSITIVITY CLASSIFICATION`) and Server/Database Auditing), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Data Discovery and Classification and Azure SQL Auditing (https://learn.microsoft.com/en-us/azure/azure-sql/database/auditing-overview).

- **A:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Both policies operate **simultaneously and independently**—server-level auditing applies to every database on the logical server regardless of any additional database-level audit policies.
- **B:** Correct. `ADD SENSITIVITY CLASSIFICATION` tags columns with `LABEL` and `INFORMATION_TYPE`, populating `data_sensitivity_information` in SQL Audit logs whenever classified columns are queried. In this scenario: Both policies operate **simultaneously and independently**—server-level auditing applies to every database on the logical server regardless of any additional database-level audit policies.
- **C:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: Both policies operate **simultaneously and independently**—server-level auditing applies to every database on the logical server regardless of any additional database-level audit policies.
- **D:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: Both policies operate **simultaneously and independently**—server-level auditing applies to every database on the logical server regardless of any additional database-level audit policies.

### Question 33 — C

Answer: Dynamic Data Masking (`default()`, `email()`, `partial()`, `random()`) with `GRANT UNMASK` scoped to authorized roles or schemas. Dynamic Data Masking persists across `SELECT INTO`, `INSERT INTO`, and `bcp`/export operations executed by non-`UNMASK` users—`#TempCards` receives the **already masked** `'XXXX'` strings rather than cleartext! DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Local study-map skill 2.13 (Implement Dynamic Data Masking (`default`, `email`, `partial`, `random`) and Scoped `UNMASK` Permissions), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Dynamic Data Masking (DDM) in Azure SQL Database, SQL Managed Instance, and SQL Server (https://learn.microsoft.com/en-us/azure/azure-sql/database/dynamic-data-masking-overview).

- **A:** Incorrect for this requirement. RLS transparently filters `SELECT`/`UPDATE`/`DELETE` rows via `FILTER PREDICATE` and blocks unauthorized cross-tenant `INSERT`/`UPDATE` writes via `BLOCK PREDICATE` inside the engine. Why the keyed choice wins: Dynamic Data Masking persists across `SELECT INTO`, `INSERT INTO`, and `bcp`/export operations executed by non-`UNMASK` users—`#TempCards` receives the **already masked** `'XXXX'` strings rather than cleartext!
- **B:** Incorrect for this requirement. BYOK TDE wraps the symmetric Database Encryption Key (`DEK`) with an asymmetric RSA key in Key Vault or Managed HSM so security admins control key rotation and instant revocation. Why the keyed choice wins: Dynamic Data Masking persists across `SELECT INTO`, `INSERT INTO`, and `bcp`/export operations executed by non-`UNMASK` users—`#TempCards` receives the **already masked** `'XXXX'` strings rather than cleartext!
- **C:** Correct. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. In this scenario: Dynamic Data Masking persists across `SELECT INTO`, `INSERT INTO`, and `bcp`/export operations executed by non-`UNMASK` users—`#TempCards` receives the **already masked** `'XXXX'` strings rather than cleartext!
- **D:** Incorrect for this requirement. Secure enclaves delegate column decryption into an isolated memory region inside SQL, unlocking `LIKE`, `<`, `>`, `ORDER BY`, and fast in-place initial encryption without exposing plaintext to DBAs. Why the keyed choice wins: Dynamic Data Masking persists across `SELECT INTO`, `INSERT INTO`, and `bcp`/export operations executed by non-`UNMASK` users—`#TempCards` receives the **already masked** `'XXXX'` strings rather than cleartext!

### Question 34 — B

Answer: Create dedicated `Security` schema → Create `SCHEMABINDING` inline TVF reading `SESSION_CONTEXT(N'TenantId')` → Create `SECURITY POLICY` with `FILTER` & `BLOCK` predicates (`STATE = ON`) → Set read-only `sp_set_session_context` on connect. Create a dedicated `Security` schema, author a `SCHEMABINDING` inline TVF checking `SESSION_CONTEXT(N'TenantId')`, create an active `SECURITY POLICY` with `FILTER` + `BLOCK` predicates, and set read-only `sp_set_session_context` (`@read_only = 1`) on connect. Best-practice multi-tenant RLS isolates objects in a dedicated schema, uses a schema-bound inline TVF predicate over read-only `SESSION_CONTEXT`, and enforces both `FILTER` and `BLOCK` predicates. Local study-map skill 2.14 (Implement Cryptographic Ledger in Azure SQL (`Azure Confidential Ledger`) and Row-Level Security (`FILTER`/`BLOCK`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Ledger cryptographic tamper-evidence and Row-Level Security (RLS) in Azure SQL (https://learn.microsoft.com/en-us/sql/relational-databases/security/ledger/ledger-overview).

- **A:** Incorrect for this requirement. Incorrect workflow: RLS requires an existing `SCHEMABINDING` inline TVF before creating the security policy, and granting `ALTER ANY SECURITY POLICY` lets tenants bypass isolation. Why the keyed choice wins: Create a dedicated `Security` schema, author a `SCHEMABINDING` inline TVF checking `SESSION_CONTEXT(N'TenantId')`, create an active `SECURITY POLICY` with `FILTER` + `BLOCK` predicates, and set read-only `sp_set_session_context` (`@read_only = 1`) on connect.
- **B:** Correct. Best-practice multi-tenant RLS isolates objects in a dedicated schema, uses a schema-bound inline TVF predicate over read-only `SESSION_CONTEXT`, and enforces both `FILTER` and `BLOCK` predicates. In this scenario: Create a dedicated `Security` schema, author a `SCHEMABINDING` inline TVF checking `SESSION_CONTEXT(N'TenantId')`, create an active `SECURITY POLICY` with `FILTER` + `BLOCK` predicates, and set read-only `sp_set_session_context` (`@read_only = 1`) on connect.
- **C:** Incorrect for this requirement. Incorrect workflow: Dynamic Data Masking obfuscates column output in result sets and never filters rows or blocks cross-tenant writes. Why the keyed choice wins: Create a dedicated `Security` schema, author a `SCHEMABINDING` inline TVF checking `SESSION_CONTEXT(N'TenantId')`, create an active `SECURITY POLICY` with `FILTER` + `BLOCK` predicates, and set read-only `sp_set_session_context` (`@read_only = 1`) on connect.
- **D:** Incorrect for this requirement. Incorrect workflow: RLS predicates must be schema-bound inline TVFs attached to a `SECURITY POLICY`, and `@read_only = 1` prevents SQL injection from changing `TenantId` mid-session. Why the keyed choice wins: Create a dedicated `Security` schema, author a `SCHEMABINDING` inline TVF checking `SESSION_CONTEXT(N'TenantId')`, create an active `SECURITY POLICY` with `FILTER` + `BLOCK` predicates, and set read-only `sp_set_session_context` (`@read_only = 1`) on connect.

### Question 35 — A

Answer: Azure Monitor metrics paired with `sys.dm_db_resource_stats` (single DB) or `sys.server_resource_stats` (SQL MI) for 15-second CPU, data I/O, log write, and memory baselines. Querying `sys.resource_stats` in `master` aggregates utilization history across **all** databases on the logical SQL server (while `sys.dm_db_resource_stats` gives 15-second granularity inside a single DB). `sys.dm_db_resource_stats` retains 14 days of 15-second resource averages (`avg_cpu_percent`, `avg_data_io_percent`, `avg_log_write_percent`) to compare current peaks against normal baselines. Local study-map skill 3.1 (Establish Performance Baselines and Interpret CPU, Memory, Data I/O, Log Write, and `tempdb` Metrics), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Monitor Azure SQL resource utilization and establish performance baselines (https://learn.microsoft.com/en-us/azure/azure-sql/database/monitoring-sql-database-azure-monitor).

- **A:** Correct. `sys.dm_db_resource_stats` retains 14 days of 15-second resource averages (`avg_cpu_percent`, `avg_data_io_percent`, `avg_log_write_percent`) to compare current peaks against normal baselines. In this scenario: Querying `sys.resource_stats` in `master` aggregates utilization history across **all** databases on the logical SQL server (while `sys.dm_db_resource_stats` gives 15-second granularity inside a single DB).
- **B:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: Querying `sys.resource_stats` in `master` aggregates utilization history across **all** databases on the logical SQL server (while `sys.dm_db_resource_stats` gives 15-second granularity inside a single DB).
- **C:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Querying `sys.resource_stats` in `master` aggregates utilization history across **all** databases on the logical SQL server (while `sys.dm_db_resource_stats` gives 15-second granularity inside a single DB).
- **D:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: Querying `sys.resource_stats` in `master` aggregates utilization history across **all** databases on the logical SQL server (while `sys.dm_db_resource_stats` gives 15-second granularity inside a single DB).

### Question 36 — D

Answer: Query `sys.dm_os_wait_stats` / `sys.dm_db_wait_stats`, `sys.dm_exec_requests`, `sys.dm_tran_locks`, and `sys.dm_db_tempdb_space_usage`. `sys.dm_db_wait_stats` returns wait counts and wait times isolated specifically to the current Azure SQL Database. Wait categories pinpoint root causes: `PAGEIOLATCH_*` indicates storage data reads, `WRITELOG` indicates log flush latency, `SOS_SCHEDULER_YIELD` indicates CPU pressure, and `LCK_M_*` indicates blocking. Local study-map skill 3.1 (Establish Performance Baselines and Interpret CPU, Memory, Data I/O, Log Write, and `tempdb` Metrics), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Monitor Azure SQL resource utilization and establish performance baselines (https://learn.microsoft.com/en-us/azure/azure-sql/database/monitoring-sql-database-azure-monitor).

- **A:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: `sys.dm_db_wait_stats` returns wait counts and wait times isolated specifically to the current Azure SQL Database.
- **B:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: `sys.dm_db_wait_stats` returns wait counts and wait times isolated specifically to the current Azure SQL Database.
- **C:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: `sys.dm_db_wait_stats` returns wait counts and wait times isolated specifically to the current Azure SQL Database.
- **D:** Correct. Wait categories pinpoint root causes: `PAGEIOLATCH_*` indicates storage data reads, `WRITELOG` indicates log flush latency, `SOS_SCHEDULER_YIELD` indicates CPU pressure, and `LCK_M_*` indicates blocking. In this scenario: `sys.dm_db_wait_stats` returns wait counts and wait times isolated specifically to the current Azure SQL Database.

### Question 37 — A

Answer: Provision Azure Data Explorer or Fabric Eventhouse store → Create database watcher with Managed Identity → Add SQL targets & grant `VIEW SERVER PERFORMANCE STATE` + ingest roles → Start watcher & open portal dashboards. Deploy the Azure Data Explorer cluster for SaaS telemetry first, create the watcher with Managed Identity, grant `VIEW SERVER PERFORMANCE STATE` on target SaaS pools/MIs plus ADX ingest roles, and start the watcher. Database watcher streams SQL telemetry into an Azure Data Explorer or Fabric Eventhouse/KQL store using Managed Identity granted least-privilege `VIEW SERVER PERFORMANCE STATE` on SQL targets. Local study-map skill 3.3 (Monitor Workloads Using Database Watcher (ADX / Fabric Eventhouse) and Plan Fabric Database Hub Transition), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Monitor Azure SQL workloads with database watcher and Database Hub in Microsoft Fabric (https://learn.microsoft.com/en-us/azure/azure-sql/database-watcher-overview).

- **A:** Correct. Database watcher streams SQL telemetry into an Azure Data Explorer or Fabric Eventhouse/KQL store using Managed Identity granted least-privilege `VIEW SERVER PERFORMANCE STATE` on SQL targets. In this scenario: Deploy the Azure Data Explorer cluster for SaaS telemetry first, create the watcher with Managed Identity, grant `VIEW SERVER PERFORMANCE STATE` on target SaaS pools/MIs plus ADX ingest roles, and start the watcher.
- **B:** Incorrect for this requirement. Incorrect workflow: watcher requires an Azure Data Explorer or Fabric Real-Time Analytics store and SQL targets configured first, and uses least-privilege Managed Identity rather than `sa` or Profiler. Why the keyed choice wins: Deploy the Azure Data Explorer cluster for SaaS telemetry first, create the watcher with Managed Identity, grant `VIEW SERVER PERFORMANCE STATE` on target SaaS pools/MIs plus ADX ingest roles, and start the watcher.
- **C:** Incorrect for this requirement. Incorrect workflow: database watcher monitors Azure SQL Database, Elastic Pools, and SQL Managed Instance and stores telemetry in Azure Data Explorer or Fabric KQL databases. Why the keyed choice wins: Deploy the Azure Data Explorer cluster for SaaS telemetry first, create the watcher with Managed Identity, grant `VIEW SERVER PERFORMANCE STATE` on target SaaS pools/MIs plus ADX ingest roles, and start the watcher.
- **D:** Incorrect for this requirement. Incorrect workflow: Azure SQL Database PaaS exposes no underlying OS for agents, `sp_trace_create` is deprecated, and database watcher is agentless. Why the keyed choice wins: Deploy the Azure Data Explorer cluster for SaaS telemetry first, create the watcher with Managed Identity, grant `VIEW SERVER PERFORMANCE STATE` on target SaaS pools/MIs plus ADX ingest roles, and start the watcher.

### Question 38 — A, D

Answers: Grant the database watcher Managed Identity `VIEW SERVER PERFORMANCE STATE` (or `VIEW DATABASE PERFORMANCE STATE`) on SQL targets; Grant the database watcher Managed Identity database `Admin` / ingest permissions on the Azure Data Explorer or Fabric Eventhouse store. Grant `VIEW SERVER PERFORMANCE STATE` to the watcher Managed Identity on SQL targets, and grant database `Admin` / ingestion permissions on the Fabric Eventhouse / ADX store. Local study-map skill 3.3 (Monitor Workloads Using Database Watcher (ADX / Fabric Eventhouse) and Plan Fabric Database Hub Transition), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Monitor Azure SQL workloads with database watcher and Database Hub in Microsoft Fabric (https://learn.microsoft.com/en-us/azure/azure-sql/database-watcher-overview).

- **A:** Correct. Database watcher collects DMVs and system catalogs using least-privilege performance-state permissions rather than `sysadmin` or data-read rights. In this scenario: Grant `VIEW SERVER PERFORMANCE STATE` to the watcher Managed Identity on SQL targets, and grant database `Admin` / ingestion permissions on the Fabric Eventhouse / ADX store.
- **B:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: Grant `VIEW SERVER PERFORMANCE STATE` to the watcher Managed Identity on SQL targets, and grant database `Admin` / ingestion permissions on the Fabric Eventhouse / ADX store.
- **C:** Incorrect for this requirement. Local ephemeral NVMe storage delivers ultra-low latency for `tempdb` spills and version stores without consuming remote disk IOPS bandwidth. Why the keyed choice wins: Grant `VIEW SERVER PERFORMANCE STATE` to the watcher Managed Identity on SQL targets, and grant database `Admin` / ingestion permissions on the Fabric Eventhouse / ADX store.
- **D:** Correct. Database watcher creates tables, retention policies, and ingestion mappings inside the target Azure Data Explorer or Fabric Real-Time Analytics KQL database. In this scenario: Grant `VIEW SERVER PERFORMANCE STATE` to the watcher Managed Identity on SQL targets, and grant database `Admin` / ingestion permissions on the Fabric Eventhouse / ADX store.
- **E:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: Grant `VIEW SERVER PERFORMANCE STATE` to the watcher Managed Identity on SQL targets, and grant database `Admin` / ingestion permissions on the Fabric Eventhouse / ADX store.

### Question 39 — A, C

Answers: Create a `DATABASE SCOPED CREDENTIAL` (`Managed Identity` or `SHARED ACCESS SIGNATURE` with `rwl` permissions) for the Azure Blob container; Define `CREATE EVENT SESSION ... ON DATABASE ADD TARGET package0.event_file(SET filename = N'https://...xel')` and start the session. Configure a `DATABASE SCOPED CREDENTIAL` (`Managed Identity` or `rwl` SAS) for the multi-tenant Blob container, and create an `ON DATABASE` session writing `blocked_process_report` / lock timeouts to `package0.event_file`. Local study-map skill 3.4 (Monitor Workloads Using Extended Events (`ON DATABASE` vs `ON SERVER` & Persistent Blob `event_file` Targets)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Extended Events in Azure SQL Database and Azure SQL Managed Instance (https://learn.microsoft.com/en-us/azure/azure-sql/database/xevent-db-diff-from-svr).

- **A:** Correct. Azure SQL Database scopes Extended Event sessions `ON DATABASE` and streams persistent `.xel` ring-rotated files to the Blob container URL. In this scenario: Configure a `DATABASE SCOPED CREDENTIAL` (`Managed Identity` or `rwl` SAS) for the multi-tenant Blob container, and create an `ON DATABASE` session writing `blocked_process_report` / lock timeouts to `package0.event_file`.
- **B:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: Configure a `DATABASE SCOPED CREDENTIAL` (`Managed Identity` or `rwl` SAS) for the multi-tenant Blob container, and create an `ON DATABASE` session writing `blocked_process_report` / lock timeouts to `package0.event_file`.
- **C:** Correct. Extended Events in Azure SQL Database requires a `DATABASE SCOPED CREDENTIAL` with Read, Write, and List rights on the target Blob Storage container. In this scenario: Configure a `DATABASE SCOPED CREDENTIAL` (`Managed Identity` or `rwl` SAS) for the multi-tenant Blob container, and create an `ON DATABASE` session writing `blocked_process_report` / lock timeouts to `package0.event_file`.
- **D:** Incorrect for this requirement. Azure SQL requires both Soft Delete and Purge Protection on Key Vault so accidental or malicious key deletion can never permanently brick encrypted databases. Why the keyed choice wins: Configure a `DATABASE SCOPED CREDENTIAL` (`Managed Identity` or `rwl` SAS) for the multi-tenant Blob container, and create an `ON DATABASE` session writing `blocked_process_report` / lock timeouts to `package0.event_file`.
- **E:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: Configure a `DATABASE SCOPED CREDENTIAL` (`Managed Identity` or `rwl` SAS) for the multi-tenant Blob container, and create an `ON DATABASE` session writing `blocked_process_report` / lock timeouts to `package0.event_file`.

### Question 40 — A

Answer: Extended Events (`CREATE EVENT SESSION ... ON DATABASE` in SQL DB or `ON SERVER` in SQL MI/VMs) writing to an `event_file` target in Azure Blob Storage. `sys.dm_xe_database_session_targets` (joined with `sys.dm_xe_database_sessions` in Azure SQL Database, versus `sys.dm_xe_sessions` on SQL MI/VMs) exposes live target status and XML buffer metadata. Unlike ephemeral in-memory `ring_buffer` targets, the `event_file` target persists `.xel` trace files durably in Azure Blob Storage using a database-scoped credential (Managed Identity or SAS). Local study-map skill 3.4 (Monitor Workloads Using Extended Events (`ON DATABASE` vs `ON SERVER` & Persistent Blob `event_file` Targets)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Extended Events in Azure SQL Database and Azure SQL Managed Instance (https://learn.microsoft.com/en-us/azure/azure-sql/database/xevent-db-diff-from-svr).

- **A:** Correct. Unlike ephemeral in-memory `ring_buffer` targets, the `event_file` target persists `.xel` trace files durably in Azure Blob Storage using a database-scoped credential (Managed Identity or SAS). In this scenario: `sys.dm_xe_database_session_targets` (joined with `sys.dm_xe_database_sessions` in Azure SQL Database, versus `sys.dm_xe_sessions` on SQL MI/VMs) exposes live target status and XML buffer metadata.
- **B:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: `sys.dm_xe_database_session_targets` (joined with `sys.dm_xe_database_sessions` in Azure SQL Database, versus `sys.dm_xe_sessions` on SQL MI/VMs) exposes live target status and XML buffer metadata.
- **C:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: `sys.dm_xe_database_session_targets` (joined with `sys.dm_xe_database_sessions` in Azure SQL Database, versus `sys.dm_xe_sessions` on SQL MI/VMs) exposes live target status and XML buffer metadata.
- **D:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: `sys.dm_xe_database_session_targets` (joined with `sys.dm_xe_database_sessions` in Azure SQL Database, versus `sys.dm_xe_sessions` on SQL MI/VMs) exposes live target status and XML buffer metadata.

### Question 41 — C, E

Answers: Execute `sys.sp_query_store_force_plan @query_id, @plan_id` to pin the historical low-latency execution plan immediately; Execute `sys.sp_query_store_set_hints @query_id, N'OPTION (RECOMPILE)'` (or `MAXDOP` / memory grant hints) without redeploying code. Use `sys.sp_query_store_force_plan` to pin a healthy `plan_id` or `sys.sp_query_store_set_hints` to attach `OPTION (RECOMPILE)` / `OPTIMIZE FOR UNKNOWN` directly to the `query_id`. Local study-map skill 3.5 (Configure and Monitor Query Store, Force Regressed Plans (`sp_query_store_force_plan`), and Set Query Store Hints), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Monitor performance by using the Query Store, plan forcing, and Query Store hints (https://learn.microsoft.com/en-us/sql/relational-databases/performance/monitoring-performance-by-using-the-query-store).

- **A:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Use `sys.sp_query_store_force_plan` to pin a healthy `plan_id` or `sys.sp_query_store_set_hints` to attach `OPTION (RECOMPILE)` / `OPTIMIZE FOR UNKNOWN` directly to the `query_id`.
- **B:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: Use `sys.sp_query_store_force_plan` to pin a healthy `plan_id` or `sys.sp_query_store_set_hints` to attach `OPTION (RECOMPILE)` / `OPTIMIZE FOR UNKNOWN` directly to the `query_id`.
- **C:** Correct. `sp_query_store_force_plan` instructs the optimizer to compile plans matching the forced `plan_id` shape without modifying application T-SQL. In this scenario: Use `sys.sp_query_store_force_plan` to pin a healthy `plan_id` or `sys.sp_query_store_set_hints` to attach `OPTION (RECOMPILE)` / `OPTIMIZE FOR UNKNOWN` directly to the `query_id`.
- **D:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: Use `sys.sp_query_store_force_plan` to pin a healthy `plan_id` or `sys.sp_query_store_set_hints` to attach `OPTION (RECOMPILE)` / `OPTIMIZE FOR UNKNOWN` directly to the `query_id`.
- **E:** Correct. Query Store hints attach `OPTION (...)` query hints directly to a `query_id` in Azure SQL DB, SQL MI, and SQL Server 2022+ when app code cannot be edited. In this scenario: Use `sys.sp_query_store_force_plan` to pin a healthy `plan_id` or `sys.sp_query_store_set_hints` to attach `OPTION (RECOMPILE)` / `OPTIMIZE FOR UNKNOWN` directly to the `query_id`.

### Question 42 — C

Answer: Confirm Query Store is `READ_WRITE` with wait capture → Compare plan IDs in Regressed Queries (`sys.query_store_runtime_stats`) → Force prior plan via `sp_query_store_force_plan` → Monitor `force_failure_count` & latency. Confirm Query Store is `READ_WRITE` with wait capture, compare plan metrics in Regressed Queries (`sys.query_store_runtime_stats`), force `plan_id = 104` via `sp_query_store_force_plan`, and monitor `force_failure_count`. Resolving a parameter-sensitive plan regression uses Query Store runtime/wait history to identify the prior known-good `plan_id`, forces it immediately without code changes, and verifies forcing health. Local study-map skill 3.5 (Configure and Monitor Query Store, Force Regressed Plans (`sp_query_store_force_plan`), and Set Query Store Hints), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Monitor performance by using the Query Store, plan forcing, and Query Store hints (https://learn.microsoft.com/en-us/sql/relational-databases/performance/monitoring-performance-by-using-the-query-store).

- **A:** Incorrect for this requirement. Incorrect workflow: system catalog tables cannot be updated directly and flushing the plan cache every minute spikes CPU compilations across the entire workload. Why the keyed choice wins: Confirm Query Store is `READ_WRITE` with wait capture, compare plan metrics in Regressed Queries (`sys.query_store_runtime_stats`), force `plan_id = 104` via `sp_query_store_force_plan`, and monitor `force_failure_count`.
- **B:** Incorrect for this requirement. Incorrect workflow: restarting SQL or running offline index rebuilds causes severe production outage and does not prevent parameter-sensitive plan regressions. Why the keyed choice wins: Confirm Query Store is `READ_WRITE` with wait capture, compare plan metrics in Regressed Queries (`sys.query_store_runtime_stats`), force `plan_id = 104` via `sp_query_store_force_plan`, and monitor `force_failure_count`.
- **C:** Correct. Resolving a parameter-sensitive plan regression uses Query Store runtime/wait history to identify the prior known-good `plan_id`, forces it immediately without code changes, and verifies forcing health. In this scenario: Confirm Query Store is `READ_WRITE` with wait capture, compare plan metrics in Regressed Queries (`sys.query_store_runtime_stats`), force `plan_id = 104` via `sp_query_store_force_plan`, and monitor `force_failure_count`.
- **D:** Incorrect for this requirement. Incorrect workflow: purging Query Store erases the historical baseline and prior good plan needed to diagnose and force the healthy execution plan. Why the keyed choice wins: Confirm Query Store is `READ_WRITE` with wait capture, compare plan metrics in Regressed Queries (`sys.query_store_runtime_stats`), force `plan_id = 104` via `sp_query_store_force_plan`, and monitor `force_failure_count`.

### Question 43 — C

Answer: Read Committed Snapshot Isolation (`READ_COMMITTED_SNAPSHOT = ON`) combined with Optimized Locking (`TID` locking + Lock After Qualification `LAQ`). No — under `LAQ` + `RCSI`, predicates are evaluated against the latest committed snapshot **without** acquiring `U` locks first; exclusive `TID`/`X` locks are taken **only** on rows that actually qualify (`Status = 'Escalated'`). `RCSI` uses row versioning so readers never block writers (`LCK_M_S`), while Optimized Locking in Azure SQL DB replaces thousands of row/page locks with a single Transaction ID lock and `LAQ`. Local study-map skill 3.6 (Identify and Resolve Session Blocking (`RCSI`, `Optimized Locking` `TID`/`LAQ`) and Deadlocks (`xml_deadlock_report`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Understand and resolve Azure SQL blocking problems, deadlocks, RCSI, and Optimized Locking (https://learn.microsoft.com/en-us/azure/azure-sql/database/analyze-prevent-deadlocks).

- **A:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: No — under `LAQ` + `RCSI`, predicates are evaluated against the latest committed snapshot **without** acquiring `U` locks first; exclusive `TID`/`X` locks are taken **only** on rows that actually qualify (`Status = 'Escalated'`).
- **B:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: No — under `LAQ` + `RCSI`, predicates are evaluated against the latest committed snapshot **without** acquiring `U` locks first; exclusive `TID`/`X` locks are taken **only** on rows that actually qualify (`Status = 'Escalated'`).
- **C:** Correct. `RCSI` uses row versioning so readers never block writers (`LCK_M_S`), while Optimized Locking in Azure SQL DB replaces thousands of row/page locks with a single Transaction ID lock and `LAQ`. In this scenario: No — under `LAQ` + `RCSI`, predicates are evaluated against the latest committed snapshot **without** acquiring `U` locks first; exclusive `TID`/`X` locks are taken **only** on rows that actually qualify (`Status = 'Escalated'`).
- **D:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: No — under `LAQ` + `RCSI`, predicates are evaluated against the latest committed snapshot **without** acquiring `U` locks first; exclusive `TID`/`X` locks are taken **only** on rows that actually qualify (`Status = 'Escalated'`).

### Question 44 — B

Answer: Capture `xml_deadlock_report` via Extended Events or `sys.event_log`, align table modification order across transactions, and add covering indexes. `sys.event_log` (paired with `database_xml_deadlock_report` in `fn_xe_telemetry_blob_target_read_file` / Extended Events) records connectivity events, throttles, and deadlock counts in `master` automatically. Cycle deadlocks (`Error 1205`) occur when concurrent transactions lock objects in opposite order or scan wide ranges; accessing tables in identical order with narrow index seeks eliminates cycles. Local study-map skill 3.6 (Identify and Resolve Session Blocking (`RCSI`, `Optimized Locking` `TID`/`LAQ`) and Deadlocks (`xml_deadlock_report`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Understand and resolve Azure SQL blocking problems, deadlocks, RCSI, and Optimized Locking (https://learn.microsoft.com/en-us/azure/azure-sql/database/analyze-prevent-deadlocks).

- **A:** Incorrect for this requirement. Over-indexing inflates every `INSERT`/`UPDATE`/`DELETE` write and log flush, while `ONLINE = OFF` holds exclusive schema/table locks that block production traffic. Why the keyed choice wins: `sys.event_log` (paired with `database_xml_deadlock_report` in `fn_xe_telemetry_blob_target_read_file` / Extended Events) records connectivity events, throttles, and deadlock counts in `master` automatically.
- **B:** Correct. Cycle deadlocks (`Error 1205`) occur when concurrent transactions lock objects in opposite order or scan wide ranges; accessing tables in identical order with narrow index seeks eliminates cycles. In this scenario: `sys.event_log` (paired with `database_xml_deadlock_report` in `fn_xe_telemetry_blob_target_read_file` / Extended Events) records connectivity events, throttles, and deadlock counts in `master` automatically.
- **C:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: `sys.event_log` (paired with `database_xml_deadlock_report` in `fn_xe_telemetry_blob_target_read_file` / Extended Events) records connectivity events, throttles, and deadlock counts in `master` automatically.
- **D:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: `sys.event_log` (paired with `database_xml_deadlock_report` in `fn_xe_telemetry_blob_target_read_file` / Extended Events) records connectivity events, throttles, and deadlock counts in `master` automatically.

### Question 45 — B

Answer: Query `sys.dm_os_wait_stats` / `sys.dm_db_wait_stats`, `sys.dm_exec_requests`, `sys.dm_tran_locks`, and `sys.dm_db_tempdb_space_usage`. `sys.dm_db_index_usage_stats` tracks `user_seeks`, `user_scans`, `user_lookups`, and `user_updates` per index so write-heavy unused indexes can be retired safely after verifying across full business cycles. Wait categories pinpoint root causes: `PAGEIOLATCH_*` indicates storage data reads, `WRITELOG` indicates log flush latency, `SOS_SCHEDULER_YIELD` indicates CPU pressure, and `LCK_M_*` indicates blocking. Local study-map skill 3.7 (Identify Performance Bottlenecks Using Dynamic Management Views (`sys.dm_os_wait_stats`, `sys.dm_exec_requests`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Monitor performance using Dynamic Management Views (DMVs) and wait statistics (https://learn.microsoft.com/en-us/azure/azure-sql/database/monitoring-with-dmvs).

- **A:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: `sys.dm_db_index_usage_stats` tracks `user_seeks`, `user_scans`, `user_lookups`, and `user_updates` per index so write-heavy unused indexes can be retired safely after verifying across full business cycles.
- **B:** Correct. Wait categories pinpoint root causes: `PAGEIOLATCH_*` indicates storage data reads, `WRITELOG` indicates log flush latency, `SOS_SCHEDULER_YIELD` indicates CPU pressure, and `LCK_M_*` indicates blocking. In this scenario: `sys.dm_db_index_usage_stats` tracks `user_seeks`, `user_scans`, `user_lookups`, and `user_updates` per index so write-heavy unused indexes can be retired safely after verifying across full business cycles.
- **C:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: `sys.dm_db_index_usage_stats` tracks `user_seeks`, `user_scans`, `user_lookups`, and `user_updates` per index so write-heavy unused indexes can be retired safely after verifying across full business cycles.
- **D:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: `sys.dm_db_index_usage_stats` tracks `user_seeks`, `user_scans`, `user_lookups`, and `user_updates` per index so write-heavy unused indexes can be retired safely after verifying across full business cycles.

### Question 46 — D

Answer: Create a selective nonclustered covering index (`CREATE NONCLUSTERED INDEX ... INCLUDE (...)`) and rewrite predicates to be SARGable without implicit type conversions. `CREATE NONCLUSTERED INDEX IX_Tickets_Tenant_Status_Created ON Tickets (TenantId, Status, CreatedAt DESC) INCLUDE (Subject)` seeks equality keys `(TenantId, Status)` first, reads `CreatedAt DESC` pre-ordered, and covers `Subject`. Adding `INCLUDE` columns eliminates expensive `Key Lookup` operators, while removing functions (`YEAR(col)`) and `VARCHAR`/`NVARCHAR` mismatches turns full index scans into fast index seeks. Local study-map skill 3.8 (Design Covering/Filtered/Columnstore Indexes and Rewrite Non-SARGable or Implicit-Conversion T-SQL Constructs), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Server and Azure SQL index design guide and SARGable T-SQL tuning (https://learn.microsoft.com/en-us/sql/relational-databases/sql-server-index-design-guide).

- **A:** Incorrect for this requirement. Row-by-row cursors and multi-statement TVFs under legacy compatibility levels execute thousands of iterative context switches and 1-row cardinality guesses. Why the keyed choice wins: `CREATE NONCLUSTERED INDEX IX_Tickets_Tenant_Status_Created ON Tickets (TenantId, Status, CreatedAt DESC) INCLUDE (Subject)` seeks equality keys `(TenantId, Status)` first, reads `CreatedAt DESC` pre-ordered, and covers `Subject`.
- **B:** Incorrect for this requirement. Over-indexing inflates every `INSERT`/`UPDATE`/`DELETE` write and log flush, while `ONLINE = OFF` holds exclusive schema/table locks that block production traffic. Why the keyed choice wins: `CREATE NONCLUSTERED INDEX IX_Tickets_Tenant_Status_Created ON Tickets (TenantId, Status, CreatedAt DESC) INCLUDE (Subject)` seeks equality keys `(TenantId, Status)` first, reads `CreatedAt DESC` pre-ordered, and covers `Subject`.
- **C:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: `CREATE NONCLUSTERED INDEX IX_Tickets_Tenant_Status_Created ON Tickets (TenantId, Status, CreatedAt DESC) INCLUDE (Subject)` seeks equality keys `(TenantId, Status)` first, reads `CreatedAt DESC` pre-ordered, and covers `Subject`.
- **D:** Correct. Adding `INCLUDE` columns eliminates expensive `Key Lookup` operators, while removing functions (`YEAR(col)`) and `VARCHAR`/`NVARCHAR` mismatches turns full index scans into fast index seeks. In this scenario: `CREATE NONCLUSTERED INDEX IX_Tickets_Tenant_Status_Created ON Tickets (TenantId, Status, CreatedAt DESC) INCLUDE (Subject)` seeks equality keys `(TenantId, Status)` first, reads `CreatedAt DESC` pre-ordered, and covers `Subject`.

### Question 47 — A

Answer: Create a selective nonclustered covering index (`CREATE NONCLUSTERED INDEX ... INCLUDE (...)`) and rewrite predicates to be SARGable without implicit type conversions. Rewrite as `WHERE (AssignedAgentId = @agent_id OR (@agent_id = -1 AND AssignedAgentId IS NULL))` (or split into `IF @agent_id = -1 ... WHERE AssignedAgentId IS NULL ELSE ... WHERE AssignedAgentId = @agent_id`) so `IX_AssignedAgentId` seeks cleanly. Adding `INCLUDE` columns eliminates expensive `Key Lookup` operators, while removing functions (`YEAR(col)`) and `VARCHAR`/`NVARCHAR` mismatches turns full index scans into fast index seeks. Local study-map skill 3.8 (Design Covering/Filtered/Columnstore Indexes and Rewrite Non-SARGable or Implicit-Conversion T-SQL Constructs), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Server and Azure SQL index design guide and SARGable T-SQL tuning (https://learn.microsoft.com/en-us/sql/relational-databases/sql-server-index-design-guide).

- **A:** Correct. Adding `INCLUDE` columns eliminates expensive `Key Lookup` operators, while removing functions (`YEAR(col)`) and `VARCHAR`/`NVARCHAR` mismatches turns full index scans into fast index seeks. In this scenario: Rewrite as `WHERE (AssignedAgentId = @agent_id OR (@agent_id = -1 AND AssignedAgentId IS NULL))` (or split into `IF @agent_id = -1 ... WHERE AssignedAgentId IS NULL ELSE ... WHERE AssignedAgentId = @agent_id`) so `IX_AssignedAgentId` seeks cleanly.
- **B:** Incorrect for this requirement. Row-by-row cursors and multi-statement TVFs under legacy compatibility levels execute thousands of iterative context switches and 1-row cardinality guesses. Why the keyed choice wins: Rewrite as `WHERE (AssignedAgentId = @agent_id OR (@agent_id = -1 AND AssignedAgentId IS NULL))` (or split into `IF @agent_id = -1 ... WHERE AssignedAgentId IS NULL ELSE ... WHERE AssignedAgentId = @agent_id`) so `IX_AssignedAgentId` seeks cleanly.
- **C:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Rewrite as `WHERE (AssignedAgentId = @agent_id OR (@agent_id = -1 AND AssignedAgentId IS NULL))` (or split into `IF @agent_id = -1 ... WHERE AssignedAgentId IS NULL ELSE ... WHERE AssignedAgentId = @agent_id`) so `IX_AssignedAgentId` seeks cleanly.
- **D:** Incorrect for this requirement. Over-indexing inflates every `INSERT`/`UPDATE`/`DELETE` write and log flush, while `ONLINE = OFF` holds exclusive schema/table locks that block production traffic. Why the keyed choice wins: Rewrite as `WHERE (AssignedAgentId = @agent_id OR (@agent_id = -1 AND AssignedAgentId IS NULL))` (or split into `IF @agent_id = -1 ... WHERE AssignedAgentId IS NULL ELSE ... WHERE AssignedAgentId = @agent_id`) so `IX_AssignedAgentId` seeks cleanly.

### Question 48 — B

Answer: Inspect Actual Execution Plans (`Key Lookup`, `TempDB` sort/hash spill warnings, cardinality skew) alongside SQL Intelligent Insights (`SQLInsights`). When `duration >> CPU time`, the query is **waiting** rather than computing—Query Store Wait Categories (`Lock`, `Buffer IO`, `Tran Log IO`, `Network IO`, `Memory`) immediately reveal whether blocking locks or client `ASYNC_NETWORK_IO` stalls caused the 4.5-second delay. Actual Execution Plans expose runtime row vs estimated row skews and `tempdb` spills, while SQL Intelligent Insights automatically compares a 7-day rolling baseline to diagnose regressions. Local study-map skill 3.9 (Analyze Execution Plans (`Key Lookup`, `TempDB` Spills, Row Skew) and Monitor via SQL Intelligent Insights), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Execution plans and SQL Intelligent Insights automated performance diagnostics (https://learn.microsoft.com/en-us/azure/azure-sql/database/intelligent-insights-overview).

- **A:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: When `duration >> CPU time`, the query is **waiting** rather than computing—Query Store Wait Categories (`Lock`, `Buffer IO`, `Tran Log IO`, `Network IO`, `Memory`) immediately reveal whether blocking locks or client `ASYNC_NETWORK_IO` stalls caused the 4.5-second delay.
- **B:** Correct. Actual Execution Plans expose runtime row vs estimated row skews and `tempdb` spills, while SQL Intelligent Insights automatically compares a 7-day rolling baseline to diagnose regressions. In this scenario: When `duration >> CPU time`, the query is **waiting** rather than computing—Query Store Wait Categories (`Lock`, `Buffer IO`, `Tran Log IO`, `Network IO`, `Memory`) immediately reveal whether blocking locks or client `ASYNC_NETWORK_IO` stalls caused the 4.5-second delay.
- **C:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: When `duration >> CPU time`, the query is **waiting** rather than computing—Query Store Wait Categories (`Lock`, `Buffer IO`, `Tran Log IO`, `Network IO`, `Memory`) immediately reveal whether blocking locks or client `ASYNC_NETWORK_IO` stalls caused the 4.5-second delay.
- **D:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: When `duration >> CPU time`, the query is **waiting** rather than computing—Query Store Wait Categories (`Lock`, `Buffer IO`, `Tran Log IO`, `Network IO`, `Memory`) immediately reveal whether blocking locks or client `ASYNC_NETWORK_IO` stalls caused the 4.5-second delay.

### Question 49 — C

Answer: Inspect Actual Execution Plans (`Key Lookup`, `TempDB` sort/hash spill warnings, cardinality skew) alongside SQL Intelligent Insights (`SQLInsights`). The client application is fetching 2 million rows row-by-row (e.g., slow UI grid rendering or single-row client loop) instead of draining TDS network buffers rapidly, stalling SQL Server's network send buffer. Actual Execution Plans expose runtime row vs estimated row skews and `tempdb` spills, while SQL Intelligent Insights automatically compares a 7-day rolling baseline to diagnose regressions. Local study-map skill 3.9 (Analyze Execution Plans (`Key Lookup`, `TempDB` Spills, Row Skew) and Monitor via SQL Intelligent Insights), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Execution plans and SQL Intelligent Insights automated performance diagnostics (https://learn.microsoft.com/en-us/azure/azure-sql/database/intelligent-insights-overview).

- **A:** Incorrect for this requirement. Both standalone Data Migration Assistant (retired July 2025) and SQL Server Stretch Database (retired) are deprecated; use Azure Migrate / Azure SQL Migration extension and partitioning/Fabric/Blob tiering. Why the keyed choice wins: The client application is fetching 2 million rows row-by-row (e.g., slow UI grid rendering or single-row client loop) instead of draining TDS network buffers rapidly, stalling SQL Server's network send buffer.
- **B:** Incorrect for this requirement. BYOK TDE wraps the symmetric Database Encryption Key (`DEK`) with an asymmetric RSA key in Key Vault or Managed HSM so security admins control key rotation and instant revocation. Why the keyed choice wins: The client application is fetching 2 million rows row-by-row (e.g., slow UI grid rendering or single-row client loop) instead of draining TDS network buffers rapidly, stalling SQL Server's network send buffer.
- **C:** Correct. Actual Execution Plans expose runtime row vs estimated row skews and `tempdb` spills, while SQL Intelligent Insights automatically compares a 7-day rolling baseline to diagnose regressions. In this scenario: The client application is fetching 2 million rows row-by-row (e.g., slow UI grid rendering or single-row client loop) instead of draining TDS network buffers rapidly, stalling SQL Server's network send buffer.
- **D:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: The client application is fetching 2 million rows row-by-row (e.g., slow UI grid rendering or single-row client loop) instead of draining TDS network buffers rapidly, stalling SQL Server's network send buffer.

### Question 50 — C

Answer: Yes — the proposed configuration satisfies every stated technical, security, and availability requirement. Yes — `sys.index_resumable_operations` tracks paused resumable index builds/rebuilds, and `ALTER INDEX ... RESUME` picks up right at 68% completion. The proposed architecture, T-SQL syntax, and operational parameters satisfy every requirement without violating Azure SQL platform constraints. Local study-map skill 3.10 (Implement Fragmentation-Aware Index Rebuilds (`ONLINE`, `RESUMABLE`), Async Statistics, and `DBCC CHECKDB`), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Optimize index maintenance, statistics updates, and DBCC CHECKDB integrity checks (https://learn.microsoft.com/en-us/sql/relational-databases/indexes/reorganize-and-rebuild-indexes).

- **A:** Incorrect for this requirement. Dynamic Data Masking is not encryption at rest or row-level access control; users with ad-hoc `WHERE` privileges can still infer masked values unless RLS or encryption is applied. Why the keyed choice wins: Yes — `sys.index_resumable_operations` tracks paused resumable index builds/rebuilds, and `ALTER INDEX ... RESUME` picks up right at 68% completion.
- **B:** Incorrect for this requirement. SQL Server write-ahead logging performs sequential unbuffered writes; enabling `ReadOnly` or `ReadWrite` host caching on `.ldf` disks degrades throughput or risks corruption. Why the keyed choice wins: Yes — `sys.index_resumable_operations` tracks paused resumable index builds/rebuilds, and `ALTER INDEX ... RESUME` picks up right at 68% completion.
- **C:** Correct. The proposed architecture, T-SQL syntax, and operational parameters satisfy every requirement without violating Azure SQL platform constraints. In this scenario: Yes — `sys.index_resumable_operations` tracks paused resumable index builds/rebuilds, and `ALTER INDEX ... RESUME` picks up right at 68% completion.
- **D:** Incorrect for this requirement. `SqlPackage` exports tables sequentially rather than at a single LSN, so exporting a live write-heavy database without creating a point-in-time copy produces torn foreign-key state. Why the keyed choice wins: Yes — `sys.index_resumable_operations` tracks paused resumable index builds/rebuilds, and `ALTER INDEX ... RESUME` picks up right at 68% completion.

### Question 51 — B

Answer: Azure SQL Database Automatic Tuning (`FORCE_LAST_GOOD_PLAN = ON`, `CREATE_INDEX = ON`, `DROP_INDEX = ON`). Automatic Tuning monitors post-creation query CPU/I/O performance in Query Store against the pre-creation baseline; if query performance regresses, it automatically reverts (removes) the auto-created index. Automatic Tuning continuously monitors Query Store, automatically forces prior plans when regressions occur, creates validated missing nonclustered indexes, and removes unused duplicate indexes. Local study-map skill 3.11 (Configure Azure SQL Database Automatic Tuning (`FORCE_LAST_GOOD_PLAN`, `CREATE_INDEX`, `DROP_INDEX`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Automatic tuning in Azure SQL Database and Azure SQL Managed Instance (https://learn.microsoft.com/en-us/azure/azure-sql/database/automatic-tuning-overview).

- **A:** Incorrect for this requirement. Over-indexing inflates every `INSERT`/`UPDATE`/`DELETE` write and log flush, while `ONLINE = OFF` holds exclusive schema/table locks that block production traffic. Why the keyed choice wins: Automatic Tuning monitors post-creation query CPU/I/O performance in Query Store against the pre-creation baseline; if query performance regresses, it automatically reverts (removes) the auto-created index.
- **B:** Correct. Automatic Tuning continuously monitors Query Store, automatically forces prior plans when regressions occur, creates validated missing nonclustered indexes, and removes unused duplicate indexes. In this scenario: Automatic Tuning monitors post-creation query CPU/I/O performance in Query Store against the pre-creation baseline; if query performance regresses, it automatically reverts (removes) the auto-created index.
- **C:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: Automatic Tuning monitors post-creation query CPU/I/O performance in Query Store against the pre-creation baseline; if query performance regresses, it automatically reverts (removes) the auto-created index.
- **D:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Automatic Tuning monitors post-creation query CPU/I/O performance in Query Store against the pre-creation baseline; if query performance regresses, it automatically reverts (removes) the auto-created index.

### Question 52 — C

Answer: No — Resource Governor is supported on SQL Server and Azure SQL Managed Instance, not single Azure SQL Databases. No — Resource Governor is unsupported in single Azure SQL Databases (supported on SQL MI and SQL Server VMs); offload tenant exports to the free Business Critical read-only replica (`ApplicationIntent=ReadOnly`) instead. Single Azure SQL Databases do not expose `CREATE WORKLOAD GROUP` or Resource Governor; compute isolation in SQL Database uses Elastic Pools, Hyperscale named replicas, or separate DBs. Local study-map skill 3.12 (Configure Server Performance Settings (`MAXDOP`, `cost threshold`, `max server memory`) and Resource Governor), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Server configuration options (MAXDOP, memory) and Resource Governor workload isolation (https://learn.microsoft.com/en-us/sql/relational-databases/resource-governor/resource-governor).

- **A:** Incorrect for this requirement. Dynamic Data Masking is not encryption at rest or row-level access control; users with ad-hoc `WHERE` privileges can still infer masked values unless RLS or encryption is applied. Why the keyed choice wins: No — Resource Governor is unsupported in single Azure SQL Databases (supported on SQL MI and SQL Server VMs); offload tenant exports to the free Business Critical read-only replica (`ApplicationIntent=ReadOnly`) instead.
- **B:** Incorrect for this requirement. The proposed solution fails at least one stated technical, security, or availability requirement. Why the keyed choice wins: No — Resource Governor is unsupported in single Azure SQL Databases (supported on SQL MI and SQL Server VMs); offload tenant exports to the free Business Critical read-only replica (`ApplicationIntent=ReadOnly`) instead.
- **C:** Correct. Single Azure SQL Databases do not expose `CREATE WORKLOAD GROUP` or Resource Governor; compute isolation in SQL Database uses Elastic Pools, Hyperscale named replicas, or separate DBs. In this scenario: No — Resource Governor is unsupported in single Azure SQL Databases (supported on SQL MI and SQL Server VMs); offload tenant exports to the free Business Critical read-only replica (`ApplicationIntent=ReadOnly`) instead.
- **D:** Incorrect for this requirement. `SqlPackage` exports tables sequentially rather than at a single LSN, so exporting a live write-heavy database without creating a point-in-time copy produces torn foreign-key state. Why the keyed choice wins: No — Resource Governor is unsupported in single Azure SQL Databases (supported on SQL MI and SQL Server VMs); offload tenant exports to the free Business Critical read-only replica (`ApplicationIntent=ReadOnly`) instead.

### Question 53 — A

Answer: Use `ALTER DATABASE SCOPED CONFIGURATION` (`MAXDOP`, `LEGACY_CARDINALITY_ESTIMATION`, `PARAMETER_SNIFFING`, `OPTIMIZED_PLAN_FORCING`) per database. Enabling `DOP_FEEDBACK = ON` iteratively tests lower parallelism degrees (`MAXDOP` step-downs) for eligible repeating queries and persists validated DOP reductions inside Query Store. Database-scoped configurations isolate optimizer settings (`MAXDOP`, CE version, parameter sniffing) to a single database without affecting sibling databases on SQL MI/VMs or requiring server access. Local study-map skill 3.13 (Implement `ALTER DATABASE SCOPED CONFIGURATION` (`MAXDOP`, `LEGACY_CARDINALITY_ESTIMATION`, `PARAMETER_SNIFFING`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: ALTER DATABASE SCOPED CONFIGURATION and dynamic compute/storage scaling (https://learn.microsoft.com/en-us/sql/t-sql/statements/alter-database-scoped-configuration-transact-sql).

- **A:** Correct. Database-scoped configurations isolate optimizer settings (`MAXDOP`, CE version, parameter sniffing) to a single database without affecting sibling databases on SQL MI/VMs or requiring server access. In this scenario: Enabling `DOP_FEEDBACK = ON` iteratively tests lower parallelism degrees (`MAXDOP` step-downs) for eligible repeating queries and persists validated DOP reductions inside Query Store.
- **B:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: Enabling `DOP_FEEDBACK = ON` iteratively tests lower parallelism degrees (`MAXDOP` step-downs) for eligible repeating queries and persists validated DOP reductions inside Query Store.
- **C:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: Enabling `DOP_FEEDBACK = ON` iteratively tests lower parallelism degrees (`MAXDOP` step-downs) for eligible repeating queries and persists validated DOP reductions inside Query Store.
- **D:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Enabling `DOP_FEEDBACK = ON` iteratively tests lower parallelism degrees (`MAXDOP` step-downs) for eligible repeating queries and persists validated DOP reductions inside Query Store.

### Question 54 — D

Answer: Enable compatibility level `160` Intelligent Query Processing (`Parameter Sensitive Plan` optimization, `Memory Grant Feedback` persistence, `Scalar UDF Inlining`, `DOP Feedback`). Intelligent Query Processing's **Table Variable Deferred Compilation** (`compat 150+`) defers compiling statements referencing `@StageIds` until first execution, using actual populated cardinality instead of `1 row`. SQL 2022 / Azure SQL compat `160` IQP caches multiple active plans per query based on parameter cardinality (`PSP`), right-sizes `tempdb`-spilling memory grants, and inlines scalar T-SQL UDFs. Local study-map skill 3.14 (Identify Use Cases for Intelligent Query Processing (`PSP` Optimization, Memory Grant Feedback, Scalar UDF Inlining)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Intelligent Query Processing (IQP) features in SQL databases (https://learn.microsoft.com/en-us/sql/relational-databases/performance/intelligent-query-processing).

- **A:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: Intelligent Query Processing's **Table Variable Deferred Compilation** (`compat 150+`) defers compiling statements referencing `@StageIds` until first execution, using actual populated cardinality instead of `1 row`.
- **B:** Incorrect for this requirement. Row-by-row cursors and multi-statement TVFs under legacy compatibility levels execute thousands of iterative context switches and 1-row cardinality guesses. Why the keyed choice wins: Intelligent Query Processing's **Table Variable Deferred Compilation** (`compat 150+`) defers compiling statements referencing `@StageIds` until first execution, using actual populated cardinality instead of `1 row`.
- **C:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: Intelligent Query Processing's **Table Variable Deferred Compilation** (`compat 150+`) defers compiling statements referencing `@StageIds` until first execution, using actual populated cardinality instead of `1 row`.
- **D:** Correct. SQL 2022 / Azure SQL compat `160` IQP caches multiple active plans per query based on parameter cardinality (`PSP`), right-sizes `tempdb`-spilling memory grants, and inlines scalar T-SQL UDFs. In this scenario: Intelligent Query Processing's **Table Variable Deferred Compilation** (`compat 150+`) defers compiling statements referencing `@StageIds` until first execution, using actual populated cardinality instead of `1 row`.

### Question 55 — A, D

Answers: Create a Windows/SQL Credential and map it to a SQL Server Agent Subsystem Proxy (`CmdExec` / `PowerShell`) instead of granting `sysadmin`; Configure Database Mail, define an Agent Operator, and create SQL Server Agent Alerts for Severity `19–25` and Errors `823`, `824`, and `825`. Map least-privilege Credentials to SQL Server Agent Subsystem Proxies, and configure Database Mail Operators bound to Severity `19–25` and Error `823–825` Alerts. Local study-map skill 4.1 (Create and Schedule SQL Server Agent Maintenance Jobs, Proxies, Severity `19–25` Alerts, and Database Mail), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Server Agent jobs, schedules, alerts, and Database Mail operators (https://learn.microsoft.com/en-us/sql/ssms/agent/sql-server-agent).

- **A:** Correct. SQL Server Agent proxies let non-`sysadmin` job owners execute external subsystem steps under a scoped least-privilege identity. In this scenario: Map least-privilege Credentials to SQL Server Agent Subsystem Proxies, and configure Database Mail Operators bound to Severity `19–25` and Error `823–825` Alerts.
- **B:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Map least-privilege Credentials to SQL Server Agent Subsystem Proxies, and configure Database Mail Operators bound to Severity `19–25` and Error `823–825` Alerts.
- **C:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: Map least-privilege Credentials to SQL Server Agent Subsystem Proxies, and configure Database Mail Operators bound to Severity `19–25` and Error `823–825` Alerts.
- **D:** Correct. Severity `19–25` and I/O errors `823–825` indicate critical resource exhaustion or storage corruption requiring immediate DBA notification. In this scenario: Map least-privilege Credentials to SQL Server Agent Subsystem Proxies, and configure Database Mail Operators bound to Severity `19–25` and Error `823–825` Alerts.
- **E:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Map least-privilege Credentials to SQL Server Agent Subsystem Proxies, and configure Database Mail Operators bound to Severity `19–25` and Error `823–825` Alerts.

### Question 56 — D

Answer: SQL Server Agent multi-step jobs using Credentials + Subsystem Proxies, Severity `19–25` / Error `823–825` Alerts, and Database Mail Operators. In `SQL Server Agent Properties -> History`, raise `Maximum job history log size (in rows)` / `Maximum job history rows per job` and enable time-based cleanup (e.g., `Remove agent history older than 4 weeks`). Least-privilege Agent steps run under Credential-backed Proxies rather than `sysadmin`, while SQL Agent Alerts notify Operators immediately via Database Mail on fatal engine/I/O errors. Local study-map skill 4.1 (Create and Schedule SQL Server Agent Maintenance Jobs, Proxies, Severity `19–25` Alerts, and Database Mail), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Server Agent jobs, schedules, alerts, and Database Mail operators (https://learn.microsoft.com/en-us/sql/ssms/agent/sql-server-agent).

- **A:** Incorrect for this requirement. Single Azure SQL Databases do not expose `SQLServerAgent`; cross-database PaaS scheduling uses Elastic Job Agents with Managed Identity or Azure Automation. Why the keyed choice wins: In `SQL Server Agent Properties -> History`, raise `Maximum job history log size (in rows)` / `Maximum job history rows per job` and enable time-based cleanup (e.g., `Remove agent history older than 4 weeks`).
- **B:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: In `SQL Server Agent Properties -> History`, raise `Maximum job history log size (in rows)` / `Maximum job history rows per job` and enable time-based cleanup (e.g., `Remove agent history older than 4 weeks`).
- **C:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: In `SQL Server Agent Properties -> History`, raise `Maximum job history log size (in rows)` / `Maximum job history rows per job` and enable time-based cleanup (e.g., `Remove agent history older than 4 weeks`).
- **D:** Correct. Least-privilege Agent steps run under Credential-backed Proxies rather than `sysadmin`, while SQL Agent Alerts notify Operators immediately via Database Mail on fatal engine/I/O errors. In this scenario: In `SQL Server Agent Properties -> History`, raise `Maximum job history log size (in rows)` / `Maximum job history rows per job` and enable time-based cleanup (e.g., `Remove agent history older than 4 weeks`).

### Question 57 — D

Answer: SQL Server Agent multi-step jobs using Credentials + Subsystem Proxies, Severity `19–25` / Error `823–825` Alerts, and Database Mail Operators. A **WMI event alert** in SQL Server Agent subscribes to `\\.\root\Microsoft\SqlServer\ServerEvents\MSSQLSERVER` WQL events such as `DEADLOCK_GRAPH` or `BLOCKED_PROCESS_REPORT`. Least-privilege Agent steps run under Credential-backed Proxies rather than `sysadmin`, while SQL Agent Alerts notify Operators immediately via Database Mail on fatal engine/I/O errors. Local study-map skill 4.1 (Create and Schedule SQL Server Agent Maintenance Jobs, Proxies, Severity `19–25` Alerts, and Database Mail), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Server Agent jobs, schedules, alerts, and Database Mail operators (https://learn.microsoft.com/en-us/sql/ssms/agent/sql-server-agent).

- **A:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: A **WMI event alert** in SQL Server Agent subscribes to `\\.\root\Microsoft\SqlServer\ServerEvents\MSSQLSERVER` WQL events such as `DEADLOCK_GRAPH` or `BLOCKED_PROCESS_REPORT`.
- **B:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: A **WMI event alert** in SQL Server Agent subscribes to `\\.\root\Microsoft\SqlServer\ServerEvents\MSSQLSERVER` WQL events such as `DEADLOCK_GRAPH` or `BLOCKED_PROCESS_REPORT`.
- **C:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: A **WMI event alert** in SQL Server Agent subscribes to `\\.\root\Microsoft\SqlServer\ServerEvents\MSSQLSERVER` WQL events such as `DEADLOCK_GRAPH` or `BLOCKED_PROCESS_REPORT`.
- **D:** Correct. Least-privilege Agent steps run under Credential-backed Proxies rather than `sysadmin`, while SQL Agent Alerts notify Operators immediately via Database Mail on fatal engine/I/O errors. In this scenario: A **WMI event alert** in SQL Server Agent subscribes to `\\.\root\Microsoft\SqlServer\ServerEvents\MSSQLSERVER` WQL events such as `DEADLOCK_GRAPH` or `BLOCKED_PROCESS_REPORT`.

### Question 58 — A

Answer: Inspect `msdb.dbo.sysjobhistory` / `sp_help_jobhistory`, verify proxy/credential permissions, and account for SQL Managed Instance Agent subsystem boundaries. `SQLAgentOperatorRole` in `msdb` grants visibility across all local jobs plus permission to enable/disable/start/stop jobs and view all job histories (whereas `SQLAgentReaderRole` is view-only and `SQLAgentUserRole` sees own jobs only). Job step failures surface in `msdb.dbo.sysjobhistory`; on SQL Managed Instance, Agent runs inside PaaS boundaries where host OS `CmdExec`/ActiveX access is restricted compared to IaaS VMs. Local study-map skill 4.2 (Troubleshoot SQL Server Agent Job Histories, Credential/Proxy Permissions, and SQL MI Subsystem Boundaries), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Troubleshoot SQL Server Agent jobs, proxies, and SQL Managed Instance Agent differences (https://learn.microsoft.com/en-us/azure/azure-sql/managed-instance/transact-sql-tsql-differences-sql-server).

- **A:** Correct. Job step failures surface in `msdb.dbo.sysjobhistory`; on SQL Managed Instance, Agent runs inside PaaS boundaries where host OS `CmdExec`/ActiveX access is restricted compared to IaaS VMs. In this scenario: `SQLAgentOperatorRole` in `msdb` grants visibility across all local jobs plus permission to enable/disable/start/stop jobs and view all job histories (whereas `SQLAgentReaderRole` is view-only and `SQLAgentUserRole` sees own jobs only).
- **B:** Incorrect for this requirement. Single Azure SQL Databases do not expose `SQLServerAgent`; cross-database PaaS scheduling uses Elastic Job Agents with Managed Identity or Azure Automation. Why the keyed choice wins: `SQLAgentOperatorRole` in `msdb` grants visibility across all local jobs plus permission to enable/disable/start/stop jobs and view all job histories (whereas `SQLAgentReaderRole` is view-only and `SQLAgentUserRole` sees own jobs only).
- **C:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: `SQLAgentOperatorRole` in `msdb` grants visibility across all local jobs plus permission to enable/disable/start/stop jobs and view all job histories (whereas `SQLAgentReaderRole` is view-only and `SQLAgentUserRole` sees own jobs only).
- **D:** Incorrect for this requirement. Both standalone Data Migration Assistant (retired July 2025) and SQL Server Stretch Database (retired) are deprecated; use Azure Migrate / Azure SQL Migration extension and partitioning/Fabric/Blob tiering. Why the keyed choice wins: `SQLAgentOperatorRole` in `msdb` grants visibility across all local jobs plus permission to enable/disable/start/stop jobs and view all job histories (whereas `SQLAgentReaderRole` is view-only and `SQLAgentUserRole` sees own jobs only).

### Question 59 — A

Answer: Inspect `msdb.dbo.sysjobhistory` / `sp_help_jobhistory`, verify proxy/credential permissions, and account for SQL Managed Instance Agent subsystem boundaries. SSMS enables `SET QUOTED_IDENTIFIER ON` by default, whereas SQL Server Agent T-SQL job steps default `QUOTED_IDENTIFIER` to `OFF` unless `SET QUOTED_IDENTIFIER ON;` is added at the top of the job step script! Job step failures surface in `msdb.dbo.sysjobhistory`; on SQL Managed Instance, Agent runs inside PaaS boundaries where host OS `CmdExec`/ActiveX access is restricted compared to IaaS VMs. Local study-map skill 4.2 (Troubleshoot SQL Server Agent Job Histories, Credential/Proxy Permissions, and SQL MI Subsystem Boundaries), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Troubleshoot SQL Server Agent jobs, proxies, and SQL Managed Instance Agent differences (https://learn.microsoft.com/en-us/azure/azure-sql/managed-instance/transact-sql-tsql-differences-sql-server).

- **A:** Correct. Job step failures surface in `msdb.dbo.sysjobhistory`; on SQL Managed Instance, Agent runs inside PaaS boundaries where host OS `CmdExec`/ActiveX access is restricted compared to IaaS VMs. In this scenario: SSMS enables `SET QUOTED_IDENTIFIER ON` by default, whereas SQL Server Agent T-SQL job steps default `QUOTED_IDENTIFIER` to `OFF` unless `SET QUOTED_IDENTIFIER ON;` is added at the top of the job step script!
- **B:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: SSMS enables `SET QUOTED_IDENTIFIER ON` by default, whereas SQL Server Agent T-SQL job steps default `QUOTED_IDENTIFIER` to `OFF` unless `SET QUOTED_IDENTIFIER ON;` is added at the top of the job step script!
- **C:** Incorrect for this requirement. BYOK TDE wraps the symmetric Database Encryption Key (`DEK`) with an asymmetric RSA key in Key Vault or Managed HSM so security admins control key rotation and instant revocation. Why the keyed choice wins: SSMS enables `SET QUOTED_IDENTIFIER ON` by default, whereas SQL Server Agent T-SQL job steps default `QUOTED_IDENTIFIER` to `OFF` unless `SET QUOTED_IDENTIFIER ON;` is added at the top of the job step script!
- **D:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: SSMS enables `SET QUOTED_IDENTIFIER ON` by default, whereas SQL Server Agent T-SQL job steps default `QUOTED_IDENTIFIER` to `OFF` unless `SET QUOTED_IDENTIFIER ON;` is added at the top of the job step script!

### Question 60 — A, C

Answers: Mark sensitive parameters with `@secure()` in Bicep and pass Key Vault secret references from the parameter file rather than cleartext values; Run `az deployment group what-if` (or `New-AzResourceGroupDeployment -WhatIf`) as a pull-request gate before applying template changes. Decorate secret parameters with `@secure()` referencing Azure Key Vault secrets, and run `az deployment group what-if` prior to deployment execution. Local study-map skill 4.3 (Automate Idempotent Deployment Using Bicep and ARM Templates with `@secure()` Key Vault References & `what-if`), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Deploy Azure SQL resources using Bicep and Azure Resource Manager (ARM) templates (https://learn.microsoft.com/en-us/azure/azure-sql/database/sql-database-Quickstart-bicep).

- **A:** Correct. `what-if` calculates predicted `Create`, `Modify`, `Delete`, and `Ignore` operations against live Azure SQL resources to catch destructive config drift. In this scenario: Decorate secret parameters with `@secure()` referencing Azure Key Vault secrets, and run `az deployment group what-if` prior to deployment execution.
- **B:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: Decorate secret parameters with `@secure()` referencing Azure Key Vault secrets, and run `az deployment group what-if` prior to deployment execution.
- **C:** Correct. `@secure()` prevents secret logging in deployment history, while Key Vault references resolve secrets inside ARM at deploy time without exposing them to CI runners. In this scenario: Decorate secret parameters with `@secure()` referencing Azure Key Vault secrets, and run `az deployment group what-if` prior to deployment execution.
- **D:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Decorate secret parameters with `@secure()` referencing Azure Key Vault secrets, and run `az deployment group what-if` prior to deployment execution.
- **E:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Decorate secret parameters with `@secure()` referencing Azure Key Vault secrets, and run `az deployment group what-if` prior to deployment execution.

### Question 61 — C

Answer: Declarative Bicep / ARM templates (`Microsoft.Sql/servers`) referencing Azure Key Vault secrets via `@secure()` parameters and validated with `az deployment group what-if`. `resource sqlServers 'Microsoft.Sql/servers@2023-08-01-preview' = [for region in regions: { ... }]` loops declaratively over `regions` in parallel with ARM idempotency. Bicep compiles to idempotent ARM JSON, injects secrets directly from Key Vault without exposing plaintext in CI logs, and previews resource mutations safely via `what-if` before execution. Local study-map skill 4.3 (Automate Idempotent Deployment Using Bicep and ARM Templates with `@secure()` Key Vault References & `what-if`), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Deploy Azure SQL resources using Bicep and Azure Resource Manager (ARM) templates (https://learn.microsoft.com/en-us/azure/azure-sql/database/sql-database-Quickstart-bicep).

- **A:** Incorrect for this requirement. Both standalone Data Migration Assistant (retired July 2025) and SQL Server Stretch Database (retired) are deprecated; use Azure Migrate / Azure SQL Migration extension and partitioning/Fabric/Blob tiering. Why the keyed choice wins: `resource sqlServers 'Microsoft.Sql/servers@2023-08-01-preview' = [for region in regions: { ... }]` loops declaratively over `regions` in parallel with ARM idempotency.
- **B:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: `resource sqlServers 'Microsoft.Sql/servers@2023-08-01-preview' = [for region in regions: { ... }]` loops declaratively over `regions` in parallel with ARM idempotency.
- **C:** Correct. Bicep compiles to idempotent ARM JSON, injects secrets directly from Key Vault without exposing plaintext in CI logs, and previews resource mutations safely via `what-if` before execution. In this scenario: `resource sqlServers 'Microsoft.Sql/servers@2023-08-01-preview' = [for region in regions: { ... }]` loops declaratively over `regions` in parallel with ARM idempotency.
- **D:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: `resource sqlServers 'Microsoft.Sql/servers@2023-08-01-preview' = [for region in regions: { ... }]` loops declaratively over `regions` in parallel with ARM idempotency.

### Question 62 — D

Answer: Idempotent day-2 scripting with Azure PowerShell (`New-AzSqlDatabase`, `Set-AzSqlElasticPool`) or Azure CLI (`az sql db update`, `az sql mi update`). `az sql db update` with `--elastic-pool pool-premium` moves an existing database seamlessly between Elastic Pools on the same logical SQL server online. `Az.Sql` cmdlets and `az sql` CLI commands automate repeatable provisioning, tier/vCore scaling, failover triggers, and firewall/backup updates from DevOps pipelines or shell scripts. Local study-map skill 4.4 (Automate Azure SQL Provisioning and Day-2 Management Using Azure PowerShell (`Az.Sql`) and Azure CLI (`az sql`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Automate Azure SQL management using Azure PowerShell and Azure CLI (https://learn.microsoft.com/en-us/azure/azure-sql/database/scripts/create-and-configure-database-powershell).

- **A:** Incorrect for this requirement. Both standalone Data Migration Assistant (retired July 2025) and SQL Server Stretch Database (retired) are deprecated; use Azure Migrate / Azure SQL Migration extension and partitioning/Fabric/Blob tiering. Why the keyed choice wins: `az sql db update` with `--elastic-pool pool-premium` moves an existing database seamlessly between Elastic Pools on the same logical SQL server online.
- **B:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: `az sql db update` with `--elastic-pool pool-premium` moves an existing database seamlessly between Elastic Pools on the same logical SQL server online.
- **C:** Incorrect for this requirement. Without the original TDE certificate and private key restored into the target SQL Server `master` database, a TDE-encrypted `.bak` or detached `.mdf` cannot be decrypted anywhere. Why the keyed choice wins: `az sql db update` with `--elastic-pool pool-premium` moves an existing database seamlessly between Elastic Pools on the same logical SQL server online.
- **D:** Correct. `Az.Sql` cmdlets and `az sql` CLI commands automate repeatable provisioning, tier/vCore scaling, failover triggers, and firewall/backup updates from DevOps pipelines or shell scripts. In this scenario: `az sql db update` with `--elastic-pool pool-premium` moves an existing database seamlessly between Elastic Pools on the same logical SQL server online.

### Question 63 — D

Answer: Idempotent day-2 scripting with Azure PowerShell (`New-AzSqlDatabase`, `Set-AzSqlElasticPool`) or Azure CLI (`az sql db update`, `az sql mi update`). `New-AzSqlElasticPool` creates a new Elastic Pool with pooled vCore capacity and per-database min/max vCore guardrails. `Az.Sql` cmdlets and `az sql` CLI commands automate repeatable provisioning, tier/vCore scaling, failover triggers, and firewall/backup updates from DevOps pipelines or shell scripts. Local study-map skill 4.4 (Automate Azure SQL Provisioning and Day-2 Management Using Azure PowerShell (`Az.Sql`) and Azure CLI (`az sql`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Automate Azure SQL management using Azure PowerShell and Azure CLI (https://learn.microsoft.com/en-us/azure/azure-sql/database/scripts/create-and-configure-database-powershell).

- **A:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: `New-AzSqlElasticPool` creates a new Elastic Pool with pooled vCore capacity and per-database min/max vCore guardrails.
- **B:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: `New-AzSqlElasticPool` creates a new Elastic Pool with pooled vCore capacity and per-database min/max vCore guardrails.
- **C:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: `New-AzSqlElasticPool` creates a new Elastic Pool with pooled vCore capacity and per-database min/max vCore guardrails.
- **D:** Correct. `Az.Sql` cmdlets and `az sql` CLI commands automate repeatable provisioning, tier/vCore scaling, failover triggers, and firewall/backup updates from DevOps pipelines or shell scripts. In this scenario: `New-AzSqlElasticPool` creates a new Elastic Pool with pooled vCore capacity and per-database min/max vCore guardrails.

### Question 64 — C

Answer: Diagnose deployment failures via `Get-AzResourceGroupDeploymentOperation` / Activity Log `CorrelationId`, checking regional vCore quotas and SQL MI subnet delegation/NSG/UDR rules. With a UAMI created beforehand, Key Vault RBAC permissions can be pre-granted and fully propagated **before** `Microsoft.Sql/servers` provisions, avoiding RBAC replication lag during initial CMK TDE validation. SQL Managed Instance deployments fail most commonly when the subnet lacks `/28+` IP space, `Microsoft.Sql/managedInstances` delegation, route table (`0.0.0.0/0` NextHop `Internet`), or regional vCore quota. Local study-map skill 4.5 (Monitor and Troubleshoot Automated Deployments (`CorrelationId`, Quota, SQL MI Subnet Delegation/UDR/NSG)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Troubleshoot ARM/Bicep template and SQL Managed Instance subnet deployment errors (https://learn.microsoft.com/en-us/azure/azure-resource-manager/troubleshooting/common-deployment-errors).

- **A:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: With a UAMI created beforehand, Key Vault RBAC permissions can be pre-granted and fully propagated **before** `Microsoft.Sql/servers` provisions, avoiding RBAC replication lag during initial CMK TDE validation.
- **B:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: With a UAMI created beforehand, Key Vault RBAC permissions can be pre-granted and fully propagated **before** `Microsoft.Sql/servers` provisions, avoiding RBAC replication lag during initial CMK TDE validation.
- **C:** Correct. SQL Managed Instance deployments fail most commonly when the subnet lacks `/28+` IP space, `Microsoft.Sql/managedInstances` delegation, route table (`0.0.0.0/0` NextHop `Internet`), or regional vCore quota. In this scenario: With a UAMI created beforehand, Key Vault RBAC permissions can be pre-granted and fully propagated **before** `Microsoft.Sql/servers` provisions, avoiding RBAC replication lag during initial CMK TDE validation.
- **D:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: With a UAMI created beforehand, Key Vault RBAC permissions can be pre-granted and fully propagated **before** `Microsoft.Sql/servers` provisions, avoiding RBAC replication lag during initial CMK TDE validation.

### Question 65 — B

Answer: Diagnose deployment failures via `Get-AzResourceGroupDeploymentOperation` / Activity Log `CorrelationId`, checking regional vCore quotas and SQL MI subnet delegation/NSG/UDR rules. `az deployment operation group list` inspects every nested resource operation inside the deployment and exposes `statusMessage.error` details for failed resources. SQL Managed Instance deployments fail most commonly when the subnet lacks `/28+` IP space, `Microsoft.Sql/managedInstances` delegation, route table (`0.0.0.0/0` NextHop `Internet`), or regional vCore quota. Local study-map skill 4.5 (Monitor and Troubleshoot Automated Deployments (`CorrelationId`, Quota, SQL MI Subnet Delegation/UDR/NSG)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Troubleshoot ARM/Bicep template and SQL Managed Instance subnet deployment errors (https://learn.microsoft.com/en-us/azure/azure-resource-manager/troubleshooting/common-deployment-errors).

- **A:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: `az deployment operation group list` inspects every nested resource operation inside the deployment and exposes `statusMessage.error` details for failed resources.
- **B:** Correct. SQL Managed Instance deployments fail most commonly when the subnet lacks `/28+` IP space, `Microsoft.Sql/managedInstances` delegation, route table (`0.0.0.0/0` NextHop `Internet`), or regional vCore quota. In this scenario: `az deployment operation group list` inspects every nested resource operation inside the deployment and exposes `statusMessage.error` details for failed resources.
- **C:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: `az deployment operation group list` inspects every nested resource operation inside the deployment and exposes `statusMessage.error` details for failed resources.
- **D:** Incorrect for this requirement. Without the original TDE certificate and private key restored into the target SQL Server `master` database, a TDE-encrypted `.bak` or detached `.mdf` cannot be decrypted anywhere. Why the keyed choice wins: `az deployment operation group list` inspects every nested resource operation inside the deployment and exposes `statusMessage.error` details for failed resources.

### Question 66 — D

Answer: Create S1+ Job Database & Elastic Job Agent with UAMI → Create contained UAMI user on target DBs with needed permissions → Define Target Group (`jobs.sp_add_target_group_member`) → Add T-SQL steps & schedule (`jobs.sp_add_job`). Create an S1+ Job Database and Elastic Job Agent with UAMI, create contained UAMI users on target DBs, define the Target Group (`jobs.sp_add_target_group_member`), and add T-SQL steps/schedule (`jobs.sp_add_job`). Modern Elastic Jobs use a dedicated S1+ job database, an Elastic Job Agent assigned a User-Assigned Managed Identity (UAMI) authorized on target databases, a target group, and scheduled T-SQL steps. Local study-map skill 4.6 (Create and Configure Azure SQL Database Elastic Jobs Across Target Groups Using User-Assigned Managed Identity), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Elastic jobs in Azure SQL Database with Managed Identity authentication (https://learn.microsoft.com/en-us/azure/azure-sql/database/elastic-jobs-overview).

- **A:** Incorrect for this requirement. Incorrect workflow: single Azure SQL Databases do not have SQL Server Agent or cross-DB linked servers in the same way as SQL MI; Elastic Jobs fan out T-SQL asynchronously. Why the keyed choice wins: Create an S1+ Job Database and Elastic Job Agent with UAMI, create contained UAMI users on target DBs, define the Target Group (`jobs.sp_add_target_group_member`), and add T-SQL steps/schedule (`jobs.sp_add_job`).
- **B:** Incorrect for this requirement. Incorrect workflow: Elastic Job Agents target Azure SQL servers, elastic pools, and databases using Managed Identity—never Cosmos DB containers or hardcoded Git secrets. Why the keyed choice wins: Create an S1+ Job Database and Elastic Job Agent with UAMI, create contained UAMI users on target DBs, define the Target Group (`jobs.sp_add_target_group_member`), and add T-SQL steps/schedule (`jobs.sp_add_job`).
- **C:** Incorrect for this requirement. Incorrect workflow: Elastic Job databases require S1 or higher, target groups must exist before binding executions, NTLM local accounts are invalid in SQL DB, and `msdb` belongs to SQL Agent. Why the keyed choice wins: Create an S1+ Job Database and Elastic Job Agent with UAMI, create contained UAMI users on target DBs, define the Target Group (`jobs.sp_add_target_group_member`), and add T-SQL steps/schedule (`jobs.sp_add_job`).
- **D:** Correct. Modern Elastic Jobs use a dedicated S1+ job database, an Elastic Job Agent assigned a User-Assigned Managed Identity (UAMI) authorized on target databases, a target group, and scheduled T-SQL steps. In this scenario: Create an S1+ Job Database and Elastic Job Agent with UAMI, create contained UAMI users on target DBs, define the Target Group (`jobs.sp_add_target_group_member`), and add T-SQL steps/schedule (`jobs.sp_add_job`).

### Question 67 — C

Answer: Azure Automation PowerShell / Python runbooks (or Azure Functions / Logic Apps) using a System-Assigned Managed Identity on a recurring schedule. Specifying `@output_type = 'SqlDatabase'`, `@output_server_name`, `@output_database_name`, and `@output_table_name` in `jobs.sp_add_jobstep` automatically writes every target DB's `SELECT` output into one central table! Azure Automation runbooks authenticate via Managed Identity (`Connect-AzAccount -Identity`) to scale vCores/Elastic Pools on schedule, rotate keys, or orchestrate hybrid maintenance via Hybrid Workers. Local study-map skill 4.7 (Automate Database Maintenance and Scaling Using Azure Automation Runbooks, Logic Apps, and Azure Functions), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Automate Azure SQL maintenance tasks with Azure Automation, Logic Apps, and Functions (https://learn.microsoft.com/en-us/azure/automation/overview).

- **A:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Specifying `@output_type = 'SqlDatabase'`, `@output_server_name`, `@output_database_name`, and `@output_table_name` in `jobs.sp_add_jobstep` automatically writes every target DB's `SELECT` output into one central table!
- **B:** Incorrect for this requirement. Without the original TDE certificate and private key restored into the target SQL Server `master` database, a TDE-encrypted `.bak` or detached `.mdf` cannot be decrypted anywhere. Why the keyed choice wins: Specifying `@output_type = 'SqlDatabase'`, `@output_server_name`, `@output_database_name`, and `@output_table_name` in `jobs.sp_add_jobstep` automatically writes every target DB's `SELECT` output into one central table!
- **C:** Correct. Azure Automation runbooks authenticate via Managed Identity (`Connect-AzAccount -Identity`) to scale vCores/Elastic Pools on schedule, rotate keys, or orchestrate hybrid maintenance via Hybrid Workers. In this scenario: Specifying `@output_type = 'SqlDatabase'`, `@output_server_name`, `@output_database_name`, and `@output_table_name` in `jobs.sp_add_jobstep` automatically writes every target DB's `SELECT` output into one central table!
- **D:** Incorrect for this requirement. Both standalone Data Migration Assistant (retired July 2025) and SQL Server Stretch Database (retired) are deprecated; use Azure Migrate / Azure SQL Migration extension and partitioning/Fabric/Blob tiering. Why the keyed choice wins: Specifying `@output_type = 'SqlDatabase'`, `@output_server_name`, `@output_database_name`, and `@output_table_name` in `jobs.sp_add_jobstep` automatically writes every target DB's `SELECT` output into one central table!

### Question 68 — A

Answer: Configure Azure Monitor Metric / Log Alert rules routed to Action Groups and query `jobs.job_executions` in the Elastic Job database to diagnose step failures. Create an Azure Monitor **Alert Processing Rule** (`Suppress notifications`) scheduled for Sundays 02:00–04:00 UTC scoped to the SaaS resource groups. Action Groups dispatch email/SMS/webhook/Logic App notifications when alert thresholds fire, while `jobs.job_executions` exposes per-target error messages, retries, and timeouts for Elastic Jobs. Local study-map skill 4.8 (Configure Azure Monitor Action Group Alerts on Database Tasks and Troubleshoot `jobs.job_executions`), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Configure Azure Monitor alerts and troubleshoot Elastic Jobs and automated runbooks (https://learn.microsoft.com/en-us/azure/azure-sql/database/alerts-insights-configure-portal).

- **A:** Correct. Action Groups dispatch email/SMS/webhook/Logic App notifications when alert thresholds fire, while `jobs.job_executions` exposes per-target error messages, retries, and timeouts for Elastic Jobs. In this scenario: Create an Azure Monitor **Alert Processing Rule** (`Suppress notifications`) scheduled for Sundays 02:00–04:00 UTC scoped to the SaaS resource groups.
- **B:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: Create an Azure Monitor **Alert Processing Rule** (`Suppress notifications`) scheduled for Sundays 02:00–04:00 UTC scoped to the SaaS resource groups.
- **C:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: Create an Azure Monitor **Alert Processing Rule** (`Suppress notifications`) scheduled for Sundays 02:00–04:00 UTC scoped to the SaaS resource groups.
- **D:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Create an Azure Monitor **Alert Processing Rule** (`Suppress notifications`) scheduled for Sundays 02:00–04:00 UTC scoped to the SaaS resource groups.

### Question 69 — B

Answer: No — exporting a `.bacpac` directly from an active OLTP database without copying first is not transactionally consistent. No — Geo-Restore has an RPO of up to `1 hour` and an RTO of up to `12 hours` (no SLA guarantee for 1-hour recovery); meeting `RPO <= 5s` / `RTO <= 1h` requires a Failover Group. `SqlPackage` exports tables sequentially rather than at a single LSN, so exporting a live write-heavy database without creating a point-in-time copy produces torn foreign-key state. Local study-map skill 5.1 (Recommend HA/DR Architectures Based on RPO and RTO (`Zone Redundant`, `Failover Groups`, `Geo-Restore`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Business continuity, RPO/RTO targets, and high availability in Azure SQL (https://learn.microsoft.com/en-us/azure/azure-sql/database/business-continuity-high-availability-disaster-recovery-hadr-overview).

- **A:** Incorrect for this requirement. Server-level IP firewall rules reside in the logical `master` database and must either be recreated on the DR logical server or replaced with portable database-level rules where appropriate. Why the keyed choice wins: No — Geo-Restore has an RPO of up to `1 hour` and an RTO of up to `12 hours` (no SLA guarantee for 1-hour recovery); meeting `RPO <= 5s` / `RTO <= 1h` requires a Failover Group.
- **B:** Correct. `SqlPackage` exports tables sequentially rather than at a single LSN, so exporting a live write-heavy database without creating a point-in-time copy produces torn foreign-key state. In this scenario: No — Geo-Restore has an RPO of up to `1 hour` and an RTO of up to `12 hours` (no SLA guarantee for 1-hour recovery); meeting `RPO <= 5s` / `RTO <= 1h` requires a Failover Group.
- **C:** Incorrect for this requirement. The proposed solution fails at least one stated technical, security, or availability requirement. Why the keyed choice wins: No — Geo-Restore has an RPO of up to `1 hour` and an RTO of up to `12 hours` (no SLA guarantee for 1-hour recovery); meeting `RPO <= 5s` / `RTO <= 1h` requires a Failover Group.
- **D:** Incorrect for this requirement. Dynamic Data Masking is not encryption at rest or row-level access control; users with ad-hoc `WHERE` privileges can still infer masked values unless RLS or encryption is applied. Why the keyed choice wins: No — Geo-Restore has an RPO of up to `1 hour` and an RTO of up to `12 hours` (no SLA guarantee for 1-hour recovery); meeting `RPO <= 5s` / `RTO <= 1h` requires a Failover Group.

### Question 70 — A

Answer: Align tiers to RPO/RTO: `Zone Redundant` (`RPO = 0` intra-region HA), `Failover Groups` (`RPO = 5s`, `RTO = 1h` SLA cross-region DR), vs `Geo-Restore` (`RPO = 1h`, `RTO = 12h`). Business Critical keeps hot synchronized Always On secondary replicas online across zones for sub-30-second failover, whereas General Purpose spins up stateless compute on another node/zone over `ZRS` storage (typically `~1–2 minutes`). Zone Redundancy survives datacenter zone loss with zero data loss; Failover Groups / Active Geo-Replication provide low-RPO/RTO regional DR; Geo-Restore is lowest-cost DR from RA-GRS backups. Local study-map skill 5.1 (Recommend HA/DR Architectures Based on RPO and RTO (`Zone Redundant`, `Failover Groups`, `Geo-Restore`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Business continuity, RPO/RTO targets, and high availability in Azure SQL (https://learn.microsoft.com/en-us/azure/azure-sql/database/business-continuity-high-availability-disaster-recovery-hadr-overview).

- **A:** Correct. Zone Redundancy survives datacenter zone loss with zero data loss; Failover Groups / Active Geo-Replication provide low-RPO/RTO regional DR; Geo-Restore is lowest-cost DR from RA-GRS backups. In this scenario: Business Critical keeps hot synchronized Always On secondary replicas online across zones for sub-30-second failover, whereas General Purpose spins up stateless compute on another node/zone over `ZRS` storage (typically `~1–2 minutes`).
- **B:** Incorrect for this requirement. Geo-Restore downloads and restores geo-replicated backups into a new server with an RPO of up to 1 hour and RTO of up to 12 hours, never automatic 5-second RPO failover. Why the keyed choice wins: Business Critical keeps hot synchronized Always On secondary replicas online across zones for sub-30-second failover, whereas General Purpose spins up stateless compute on another node/zone over `ZRS` storage (typically `~1–2 minutes`).
- **C:** Incorrect for this requirement. DTU Basic supports max 2 GB and Standard S0–S2 max 250 GB without compute-isolated read replicas, making them incapable of hosting multi-TB OLTP workloads. Why the keyed choice wins: Business Critical keeps hot synchronized Always On secondary replicas online across zones for sub-30-second failover, whereas General Purpose spins up stateless compute on another node/zone over `ZRS` storage (typically `~1–2 minutes`).
- **D:** Incorrect for this requirement. Serverless auto-scales compute between configured min and max vCores per second and pauses compute billing during idle periods (minimum 1-hour auto-pause delay), charging only storage. Why the keyed choice wins: Business Critical keeps hot synchronized Always On secondary replicas online across zones for sub-30-second failover, whereas General Purpose spins up stateless compute on another node/zone over `ZRS` storage (typically `~1–2 minutes`).

### Question 71 — D

Answer: Hybrid DR using Managed Instance link with bidirectional online failover between SQL Server 2022 and Azure SQL Managed Instance. Managed Instance link bidirectional online planned failover between SQL Server 2022 and Azure SQL Managed Instance switches primary/secondary roles across the distributed Availability Group with zero data loss. SQL Server 2022 supports two-way online planned failover back and forth with Azure SQL Managed Instance via Managed Instance link (whereas SQL Server 2016–2019 link failover is one-way to Azure). Local study-map skill 5.2 (Evaluate Hybrid HA/DR (`Managed Instance Link` Bidirectional SQL 2022 Failover) and Azure-Specific HA Tiers), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Hybrid HA/DR with Managed Instance link and distributed Availability Groups (https://learn.microsoft.com/en-us/azure/azure-sql/managed-instance/managed-instance-link-disaster-recovery).

- **A:** Incorrect for this requirement. Creating a point-in-time database copy isolates active OLTP writes so `SqlPackage /Action:Export` produces a foreign-key-consistent `.bacpac` archive in Azure Blob Storage. Why the keyed choice wins: Managed Instance link bidirectional online planned failover between SQL Server 2022 and Azure SQL Managed Instance switches primary/secondary roles across the distributed Availability Group with zero data loss.
- **B:** Incorrect for this requirement. Both standalone Data Migration Assistant (retired July 2025) and SQL Server Stretch Database (retired) are deprecated; use Azure Migrate / Azure SQL Migration extension and partitioning/Fabric/Blob tiering. Why the keyed choice wins: Managed Instance link bidirectional online planned failover between SQL Server 2022 and Azure SQL Managed Instance switches primary/secondary roles across the distributed Availability Group with zero data loss.
- **C:** Incorrect for this requirement. Managed Instance link online failback from SQL MI to SQL Server requires SQL Server 2022 or later; SQL Server 2016 and 2019 support one-way migration into SQL MI only. Why the keyed choice wins: Managed Instance link bidirectional online planned failover between SQL Server 2022 and Azure SQL Managed Instance switches primary/secondary roles across the distributed Availability Group with zero data loss.
- **D:** Correct. SQL Server 2022 supports two-way online planned failover back and forth with Azure SQL Managed Instance via Managed Instance link (whereas SQL Server 2016–2019 link failover is one-way to Azure). In this scenario: Managed Instance link bidirectional online planned failover between SQL Server 2022 and Azure SQL Managed Instance switches primary/secondary roles across the distributed Availability Group with zero data loss.

### Question 72 — B

Answer: Align tiers to RPO/RTO: `Zone Redundant` (`RPO = 0` intra-region HA), `Failover Groups` (`RPO = 5s`, `RTO = 1h` SLA cross-region DR), vs `Geo-Restore` (`RPO = 1h`, `RTO = 12h`). Yes — Azure SQL Database Serverless (`General Purpose` and `Hyperscale` where supported) supports `Zone Redundant` HA across Availability Zones so paused/active serverless databases survive single-zone outages. Zone Redundancy survives datacenter zone loss with zero data loss; Failover Groups / Active Geo-Replication provide low-RPO/RTO regional DR; Geo-Restore is lowest-cost DR from RA-GRS backups. Local study-map skill 5.2 (Evaluate Hybrid HA/DR (`Managed Instance Link` Bidirectional SQL 2022 Failover) and Azure-Specific HA Tiers), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Hybrid HA/DR with Managed Instance link and distributed Availability Groups (https://learn.microsoft.com/en-us/azure/azure-sql/managed-instance/managed-instance-link-disaster-recovery).

- **A:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Yes — Azure SQL Database Serverless (`General Purpose` and `Hyperscale` where supported) supports `Zone Redundant` HA across Availability Zones so paused/active serverless databases survive single-zone outages.
- **B:** Correct. Zone Redundancy survives datacenter zone loss with zero data loss; Failover Groups / Active Geo-Replication provide low-RPO/RTO regional DR; Geo-Restore is lowest-cost DR from RA-GRS backups. In this scenario: Yes — Azure SQL Database Serverless (`General Purpose` and `Hyperscale` where supported) supports `Zone Redundant` HA across Availability Zones so paused/active serverless databases survive single-zone outages.
- **C:** Incorrect for this requirement. A 2-node WSFC without a Cloud/File-Share Witness loses quorum if one node fails, and blocking Azure ILB health-probe port `59999` blackholes AG listener connections. Why the keyed choice wins: Yes — Azure SQL Database Serverless (`General Purpose` and `Hyperscale` where supported) supports `Zone Redundant` HA across Availability Zones so paused/active serverless databases survive single-zone outages.
- **D:** Incorrect for this requirement. Placing database or log files on `C:` or enabling `ReadWrite` caching risks data corruption during host crashes and exhausts OS disk IOPS caps. Why the keyed choice wins: Yes — Azure SQL Database Serverless (`General Purpose` and `Hyperscale` where supported) supports `Zone Redundant` HA across Availability Zones so paused/active serverless databases survive single-zone outages.

### Question 73 — D

Answer: Provision secondary SQL server with matching firewall/Private Link & Entra admin → Create Failover Group with coupled DBs → Point apps to `<fog>.database.windows.net` & `.secondary` → Run planned `Switch-AzSqlDatabaseFailoverGroup` drill. Mirror network/Entra configs on the secondary server + matching Elastic Pool, include all 60 DBs in the Failover Group, point APIs to `<fog>.database.windows.net` / `.secondary`, and run planned `Switch-AzSqlDatabaseFailoverGroup` failover and failback. A resilient Failover Group mirrors security/network configs on the secondary server, groups coupled databases under stable read-write and read-only listeners, and validates readiness via planned zero-data-loss failover. Local study-map skill 5.3 (Plan Non-Disruptive HA/DR Failover Drills, Listener Redirection Validation, and Read-Only Secondary Testing), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Disaster recovery drills and failover testing for Azure SQL solutions (https://learn.microsoft.com/en-us/azure/azure-sql/database/disaster-recovery-drills).

- **A:** Incorrect for this requirement. Incorrect workflow: forced failover with `AllowDataLoss` risks dropping uncommitted transactions during drills, and hardcoding regional server names breaks automatic client redirection. Why the keyed choice wins: Mirror network/Entra configs on the secondary server + matching Elastic Pool, include all 60 DBs in the Failover Group, point APIs to `<fog>.database.windows.net` / `.secondary`, and run planned `Switch-AzSqlDatabaseFailoverGroup` failover and failback.
- **B:** Incorrect for this requirement. Incorrect workflow: Failover Groups span distinct regions, replicate user databases rather than `master`/`tempdb`, and `.secondary.database.windows.net` is strictly read-only. Why the keyed choice wins: Mirror network/Entra configs on the secondary server + matching Elastic Pool, include all 60 DBs in the Failover Group, point APIs to `<fog>.database.windows.net` / `.secondary`, and run planned `Switch-AzSqlDatabaseFailoverGroup` failover and failback.
- **C:** Incorrect for this requirement. Incorrect workflow: deleting production databases and manually rewriting connection strings causes hours of avoidable downtime instead of testing non-disruptive Failover Group listener failover. Why the keyed choice wins: Mirror network/Entra configs on the secondary server + matching Elastic Pool, include all 60 DBs in the Failover Group, point APIs to `<fog>.database.windows.net` / `.secondary`, and run planned `Switch-AzSqlDatabaseFailoverGroup` failover and failback.
- **D:** Correct. A resilient Failover Group mirrors security/network configs on the secondary server, groups coupled databases under stable read-write and read-only listeners, and validates readiness via planned zero-data-loss failover. In this scenario: Mirror network/Entra configs on the secondary server + matching Elastic Pool, include all 60 DBs in the Failover Group, point APIs to `<fog>.database.windows.net` / `.secondary`, and run planned `Switch-AzSqlDatabaseFailoverGroup` failover and failback.

### Question 74 — A

Answer: Non-disruptive DR readiness drill executing a planned zero-data-loss Failover Group switch (`Switch-AzSqlDatabaseFailoverGroup`), validating app listeners, and failing back. Create an isolated database copy (`New-AzSqlDatabaseCopy`) or Point-in-Time Restore in the secondary/DR test environment and run full read-write application validation against that isolated clone. Planned failover synchronizes pending log records before switching roles (`RPO = 0`), validating secondary firewall/Entra configs and `<fog>.database.windows.net` DNS redirection safely. Local study-map skill 5.3 (Plan Non-Disruptive HA/DR Failover Drills, Listener Redirection Validation, and Read-Only Secondary Testing), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Disaster recovery drills and failover testing for Azure SQL solutions (https://learn.microsoft.com/en-us/azure/azure-sql/database/disaster-recovery-drills).

- **A:** Correct. Planned failover synchronizes pending log records before switching roles (`RPO = 0`), validating secondary firewall/Entra configs and `<fog>.database.windows.net` DNS redirection safely. In this scenario: Create an isolated database copy (`New-AzSqlDatabaseCopy`) or Point-in-Time Restore in the secondary/DR test environment and run full read-write application validation against that isolated clone.
- **B:** Incorrect for this requirement. Geo-Restore downloads and restores geo-replicated backups into a new server with an RPO of up to 1 hour and RTO of up to 12 hours, never automatic 5-second RPO failover. Why the keyed choice wins: Create an isolated database copy (`New-AzSqlDatabaseCopy`) or Point-in-Time Restore in the secondary/DR test environment and run full read-write application validation against that isolated clone.
- **C:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Create an isolated database copy (`New-AzSqlDatabaseCopy`) or Point-in-Time Restore in the secondary/DR test environment and run full read-write application validation against that isolated clone.
- **D:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Create an isolated database copy (`New-AzSqlDatabaseCopy`) or Point-in-Time Restore in the secondary/DR test environment and run full read-write application validation against that isolated clone.

### Question 75 — A

Answer: No — taking an ad-hoc non-`COPY_ONLY` full backup resets the differential base and breaks downstream differential restores. No — Thursday's non-`COPY_ONLY` Full backup reset `differential_base_lsn`, so Friday's Differential backup requires Thursday's `.bak` file and fails with an LSN mismatch against Sunday's Full backup. A standard `BACKUP DATABASE` updates the differential base LSN; ad-hoc exports on SQL Managed Instance or Availability Groups must specify `WITH COPY_ONLY` to preserve the backup chain. Local study-map skill 5.4 (Recommend Backup & Restore Strategies (`COPY_ONLY` on MI/AGs and Azure Backup SQL-Aware Policies on VMs)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Automated backups, COPY_ONLY backups, and Azure Backup for SQL Server in Azure VMs (https://learn.microsoft.com/en-us/azure/azure-sql/database/automated-backups-overview).

- **A:** Correct. A standard `BACKUP DATABASE` updates the differential base LSN; ad-hoc exports on SQL Managed Instance or Availability Groups must specify `WITH COPY_ONLY` to preserve the backup chain. In this scenario: No — Thursday's non-`COPY_ONLY` Full backup reset `differential_base_lsn`, so Friday's Differential backup requires Thursday's `.bak` file and fails with an LSN mismatch against Sunday's Full backup.
- **B:** Incorrect for this requirement. Server-level IP firewall rules reside in the logical `master` database and must either be recreated on the DR logical server or replaced with portable database-level rules where appropriate. Why the keyed choice wins: No — Thursday's non-`COPY_ONLY` Full backup reset `differential_base_lsn`, so Friday's Differential backup requires Thursday's `.bak` file and fails with an LSN mismatch against Sunday's Full backup.
- **C:** Incorrect for this requirement. Dynamic Data Masking is not encryption at rest or row-level access control; users with ad-hoc `WHERE` privileges can still infer masked values unless RLS or encryption is applied. Why the keyed choice wins: No — Thursday's non-`COPY_ONLY` Full backup reset `differential_base_lsn`, so Friday's Differential backup requires Thursday's `.bak` file and fails with an LSN mismatch against Sunday's Full backup.
- **D:** Incorrect for this requirement. The proposed solution fails at least one stated technical, security, or availability requirement. Why the keyed choice wins: No — Thursday's non-`COPY_ONLY` Full backup reset `differential_base_lsn`, so Friday's Differential backup requires Thursday's `.bak` file and fails with an LSN mismatch against Sunday's Full backup.

### Question 76 — B

Answer: Use `BACKUP DATABASE ... WITH COPY_ONLY` for ad-hoc exports on SQL MI / AGs, and Azure Backup Recovery Services Vault SQL-aware policies (`15-min` log RPO) on SQL VMs. Weekly Full backups, Differential backups every `12` or `24` hours (configurable in Azure SQL DB/MI), and Transaction Log backups approximately every `10 minutes` based on log activity. `COPY_ONLY` preserves the differential and log backup chain, while Azure Backup for SQL Server in Azure VMs automates application-consistent Full, Differential, and 15-minute Transaction Log backups. Local study-map skill 5.4 (Recommend Backup & Restore Strategies (`COPY_ONLY` on MI/AGs and Azure Backup SQL-Aware Policies on VMs)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Automated backups, COPY_ONLY backups, and Azure Backup for SQL Server in Azure VMs (https://learn.microsoft.com/en-us/azure/azure-sql/database/automated-backups-overview).

- **A:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Weekly Full backups, Differential backups every `12` or `24` hours (configurable in Azure SQL DB/MI), and Transaction Log backups approximately every `10 minutes` based on log activity.
- **B:** Correct. `COPY_ONLY` preserves the differential and log backup chain, while Azure Backup for SQL Server in Azure VMs automates application-consistent Full, Differential, and 15-minute Transaction Log backups. In this scenario: Weekly Full backups, Differential backups every `12` or `24` hours (configurable in Azure SQL DB/MI), and Transaction Log backups approximately every `10 minutes` based on log activity.
- **C:** Incorrect for this requirement. Placing database or log files on `C:` or enabling `ReadWrite` caching risks data corruption during host crashes and exhausts OS disk IOPS caps. Why the keyed choice wins: Weekly Full backups, Differential backups every `12` or `24` hours (configurable in Azure SQL DB/MI), and Transaction Log backups approximately every `10 minutes` based on log activity.
- **D:** Incorrect for this requirement. A single Page Blob `BACKUP TO URL` maxes out at 1 TB and requires a SQL Credential; multi-TB cloud backups must stripe across multiple Block Blob URLs. Why the keyed choice wins: Weekly Full backups, Differential backups every `12` or `24` hours (configurable in Azure SQL DB/MI), and Transaction Log backups approximately every `10 minutes` based on log activity.

### Question 77 — A

Answer: Automated Point-in-Time Restore (`1–35` days PITR), Deleted-Database restore from the logical server, and Accelerated Database Recovery (`ADR`) instant rollback. Deleting a logical SQL server permanently deletes all short-term **PITR** backups for its databases (cannot be recovered via PITR!), whereas configured **LTR** backups survive in Azure Storage until their retention expires (protect production servers with `CanNotDelete` Resource Locks!). Azure SQL DB/MI retains automated backups for `1–35` days (`STOPAT`-equivalent PITR even if a DB was deleted within retention), while `ADR` uses a Persistent Version Store for instant rollback. Local study-map skill 5.5 (Perform Native Restores, Point-in-Time Restore (`1–35d` PITR), Deleted-DB Restore, and `ADR` Instant Rollback), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Point-in-time restore (PITR), Accelerated Database Recovery (ADR), and deleted DB restore (https://learn.microsoft.com/en-us/azure/azure-sql/database/recovery-using-backups).

- **A:** Correct. Azure SQL DB/MI retains automated backups for `1–35` days (`STOPAT`-equivalent PITR even if a DB was deleted within retention), while `ADR` uses a Persistent Version Store for instant rollback. In this scenario: Deleting a logical SQL server permanently deletes all short-term **PITR** backups for its databases (cannot be recovered via PITR!), whereas configured **LTR** backups survive in Azure Storage until their retention expires (protect production servers with `CanNotDelete` Resource Locks!).
- **B:** Incorrect for this requirement. Short-Term PITR caps at `35` days (`1–35` days); multi-year retention up to `10 years` with WORM deletion lock requires Long-Term Retention (`LTR`) with time-based immutability. Why the keyed choice wins: Deleting a logical SQL server permanently deletes all short-term **PITR** backups for its databases (cannot be recovered via PITR!), whereas configured **LTR** backups survive in Azure Storage until their retention expires (protect production servers with `CanNotDelete` Resource Locks!).
- **C:** Incorrect for this requirement. Creating a point-in-time database copy isolates active OLTP writes so `SqlPackage /Action:Export` produces a foreign-key-consistent `.bacpac` archive in Azure Blob Storage. Why the keyed choice wins: Deleting a logical SQL server permanently deletes all short-term **PITR** backups for its databases (cannot be recovered via PITR!), whereas configured **LTR** backups survive in Azure Storage until their retention expires (protect production servers with `CanNotDelete` Resource Locks!).
- **D:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Deleting a logical SQL server permanently deletes all short-term **PITR** backups for its databases (cannot be recovered via PITR!), whereas configured **LTR** backups survive in Azure Storage until their retention expires (protect production servers with `CanNotDelete` Resource Locks!).

### Question 78 — A

Answer: No — moving a database across SQL Managed Instances starts a fresh backup chain and does not carry over prior PITR backups. No — online SQL MI Database Move starts a new backup chain at `10:00 UTC` and does not transfer pre-move PITR history to the destination instance. Online SQL Managed Instance Database Move replicates current data with zero loss, but historical PITR backups remain tied to the source instance and are unavailable on the destination. Local study-map skill 5.5 (Perform Native Restores, Point-in-Time Restore (`1–35d` PITR), Deleted-DB Restore, and `ADR` Instant Rollback), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Point-in-time restore (PITR), Accelerated Database Recovery (ADR), and deleted DB restore (https://learn.microsoft.com/en-us/azure/azure-sql/database/recovery-using-backups).

- **A:** Correct. Online SQL Managed Instance Database Move replicates current data with zero loss, but historical PITR backups remain tied to the source instance and are unavailable on the destination. In this scenario: No — online SQL MI Database Move starts a new backup chain at `10:00 UTC` and does not transfer pre-move PITR history to the destination instance.
- **B:** Incorrect for this requirement. The proposed solution fails at least one stated technical, security, or availability requirement. Why the keyed choice wins: No — online SQL MI Database Move starts a new backup chain at `10:00 UTC` and does not transfer pre-move PITR history to the destination instance.
- **C:** Incorrect for this requirement. Server-level IP firewall rules reside in the logical `master` database and must either be recreated on the DR logical server or replaced with portable database-level rules where appropriate. Why the keyed choice wins: No — online SQL MI Database Move starts a new backup chain at `10:00 UTC` and does not transfer pre-move PITR history to the destination instance.
- **D:** Incorrect for this requirement. Dynamic Data Masking is not encryption at rest or row-level access control; users with ad-hoc `WHERE` privileges can still infer masked values unless RLS or encryption is applied. Why the keyed choice wins: No — online SQL MI Database Move starts a new backup chain at `10:00 UTC` and does not transfer pre-move PITR history to the destination instance.

### Question 79 — C, D

Answers: Configure an Azure SQL Long-Term Retention (`LTR`) policy (`WeeklyRetention`, `MonthlyRetention`, `YearlyRetention`, `WeekOfYear`) up to 10 years; Enable and lock time-based immutability (`WORM`) on the LTR backup policy so nobody can shorten retention or delete compliance backups early. Configure a Long-Term Retention (`LTR`) policy (`MonthlyRetention = P7Y`) and enable + lock time-based immutability (`WORM`) on the LTR policy. Local study-map skill 5.6 (Configure Long-Term Backup Retention (`LTR` up to `10y`), Time-Based Immutable WORM Locks, and Storage Redundancy), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Long-term backup retention (LTR) and time-based immutable WORM backups in Azure SQL (https://learn.microsoft.com/en-us/azure/azure-sql/database/long-term-retention-overview).

- **A:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Configure a Long-Term Retention (`LTR`) policy (`MonthlyRetention = P7Y`) and enable + lock time-based immutability (`WORM`) on the LTR policy.
- **B:** Incorrect for this requirement. Short-Term PITR caps at `35` days (`1–35` days); multi-year retention up to `10 years` with WORM deletion lock requires Long-Term Retention (`LTR`) with time-based immutability. Why the keyed choice wins: Configure a Long-Term Retention (`LTR`) policy (`MonthlyRetention = P7Y`) and enable + lock time-based immutability (`WORM`) on the LTR policy.
- **C:** Correct. LTR copies full backups into separate geo-redundant/zone-redundant Azure Blob tiers according to ISO-8601 duration policies (e.g., `P7Y`). In this scenario: Configure a Long-Term Retention (`LTR`) policy (`MonthlyRetention = P7Y`) and enable + lock time-based immutability (`WORM`) on the LTR policy.
- **D:** Correct. Once locked, time-based LTR immutability enforces write-once-read-many protection against ransomware or rogue privileged admins. In this scenario: Configure a Long-Term Retention (`LTR`) policy (`MonthlyRetention = P7Y`) and enable + lock time-based immutability (`WORM`) on the LTR policy.
- **E:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Configure a Long-Term Retention (`LTR`) policy (`MonthlyRetention = P7Y`) and enable + lock time-based immutability (`WORM`) on the LTR policy.

### Question 80 — C

Answer: Long-Term Retention (`LTR`) weekly/monthly/yearly backups up to `10 years` protected by a locked time-based immutable (`WORM`) policy and `RA-GRS` / `ZRS` backup storage. A `12-hour` differential interval halves the number of `.trn` transaction log backups that must be replayed during Point-in-Time Restore (faster `RTO`) at slightly higher backup storage cost. LTR retains compliance backups up to 10 years independently of PITR, and locking time-based immutability prevents even Subscription Owners from deleting backups before expiry. Local study-map skill 5.6 (Configure Long-Term Backup Retention (`LTR` up to `10y`), Time-Based Immutable WORM Locks, and Storage Redundancy), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Long-term backup retention (LTR) and time-based immutable WORM backups in Azure SQL (https://learn.microsoft.com/en-us/azure/azure-sql/database/long-term-retention-overview).

- **A:** Incorrect for this requirement. Serverless auto-scales compute between configured min and max vCores per second and pauses compute billing during idle periods (minimum 1-hour auto-pause delay), charging only storage. Why the keyed choice wins: A `12-hour` differential interval halves the number of `.trn` transaction log backups that must be replayed during Point-in-Time Restore (faster `RTO`) at slightly higher backup storage cost.
- **B:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: A `12-hour` differential interval halves the number of `.trn` transaction log backups that must be replayed during Point-in-Time Restore (faster `RTO`) at slightly higher backup storage cost.
- **C:** Correct. LTR retains compliance backups up to 10 years independently of PITR, and locking time-based immutability prevents even Subscription Owners from deleting backups before expiry. In this scenario: A `12-hour` differential interval halves the number of `.trn` transaction log backups that must be replayed during Point-in-Time Restore (faster `RTO`) at slightly higher backup storage cost.
- **D:** Incorrect for this requirement. Short-Term PITR caps at `35` days (`1–35` days); multi-year retention up to `10 years` with WORM deletion lock requires Long-Term Retention (`LTR`) with time-based immutability. Why the keyed choice wins: A `12-hour` differential interval halves the number of `.trn` transaction log backups that must be replayed during Point-in-Time Restore (faster `RTO`) at slightly higher backup storage cost.

### Question 81 — B, C

Answers: Create a SQL Server `CREDENTIAL` (`IDENTITY = 'Managed Identity'` or `'SHARED ACCESS SIGNATURE'`) matching the Azure Blob container URL; Stripe `BACKUP DATABASE` across multiple `TO URL = 'https://...bak'` block blob targets with `COMPRESSION` and `MAXTRANSFERSIZE = 4194304`. Create a server `CREDENTIAL` with `IDENTITY = 'Managed Identity'` for the Blob container URL, and stripe `BACKUP DATABASE` across multiple `TO URL` block blobs with `COMPRESSION`. Local study-map skill 5.7 (Back Up to and Restore from Azure Blob Storage URL Using T-SQL Stripes (`TO URL`) and Managed Identity / SAS), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Server backup to URL and restore from Azure Blob Storage with Managed Identity or SAS (https://learn.microsoft.com/en-us/sql/relational-databases/backup-restore/sql-server-backup-to-url-azure-blob-storage).

- **A:** Incorrect for this requirement. Local ephemeral NVMe storage delivers ultra-low latency for `tempdb` spills and version stores without consuming remote disk IOPS bandwidth. Why the keyed choice wins: Create a server `CREDENTIAL` with `IDENTITY = 'Managed Identity'` for the Blob container URL, and stripe `BACKUP DATABASE` across multiple `TO URL` block blobs with `COMPRESSION`.
- **B:** Correct. SQL Server and SQL MI authenticate `BACKUP TO URL` / `RESTORE FROM URL` requests to Azure Storage via a server-level credential. In this scenario: Create a server `CREDENTIAL` with `IDENTITY = 'Managed Identity'` for the Blob container URL, and stripe `BACKUP DATABASE` across multiple `TO URL` block blobs with `COMPRESSION`.
- **C:** Correct. Multiple `URL` targets write to Azure Block Blobs in parallel, scaling single backups up to ~12.8 TB (`64` stripes) with maximum throughput. In this scenario: Create a server `CREDENTIAL` with `IDENTITY = 'Managed Identity'` for the Blob container URL, and stripe `BACKUP DATABASE` across multiple `TO URL` block blobs with `COMPRESSION`.
- **D:** Incorrect for this requirement. A single Page Blob `BACKUP TO URL` maxes out at 1 TB and requires a SQL Credential; multi-TB cloud backups must stripe across multiple Block Blob URLs. Why the keyed choice wins: Create a server `CREDENTIAL` with `IDENTITY = 'Managed Identity'` for the Blob container URL, and stripe `BACKUP DATABASE` across multiple `TO URL` block blobs with `COMPRESSION`.
- **E:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Create a server `CREDENTIAL` with `IDENTITY = 'Managed Identity'` for the Blob container URL, and stripe `BACKUP DATABASE` across multiple `TO URL` block blobs with `COMPRESSION`.

### Question 82 — C

Answer: Striped T-SQL `BACKUP DATABASE ... TO URL = ...` across up to 64 block blobs (`MAXTRANSFERSIZE`, `COMPRESSION`) authenticated via `Managed Identity` or `SHARED ACCESS SIGNATURE` Credential. SQL Server 2022 added native S3-compatible object storage backup/restore support (`TO URL = 's3://<endpoint>/<bucket>/db.bak'`) authenticated via an `'S3 Access Key'` SQL Credential! Backing up to multiple URLs creates block blobs supporting up to ~12.8 TB striped backups (`200 GB+` per blob, unlike legacy single-page-blob 1 TB limits) using `CREATE CREDENTIAL`. Local study-map skill 5.7 (Back Up to and Restore from Azure Blob Storage URL Using T-SQL Stripes (`TO URL`) and Managed Identity / SAS), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Server backup to URL and restore from Azure Blob Storage with Managed Identity or SAS (https://learn.microsoft.com/en-us/sql/relational-databases/backup-restore/sql-server-backup-to-url-azure-blob-storage).

- **A:** Incorrect for this requirement. Both standalone Data Migration Assistant (retired July 2025) and SQL Server Stretch Database (retired) are deprecated; use Azure Migrate / Azure SQL Migration extension and partitioning/Fabric/Blob tiering. Why the keyed choice wins: SQL Server 2022 added native S3-compatible object storage backup/restore support (`TO URL = 's3://<endpoint>/<bucket>/db.bak'`) authenticated via an `'S3 Access Key'` SQL Credential!
- **B:** Incorrect for this requirement. A single Page Blob `BACKUP TO URL` maxes out at 1 TB and requires a SQL Credential; multi-TB cloud backups must stripe across multiple Block Blob URLs. Why the keyed choice wins: SQL Server 2022 added native S3-compatible object storage backup/restore support (`TO URL = 's3://<endpoint>/<bucket>/db.bak'`) authenticated via an `'S3 Access Key'` SQL Credential!
- **C:** Correct. Backing up to multiple URLs creates block blobs supporting up to ~12.8 TB striped backups (`200 GB+` per blob, unlike legacy single-page-blob 1 TB limits) using `CREATE CREDENTIAL`. In this scenario: SQL Server 2022 added native S3-compatible object storage backup/restore support (`TO URL = 's3://<endpoint>/<bucket>/db.bak'`) authenticated via an `'S3 Access Key'` SQL Credential!
- **D:** Incorrect for this requirement. Creating a point-in-time database copy isolates active OLTP writes so `SqlPackage /Action:Export` produces a foreign-key-consistent `.bacpac` archive in Azure Blob Storage. Why the keyed choice wins: SQL Server 2022 added native S3-compatible object storage backup/restore support (`TO URL = 's3://<endpoint>/<bucket>/db.bak'`) authenticated via an `'S3 Access Key'` SQL Credential!

### Question 83 — A, C

Answers: Connect OLTP write traffic to `<fog>.database.windows.net` and read-only analytics to `<fog>.secondary.database.windows.net`; Configure `ReadWriteFailoverPolicy = Automatic` with `GracePeriodWithDataLossHours >= 1` so transient blips do not trigger premature lossy failover. Point write apps to `fog-stackbeacon.database.windows.net` and read-only apps to `fog-stackbeacon.secondary.database.windows.net`, and configure `GracePeriodWithDataLossHours >= 1`. Local study-map skill 5.8 (Configure Failover Groups (`<fog>.database.windows.net`, Grace Period) vs Active Geo-Replication (`4` Replicas)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Failover groups and active geo-replication in Azure SQL Database and SQL Managed Instance (https://learn.microsoft.com/en-us/azure/azure-sql/database/failover-group-sql-db).

- **A:** Correct. Failover Group listener endpoints abstract underlying regional server names and automatically redirect read-write and read-only connections after failover. In this scenario: Point write apps to `fog-stackbeacon.database.windows.net` and read-only apps to `fog-stackbeacon.secondary.database.windows.net`, and configure `GracePeriodWithDataLossHours >= 1`.
- **B:** Incorrect for this requirement. Local ephemeral NVMe storage delivers ultra-low latency for `tempdb` spills and version stores without consuming remote disk IOPS bandwidth. Why the keyed choice wins: Point write apps to `fog-stackbeacon.database.windows.net` and read-only apps to `fog-stackbeacon.secondary.database.windows.net`, and configure `GracePeriodWithDataLossHours >= 1`.
- **C:** Correct. The grace period controls how long Azure waits during an unrecoverable primary region outage before forcing an automatic failover if async log lag remains. In this scenario: Point write apps to `fog-stackbeacon.database.windows.net` and read-only apps to `fog-stackbeacon.secondary.database.windows.net`, and configure `GracePeriodWithDataLossHours >= 1`.
- **D:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Point write apps to `fog-stackbeacon.database.windows.net` and read-only apps to `fog-stackbeacon.secondary.database.windows.net`, and configure `GracePeriodWithDataLossHours >= 1`.
- **E:** Incorrect for this requirement. Geo-Restore downloads and restores geo-replicated backups into a new server with an RPO of up to 1 hour and RTO of up to 12 hours, never automatic 5-second RPO failover. Why the keyed choice wins: Point write apps to `fog-stackbeacon.database.windows.net` and read-only apps to `fog-stackbeacon.secondary.database.windows.net`, and configure `GracePeriodWithDataLossHours >= 1`.

### Question 84 — B

Answer: Always On Availability Group on Azure VMs using WSFC with Azure Cloud Witness, Distributed Network Name (`DNN`) or Internal Load Balancer (`ILB` port `59999`), and `MultiSubnetFailover=True`. A `DNN` listener routes directly via DNS without waiting 10–30 seconds for ILB health probes (`TCP 59999`) to detect failover, eliminating the load balancer hop and simplifying multi-subnet configuration when `MultiSubnetFailover=True` is set. Cloud Witness provides low-cost Blob quorum without a third VM; `DNN` routes multi-subnet AG traffic via DNS without ILB failover delay (requiring `MultiSubnetFailover=True` in client drivers). Local study-map skill 5.9 (Configure Always On Availability Groups on SQL MI and Azure VMs (`Cloud Witness`, `DNN`, `ILB` Port `59999`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Always On availability groups on SQL Server on Azure VMs (Cloud Witness, DNN, ILB) (https://learn.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/availability-group-overview).

- **A:** Incorrect for this requirement. Serverless auto-scales compute between configured min and max vCores per second and pauses compute billing during idle periods (minimum 1-hour auto-pause delay), charging only storage. Why the keyed choice wins: A `DNN` listener routes directly via DNS without waiting 10–30 seconds for ILB health probes (`TCP 59999`) to detect failover, eliminating the load balancer hop and simplifying multi-subnet configuration when `MultiSubnetFailover=True` is set.
- **B:** Correct. Cloud Witness provides low-cost Blob quorum without a third VM; `DNN` routes multi-subnet AG traffic via DNS without ILB failover delay (requiring `MultiSubnetFailover=True` in client drivers). In this scenario: A `DNN` listener routes directly via DNS without waiting 10–30 seconds for ILB health probes (`TCP 59999`) to detect failover, eliminating the load balancer hop and simplifying multi-subnet configuration when `MultiSubnetFailover=True` is set.
- **C:** Incorrect for this requirement. A 2-node WSFC without a Cloud/File-Share Witness loses quorum if one node fails, and blocking Azure ILB health-probe port `59999` blackholes AG listener connections. Why the keyed choice wins: A `DNN` listener routes directly via DNS without waiting 10–30 seconds for ILB health probes (`TCP 59999`) to detect failover, eliminating the load balancer hop and simplifying multi-subnet configuration when `MultiSubnetFailover=True` is set.
- **D:** Incorrect for this requirement. SQL database in Microsoft Fabric runs the Azure SQL engine for OLTP with Microsoft Entra-only auth, automatic near-real-time OneLake Delta Parquet replication, and a read-only SQL analytics endpoint. Why the keyed choice wins: A `DNN` listener routes directly via DNS without waiting 10–30 seconds for ILB health probes (`TCP 59999`) to detect failover, eliminating the load balancer hop and simplifying multi-subnet configuration when `MultiSubnetFailover=True` is set.

### Question 85 — B

Answer: Always On Availability Group on Azure VMs using WSFC with Azure Cloud Witness, Distributed Network Name (`DNN`) or Internal Load Balancer (`ILB` port `59999`), and `MultiSubnetFailover=True`. Configure `READ_ONLY_ROUTING_URL` on each replica and define a prioritized `READ_ONLY_ROUTING_LIST = (('Node3'), 'Node2', 'Node1')` on the primary replica! Cloud Witness provides low-cost Blob quorum without a third VM; `DNN` routes multi-subnet AG traffic via DNS without ILB failover delay (requiring `MultiSubnetFailover=True` in client drivers). Local study-map skill 5.9 (Configure Always On Availability Groups on SQL MI and Azure VMs (`Cloud Witness`, `DNN`, `ILB` Port `59999`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Always On availability groups on SQL Server on Azure VMs (Cloud Witness, DNN, ILB) (https://learn.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/availability-group-overview).

- **A:** Incorrect for this requirement. Placing database or log files on `C:` or enabling `ReadWrite` caching risks data corruption during host crashes and exhausts OS disk IOPS caps. Why the keyed choice wins: Configure `READ_ONLY_ROUTING_URL` on each replica and define a prioritized `READ_ONLY_ROUTING_LIST = (('Node3'), 'Node2', 'Node1')` on the primary replica!
- **B:** Correct. Cloud Witness provides low-cost Blob quorum without a third VM; `DNN` routes multi-subnet AG traffic via DNS without ILB failover delay (requiring `MultiSubnetFailover=True` in client drivers). In this scenario: Configure `READ_ONLY_ROUTING_URL` on each replica and define a prioritized `READ_ONLY_ROUTING_LIST = (('Node3'), 'Node2', 'Node1')` on the primary replica!
- **C:** Incorrect for this requirement. A 2-node WSFC without a Cloud/File-Share Witness loses quorum if one node fails, and blocking Azure ILB health-probe port `59999` blackholes AG listener connections. Why the keyed choice wins: Configure `READ_ONLY_ROUTING_URL` on each replica and define a prioritized `READ_ONLY_ROUTING_LIST = (('Node3'), 'Node2', 'Node1')` on the primary replica!
- **D:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Configure `READ_ONLY_ROUTING_URL` on each replica and define a prioritized `READ_ONLY_ROUTING_LIST = (('Node3'), 'Node2', 'Node1')` on the primary replica!

### Question 86 — B

Answer: Always On Failover Cluster Instance (`FCI`) on Azure VMs backed by `ZRS` Premium SSD Azure Shared Disks (or `S2D`), or Log Shipping (`BACKUP LOG` -> copy -> `RESTORE LOG WITH NORECOVERY`/`STANDBY`). Even in a shared-storage FCI, SQL Server supports placing `tempdb` on each node's **local** fast NVMe/`D:` drive (so long as identical local folder paths `D:\SQLTempDB` exist on **every** cluster node before failover!). Azure Shared Disks provide native SCSI PR shared block storage across Availability Zones for instance-level FCI failover, whereas Log Shipping maintains warm DR secondaries via scheduled `.trn` restores. Local study-map skill 5.10 (Configure Always On Failover Cluster Instances (`Azure Shared Disks` `ZRS`) and T-SQL Log Shipping on Azure VMs), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Always On Failover Cluster Instances (Azure Shared Disks) and Log Shipping on Azure VMs (https://learn.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/failover-cluster-instance-overview).

- **A:** Incorrect for this requirement. Hyperscale scales up to 100 TB via distributed page servers, performs constant-time log restores, and attaches up to 30 Named Replicas with independent vCore compute over shared storage. Why the keyed choice wins: Even in a shared-storage FCI, SQL Server supports placing `tempdb` on each node's **local** fast NVMe/`D:` drive (so long as identical local folder paths `D:\SQLTempDB` exist on **every** cluster node before failover!).
- **B:** Correct. Azure Shared Disks provide native SCSI PR shared block storage across Availability Zones for instance-level FCI failover, whereas Log Shipping maintains warm DR secondaries via scheduled `.trn` restores. In this scenario: Even in a shared-storage FCI, SQL Server supports placing `tempdb` on each node's **local** fast NVMe/`D:` drive (so long as identical local folder paths `D:\SQLTempDB` exist on **every** cluster node before failover!).
- **C:** Incorrect for this requirement. Placing database or log files on `C:` or enabling `ReadWrite` caching risks data corruption during host crashes and exhausts OS disk IOPS caps. Why the keyed choice wins: Even in a shared-storage FCI, SQL Server supports placing `tempdb` on each node's **local** fast NVMe/`D:` drive (so long as identical local folder paths `D:\SQLTempDB` exist on **every** cluster node before failover!).
- **D:** Incorrect for this requirement. SQL database in Microsoft Fabric runs the Azure SQL engine for OLTP with Microsoft Entra-only auth, automatic near-real-time OneLake Delta Parquet replication, and a read-only SQL analytics endpoint. Why the keyed choice wins: Even in a shared-storage FCI, SQL Server supports placing `tempdb` on each node's **local** fast NVMe/`D:` drive (so long as identical local folder paths `D:\SQLTempDB` exist on **every** cluster node before failover!).

### Question 87 — D

Answer: Always On Failover Cluster Instance (`FCI`) on Azure VMs backed by `ZRS` Premium SSD Azure Shared Disks (or `S2D`), or Log Shipping (`BACKUP LOG` -> copy -> `RESTORE LOG WITH NORECOVERY`/`STANDBY`). The Log Shipping **Alert job** (`sp_cleanup_log_shipping_history` / `sp_check_log_shipping_monitor_alert`) checks both `@backup_threshold` (`14420`) and `@restore_threshold` (`14421`) to detect stalled log shipping pipelines. Azure Shared Disks provide native SCSI PR shared block storage across Availability Zones for instance-level FCI failover, whereas Log Shipping maintains warm DR secondaries via scheduled `.trn` restores. Local study-map skill 5.10 (Configure Always On Failover Cluster Instances (`Azure Shared Disks` `ZRS`) and T-SQL Log Shipping on Azure VMs), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Always On Failover Cluster Instances (Azure Shared Disks) and Log Shipping on Azure VMs (https://learn.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/failover-cluster-instance-overview).

- **A:** Incorrect for this requirement. Serverless auto-scales compute between configured min and max vCores per second and pauses compute billing during idle periods (minimum 1-hour auto-pause delay), charging only storage. Why the keyed choice wins: The Log Shipping **Alert job** (`sp_cleanup_log_shipping_history` / `sp_check_log_shipping_monitor_alert`) checks both `@backup_threshold` (`14420`) and `@restore_threshold` (`14421`) to detect stalled log shipping pipelines.
- **B:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: The Log Shipping **Alert job** (`sp_cleanup_log_shipping_history` / `sp_check_log_shipping_monitor_alert`) checks both `@backup_threshold` (`14420`) and `@restore_threshold` (`14421`) to detect stalled log shipping pipelines.
- **C:** Incorrect for this requirement. Geo-Restore downloads and restores geo-replicated backups into a new server with an RPO of up to 1 hour and RTO of up to 12 hours, never automatic 5-second RPO failover. Why the keyed choice wins: The Log Shipping **Alert job** (`sp_cleanup_log_shipping_history` / `sp_check_log_shipping_monitor_alert`) checks both `@backup_threshold` (`14420`) and `@restore_threshold` (`14421`) to detect stalled log shipping pipelines.
- **D:** Correct. Azure Shared Disks provide native SCSI PR shared block storage across Availability Zones for instance-level FCI failover, whereas Log Shipping maintains warm DR secondaries via scheduled `.trn` restores. In this scenario: The Log Shipping **Alert job** (`sp_cleanup_log_shipping_history` / `sp_check_log_shipping_monitor_alert`) checks both `@backup_threshold` (`14420`) and `@restore_threshold` (`14421`) to detect stalled log shipping pipelines.

### Question 88 — C

Answer: Query `sys.dm_hadr_database_replica_states` (`synchronization_state_desc`, `log_send_queue_size`, `redo_queue_size`) and `sys.dm_geo_replication_link_status`, plus verify NSG probe port `59999`. High `log_send_queue_size` with zero `redo_queue_size` indicates primary log generation rate exceeds WAN network bandwidth / TCP throughput between East US and West Europe (enable endpoint compression or increase ExpressRoute/VPN bandwidth). High `log_send_queue_size` indicates network bottlenecks between primary and secondary, high `redo_queue_size` indicates slow redo I/O/CPU or long-running read queries on the secondary, and blocked ILB probe port `59999` breaks AG listener routing. Local study-map skill 5.11 (Monitor and Troubleshoot HA/DR Health (`sys.dm_hadr_database_replica_states`, `redo_queue_size`, `log_send_queue_size`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Monitor and troubleshoot Always On availability groups and geo-replication health (https://learn.microsoft.com/en-us/sql/database-engine/availability-groups/windows/monitor-availability-groups-transact-sql).

- **A:** Incorrect for this requirement. A 2-node WSFC without a Cloud/File-Share Witness loses quorum if one node fails, and blocking Azure ILB health-probe port `59999` blackholes AG listener connections. Why the keyed choice wins: High `log_send_queue_size` with zero `redo_queue_size` indicates primary log generation rate exceeds WAN network bandwidth / TCP throughput between East US and West Europe (enable endpoint compression or increase ExpressRoute/VPN bandwidth).
- **B:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: High `log_send_queue_size` with zero `redo_queue_size` indicates primary log generation rate exceeds WAN network bandwidth / TCP throughput between East US and West Europe (enable endpoint compression or increase ExpressRoute/VPN bandwidth).
- **C:** Correct. High `log_send_queue_size` indicates network bottlenecks between primary and secondary, high `redo_queue_size` indicates slow redo I/O/CPU or long-running read queries on the secondary, and blocked ILB probe port `59999` breaks AG listener routing. In this scenario: High `log_send_queue_size` with zero `redo_queue_size` indicates primary log generation rate exceeds WAN network bandwidth / TCP throughput between East US and West Europe (enable endpoint compression or increase ExpressRoute/VPN bandwidth).
- **D:** Incorrect for this requirement. `NOLOCK` (`READ UNCOMMITTED`) permits dirty reads of uncommitted rolled-back rows, double-counting rows, or skipping committed rows during page splits—unacceptable for accurate OLTP. Why the keyed choice wins: High `log_send_queue_size` with zero `redo_queue_size` indicates primary log generation rate exceeds WAN network bandwidth / TCP throughput between East US and West Europe (enable endpoint compression or increase ExpressRoute/VPN bandwidth).

### Question 89 — A

Answer: SQL Data Discovery & Classification (`ADD SENSITIVITY CLASSIFICATION`) integrated with Azure SQL Auditing to Log Analytics / immutable Storage. `data_sensitivity_information_s` (`data_sensitivity_information` in `fn_get_audit_file`) records JSON sensitivity labels and information types accessed by each audited T-SQL batch. `ADD SENSITIVITY CLASSIFICATION` tags columns with `LABEL` and `INFORMATION_TYPE`, populating `data_sensitivity_information` in SQL Audit logs whenever classified columns are queried. Local study-map skill 2.11 (Apply SQL Data Discovery & Classification (`ADD SENSITIVITY CLASSIFICATION`) and Server/Database Auditing), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: SQL Data Discovery and Classification and Azure SQL Auditing (https://learn.microsoft.com/en-us/azure/azure-sql/database/auditing-overview).

- **A:** Correct. `ADD SENSITIVITY CLASSIFICATION` tags columns with `LABEL` and `INFORMATION_TYPE`, populating `data_sensitivity_information` in SQL Audit logs whenever classified columns are queried. In this scenario: `data_sensitivity_information_s` (`data_sensitivity_information` in `fn_get_audit_file`) records JSON sensitivity labels and information types accessed by each audited T-SQL batch.
- **B:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: `data_sensitivity_information_s` (`data_sensitivity_information` in `fn_get_audit_file`) records JSON sensitivity labels and information types accessed by each audited T-SQL batch.
- **C:** Incorrect for this requirement. Change Tracking records only which primary keys changed with minimal overhead, whereas CDC reads the transaction log asynchronously to retain every intermediate `INSERT`/`UPDATE`/`DELETE` payload. Why the keyed choice wins: `data_sensitivity_information_s` (`data_sensitivity_information` in `fn_get_audit_file`) records JSON sensitivity labels and information types accessed by each audited T-SQL batch.
- **D:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: `data_sensitivity_information_s` (`data_sensitivity_information` in `fn_get_audit_file`) records JSON sensitivity labels and information types accessed by each audited T-SQL batch.

### Question 90 — C

Answer: Change Tracking (`CHANGETABLE(CHANGES ...)`) for lightweight net PK sync; Change Data Capture (`sys.sp_cdc_enable_table`) for full intermediate before/after history. SQL Change Tracking (`ALTER TABLE ... ENABLE CHANGE_TRACKING` queried via `CHANGETABLE(CHANGES ...)`) provides low-overhead synchronous primary-key change tracking ideal for microservice sync. Change Tracking records only which primary keys changed with minimal overhead, whereas CDC reads the transaction log asynchronously to retain every intermediate `INSERT`/`UPDATE`/`DELETE` payload. Local study-map skill 2.12 (Implement Change Tracking (`CHANGETABLE`) vs Change Data Capture (`CDC`) for Downstream Data Changes), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Track data changes with Change Tracking (CT) and Change Data Capture (CDC) (https://learn.microsoft.com/en-us/sql/relational-databases/track-changes/track-data-changes-sql-server).

- **A:** Incorrect for this requirement. CDC requires `S3+` or `vCore` tiers in Azure SQL Database, and Change Tracking stores only net version numbers/PKs—never intermediate before/after column values. Why the keyed choice wins: SQL Change Tracking (`ALTER TABLE ... ENABLE CHANGE_TRACKING` queried via `CHANGETABLE(CHANGES ...)`) provides low-overhead synchronous primary-key change tracking ideal for microservice sync.
- **B:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: SQL Change Tracking (`ALTER TABLE ... ENABLE CHANGE_TRACKING` queried via `CHANGETABLE(CHANGES ...)`) provides low-overhead synchronous primary-key change tracking ideal for microservice sync.
- **C:** Correct. Change Tracking records only which primary keys changed with minimal overhead, whereas CDC reads the transaction log asynchronously to retain every intermediate `INSERT`/`UPDATE`/`DELETE` payload. In this scenario: SQL Change Tracking (`ALTER TABLE ... ENABLE CHANGE_TRACKING` queried via `CHANGETABLE(CHANGES ...)`) provides low-overhead synchronous primary-key change tracking ideal for microservice sync.
- **D:** Incorrect for this requirement. Unlike server-level rules stored in `master`, database-level IP firewall rules travel inside the user database across Active Geo-Replication and Failover Group failovers. Why the keyed choice wins: SQL Change Tracking (`ALTER TABLE ... ENABLE CHANGE_TRACKING` queried via `CHANGETABLE(CHANGES ...)`) provides low-overhead synchronous primary-key change tracking ideal for microservice sync.

### Question 91 — A, B, D

Answers: Create an inline table-valued function `WITH SCHEMABINDING` evaluating `SESSION_CONTEXT()` or `DATABASE_PRINCIPAL_ID()`; Add a `FILTER PREDICATE` in `CREATE SECURITY POLICY` to hide non-matching rows silently from `SELECT`, `UPDATE`, and `DELETE`; Add `AFTER INSERT` and `AFTER UPDATE` / `BEFORE UPDATE` `BLOCK PREDICATE` clauses in `CREATE SECURITY POLICY` (`STATE = ON`). Build a `SCHEMABINDING` inline TVF reading `SESSION_CONTEXT(N'TenantId')`, and enforce both `FILTER PREDICATE` and `BLOCK PREDICATE` inside `CREATE SECURITY POLICY ... WITH (STATE = ON)`. Local study-map skill 2.14 (Implement Cryptographic Ledger in Azure SQL (`Azure Confidential Ledger`) and Row-Level Security (`FILTER`/`BLOCK`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Ledger cryptographic tamper-evidence and Row-Level Security (RLS) in Azure SQL (https://learn.microsoft.com/en-us/sql/relational-databases/security/ledger/ledger-overview).

- **A:** Correct. `FILTER PREDICATE` injects the security TVF into read, update, and delete operators transparently without changing application `SELECT` statements. In this scenario: Build a `SCHEMABINDING` inline TVF reading `SESSION_CONTEXT(N'TenantId')`, and enforce both `FILTER PREDICATE` and `BLOCK PREDICATE` inside `CREATE SECURITY POLICY ... WITH (STATE = ON)`.
- **B:** Correct. `BLOCK PREDICATE` raises an error if a shared application login attempts to insert or update a row carrying another tenant's identifier. In this scenario: Build a `SCHEMABINDING` inline TVF reading `SESSION_CONTEXT(N'TenantId')`, and enforce both `FILTER PREDICATE` and `BLOCK PREDICATE` inside `CREATE SECURITY POLICY ... WITH (STATE = ON)`.
- **C:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: Build a `SCHEMABINDING` inline TVF reading `SESSION_CONTEXT(N'TenantId')`, and enforce both `FILTER PREDICATE` and `BLOCK PREDICATE` inside `CREATE SECURITY POLICY ... WITH (STATE = ON)`.
- **D:** Correct. RLS predicate functions must be inline TVFs bound with `SCHEMABINDING` so underlying columns cannot be altered silently and query plans inline cleanly. In this scenario: Build a `SCHEMABINDING` inline TVF reading `SESSION_CONTEXT(N'TenantId')`, and enforce both `FILTER PREDICATE` and `BLOCK PREDICATE` inside `CREATE SECURITY POLICY ... WITH (STATE = ON)`.
- **E:** Incorrect for this requirement. Opening `0.0.0.0–255.255.255.255` exposes the SQL endpoint to the entire public internet rather than isolating traffic via Private Endpoints or scoped IP rules. Why the keyed choice wins: Build a `SCHEMABINDING` inline TVF reading `SESSION_CONTEXT(N'TenantId')`, and enforce both `FILTER PREDICATE` and `BLOCK PREDICATE` inside `CREATE SECURITY POLICY ... WITH (STATE = ON)`.
- **F:** Incorrect for this requirement. Append-only Ledger tables strictly block `UPDATE`, `DELETE`, and `TRUNCATE` statements in the SQL engine so cryptographic audit trails cannot be altered. Why the keyed choice wins: Build a `SCHEMABINDING` inline TVF reading `SESSION_CONTEXT(N'TenantId')`, and enforce both `FILTER PREDICATE` and `BLOCK PREDICATE` inside `CREATE SECURITY POLICY ... WITH (STATE = ON)`.

### Question 92 — D

Answer: Azure Monitor Diagnostic Settings streaming `SQLInsights`, `QueryStoreRuntimeStatistics`, `Errors`, and `Blocks` to a Log Analytics workspace (`KQL`). Enabling the `SQLInsights` log category in Diagnostic Settings streams SQL Intelligent Insights root-cause telemetry into Log Analytics for centralized KQL dashboards and alerts. Diagnostic Settings export telemetry across hundreds of databases into Log Analytics so DBAs can correlate `SQLInsights`, wait stats, deadlocks, and timeouts via KQL queries and alerts. Local study-map skill 3.2 (Configure Azure Monitor Diagnostic Settings (`SQLInsights`, `AzureDiagnostics` KQL) and Resource Monitoring), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Azure Monitor diagnostic settings, SQLInsights logs, and metric alerts (https://learn.microsoft.com/en-us/azure/azure-sql/database/metrics-diagnostic-telemetry-logging-streaming-export-configure).

- **A:** Incorrect for this requirement. Without the original TDE certificate and private key restored into the target SQL Server `master` database, a TDE-encrypted `.bak` or detached `.mdf` cannot be decrypted anywhere. Why the keyed choice wins: Enabling the `SQLInsights` log category in Diagnostic Settings streams SQL Intelligent Insights root-cause telemetry into Log Analytics for centralized KQL dashboards and alerts.
- **B:** Incorrect for this requirement. Unlike server-level rules stored in `master`, database-level IP firewall rules travel inside the user database across Active Geo-Replication and Failover Group failovers. Why the keyed choice wins: Enabling the `SQLInsights` log category in Diagnostic Settings streams SQL Intelligent Insights root-cause telemetry into Log Analytics for centralized KQL dashboards and alerts.
- **C:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: Enabling the `SQLInsights` log category in Diagnostic Settings streams SQL Intelligent Insights root-cause telemetry into Log Analytics for centralized KQL dashboards and alerts.
- **D:** Correct. Diagnostic Settings export telemetry across hundreds of databases into Log Analytics so DBAs can correlate `SQLInsights`, wait stats, deadlocks, and timeouts via KQL queries and alerts. In this scenario: Enabling the `SQLInsights` log category in Diagnostic Settings streams SQL Intelligent Insights root-cause telemetry into Log Analytics for centralized KQL dashboards and alerts.

### Question 93 — D

Answer: Query `sys.dm_os_wait_stats` / `sys.dm_db_wait_stats`, `sys.dm_exec_requests`, `sys.dm_tran_locks`, and `sys.dm_db_tempdb_space_usage`. Query `sys.dm_db_wait_stats` / `sys.dm_os_wait_stats` to confirm `CXPACKET` share, then lower `ALTER DATABASE SCOPED CONFIGURATION SET MAXDOP = 8` (or `4`, or enable compat `160` `DOP_FEEDBACK = ON`). Wait categories pinpoint root causes: `PAGEIOLATCH_*` indicates storage data reads, `WRITELOG` indicates log flush latency, `SOS_SCHEDULER_YIELD` indicates CPU pressure, and `LCK_M_*` indicates blocking. Local study-map skill 3.7 (Identify Performance Bottlenecks Using Dynamic Management Views (`sys.dm_os_wait_stats`, `sys.dm_exec_requests`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Monitor performance using Dynamic Management Views (DMVs) and wait statistics (https://learn.microsoft.com/en-us/azure/azure-sql/database/monitoring-with-dmvs).

- **A:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Query `sys.dm_db_wait_stats` / `sys.dm_os_wait_stats` to confirm `CXPACKET` share, then lower `ALTER DATABASE SCOPED CONFIGURATION SET MAXDOP = 8` (or `4`, or enable compat `160` `DOP_FEEDBACK = ON`).
- **B:** Incorrect for this requirement. DDM masks query result columns on the fly for non-privileged callers (`db_owner` and `UNMASK` holders see cleartext) using built-in masking functions without altering stored values. Why the keyed choice wins: Query `sys.dm_db_wait_stats` / `sys.dm_os_wait_stats` to confirm `CXPACKET` share, then lower `ALTER DATABASE SCOPED CONFIGURATION SET MAXDOP = 8` (or `4`, or enable compat `160` `DOP_FEEDBACK = ON`).
- **C:** Incorrect for this requirement. Interactive SQL Server Profiler GUI tracing imposes heavy observer overhead and is deprecated in favor of lightweight Extended Events and Query Store. Why the keyed choice wins: Query `sys.dm_db_wait_stats` / `sys.dm_os_wait_stats` to confirm `CXPACKET` share, then lower `ALTER DATABASE SCOPED CONFIGURATION SET MAXDOP = 8` (or `4`, or enable compat `160` `DOP_FEEDBACK = ON`).
- **D:** Correct. Wait categories pinpoint root causes: `PAGEIOLATCH_*` indicates storage data reads, `WRITELOG` indicates log flush latency, `SOS_SCHEDULER_YIELD` indicates CPU pressure, and `LCK_M_*` indicates blocking. In this scenario: Query `sys.dm_db_wait_stats` / `sys.dm_os_wait_stats` to confirm `CXPACKET` share, then lower `ALTER DATABASE SCOPED CONFIGURATION SET MAXDOP = 8` (or `4`, or enable compat `160` `DOP_FEEDBACK = ON`).

### Question 94 — B, D, F

Answers: Run `ALTER INDEX ... REBUILD WITH (ONLINE = ON, RESUMABLE = ON, MAX_DURATION = 90 MINUTES)` for heavily fragmented (`>30%`) indexes; Enable `AUTO_UPDATE_STATISTICS_ASYNC = ON` and schedule targeted `UPDATE STATISTICS` jobs so user queries do not stall waiting on sampling; Run `DBCC CHECKDB WITH PHYSICAL_ONLY` during off-peak windows or offload full `DBCC CHECKDB` onto a restored backup replica. Use `ALTER INDEX ... REBUILD WITH (ONLINE = ON, RESUMABLE = ON)`, enable `AUTO_UPDATE_STATISTICS_ASYNC = ON`, and run `DBCC CHECKDB WITH PHYSICAL_ONLY` (or offload full `CHECKDB` to restored backups). Local study-map skill 3.10 (Implement Fragmentation-Aware Index Rebuilds (`ONLINE`, `RESUMABLE`), Async Statistics, and `DBCC CHECKDB`), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Optimize index maintenance, statistics updates, and DBCC CHECKDB integrity checks (https://learn.microsoft.com/en-us/sql/relational-databases/indexes/reorganize-and-rebuild-indexes).

- **A:** Incorrect for this requirement. Flushing the entire plan cache repeatedly causes CPU compilation storms across all queries, and disabling statistics forces blind cardinality guesses. Why the keyed choice wins: Use `ALTER INDEX ... REBUILD WITH (ONLINE = ON, RESUMABLE = ON)`, enable `AUTO_UPDATE_STATISTICS_ASYNC = ON`, and run `DBCC CHECKDB WITH PHYSICAL_ONLY` (or offload full `CHECKDB` to restored backups).
- **B:** Correct. Asynchronous statistics updates let incoming OLTP queries execute immediately with existing stats while a background thread refreshes stale histograms. In this scenario: Use `ALTER INDEX ... REBUILD WITH (ONLINE = ON, RESUMABLE = ON)`, enable `AUTO_UPDATE_STATISTICS_ASYNC = ON`, and run `DBCC CHECKDB WITH PHYSICAL_ONLY` (or offload full `CHECKDB` to restored backups).
- **C:** Incorrect for this requirement. Over-indexing inflates every `INSERT`/`UPDATE`/`DELETE` write and log flush, while `ONLINE = OFF` holds exclusive schema/table locks that block production traffic. Why the keyed choice wins: Use `ALTER INDEX ... REBUILD WITH (ONLINE = ON, RESUMABLE = ON)`, enable `AUTO_UPDATE_STATISTICS_ASYNC = ON`, and run `DBCC CHECKDB WITH PHYSICAL_ONLY` (or offload full `CHECKDB` to restored backups).
- **D:** Correct. Resumable online index rebuilds persist progress in place, bound transaction log growth, and automatically pause at `MAX_DURATION` so later windows can `RESUME`. In this scenario: Use `ALTER INDEX ... REBUILD WITH (ONLINE = ON, RESUMABLE = ON)`, enable `AUTO_UPDATE_STATISTICS_ASYNC = ON`, and run `DBCC CHECKDB WITH PHYSICAL_ONLY` (or offload full `CHECKDB` to restored backups).
- **E:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Use `ALTER INDEX ... REBUILD WITH (ONLINE = ON, RESUMABLE = ON)`, enable `AUTO_UPDATE_STATISTICS_ASYNC = ON`, and run `DBCC CHECKDB WITH PHYSICAL_ONLY` (or offload full `CHECKDB` to restored backups).
- **F:** Correct. `PHYSICAL_ONLY` checks page checksums, torn pages, and allocation structures at a fraction of full logical `CHECKDB` CPU/memory cost. In this scenario: Use `ALTER INDEX ... REBUILD WITH (ONLINE = ON, RESUMABLE = ON)`, enable `AUTO_UPDATE_STATISTICS_ASYNC = ON`, and run `DBCC CHECKDB WITH PHYSICAL_ONLY` (or offload full `CHECKDB` to restored backups).

### Question 95 — D

Answer: Azure SQL Database Elastic Job Agent (`jobs.sp_add_job`) authenticating to Target Groups across servers/pools via a User-Assigned Managed Identity (`UAMI`). An Azure SQL Database Elastic Job Agent configured with a User-Assigned Managed Identity (`UAMI`) and pool/server Target Groups fans out T-SQL asynchronously across all 480 databases. Elastic Jobs fan out T-SQL maintenance and schema scripts asynchronously across hundreds of Azure SQL Databases, elastic pools, and subscriptions using passwordless UAMI authentication. Local study-map skill 4.6 (Create and Configure Azure SQL Database Elastic Jobs Across Target Groups Using User-Assigned Managed Identity), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Elastic jobs in Azure SQL Database with Managed Identity authentication (https://learn.microsoft.com/en-us/azure/azure-sql/database/elastic-jobs-overview).

- **A:** Incorrect for this requirement. Single Azure SQL Databases do not expose `SQLServerAgent`; cross-database PaaS scheduling uses Elastic Job Agents with Managed Identity or Azure Automation. Why the keyed choice wins: An Azure SQL Database Elastic Job Agent configured with a User-Assigned Managed Identity (`UAMI`) and pool/server Target Groups fans out T-SQL asynchronously across all 480 databases.
- **B:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: An Azure SQL Database Elastic Job Agent configured with a User-Assigned Managed Identity (`UAMI`) and pool/server Target Groups fans out T-SQL asynchronously across all 480 databases.
- **C:** Incorrect for this requirement. Both standalone Data Migration Assistant (retired July 2025) and SQL Server Stretch Database (retired) are deprecated; use Azure Migrate / Azure SQL Migration extension and partitioning/Fabric/Blob tiering. Why the keyed choice wins: An Azure SQL Database Elastic Job Agent configured with a User-Assigned Managed Identity (`UAMI`) and pool/server Target Groups fans out T-SQL asynchronously across all 480 databases.
- **D:** Correct. Elastic Jobs fan out T-SQL maintenance and schema scripts asynchronously across hundreds of Azure SQL Databases, elastic pools, and subscriptions using passwordless UAMI authentication. In this scenario: An Azure SQL Database Elastic Job Agent configured with a User-Assigned Managed Identity (`UAMI`) and pool/server Target Groups fans out T-SQL asynchronously across all 480 databases.

### Question 96 — B

Answer: Azure Automation PowerShell / Python runbooks (or Azure Functions / Logic Apps) using a System-Assigned Managed Identity on a recurring schedule. Schedule an Azure Automation PowerShell runbook authenticating via System-Assigned Managed Identity (`Connect-AzAccount -Identity`) to run `Set-AzSqlElasticPool` at 07:00 and 20:00 UTC. Azure Automation runbooks authenticate via Managed Identity (`Connect-AzAccount -Identity`) to scale vCores/Elastic Pools on schedule, rotate keys, or orchestrate hybrid maintenance via Hybrid Workers. Local study-map skill 4.7 (Automate Database Maintenance and Scaling Using Azure Automation Runbooks, Logic Apps, and Azure Functions), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Automate Azure SQL maintenance tasks with Azure Automation, Logic Apps, and Functions (https://learn.microsoft.com/en-us/azure/automation/overview).

- **A:** Incorrect for this requirement. Sharing `sa` credentials or granting `sysadmin` violates least privilege, bypasses auditing attribution, and fails Microsoft Entra-only zero-password compliance. Why the keyed choice wins: Schedule an Azure Automation PowerShell runbook authenticating via System-Assigned Managed Identity (`Connect-AzAccount -Identity`) to run `Set-AzSqlElasticPool` at 07:00 and 20:00 UTC.
- **B:** Correct. Azure Automation runbooks authenticate via Managed Identity (`Connect-AzAccount -Identity`) to scale vCores/Elastic Pools on schedule, rotate keys, or orchestrate hybrid maintenance via Hybrid Workers. In this scenario: Schedule an Azure Automation PowerShell runbook authenticating via System-Assigned Managed Identity (`Connect-AzAccount -Identity`) to run `Set-AzSqlElasticPool` at 07:00 and 20:00 UTC.
- **C:** Incorrect for this requirement. `DBCC SHRINKDATABASE` and `AUTO_SHRINK` cause massive physical index fragmentation (`>90%`), heavy transaction log generation, and immediate file regrow stalls. Why the keyed choice wins: Schedule an Azure Automation PowerShell runbook authenticating via System-Assigned Managed Identity (`Connect-AzAccount -Identity`) to run `Set-AzSqlElasticPool` at 07:00 and 20:00 UTC.
- **D:** Incorrect for this requirement. Single Azure SQL Databases do not expose `SQLServerAgent`; cross-database PaaS scheduling uses Elastic Job Agents with Managed Identity or Azure Automation. Why the keyed choice wins: Schedule an Azure Automation PowerShell runbook authenticating via System-Assigned Managed Identity (`Connect-AzAccount -Identity`) to run `Set-AzSqlElasticPool` at 07:00 and 20:00 UTC.

### Question 97 — B

Answer: Failover Groups for automatic multi-database failover behind stable `<fog>.database.windows.net` / `.secondary` listeners vs Active Geo-Replication for up to 4 readable secondaries. Active Geo-Replication supports up to **four** concurrent readable secondary replicas per database across any Azure regions (and one of those secondaries can also participate in a Failover Group for automatic DR). Failover Groups fail over coupled databases together and redirect connection strings automatically (`GracePeriodWithDataLossHours >= 1`), whereas Active Geo-Replication supports up to 4 secondaries per DB without automatic listener redirection. Local study-map skill 5.8 (Configure Failover Groups (`<fog>.database.windows.net`, Grace Period) vs Active Geo-Replication (`4` Replicas)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Failover groups and active geo-replication in Azure SQL Database and SQL Managed Instance (https://learn.microsoft.com/en-us/azure/azure-sql/database/failover-group-sql-db).

- **A:** Incorrect for this requirement. Geo-Restore downloads and restores geo-replicated backups into a new server with an RPO of up to 1 hour and RTO of up to 12 hours, never automatic 5-second RPO failover. Why the keyed choice wins: Active Geo-Replication supports up to **four** concurrent readable secondary replicas per database across any Azure regions (and one of those secondaries can also participate in a Failover Group for automatic DR).
- **B:** Correct. Failover Groups fail over coupled databases together and redirect connection strings automatically (`GracePeriodWithDataLossHours >= 1`), whereas Active Geo-Replication supports up to 4 secondaries per DB without automatic listener redirection. In this scenario: Active Geo-Replication supports up to **four** concurrent readable secondary replicas per database across any Azure regions (and one of those secondaries can also participate in a Failover Group for automatic DR).
- **C:** Incorrect for this requirement. DTU Basic supports max 2 GB and Standard S0–S2 max 250 GB without compute-isolated read replicas, making them incapable of hosting multi-TB OLTP workloads. Why the keyed choice wins: Active Geo-Replication supports up to **four** concurrent readable secondary replicas per database across any Azure regions (and one of those secondaries can also participate in a Failover Group for automatic DR).
- **D:** Incorrect for this requirement. Serverless auto-scales compute between configured min and max vCores per second and pauses compute billing during idle periods (minimum 1-hour auto-pause delay), charging only storage. Why the keyed choice wins: Active Geo-Replication supports up to **four** concurrent readable secondary replicas per database across any Azure regions (and one of those secondaries can also participate in a Failover Group for automatic DR).

### Question 98 — D

Answer: Azure SQL Database vCore Elastic Pool with per-database min and max vCore limits. An Azure SQL Database vCore Elastic Pool shares pooled vCores across staggered tenant peaks while setting per-database `max vCores` so no single tenant can monopolize pool compute. Elastic Pools share a pooled vCore/storage envelope across many multi-tenant databases with staggered peaks while capping per-database max vCores to stop noisy-neighbor starvation. Local study-map skill 1.1 (Recommend an Azure SQL Offering (SQL Database, SQL Managed Instance, or SQL Server on Azure VMs)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Compare Azure SQL Database, Azure SQL Managed Instance, and SQL Server on Azure VMs (https://learn.microsoft.com/en-us/azure/azure-sql/azure-sql-iaas-vs-paas-what-is-overview).

- **A:** Incorrect for this requirement. SQL Server on Azure VMs (IaaS) provides full OS access, custom third-party drivers, legacy SQL Server version pinning, SSIS/SSRS/SSAS co-hosting, and `Ebdsv5` high remote storage throughput. Why the keyed choice wins: An Azure SQL Database vCore Elastic Pool shares pooled vCores across staggered tenant peaks while setting per-database `max vCores` so no single tenant can monopolize pool compute.
- **B:** Incorrect for this requirement. Serverless auto-scales compute between configured min and max vCores per second and pauses compute billing during idle periods (minimum 1-hour auto-pause delay), charging only storage. Why the keyed choice wins: An Azure SQL Database vCore Elastic Pool shares pooled vCores across staggered tenant peaks while setting per-database `max vCores` so no single tenant can monopolize pool compute.
- **C:** Incorrect for this requirement. DTU Basic supports max 2 GB and Standard S0–S2 max 250 GB without compute-isolated read replicas, making them incapable of hosting multi-TB OLTP workloads. Why the keyed choice wins: An Azure SQL Database vCore Elastic Pool shares pooled vCores across staggered tenant peaks while setting per-database `max vCores` so no single tenant can monopolize pool compute.
- **D:** Correct. Elastic Pools share a pooled vCore/storage envelope across many multi-tenant databases with staggered peaks while capping per-database max vCores to stop noisy-neighbor starvation. In this scenario: An Azure SQL Database vCore Elastic Pool shares pooled vCores across staggered tenant peaks while setting per-database `max vCores` so no single tenant can monopolize pool compute.

### Question 99 — A

Answer: Horizontal sharding using the Elastic Database Client Library (`ShardMapManager` with `ListShardMap` or `RangeShardMap`). The Elastic Database Client Library's `ShardMapManager` (`ListShardMap`) stores discrete `TenantId -> Shard` mappings in a dedicated Shard Map Manager database and caches routing lookups in the app tier. `ListShardMap` maps discrete `TenantId` keys and `RangeShardMap` maps contiguous ID spans to independent Azure SQL Databases, routing data-dependent connections directly from the app tier. Local study-map skill 1.4 (Plan for Table Partitioning (`RANGE RIGHT` / `SWITCH`) and Horizontal Database Sharding (`ShardMapManager`)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Table partitioning and scaling out with Azure SQL Database sharding (https://learn.microsoft.com/en-us/azure/azure-sql/database/elastic-scale-introduction).

- **A:** Correct. `ListShardMap` maps discrete `TenantId` keys and `RangeShardMap` maps contiguous ID spans to independent Azure SQL Databases, routing data-dependent connections directly from the app tier. In this scenario: The Elastic Database Client Library's `ShardMapManager` (`ListShardMap`) stores discrete `TenantId -> Shard` mappings in a dedicated Shard Map Manager database and caches routing lookups in the app tier.
- **B:** Incorrect for this requirement. `sp_estimate_data_compression_savings` models space gains before compressing; `ROW`/`PAGE` shrink OLTP B-trees while `COLUMNSTORE` / `COLUMNSTORE_ARCHIVE` achieves up to 10x analytics compression. Why the keyed choice wins: The Elastic Database Client Library's `ShardMapManager` (`ListShardMap`) stores discrete `TenantId -> Shard` mappings in a dedicated Shard Map Manager database and caches routing lookups in the app tier.
- **C:** Incorrect for this requirement. DTU Basic supports max 2 GB and Standard S0–S2 max 250 GB without compute-isolated read replicas, making them incapable of hosting multi-TB OLTP workloads. Why the keyed choice wins: The Elastic Database Client Library's `ShardMapManager` (`ListShardMap`) stores discrete `TenantId -> Shard` mappings in a dedicated Shard Map Manager database and caches routing lookups in the app tier.
- **D:** Incorrect for this requirement. `RANGE RIGHT` places each upper-boundary date value cleanly as the lower bound of its own monthly/daily partition, enabling metadata-only `SWITCH` archival when indexes are aligned. Why the keyed choice wins: The Elastic Database Client Library's `ShardMapManager` (`ListShardMap`) stores discrete `TenantId -> Shard` mappings in a dedicated Shard Map Manager database and caches routing lookups in the app tier.

### Question 100 — B

Answer: Log Replay Service (`LRS`) streaming Full, Differential, and Tail-Log backups from Azure Blob Storage into SQL Managed Instance. Log Replay Service (`LRS`, invoked via `Start-AzSqlInstanceDatabaseLogReplay` and completed via `Complete-AzSqlInstanceDatabaseLogReplay`) streams backups continuously from Azure Blob Storage into SQL Managed Instance. `Start-AzSqlInstanceDatabaseLogReplay` continuously replays `.bak`/`.trn` files from Blob storage until `Complete-AzSqlInstanceDatabaseLogReplay` restores the final tail-log backup. Local study-map skill 1.11 (Implement Online and Offline Migrations to and Between Azure SQL Services (`MI Link`, `LRS`, `SqlPackage` Copy)), aligned to the official DP-300 study guide (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-300). Primary reference: Online and offline SQL migrations with Managed Instance link, Log Replay Service, and SqlPackage (https://learn.microsoft.com/en-us/azure/azure-sql/managed-instance/managed-instance-link-feature-overview).

- **A:** Incorrect for this requirement. Managed Instance link online failback from SQL MI to SQL Server requires SQL Server 2022 or later; SQL Server 2016 and 2019 support one-way migration into SQL MI only. Why the keyed choice wins: Log Replay Service (`LRS`, invoked via `Start-AzSqlInstanceDatabaseLogReplay` and completed via `Complete-AzSqlInstanceDatabaseLogReplay`) streams backups continuously from Azure Blob Storage into SQL Managed Instance.
- **B:** Correct. `Start-AzSqlInstanceDatabaseLogReplay` continuously replays `.bak`/`.trn` files from Blob storage until `Complete-AzSqlInstanceDatabaseLogReplay` restores the final tail-log backup. In this scenario: Log Replay Service (`LRS`, invoked via `Start-AzSqlInstanceDatabaseLogReplay` and completed via `Complete-AzSqlInstanceDatabaseLogReplay`) streams backups continuously from Azure Blob Storage into SQL Managed Instance.
- **C:** Incorrect for this requirement. Both standalone Data Migration Assistant (retired July 2025) and SQL Server Stretch Database (retired) are deprecated; use Azure Migrate / Azure SQL Migration extension and partitioning/Fabric/Blob tiering. Why the keyed choice wins: Log Replay Service (`LRS`, invoked via `Start-AzSqlInstanceDatabaseLogReplay` and completed via `Complete-AzSqlInstanceDatabaseLogReplay`) streams backups continuously from Azure Blob Storage into SQL Managed Instance.
- **D:** Incorrect for this requirement. Creating a point-in-time database copy isolates active OLTP writes so `SqlPackage /Action:Export` produces a foreign-key-consistent `.bacpac` archive in Azure Blob Storage. Why the keyed choice wins: Log Replay Service (`LRS`, invoked via `Start-AzSqlInstanceDatabaseLogReplay` and completed via `Complete-AzSqlInstanceDatabaseLogReplay`) streams backups continuously from Azure Blob Storage into SQL Managed Instance.
