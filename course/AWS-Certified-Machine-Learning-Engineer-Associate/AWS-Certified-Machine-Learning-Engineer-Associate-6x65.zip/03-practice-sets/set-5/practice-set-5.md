# AWS Certified Machine Learning Engineer – Associate (MLA-C02) — Full-Length Mock Exam 5

Machine Learning Engineer · 65 questions · 130 minutes · scaled passing score 720 of 1000

Blueprint-weighted mock exam. Item mix: 50 multiple-choice and 15 multiple-response items (the selection count is stated in each multi-response stem). The published exam has 65 questions in 130 minutes, of which 50 are scored and 15 are unscored, and AWS does not identify the unscored items. AWS publishes no split between multiple-choice and multiple-response items, so the 15-item multi-response block is an authoring choice. At 65 items in 130 minutes this set matches the published pacing at about 120 seconds per item. AWS is currently delivering MLA-C02 as a beta of 85 questions in 170 minutes with the extra items unscored; this set follows the published 65-question form. The published format has no case-study component, so no case-study item appears here. See the README for the exact fidelity boundary.

Original educational content, not actual, recalled, or copied AWS exam items.

## Questions

---

## Domain 1 — Data Preparation for ML and AI (28%) — Ingestion, storage, feature engineering, embeddings, and data quality

### 1. A media catalogue must return asset metadata in milliseconds per play, and the same catalogue must answer similarity searches over plot summaries. Which two stores fit? Select two.

- A. Mount a shared Amazon EFS file system on every training host
- B. Land the dataset as Parquet in Amazon S3
- C. Use Amazon FSx for Lustre for the training file system
- D. Serve low-latency feature lookups from Amazon DynamoDB
- E. Index the vectors in Amazon OpenSearch Service with k-NN search

### 2. A video-encoding model trains from four terabytes of frames per epoch, and the shared file system cannot keep the accelerators fed. What should the job read from?

- A. Mount a shared Amazon EFS file system on every training host
- B. Attach a gp3 Amazon EBS volume to the training instance
- C. Use Amazon FSx for Lustre for the training file system
- D. Land the dataset as Parquet in Amazon S3

### 3. Playback events must land in the lake as compact objects within two minutes, with no consumer to operate. What fits?

- A. Ingest the events with Amazon Kinesis Data Streams
- B. Transform each stream record with AWS Lambda
- C. Deliver the stream to Amazon S3 with Amazon Data Firehose
- D. Ingest the events through Amazon MSK

### 4. Thumbnails are regenerated on demand, so the stored copies must be deleted automatically after fourteen days. What fits?

- A. Archive the raw corpus to an S3 Glacier storage class
- B. Apply S3 Object Lock to the regulated training data
- C. Expire intermediate artefacts with an S3 lifecycle rule
- D. Use S3 Intelligent-Tiering for the unevenly accessed corpus

### 5. Recommendation features read eight of forty event columns and always filter to one day. Which two storage choices fit? Select two.

- A. Use S3 Intelligent-Tiering for the unevenly accessed corpus
- B. Land the raw JSON events in Amazon S3 unchanged
- C. Mount a shared Amazon EFS file system on every training host
- D. Land the dataset as Parquet in Amazon S3
- E. Partition the S3 prefix by event date

### 6. Viewer telemetry is hot for a week after release and then almost never touched, and nobody wants to write tiering rules. What fits?

- A. Partition the S3 prefix by event date
- B. Land the dataset as Parquet in Amazon S3
- C. Apply S3 Object Lock to the regulated training data
- D. Use S3 Intelligent-Tiering for the unevenly accessed corpus

### 7. Watch history and catalogue metadata must be joined every night, and the team has nobody to operate a cluster. What fits?

- A. Profile and clean the data with AWS Glue DataBrew
- B. Transform the data with an AWS Glue ETL job
- C. Replicate the operational tables with AWS Database Migration Service
- D. Register the tables in the AWS Glue Data Catalog

### 8. A content analyst must profile and clean the metadata table interactively without writing code. What fits?

- A. Profile and clean the data with AWS Glue DataBrew
- B. Transform each stream record with AWS Lambda
- C. Transform the data with an AWS Glue ETL job
- D. Prepare the data in SageMaker Data Wrangler

### 9. The recommendation endpoint must read the latest viewer affinity vector within milliseconds of a request. What serves that read?

- A. Keep the point-in-time history in the Feature Store offline store
- B. Publish the features to the SageMaker Feature Store online store
- C. Ingest the cleaned rows into a SageMaker Feature Group
- D. Register the tables in the AWS Glue Data Catalog

### 10. A genre column has fifteen unordered values, and the model is treating them as increasing numbers. What should be applied?

- A. Apply a log transform to the skewed amount column
- B. Standardise the numeric columns before training
- C. One-hot encode the categorical columns
- D. Bin the continuous age column into ranges

### 11. Watch-time seconds and a completion ratio in different units must be comparable, and the rare churn label must appear in every split. Which two steps fit? Select two.

- A. One-hot encode the categorical columns
- B. Standardise the numeric columns before training
- C. Shuffle the rows before every epoch
- D. Bin the continuous age column into ranges
- E. Stratify the train, validation and test splits by label

### 12. Episode vectors must stay joined to the relational schedule table that the application already queries. What fits?

- A. Index the vectors in Amazon OpenSearch Service with k-NN search
- B. Load every vector into the application process on each request
- C. Store the vectors in Amazon RDS for PostgreSQL with pgvector
- D. Keep the vectors in Amazon S3 with a vector index

### 13. Subtitles must become searchable vectors, and searches by exact episode title must keep working alongside semantic search. Which two components fit? Select two.

- A. Generate the embeddings with an Amazon Bedrock embedding model
- B. Add a reranking step after retrieval
- C. Combine keyword and vector retrieval
- D. Keep the vectors in Amazon S3 with a vector index
- E. Fine-tune the embedding model on the domain question-answer pairs

### 14. Retrieval matches individual lines of dialogue well but loses the scene context needed to answer. What pattern fits?

- A. Split the documents into fixed-size overlapping chunks
- B. Index parent sections and retrieve their child chunks
- C. Chunk the documents on semantic boundaries such as headings
- D. Store source, date and section metadata with each chunk

### 15. Before any production data arrives, the team must record what normal event volumes and field distributions look like. What should be captured?

- A. Profile the incoming data and store the statistics as a baseline
- B. Enforce a schema contract on the ingested records
- C. Evaluate AWS Glue Data Quality rules on the prepared table
- D. Remove duplicate rows before splitting

### 16. Editors must tag a sample of clips for content category, with two reviewers per clip and a quality report. What fits?

- A. Use automated data labelling with a human review sample in Ground Truth
- B. Send the unlabelled records to Amazon SageMaker Ground Truth
- C. Remove duplicate rows before splitting
- D. Mask and redact personal identifiers before training

### 17. A recommendation model under-serves one viewer cohort, and the business will not remove any cohort from the data. What mitigation fits?

- A. Reweight the under-represented group in the loss
- B. Rebalance the numeric, text and image assets in the set
- C. Measure bias with SageMaker Clarify before training
- D. Stratify the train, validation and test splits by label

### 18. The same subscriber event was exported twice and landed in both the training and validation splits. What should be applied?

- A. Impute missing numeric values with the median
- B. Remove duplicate rows before splitting
- C. Generate synthetic minority samples to rebalance the classes
- D. Clip extreme outliers to a defined percentile

---

## Domain 2 — ML Model and Foundation Model (FM) Development (24%) — Model and FM selection, tuning, customisation, and evaluation

### 19. A streaming service needs probabilistic forecasts of concurrent viewers for every title. Which algorithm fits?

- A. Train with the linear learner algorithm
- B. Train the tabular classifier with the XGBoost built-in algorithm
- C. Use the k-nearest-neighbours algorithm
- D. Forecast the series with the DeepAR algorithm

### 20. Newly published titles have no history, and the team must rank how unusual each title's traffic pattern is. What fits?

- A. Average several models into an ensemble
- B. Train the tabular classifier with the XGBoost built-in algorithm
- C. Forecast the series with the DeepAR algorithm
- D. Use Random Cut Forest for anomaly scoring

### 21. A writers' assistant must reason over a full episode script plus previous episode summaries in one request. Which model choice fits?

- A. Select an Amazon Nova foundation model in Amazon Bedrock
- B. Download open weights and host them on your own endpoint
- C. Select an Anthropic Claude model in Amazon Bedrock
- D. Select a Titan embedding model in Amazon Bedrock

### 22. Two hundred thousand synopses must become vectors for similarity clustering. What fits?

- A. Download open weights and host them on your own endpoint
- B. Select a Titan embedding model in Amazon Bedrock
- C. Select an Amazon Nova foundation model in Amazon Bedrock
- D. Select an Anthropic Claude model in Amazon Bedrock

### 23. The model must absorb the studio's own character names and invented terminology before any task tuning. What fits?

- A. Run continued pre-training on the domain corpus
- B. Fine-tune with parameter-efficient adapters such as LoRA
- C. Start with task-specific prompt engineering before any training
- D. Run full-parameter fine-tuning on the curated corpus

### 24. The assistant must follow a house style guide, and its general writing quality must survive that tuning. Which two techniques fit? Select two.

- A. Start with task-specific prompt engineering before any training
- B. Run full-parameter fine-tuning on the curated corpus
- C. Mix replay samples from the original distribution into fine-tuning
- D. Distil the large model into a smaller student model
- E. Fine-tune with parameter-efficient adapters such as LoRA

### 25. Answers must cite the episode title and air date, and retrieval must be filterable to one season. What should each chunk carry?

- A. Store source, date and section metadata with each chunk
- B. Index parent sections and retrieve their child chunks
- C. Chunk the documents on semantic boundaries such as headings
- D. Split the documents into fixed-size overlapping chunks

### 26. Thirty thousand hours of interviews must become searchable text with speaker labels. What fits?

- A. Transcribe the calls with Amazon Transcribe
- B. Detect entities and sentiment with Amazon Comprehend
- C. Detect objects and text in images with Amazon Rekognition
- D. Extract the form fields with Amazon Textract

### 27. A small team needs a pre-trained image classifier served this week with no training data of its own. What fits?

- A. Start from a SageMaker JumpStart model
- B. Train the tabular classifier with the XGBoost built-in algorithm
- C. Bring a custom training container image
- D. Package the training code in script mode with a supported framework

### 28. The tuner maximises click-through while the business is judged on watch completion, and the selected model disappoints. What should change?

- A. Define the tuning objective on the validation metric that matters
- B. Run a hand-written grid of training jobs
- C. Enable early stopping on the validation metric
- D. Use random search over a small range

### 29. The first tuning pass must be a managed search, and a manual sweep is needed for two parameters the search cannot express. Which two approaches fit? Select two.

- A. Define the tuning objective on the validation metric that matters
- B. Tune hyperparameters with SageMaker automatic model tuning
- C. Enable early stopping on the validation metric
- D. Keep a managed warm pool for the training cluster
- E. Run a hand-written grid of training jobs

### 30. Training error is 0.02 while validation error is 0.31, and the gap widens every epoch. Which two responses fit? Select two.

- A. Add regularisation and reduce model capacity
- B. Add training data and keep a held-out validation split
- C. Average several models into an ensemble
- D. Increase model capacity and train for more epochs
- E. Checkpoint to Amazon S3 so an interrupted job resumes

### 31. A model forecasts minutes watched per viewer, and the error must be reported in minutes. Which metric fits?

- A. Report F1 on the holdout set
- B. Score the generated summaries with BLEU
- C. Report RMSE for the regression
- D. Report ROC-AUC for the ranking task

### 32. Churn probability must be compared across all thresholds, and the retention team needs the exact cut-off that fits its call capacity. Which two outputs fit? Select two.

- A. Report F1 on the holdout set
- B. Report ROC-AUC for the ranking task
- C. Pick the threshold from the precision-recall curve
- D. Report RMSE for the regression
- E. Inspect the confusion matrix on the minority class

### 33. Episode recaps must be scored for how much of the reference summary's content they include. Which metric fits?

- A. Measure semantic similarity to the reference answer
- B. Score the generated summaries with BLEU
- C. Score the generated summaries with ROUGE
- D. Score the answers with BERTScore

### 34. A streaming service must choose between two candidate models on a shared prompt suite, using a managed scoring job rather than a hand-written harness. What fits?

- A. Run an Amazon Bedrock model evaluation job
- B. Store the prompt templates in Amazon Bedrock Prompt Management
- C. Register the approved version in the SageMaker Model Registry
- D. Log runs with MLflow on SageMaker AI

---

## Domain 3 — Deployment and Orchestration of ML and AI Workflows (24%) — Inference infrastructure, scaling, CI/CD, and orchestration

### 35. Every player start needs a recommendation within 100 milliseconds, all day, at steady volume. What fits?

- A. Run a batch transform job over the stored records
- B. Deploy a serverless inference endpoint
- C. Deploy a real-time SageMaker AI endpoint
- D. Use asynchronous inference with results written to Amazon S3

### 36. Every title's full back catalogue must be rescored nightly, and hundreds of small per-title models must share hosting capacity. Which two methods fit? Select two.

- A. Deploy a serverless inference endpoint
- B. Run a batch transform job over the stored records
- C. Use asynchronous inference with results written to Amazon S3
- D. Deploy a real-time SageMaker AI endpoint
- E. Host many small models behind one multi-model endpoint

### 37. Feature assembly and the ranking model must run behind one endpoint call. What fits?

- A. Deploy a serverless inference endpoint
- B. Host many small models behind one multi-model endpoint
- C. Deploy a real-time SageMaker AI endpoint
- D. Run several containers behind one endpoint

### 38. The recommendations assistant runs at high, steady volume all day, and throttling has already dropped requests. What should be purchased?

- A. Compare provisioned throughput against on-demand spend
- B. Buy provisioned throughput for the Bedrock model
- C. Import the fine-tuned weights with Bedrock custom model import
- D. Call the Bedrock model on demand

### 39. A prototype assistant must run on the cheapest instance family that still holds its latency target, chosen from measurements. What should be used?

- A. Right-size the endpoint with SageMaker Inference Recommender
- B. Buy provisioned throughput for the Bedrock model
- C. Compare provisioned throughput against on-demand spend
- D. Call the Bedrock model on demand

### 40. The catalogue changes every night, and the assistant keeps recommending titles that left the platform. What should be scheduled?

- A. Deploy the agent with its action groups and knowledge base
- B. Schedule a knowledge base sync when documents change
- C. Persist the agent session state between turns
- D. Store the prompt templates in Amazon Bedrock Prompt Management

### 41. The ranking image must be versioned so the hosting service pulls exactly the tested build. Where should it live?

- A. Build and test the model image with AWS CodeBuild
- B. Run the container on Amazon ECS
- C. Bring a custom training container image
- D. Store the container image in Amazon ECR

### 42. Each ranking request occupies the accelerator for seconds, so instance count lags the real queue. What should the scaling policy track?

- A. Auto scale the endpoint on a target-tracking policy
- B. Auto scale on a step policy with CloudWatch alarms
- C. Scale the endpoint to zero outside business hours
- D. Scale on GPU utilisation rather than invocation count

### 43. Viewer load rises smoothly through the evening, and the first requests of prime time must not hit a cold start. Which two settings fit? Select two.

- A. Auto scale on a step policy with CloudWatch alarms
- B. Keep provisioned concurrency ready for the burst window
- C. Auto scale the endpoint on a target-tracking policy
- D. Keep a managed warm pool for the training cluster
- E. Scale the endpoint to zero outside business hours

### 44. The endpoint must reach the model registry and S3 without an internet path and without paying for a NAT gateway. What should be created?

- A. Allow ingress from any address on the endpoint port
- B. Create an interface VPC endpoint for the service
- C. Place the endpoint and model containers in private subnets
- D. Route the private subnet through a NAT gateway

### 45. Every commit must build the image and run the tests, and the release must follow ordered stages with recorded outcomes. Which two services fit? Select two.

- A. Connect the external repository with AWS CodeConnections
- B. Build and test the model image with AWS CodeBuild
- C. Shift traffic with AWS CodeDeploy
- D. Orchestrate the release with AWS CodePipeline
- E. Keep the pipeline source in AWS CodeCommit

### 46. A model whose offline evaluation misses the agreed threshold must not be promoted by an automated pipeline. What must the pipeline include?

- A. Shift traffic with AWS CodeDeploy
- B. Orchestrate the release with AWS CodePipeline
- C. Build and test the model image with AWS CodeBuild
- D. Fail the pipeline when the evaluation threshold is missed

### 47. Every prompt change to the recommendation assistant must be versioned and reversible without a deployment. What fits?

- A. Register the approved version in the SageMaker Model Registry
- B. Log runs with MLflow on SageMaker AI
- C. Keep the pipeline source in AWS CodeCommit
- D. Store the prompt templates in Amazon Bedrock Prompt Management

### 48. A new ranking model must reach one percent of viewers until its engagement metric is reviewed. What fits?

- A. Mirror traffic to the new model without serving its answers
- B. Stand the new version beside the old and switch traffic
- C. Replace the production version in a single switch
- D. Send a small share of traffic to the new version first

### 49. A replacement model must be scored on live traffic with no viewer affected, and the previous version must remain switchable within seconds. Which two strategies fit? Select two.

- A. Mirror traffic to the new model without serving its answers
- B. Replace the production version in a single switch
- C. Send a small share of traffic to the new version first
- D. Stand the new version beside the old and switch traffic
- E. Shift traffic to the new version in equal steps

### 50. Feature build, training and registration must run as one scheduled workflow with lineage between the steps. What fits?

- A. Trigger the retraining run with an EventBridge schedule
- B. Orchestrate the steps with AWS Step Functions
- C. Orchestrate the release with AWS CodePipeline
- D. Define the workflow as a SageMaker pipeline

---

## Domain 4 — Operating, Monitoring, and Securing ML and AI Solutions (24%) — Monitoring, cost control, identity, network isolation, and guardrails

### 51. Engagement labels arrive a day later, and the team must prove whether ranking quality actually fell. What fits?

- A. Enable a data drift monitor on the endpoint
- B. Enable feature attribution drift monitoring
- C. Enable a model quality monitor with ground-truth labels
- D. Enable a bias drift monitor

### 52. A new device type changed the playback event fields, and one viewer cohort must be watched for a changing outcome rate. Which two monitors fit? Select two.

- A. Enable feature attribution drift monitoring
- B. Enable a model quality monitor with ground-truth labels
- C. Enable a data drift monitor on the endpoint
- D. Alarm on the CloudWatch latency and error metrics
- E. Enable a bias drift monitor

### 53. Scoring requests returned empty lists yesterday, and the team needs the common failing field across millions of log lines. What fits?

- A. Build a CloudWatch dashboard for the pipeline metrics
- B. Alarm on the CloudWatch latency and error metrics
- C. Trace the pipeline service calls with AWS X-Ray
- D. Query the inference logs with CloudWatch Logs Insights

### 54. The on-call engineer must be paged when the endpoint error rate passes one percent. What fits?

- A. Trace the pipeline service calls with AWS X-Ray
- B. Query the inference logs with CloudWatch Logs Insights
- C. Alarm on the CloudWatch latency and error metrics
- D. Build a CloudWatch dashboard for the pipeline metrics

### 55. Finance wants the token count and time-to-first-token of every assistant call recorded for chargeback to each content team. What fits?

- A. Enable CloudWatch generative AI observability for the model calls
- B. Alarm on the CloudWatch latency and error metrics
- C. Trace the pipeline service calls with AWS X-Ray
- D. Trace agent tool calls with Bedrock AgentCore Observability

### 56. The ML bill rose by forty percent and nobody can say which endpoint caused it. What fits?

- A. Cover the steady inference load with a Savings Plan
- B. Break the spend down by endpoint with AWS Cost Explorer
- C. Right-size the instance family against the measured latency
- D. Move the offline scoring to batch transform

### 57. Scores are produced in a nightly batch while an idle endpoint waits, and the endpoint family exceeds the measured need. Which two changes fit? Select two.

- A. Start with the largest available model for every request
- B. Cover the steady inference load with a Savings Plan
- C. Move the offline scoring to batch transform
- D. Right-size the instance family against the measured latency
- E. Scale the endpoint to zero outside business hours

### 58. Each assistant call attaches eight retrieved episode synopses, and reviewers confirm only the top two ever matter. What should change?

- A. Route routine requests to a smaller model
- B. Trim the retrieved context sent to the model
- C. Cache embeddings for documents that have not changed
- D. Cap the output tokens per request

### 59. Ninety percent of recommendation-explanation requests are trivial title lookups, yet all of them run on the largest model. What should be added?

- A. Route routine requests to a smaller model
- B. Trim the retrieved context sent to the model
- C. Cap the output tokens per request
- D. Cache embeddings for documents that have not changed

### 60. The training bucket must be readable only through the VPC endpoint, and a job should read only its own prefix. Which two controls fit? Select two.

- A. Attach one policy to an IAM group the engineers belong to
- B. Attach a policy scoped to the one bucket prefix
- C. Use the account root user for pipeline administration
- D. Deny access to the bucket unless the request comes through the VPC endpoint
- E. Create a long-lived access key for the integration

### 61. A microservice must call a Bedrock model, and the security team forbids storing IAM keys in its environment. What fits?

- A. Use the account root user for pipeline administration
- B. Issue a Bedrock API key for the calling application
- C. Create a long-lived access key for the integration
- D. Attach one policy to an IAM group the engineers belong to

### 62. The ranking endpoint answers anything that can reach its port inside the VPC, including a marketing tool that should never call it. What should change?

- A. Create an interface VPC endpoint for the service
- B. Allow ingress from any address on the endpoint port
- C. Place the endpoint and model containers in private subnets
- D. Restrict the security group to the application subnet

### 63. Subtitles and transcripts used for training must be encrypted with a key the studio can revoke on its own authority. What fits?

- A. Encrypt the artefacts with a customer managed KMS key
- B. Store the model API credential in AWS Secrets Manager
- C. Track resource configuration with AWS Config
- D. Apply Amazon Bedrock Guardrails to the model responses

### 64. An audience-facing assistant must refuse legal and medical questions and mask personal data in answers, through one managed control. What fits?

- A. Configure a denied-topics policy for the assistant
- B. Screen the training text for unsafe content
- C. Apply Amazon Bedrock Guardrails to the model responses
- D. Redact personal data before the prompt reaches the model

### 65. An auditor must see that every training bucket had encryption enabled continuously for the past year. What fits?

- A. Scan the built image with Amazon Inspector
- B. Track resource configuration with AWS Config
- C. Query the inference logs with CloudWatch Logs Insights
- D. Record the API calls with AWS CloudTrail

---

## Answer key and explanations

### Question 1 — D, E

Answers: Serve low-latency feature lookups from Amazon DynamoDB; Index the vectors in Amazon OpenSearch Service with k-NN search. A key-value store serves the metadata lookup, and a vector index answers the similarity search. DynamoDB answers key lookups at single-digit millisecond latency. OpenSearch provides a managed vector index with filtered k-nearest-neighbour search. Local study-map skill 1.1 (Ingestion Sources and Storage Choice), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. EFS gives many hosts one POSIX file system, which suits shared code and small data. Why the correct answer wins: A key-value store serves the metadata lookup, and a vector index answers the similarity search.
- **B:** Incorrect for this question. Columnar Parquet files in S3 are read in column subsets, which suits repeated training scans. Why the correct answer wins: A key-value store serves the metadata lookup, and a vector index answers the similarity search.
- **C:** Incorrect for this question. Lustre delivers the high throughput a multi-node training job needs from shared storage. Why the correct answer wins: A key-value store serves the metadata lookup, and a vector index answers the similarity search.
- **D:** Correct. DynamoDB answers key lookups at single-digit millisecond latency. In this case: A key-value store serves the metadata lookup, and a vector index answers the similarity search.
- **E:** Correct. OpenSearch provides a managed vector index with filtered k-nearest-neighbour search. In this case: A key-value store serves the metadata lookup, and a vector index answers the similarity search.

### Question 2 — C

Answer: Use Amazon FSx for Lustre for the training file system. Lustre delivers the throughput a multi-accelerator job needs. Lustre delivers the high throughput a multi-node training job needs from shared storage. Local study-map skill 1.1 (Ingestion Sources and Storage Choice), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. EFS gives many hosts one POSIX file system, which suits shared code and small data. Why the correct answer wins: Lustre delivers the throughput a multi-accelerator job needs.
- **B:** Incorrect for this question. EBS is block storage bound to one instance, which suits a single host and not a fleet. Why the correct answer wins: Lustre delivers the throughput a multi-accelerator job needs.
- **C:** Correct. Lustre delivers the high throughput a multi-node training job needs from shared storage. In this case: Lustre delivers the throughput a multi-accelerator job needs.
- **D:** Incorrect for this question. Columnar Parquet files in S3 are read in column subsets, which suits repeated training scans. Why the correct answer wins: Lustre delivers the throughput a multi-accelerator job needs.

### Question 3 — C

Answer: Deliver the stream to Amazon S3 with Amazon Data Firehose. A delivery stream batches the events into objects without a consumer. Local study-map skill 1.2 (Streaming Ingestion), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. Kinesis holds an ordered stream that several consumers can read at their own pace. Why the correct answer wins: A delivery stream batches the events into objects without a consumer.
- **B:** Incorrect for this question. A function per record suits lightweight enrichment and filtering of a stream. Why the correct answer wins: A delivery stream batches the events into objects without a consumer.
- **C:** Correct. In this case: A delivery stream batches the events into objects without a consumer.
- **D:** Incorrect for this question. MSK runs managed Kafka, which suits teams already using Kafka clients and topics. Why the correct answer wins: A delivery stream batches the events into objects without a consumer.

### Question 4 — C

Answer: Expire intermediate artefacts with an S3 lifecycle rule. A lifecycle rule expires the objects on a schedule. A lifecycle rule deletes the derived copies on a schedule, so storage does not grow forever. Local study-map skill 1.3 (Storage Class and Retention), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. An archive class is priced for data that is kept but rarely read. Why the correct answer wins: A lifecycle rule expires the objects on a schedule.
- **B:** Incorrect for this question. Object Lock prevents the retained objects from being altered or deleted for the stated period. Why the correct answer wins: A lifecycle rule expires the objects on a schedule.
- **C:** Correct. A lifecycle rule deletes the derived copies on a schedule, so storage does not grow forever. In this case: A lifecycle rule expires the objects on a schedule.
- **D:** Incorrect for this question. Intelligent-Tiering moves objects between access tiers as usage changes, with no rules to write. Why the correct answer wins: A lifecycle rule expires the objects on a schedule.

### Question 5 — D, E

Answers: Land the dataset as Parquet in Amazon S3; Partition the S3 prefix by event date. A columnar format reads only the needed columns, and a date prefix skips the rest. Columnar Parquet files in S3 are read in column subsets, which suits repeated training scans. Date partitioning lets a query or a training job skip the prefixes it does not need. Local study-map skill 1.4 (Data Formats and Partitioning), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. Intelligent-Tiering moves objects between access tiers as usage changes, with no rules to write. Why the correct answer wins: A columnar format reads only the needed columns, and a date prefix skips the rest.
- **B:** Incorrect for this question. Raw JSON is readable but forces every query to parse whole records. Why the correct answer wins: A columnar format reads only the needed columns, and a date prefix skips the rest.
- **C:** Incorrect for this question. EFS gives many hosts one POSIX file system, which suits shared code and small data. Why the correct answer wins: A columnar format reads only the needed columns, and a date prefix skips the rest.
- **D:** Correct. Columnar Parquet files in S3 are read in column subsets, which suits repeated training scans. In this case: A columnar format reads only the needed columns, and a date prefix skips the rest.
- **E:** Correct. Date partitioning lets a query or a training job skip the prefixes it does not need. In this case: A columnar format reads only the needed columns, and a date prefix skips the rest.

### Question 6 — D

Answer: Use S3 Intelligent-Tiering for the unevenly accessed corpus. Intelligent tiering follows the access pattern with no rules to write. Intelligent-Tiering moves objects between access tiers as usage changes, with no rules to write. Local study-map skill 1.4 (Data Formats and Partitioning), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. Date partitioning lets a query or a training job skip the prefixes it does not need. Why the correct answer wins: Intelligent tiering follows the access pattern with no rules to write.
- **B:** Incorrect for this question. Columnar Parquet files in S3 are read in column subsets, which suits repeated training scans. Why the correct answer wins: Intelligent tiering follows the access pattern with no rules to write.
- **C:** Incorrect for this question. Object Lock prevents the retained objects from being altered or deleted for the stated period. Why the correct answer wins: Intelligent tiering follows the access pattern with no rules to write.
- **D:** Correct. Intelligent-Tiering moves objects between access tiers as usage changes, with no rules to write. In this case: Intelligent tiering follows the access pattern with no rules to write.

### Question 7 — B

Answer: Transform the data with an AWS Glue ETL job. A managed transform job performs the join without a cluster to run. Glue runs a managed Spark job against catalogued sources and writes the prepared output. Local study-map skill 1.5 (Merge and Transform Tooling), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. DataBrew provides a visual recipe for profiling, cleaning and normalising columns. Why the correct answer wins: A managed transform job performs the join without a cluster to run.
- **B:** Correct. Glue runs a managed Spark job against catalogued sources and writes the prepared output. In this case: A managed transform job performs the join without a cluster to run.
- **C:** Incorrect for this question. DMS copies and keeps replicating rows from the source database without custom extract code. Why the correct answer wins: A managed transform job performs the join without a cluster to run.
- **D:** Incorrect for this question. The catalog gives every engine the same table definitions and schemas. Why the correct answer wins: A managed transform job performs the join without a cluster to run.

### Question 8 — A

Answer: Profile and clean the data with AWS Glue DataBrew. A visual recipe performs the profiling and cleaning. DataBrew provides a visual recipe for profiling, cleaning and normalising columns. Local study-map skill 1.5 (Merge and Transform Tooling), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Correct. DataBrew provides a visual recipe for profiling, cleaning and normalising columns. In this case: A visual recipe performs the profiling and cleaning.
- **B:** Incorrect for this question. A function per record suits lightweight enrichment and filtering of a stream. Why the correct answer wins: A visual recipe performs the profiling and cleaning.
- **C:** Incorrect for this question. Glue runs a managed Spark job against catalogued sources and writes the prepared output. Why the correct answer wins: A visual recipe performs the profiling and cleaning.
- **D:** Incorrect for this question. Data Wrangler builds a reusable preparation flow and can export it into a pipeline. Why the correct answer wins: A visual recipe performs the profiling and cleaning.

### Question 9 — B

Answer: Publish the features to the SageMaker Feature Store online store. The online store returns the latest values at low latency. The online store serves the latest feature values for low-latency inference lookups. Local study-map skill 1.6 (Feature Store), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. The offline store keeps timestamped values so training reads the values that existed at the time. Why the correct answer wins: The online store returns the latest values at low latency.
- **B:** Correct. The online store serves the latest feature values for low-latency inference lookups. In this case: The online store returns the latest values at low latency.
- **C:** Incorrect for this question. A feature group gives one definition that both training and inference read. Why the correct answer wins: The online store returns the latest values at low latency.
- **D:** Incorrect for this question. The catalog gives every engine the same table definitions and schemas. Why the correct answer wins: The online store returns the latest values at low latency.

### Question 10 — C

Answer: One-hot encode the categorical columns. One-hot encoding keeps an unordered category from implying order. One-hot encoding turns unordered categories into separate binary columns. Local study-map skill 1.7 (Feature Engineering and Scaling), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. A log transform compresses the long tail of a heavily skewed amount distribution. Why the correct answer wins: One-hot encoding keeps an unordered category from implying order.
- **B:** Incorrect for this question. Scaling puts the numeric columns on comparable ranges so no column dominates the fit. Why the correct answer wins: One-hot encoding keeps an unordered category from implying order.
- **C:** Correct. One-hot encoding turns unordered categories into separate binary columns. In this case: One-hot encoding keeps an unordered category from implying order.
- **D:** Incorrect for this question. Binning trades resolution for robustness to small variations inside a range. Why the correct answer wins: One-hot encoding keeps an unordered category from implying order.

### Question 11 — B, E

Answers: Standardise the numeric columns before training; Stratify the train, validation and test splits by label. Scaling makes the units comparable, and stratification preserves the rare label. Scaling puts the numeric columns on comparable ranges so no column dominates the fit. Stratifying keeps the label proportions the same in every split. Local study-map skill 1.7 (Feature Engineering and Scaling), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. One-hot encoding turns unordered categories into separate binary columns. Why the correct answer wins: Scaling makes the units comparable, and stratification preserves the rare label.
- **B:** Correct. Scaling puts the numeric columns on comparable ranges so no column dominates the fit. In this case: Scaling makes the units comparable, and stratification preserves the rare label.
- **C:** Incorrect for this question. Shuffling stops the batch order from encoding an accidental pattern. Why the correct answer wins: Scaling makes the units comparable, and stratification preserves the rare label.
- **D:** Incorrect for this question. Binning trades resolution for robustness to small variations inside a range. Why the correct answer wins: Scaling makes the units comparable, and stratification preserves the rare label.
- **E:** Correct. Stratifying keeps the label proportions the same in every split. In this case: Scaling makes the units comparable, and stratification preserves the rare label.

### Question 12 — C

Answer: Store the vectors in Amazon RDS for PostgreSQL with pgvector. Vectors stored beside the relational rows keep the join. pgvector keeps vectors beside relational rows the application already queries. Local study-map skill 1.8 (Vector Stores and Embeddings), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. OpenSearch provides a managed vector index with filtered k-nearest-neighbour search. Why the correct answer wins: Vectors stored beside the relational rows keep the join.
- **B:** Incorrect for this question. Rebuilding the index per request cannot hold a large corpus or a latency target. Why the correct answer wins: Vectors stored beside the relational rows keep the join.
- **C:** Correct. pgvector keeps vectors beside relational rows the application already queries. In this case: Vectors stored beside the relational rows keep the join.
- **D:** Incorrect for this question. An S3-backed index suits a large, cost-sensitive corpus read less often. Why the correct answer wins: Vectors stored beside the relational rows keep the join.

### Question 13 — A, C

Answers: Generate the embeddings with an Amazon Bedrock embedding model; Combine keyword and vector retrieval. An embedding model produces the vectors, and hybrid retrieval keeps exact matches working. A managed embedding model converts text into vectors without hosts to run. Hybrid retrieval catches exact identifiers that a vector search alone can miss. Local study-map skill 1.8 (Vector Stores and Embeddings), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Correct. A managed embedding model converts text into vectors without hosts to run. In this case: An embedding model produces the vectors, and hybrid retrieval keeps exact matches working.
- **B:** Incorrect for this question. A reranker reorders the retrieved passages by relevance before they reach the model. Why the correct answer wins: An embedding model produces the vectors, and hybrid retrieval keeps exact matches working.
- **C:** Correct. Hybrid retrieval catches exact identifiers that a vector search alone can miss. In this case: An embedding model produces the vectors, and hybrid retrieval keeps exact matches working.
- **D:** Incorrect for this question. An S3-backed index suits a large, cost-sensitive corpus read less often. Why the correct answer wins: An embedding model produces the vectors, and hybrid retrieval keeps exact matches working.
- **E:** Incorrect for this question. Domain tuning moves relevant passages closer to their questions in the vector space. Why the correct answer wins: An embedding model produces the vectors, and hybrid retrieval keeps exact matches working.

### Question 14 — B

Answer: Index parent sections and retrieve their child chunks. Small child chunks match precisely while the parent scene supplies context. Local study-map skill 1.9 (Text Pre-processing and Chunking), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. Overlapping fixed chunks bound the context size and avoid cutting a sentence in half. Why the correct answer wins: Small child chunks match precisely while the parent scene supplies context.
- **B:** Correct. In this case: Small child chunks match precisely while the parent scene supplies context.
- **C:** Incorrect for this question. Semantic chunks keep a coherent passage together, which improves what retrieval returns. Why the correct answer wins: Small child chunks match precisely while the parent scene supplies context.
- **D:** Incorrect for this question. Metadata lets retrieval filter by source or recency and lets answers cite the document. Why the correct answer wins: Small child chunks match precisely while the parent scene supplies context.

### Question 15 — A

Answer: Profile the incoming data and store the statistics as a baseline. A stored profile is what later comparisons are measured against. Local study-map skill 1.10 (Data Quality Validation), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Correct. In this case: A stored profile is what later comparisons are measured against.
- **B:** Incorrect for this question. A schema check rejects records whose fields changed shape before they corrupt the set. Why the correct answer wins: A stored profile is what later comparisons are measured against.
- **C:** Incorrect for this question. Data Quality rules fail the job on nulls, duplicates or range violations before training starts. Why the correct answer wins: A stored profile is what later comparisons are measured against.
- **D:** Incorrect for this question. Duplicates that straddle splits leak the same row into training and evaluation. Why the correct answer wins: A stored profile is what later comparisons are measured against.

### Question 16 — B

Answer: Send the unlabelled records to Amazon SageMaker Ground Truth. Managed labelling handles the workforce, review and quality reporting. Ground Truth manages the labelling workforce, instructions and quality checks. Local study-map skill 1.11 (Labelling and Annotation), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. Active learning labels most records automatically and sends only uncertain ones to a person. Why the correct answer wins: Managed labelling handles the workforce, review and quality reporting.
- **B:** Correct. Ground Truth manages the labelling workforce, instructions and quality checks. In this case: Managed labelling handles the workforce, review and quality reporting.
- **C:** Incorrect for this question. Duplicates that straddle splits leak the same row into training and evaluation. Why the correct answer wins: Managed labelling handles the workforce, review and quality reporting.
- **D:** Incorrect for this question. Removing the identifiers stops the model from learning or echoing personal data. Why the correct answer wins: Managed labelling handles the workforce, review and quality reporting.

### Question 17 — A

Answer: Reweight the under-represented group in the loss. Reweighting changes what the model optimises without discarding records. Local study-map skill 1.12 (Bias Detection and Mitigation), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Correct. In this case: Reweighting changes what the model optimises without discarding records.
- **B:** Incorrect for this question. A modality with far fewer examples is under-trained even when the label mix looks even. Why the correct answer wins: Reweighting changes what the model optimises without discarding records.
- **C:** Incorrect for this question. Clarify reports label and feature bias metrics so the imbalance is quantified first. Why the correct answer wins: Reweighting changes what the model optimises without discarding records.
- **D:** Incorrect for this question. Stratifying keeps the label proportions the same in every split. Why the correct answer wins: Reweighting changes what the model optimises without discarding records.

### Question 18 — B

Answer: Remove duplicate rows before splitting. Deduplication stops the same row from straddling both splits. Duplicates that straddle splits leak the same row into training and evaluation. Local study-map skill 1.13 (Cleaning and Class Imbalance), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 1 (data preparation for ML and AI, 28 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain1.html.

- **A:** Incorrect for this question. Median imputation is robust to a skewed distribution and keeps the row. Why the correct answer wins: Deduplication stops the same row from straddling both splits.
- **B:** Correct. Duplicates that straddle splits leak the same row into training and evaluation. In this case: Deduplication stops the same row from straddling both splits.
- **C:** Incorrect for this question. Synthetic minority sampling gives the learner more examples of the rare class. Why the correct answer wins: Deduplication stops the same row from straddling both splits.
- **D:** Incorrect for this question. Clipping caps the influence of a few extreme values without deleting the records. Why the correct answer wins: Deduplication stops the same row from straddling both splits.

### Question 19 — D

Answer: Forecast the series with the DeepAR algorithm. DeepAR learns across related series and returns probabilistic forecasts. Local study-map skill 2.1 (Model and Algorithm Selection), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Incorrect for this question. A linear model is cheap and interpretable when the relationship is close to linear. Why the correct answer wins: DeepAR learns across related series and returns probabilistic forecasts.
- **B:** Incorrect for this question. Gradient-boosted trees are the usual strong baseline for tabular data. Why the correct answer wins: DeepAR learns across related series and returns probabilistic forecasts.
- **C:** Incorrect for this question. Nearest neighbours suit a small, low-dimensional similarity problem. Why the correct answer wins: DeepAR learns across related series and returns probabilistic forecasts.
- **D:** Correct. In this case: DeepAR learns across related series and returns probabilistic forecasts.

### Question 20 — D

Answer: Use Random Cut Forest for anomaly scoring. Random Cut Forest scores each series against the learned shape of normal traffic. Local study-map skill 2.1 (Model and Algorithm Selection), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Incorrect for this question. An ensemble reduces variance from any single model fit. Why the correct answer wins: Random Cut Forest scores each series against the learned shape of normal traffic.
- **B:** Incorrect for this question. Gradient-boosted trees are the usual strong baseline for tabular data. Why the correct answer wins: Random Cut Forest scores each series against the learned shape of normal traffic.
- **C:** Incorrect for this question. DeepAR learns across many related time series and returns probabilistic forecasts. Why the correct answer wins: Random Cut Forest scores each series against the learned shape of normal traffic.
- **D:** Correct. In this case: Random Cut Forest scores each series against the learned shape of normal traffic.

### Question 21 — C

Answer: Select an Anthropic Claude model in Amazon Bedrock. A long context window is what the request size requires. Claude models are available through Bedrock for long-context reasoning tasks. Local study-map skill 2.2 (Foundation Model Selection), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Incorrect for this question. Nova models are reached through the Bedrock API with no infrastructure to host. Why the correct answer wins: A long context window is what the request size requires.
- **B:** Incorrect for this question. Self-hosting gives full control but puts model operations on your team. Why the correct answer wins: A long context window is what the request size requires.
- **C:** Correct. Claude models are available through Bedrock for long-context reasoning tasks. In this case: A long context window is what the request size requires.
- **D:** Incorrect for this question. A Titan embedding model turns text into vectors for search and clustering. Why the correct answer wins: A long context window is what the request size requires.

### Question 22 — B

Answer: Select a Titan embedding model in Amazon Bedrock. An embedding model turns each synopsis into a vector through a managed API. A Titan embedding model turns text into vectors for search and clustering. Local study-map skill 2.2 (Foundation Model Selection), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Incorrect for this question. Self-hosting gives full control but puts model operations on your team. Why the correct answer wins: An embedding model turns each synopsis into a vector through a managed API.
- **B:** Correct. A Titan embedding model turns text into vectors for search and clustering. In this case: An embedding model turns each synopsis into a vector through a managed API.
- **C:** Incorrect for this question. Nova models are reached through the Bedrock API with no infrastructure to host. Why the correct answer wins: An embedding model turns each synopsis into a vector through a managed API.
- **D:** Incorrect for this question. Claude models are available through Bedrock for long-context reasoning tasks. Why the correct answer wins: An embedding model turns each synopsis into a vector through a managed API.

### Question 23 — A

Answer: Run continued pre-training on the domain corpus. Continued pre-training adapts the model to domain vocabulary. Local study-map skill 2.3 (Fine-tuning and Customisation), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Correct. In this case: Continued pre-training adapts the model to domain vocabulary.
- **B:** Incorrect for this question. Adapters train a small number of parameters, which lowers cost and the risk of forgetting. Why the correct answer wins: Continued pre-training adapts the model to domain vocabulary.
- **C:** Incorrect for this question. A well-structured prompt often meets the requirement without a training run. Why the correct answer wins: Continued pre-training adapts the model to domain vocabulary.
- **D:** Incorrect for this question. Full fine-tuning updates every weight and needs more data, memory and care. Why the correct answer wins: Continued pre-training adapts the model to domain vocabulary.

### Question 24 — C, E

Answers: Fine-tune with parameter-efficient adapters such as LoRA; Mix replay samples from the original distribution into fine-tuning. Adapters teach the style cheaply, and replay samples preserve general quality. Adapters train a small number of parameters, which lowers cost and the risk of forgetting. Replay samples keep the earlier behaviour from being overwritten by the narrow new data. Local study-map skill 2.3 (Fine-tuning and Customisation), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Incorrect for this question. A well-structured prompt often meets the requirement without a training run. Why the correct answer wins: Adapters teach the style cheaply, and replay samples preserve general quality.
- **B:** Incorrect for this question. Full fine-tuning updates every weight and needs more data, memory and care. Why the correct answer wins: Adapters teach the style cheaply, and replay samples preserve general quality.
- **C:** Correct. Replay samples keep the earlier behaviour from being overwritten by the narrow new data. In this case: Adapters teach the style cheaply, and replay samples preserve general quality.
- **D:** Incorrect for this question. Distillation transfers the large model behaviour into a cheaper model to serve. Why the correct answer wins: Adapters teach the style cheaply, and replay samples preserve general quality.
- **E:** Correct. Adapters train a small number of parameters, which lowers cost and the risk of forgetting. In this case: Adapters teach the style cheaply, and replay samples preserve general quality.

### Question 25 — A

Answer: Store source, date and section metadata with each chunk. Metadata carries the source and date that citation and filtering need. Metadata lets retrieval filter by source or recency and lets answers cite the document. Local study-map skill 2.4 (RAG Architecture Patterns), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Correct. Metadata lets retrieval filter by source or recency and lets answers cite the document. In this case: Metadata carries the source and date that citation and filtering need.
- **B:** Incorrect for this question. Small child chunks match a query precisely while the parent supplies full context. Why the correct answer wins: Metadata carries the source and date that citation and filtering need.
- **C:** Incorrect for this question. Semantic chunks keep a coherent passage together, which improves what retrieval returns. Why the correct answer wins: Metadata carries the source and date that citation and filtering need.
- **D:** Incorrect for this question. Overlapping fixed chunks bound the context size and avoid cutting a sentence in half. Why the correct answer wins: Metadata carries the source and date that citation and filtering need.

### Question 26 — A

Answer: Transcribe the calls with Amazon Transcribe. Managed speech-to-text with speaker labelling covers interviews. Transcribe converts speech to text and can label speakers. Local study-map skill 2.5 (Managed AI Services), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Correct. Transcribe converts speech to text and can label speakers. In this case: Managed speech-to-text with speaker labelling covers interviews.
- **B:** Incorrect for this question. Comprehend provides managed entity, key-phrase and sentiment analysis. Why the correct answer wins: Managed speech-to-text with speaker labelling covers interviews.
- **C:** Incorrect for this question. Rekognition provides managed image and video analysis for common labels and text. Why the correct answer wins: Managed speech-to-text with speaker labelling covers interviews.
- **D:** Incorrect for this question. Textract reads forms and tables into structured fields without a custom model. Why the correct answer wins: Managed speech-to-text with speaker labelling covers interviews.

### Question 27 — A

Answer: Start from a SageMaker JumpStart model. A jump-start model supplies weights and a deployment template. Local study-map skill 2.6 (Built-in Algorithms and Script Mode), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Correct. In this case: A jump-start model supplies weights and a deployment template.
- **B:** Incorrect for this question. Gradient-boosted trees are the usual strong baseline for tabular data. Why the correct answer wins: A jump-start model supplies weights and a deployment template.
- **C:** Incorrect for this question. A custom image is needed only when the managed framework images cannot carry the dependencies. Why the correct answer wins: A jump-start model supplies weights and a deployment template.
- **D:** Incorrect for this question. Script mode runs your own training script inside a managed framework container. Why the correct answer wins: A jump-start model supplies weights and a deployment template.

### Question 28 — A

Answer: Define the tuning objective on the validation metric that matters. The search optimises exactly the metric it is given. Local study-map skill 2.7 (Hyperparameter Tuning), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Correct. In this case: The search optimises exactly the metric it is given.
- **B:** Incorrect for this question. A manual grid costs a job per combination and adapts to nothing. Why the correct answer wins: The search optimises exactly the metric it is given.
- **C:** Incorrect for this question. Early stopping ends a trial once the validation metric stops improving. Why the correct answer wins: The search optimises exactly the metric it is given.
- **D:** Incorrect for this question. Random search is a cheap baseline but ignores what earlier trials learned. Why the correct answer wins: The search optimises exactly the metric it is given.

### Question 29 — B, E

Answers: Tune hyperparameters with SageMaker automatic model tuning; Run a hand-written grid of training jobs. Automatic tuning covers the managed search, and a hand-written grid covers the rest. Automatic model tuning runs the search over a stated objective metric. A manual grid costs a job per combination and adapts to nothing. Local study-map skill 2.7 (Hyperparameter Tuning), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Incorrect for this question. The search optimises exactly the metric it is given, so the metric must match the goal. Why the correct answer wins: Automatic tuning covers the managed search, and a hand-written grid covers the rest.
- **B:** Correct. Automatic model tuning runs the search over a stated objective metric. In this case: Automatic tuning covers the managed search, and a hand-written grid covers the rest.
- **C:** Incorrect for this question. Early stopping ends a trial once the validation metric stops improving. Why the correct answer wins: Automatic tuning covers the managed search, and a hand-written grid covers the rest.
- **D:** Incorrect for this question. A warm pool removes the provisioning delay between consecutive training jobs. Why the correct answer wins: Automatic tuning covers the managed search, and a hand-written grid covers the rest.
- **E:** Correct. A manual grid costs a job per combination and adapts to nothing. In this case: Automatic tuning covers the managed search, and a hand-written grid covers the rest.

### Question 30 — A, B

Answers: Add regularisation and reduce model capacity; Add training data and keep a held-out validation split. Stronger regularisation and more representative data both reduce variance. Regularisation and smaller capacity reduce variance when training error is far below validation. More representative data reduces variance without shrinking the model. Local study-map skill 2.8 (Training Efficiency and Regularisation), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Correct. Regularisation and smaller capacity reduce variance when training error is far below validation. In this case: Stronger regularisation and more representative data both reduce variance.
- **B:** Correct. More representative data reduces variance without shrinking the model. In this case: Stronger regularisation and more representative data both reduce variance.
- **C:** Incorrect for this question. An ensemble reduces variance from any single model fit. Why the correct answer wins: Stronger regularisation and more representative data both reduce variance.
- **D:** Incorrect for this question. Raising capacity addresses underfitting where both training and validation error are high. Why the correct answer wins: Stronger regularisation and more representative data both reduce variance.
- **E:** Incorrect for this question. Checkpoints let a reclaimed instance continue from the last saved state. Why the correct answer wins: Stronger regularisation and more representative data both reduce variance.

### Question 31 — C

Answer: Report RMSE for the regression. RMSE expresses the typical error in the target units. Local study-map skill 2.9 (Classic Model Evaluation), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Incorrect for this question. F1 balances precision and recall, which suits an uneven class mix. Why the correct answer wins: RMSE expresses the typical error in the target units.
- **B:** Incorrect for this question. BLEU measures n-gram overlap with the reference summaries. Why the correct answer wins: RMSE expresses the typical error in the target units.
- **C:** Correct. In this case: RMSE expresses the typical error in the target units.
- **D:** Incorrect for this question. ROC-AUC measures how well the scores separate the classes across thresholds. Why the correct answer wins: RMSE expresses the typical error in the target units.

### Question 32 — B, C

Answers: Report ROC-AUC for the ranking task; Pick the threshold from the precision-recall curve. AUC compares the ranking, and the precision-recall curve locates the cut-off. ROC-AUC measures how well the scores separate the classes across thresholds. The operating threshold should follow the cost of a false positive against a false negative. Local study-map skill 2.9 (Classic Model Evaluation), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Incorrect for this question. F1 balances precision and recall, which suits an uneven class mix. Why the correct answer wins: AUC compares the ranking, and the precision-recall curve locates the cut-off.
- **B:** Correct. ROC-AUC measures how well the scores separate the classes across thresholds. In this case: AUC compares the ranking, and the precision-recall curve locates the cut-off.
- **C:** Correct. The operating threshold should follow the cost of a false positive against a false negative. In this case: AUC compares the ranking, and the precision-recall curve locates the cut-off.
- **D:** Incorrect for this question. RMSE expresses the typical error in the target units and penalises large misses. Why the correct answer wins: AUC compares the ranking, and the precision-recall curve locates the cut-off.
- **E:** Incorrect for this question. The confusion matrix shows which class the model keeps confusing. Why the correct answer wins: AUC compares the ranking, and the precision-recall curve locates the cut-off.

### Question 33 — C

Answer: Score the generated summaries with ROUGE. ROUGE measures recall of reference n-grams, which suits summarisation. Local study-map skill 2.10 (GenAI and NLP Evaluation), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Incorrect for this question. Embedding similarity tolerates wording changes that an n-gram metric penalises. Why the correct answer wins: ROUGE measures recall of reference n-grams, which suits summarisation.
- **B:** Incorrect for this question. BLEU measures n-gram overlap with the reference summaries. Why the correct answer wins: ROUGE measures recall of reference n-grams, which suits summarisation.
- **C:** Correct. In this case: ROUGE measures recall of reference n-grams, which suits summarisation.
- **D:** Incorrect for this question. BERTScore compares contextual embeddings, so a paraphrase can still score well. Why the correct answer wins: ROUGE measures recall of reference n-grams, which suits summarisation.

### Question 34 — A

Answer: Run an Amazon Bedrock model evaluation job. A managed evaluation job scores both candidates on the same suite. Bedrock evaluation scores model output against built-in or custom metrics. Local study-map skill 2.11 (Experiment Tracking and Baselines), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 2 (ML model and foundation model development, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain2.html.

- **A:** Correct. Bedrock evaluation scores model output against built-in or custom metrics. In this case: A managed evaluation job scores both candidates on the same suite.
- **B:** Incorrect for this question. Prompt Management versions templates so a prompt change is reviewable and reversible. Why the correct answer wins: A managed evaluation job scores both candidates on the same suite.
- **C:** Incorrect for this question. The registry holds model versions and their approval status for deployment. Why the correct answer wins: A managed evaluation job scores both candidates on the same suite.
- **D:** Incorrect for this question. Run logging keeps parameters, metrics and artefacts comparable across experiments. Why the correct answer wins: A managed evaluation job scores both candidates on the same suite.

### Question 35 — C

Answer: Deploy a real-time SageMaker AI endpoint. A real-time endpoint keeps a host ready for synchronous calls. A real-time endpoint answers synchronous requests with a persistent host behind it. Local study-map skill 3.1 (Inference Strategy), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. Batch transform scores a stored dataset with no endpoint to keep running. Why the correct answer wins: A real-time endpoint keeps a host ready for synchronous calls.
- **B:** Incorrect for this question. Serverless inference scales to zero and suits intermittent, short requests. Why the correct answer wins: A real-time endpoint keeps a host ready for synchronous calls.
- **C:** Correct. A real-time endpoint answers synchronous requests with a persistent host behind it. In this case: A real-time endpoint keeps a host ready for synchronous calls.
- **D:** Incorrect for this question. Asynchronous inference queues large or long requests and returns results through S3. Why the correct answer wins: A real-time endpoint keeps a host ready for synchronous calls.

### Question 36 — B, E

Answers: Run a batch transform job over the stored records; Host many small models behind one multi-model endpoint. Batch transform scores the stored catalogue, and a multi-model endpoint shares capacity. Batch transform scores a stored dataset with no endpoint to keep running. A multi-model endpoint loads models on demand from S3 behind shared hosting capacity. Local study-map skill 3.1 (Inference Strategy), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. Serverless inference scales to zero and suits intermittent, short requests. Why the correct answer wins: Batch transform scores the stored catalogue, and a multi-model endpoint shares capacity.
- **B:** Correct. Batch transform scores a stored dataset with no endpoint to keep running. In this case: Batch transform scores the stored catalogue, and a multi-model endpoint shares capacity.
- **C:** Incorrect for this question. Asynchronous inference queues large or long requests and returns results through S3. Why the correct answer wins: Batch transform scores the stored catalogue, and a multi-model endpoint shares capacity.
- **D:** Incorrect for this question. A real-time endpoint answers synchronous requests with a persistent host behind it. Why the correct answer wins: Batch transform scores the stored catalogue, and a multi-model endpoint shares capacity.
- **E:** Correct. A multi-model endpoint loads models on demand from S3 behind shared hosting capacity. In this case: Batch transform scores the stored catalogue, and a multi-model endpoint shares capacity.

### Question 37 — D

Answer: Run several containers behind one endpoint. A multi-container endpoint chains the two containers behind one call. A multi-container endpoint chains containers such as preprocessing and inference. Local study-map skill 3.2 (Endpoint Architecture), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. Serverless inference scales to zero and suits intermittent, short requests. Why the correct answer wins: A multi-container endpoint chains the two containers behind one call.
- **B:** Incorrect for this question. A multi-model endpoint loads models on demand from S3 behind shared hosting capacity. Why the correct answer wins: A multi-container endpoint chains the two containers behind one call.
- **C:** Incorrect for this question. A real-time endpoint answers synchronous requests with a persistent host behind it. Why the correct answer wins: A multi-container endpoint chains the two containers behind one call.
- **D:** Correct. A multi-container endpoint chains containers such as preprocessing and inference. In this case: A multi-container endpoint chains the two containers behind one call.

### Question 38 — B

Answer: Buy provisioned throughput for the Bedrock model. Reserved capacity keeps the steady volume from being throttled. Provisioned throughput reserves model capacity for predictable, high-volume traffic. Local study-map skill 3.3 (Foundation Model Deployment), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. The reservation only pays off when the steady volume exceeds the break-even point. Why the correct answer wins: Reserved capacity keeps the steady volume from being throttled.
- **B:** Correct. Provisioned throughput reserves model capacity for predictable, high-volume traffic. In this case: Reserved capacity keeps the steady volume from being throttled.
- **C:** Incorrect for this question. Custom model import runs your own fine-tuned weights on Bedrock infrastructure. Why the correct answer wins: Reserved capacity keeps the steady volume from being throttled.
- **D:** Incorrect for this question. On-demand calls need no reservation and suit bursty, lower-volume traffic. Why the correct answer wins: Reserved capacity keeps the steady volume from being throttled.

### Question 39 — A

Answer: Right-size the endpoint with SageMaker Inference Recommender. The recommender benchmarks instance types against the latency target. Local study-map skill 3.3 (Foundation Model Deployment), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Correct. In this case: The recommender benchmarks instance types against the latency target.
- **B:** Incorrect for this question. Provisioned throughput reserves model capacity for predictable, high-volume traffic. Why the correct answer wins: The recommender benchmarks instance types against the latency target.
- **C:** Incorrect for this question. The reservation only pays off when the steady volume exceeds the break-even point. Why the correct answer wins: The recommender benchmarks instance types against the latency target.
- **D:** Incorrect for this question. On-demand calls need no reservation and suit bursty, lower-volume traffic. Why the correct answer wins: The recommender benchmarks instance types against the latency target.

### Question 40 — B

Answer: Schedule a knowledge base sync when documents change. A knowledge base sync re-indexes changed documents. A sync re-indexes changed documents so retrieval does not serve stale passages. Local study-map skill 3.4 (Agents and Retrieval Runtime), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. An agent needs its tools, knowledge base and instructions deployed together as one unit. Why the correct answer wins: A knowledge base sync re-indexes changed documents.
- **B:** Correct. A sync re-indexes changed documents so retrieval does not serve stale passages. In this case: A knowledge base sync re-indexes changed documents.
- **C:** Incorrect for this question. Persisted session state keeps multi-turn context without resending the whole history. Why the correct answer wins: A knowledge base sync re-indexes changed documents.
- **D:** Incorrect for this question. Prompt Management versions templates so a prompt change is reviewable and reversible. Why the correct answer wins: A knowledge base sync re-indexes changed documents.

### Question 41 — D

Answer: Store the container image in Amazon ECR. A registry stores the versioned image the service pulls. ECR holds the versioned image that the training or hosting service pulls. Local study-map skill 3.5 (Containers and Compute Provisioning), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. CodeBuild runs the build and the automated tests in a clean managed environment. Why the correct answer wins: A registry stores the versioned image the service pulls.
- **B:** Incorrect for this question. ECS schedules the container on managed cluster capacity. Why the correct answer wins: A registry stores the versioned image the service pulls.
- **C:** Incorrect for this question. A custom image is needed only when the managed framework images cannot carry the dependencies. Why the correct answer wins: A registry stores the versioned image the service pulls.
- **D:** Correct. ECR holds the versioned image that the training or hosting service pulls. In this case: A registry stores the versioned image the service pulls.

### Question 42 — D

Answer: Scale on GPU utilisation rather than invocation count. Accelerator utilisation reflects the real bottleneck. GPU utilisation reflects the real bottleneck when each request is expensive. Local study-map skill 3.6 (Autoscaling and Concurrency), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. Target tracking holds a metric such as invocations per instance near a chosen value. Why the correct answer wins: Accelerator utilisation reflects the real bottleneck.
- **B:** Incorrect for this question. Step scaling adds capacity in bands as the alarm breaches, which suits sharp bursts. Why the correct answer wins: Accelerator utilisation reflects the real bottleneck.
- **C:** Incorrect for this question. A scale-to-zero policy removes the idle cost when nothing calls the endpoint. Why the correct answer wins: Accelerator utilisation reflects the real bottleneck.
- **D:** Correct. GPU utilisation reflects the real bottleneck when each request is expensive. In this case: Accelerator utilisation reflects the real bottleneck.

### Question 43 — B, C

Answers: Auto scale the endpoint on a target-tracking policy; Keep provisioned concurrency ready for the burst window. Target tracking follows the smooth rise, and warm capacity avoids the cold start. Target tracking holds a metric such as invocations per instance near a chosen value. Provisioned concurrency pre-warms capacity so the burst does not meet a cold start. Local study-map skill 3.6 (Autoscaling and Concurrency), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. Step scaling adds capacity in bands as the alarm breaches, which suits sharp bursts. Why the correct answer wins: Target tracking follows the smooth rise, and warm capacity avoids the cold start.
- **B:** Correct. Provisioned concurrency pre-warms capacity so the burst does not meet a cold start. In this case: Target tracking follows the smooth rise, and warm capacity avoids the cold start.
- **C:** Correct. Target tracking holds a metric such as invocations per instance near a chosen value. In this case: Target tracking follows the smooth rise, and warm capacity avoids the cold start.
- **D:** Incorrect for this question. A warm pool removes the provisioning delay between consecutive training jobs. Why the correct answer wins: Target tracking follows the smooth rise, and warm capacity avoids the cold start.
- **E:** Incorrect for this question. A scale-to-zero policy removes the idle cost when nothing calls the endpoint. Why the correct answer wins: Target tracking follows the smooth rise, and warm capacity avoids the cold start.

### Question 44 — B

Answer: Create an interface VPC endpoint for the service. A private endpoint keeps the traffic inside the VPC. Local study-map skill 3.7 (VPC Networking for Endpoints), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. An open ingress rule exposes the model to anything that can reach the VPC. Why the correct answer wins: A private endpoint keeps the traffic inside the VPC.
- **B:** Correct. In this case: A private endpoint keeps the traffic inside the VPC.
- **C:** Incorrect for this question. Private subnets remove the inbound internet path to the model hosts. Why the correct answer wins: A private endpoint keeps the traffic inside the VPC.
- **D:** Incorrect for this question. A NAT gateway gives private hosts outbound access without accepting inbound traffic. Why the correct answer wins: A private endpoint keeps the traffic inside the VPC.

### Question 45 — B, D

Answers: Build and test the model image with AWS CodeBuild; Orchestrate the release with AWS CodePipeline. A build service runs the build and tests, and a pipeline sequences the stages. CodeBuild runs the build and the automated tests in a clean managed environment. CodePipeline sequences the build, test and deploy stages and records each outcome. Local study-map skill 3.8 (CI/CD Pipelines), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. CodeConnections lets the pipeline read a repository hosted elsewhere. Why the correct answer wins: A build service runs the build and tests, and a pipeline sequences the stages.
- **B:** Correct. CodeBuild runs the build and the automated tests in a clean managed environment. In this case: A build service runs the build and tests, and a pipeline sequences the stages.
- **C:** Incorrect for this question. CodeDeploy performs the traffic shift and can roll back on an alarm. Why the correct answer wins: A build service runs the build and tests, and a pipeline sequences the stages.
- **D:** Correct. CodePipeline sequences the build, test and deploy stages and records each outcome. In this case: A build service runs the build and tests, and a pipeline sequences the stages.
- **E:** Incorrect for this question. CodeCommit is the managed Git repository the pipeline reads from. Why the correct answer wins: A build service runs the build and tests, and a pipeline sequences the stages.

### Question 46 — D

Answer: Fail the pipeline when the evaluation threshold is missed. A quality gate blocks a model that misses the bar. A quality gate blocks a release whose measured metric is below the agreed bar. Local study-map skill 3.8 (CI/CD Pipelines), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. CodeDeploy performs the traffic shift and can roll back on an alarm. Why the correct answer wins: A quality gate blocks a model that misses the bar.
- **B:** Incorrect for this question. CodePipeline sequences the build, test and deploy stages and records each outcome. Why the correct answer wins: A quality gate blocks a model that misses the bar.
- **C:** Incorrect for this question. CodeBuild runs the build and the automated tests in a clean managed environment. Why the correct answer wins: A quality gate blocks a model that misses the bar.
- **D:** Correct. A quality gate blocks a release whose measured metric is below the agreed bar. In this case: A quality gate blocks a model that misses the bar.

### Question 47 — D

Answer: Store the prompt templates in Amazon Bedrock Prompt Management. Prompt management versions templates so each change is reversible. Local study-map skill 3.9 (Model Registry and Versioning), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. The registry holds model versions and their approval status for deployment. Why the correct answer wins: Prompt management versions templates so each change is reversible.
- **B:** Incorrect for this question. Run logging keeps parameters, metrics and artefacts comparable across experiments. Why the correct answer wins: Prompt management versions templates so each change is reversible.
- **C:** Incorrect for this question. CodeCommit is the managed Git repository the pipeline reads from. Why the correct answer wins: Prompt management versions templates so each change is reversible.
- **D:** Correct. In this case: Prompt management versions templates so each change is reversible.

### Question 48 — D

Answer: Send a small share of traffic to the new version first. A canary limits exposure to the share it serves. A canary release limits the blast radius of a bad model to the canary share. Local study-map skill 3.10 (Deployment Strategy and Rollback), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. Mirroring collects comparison data with no user impact. Why the correct answer wins: A canary limits exposure to the share it serves.
- **B:** Incorrect for this question. Blue/green keeps the previous version ready for an immediate switch back. Why the correct answer wins: A canary limits exposure to the share it serves.
- **C:** Incorrect for this question. A single switch gives a bad model the whole traffic share at once. Why the correct answer wins: A canary limits exposure to the share it serves.
- **D:** Correct. A canary release limits the blast radius of a bad model to the canary share. In this case: A canary limits exposure to the share it serves.

### Question 49 — A, D

Answers: Mirror traffic to the new model without serving its answers; Stand the new version beside the old and switch traffic. Mirrored traffic collects the comparison, and blue/green keeps the old version ready. Mirroring collects comparison data with no user impact. Blue/green keeps the previous version ready for an immediate switch back. Local study-map skill 3.10 (Deployment Strategy and Rollback), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Correct. Mirroring collects comparison data with no user impact. In this case: Mirrored traffic collects the comparison, and blue/green keeps the old version ready.
- **B:** Incorrect for this question. A single switch gives a bad model the whole traffic share at once. Why the correct answer wins: Mirrored traffic collects the comparison, and blue/green keeps the old version ready.
- **C:** Incorrect for this question. A canary release limits the blast radius of a bad model to the canary share. Why the correct answer wins: Mirrored traffic collects the comparison, and blue/green keeps the old version ready.
- **D:** Correct. Blue/green keeps the previous version ready for an immediate switch back. In this case: Mirrored traffic collects the comparison, and blue/green keeps the old version ready.
- **E:** Incorrect for this question. A linear shift moves traffic gradually while the metrics are watched. Why the correct answer wins: Mirrored traffic collects the comparison, and blue/green keeps the old version ready.

### Question 50 — D

Answer: Define the workflow as a SageMaker pipeline. A SageMaker pipeline expresses those steps as one managed graph. A SageMaker pipeline expresses the processing, training and registration steps as one DAG. Local study-map skill 3.11 (Orchestration and Retraining), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 3 (deployment and orchestration of ML and AI workflows, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain3.html.

- **A:** Incorrect for this question. A schedule starts the pipeline on a fixed cadence without an external cron host. Why the correct answer wins: A SageMaker pipeline expresses those steps as one managed graph.
- **B:** Incorrect for this question. Step Functions coordinates long-running steps and service calls with retries and branching. Why the correct answer wins: A SageMaker pipeline expresses those steps as one managed graph.
- **C:** Incorrect for this question. CodePipeline sequences the build, test and deploy stages and records each outcome. Why the correct answer wins: A SageMaker pipeline expresses those steps as one managed graph.
- **D:** Correct. A SageMaker pipeline expresses the processing, training and registration steps as one DAG. In this case: A SageMaker pipeline expresses those steps as one managed graph.

### Question 51 — C

Answer: Enable a model quality monitor with ground-truth labels. A quality monitor scores predictions once the labels arrive. Local study-map skill 4.1 (Drift and Model Monitoring), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Incorrect for this question. A data drift monitor compares the live request distribution against the training baseline. Why the correct answer wins: A quality monitor scores predictions once the labels arrive.
- **B:** Incorrect for this question. Attribution drift shows that the model now relies on different features than it did. Why the correct answer wins: A quality monitor scores predictions once the labels arrive.
- **C:** Correct. In this case: A quality monitor scores predictions once the labels arrive.
- **D:** Incorrect for this question. A bias monitor watches whether the outcome distribution shifts for a protected group. Why the correct answer wins: A quality monitor scores predictions once the labels arrive.

### Question 52 — C, E

Answers: Enable a data drift monitor on the endpoint; Enable a bias drift monitor. A data drift monitor catches the changed fields, and a bias monitor watches the cohort. A data drift monitor compares the live request distribution against the training baseline. A bias monitor watches whether the outcome distribution shifts for a protected group. Local study-map skill 4.1 (Drift and Model Monitoring), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Incorrect for this question. Attribution drift shows that the model now relies on different features than it did. Why the correct answer wins: A data drift monitor catches the changed fields, and a bias monitor watches the cohort.
- **B:** Incorrect for this question. A quality monitor scores live predictions once the true labels arrive. Why the correct answer wins: A data drift monitor catches the changed fields, and a bias monitor watches the cohort.
- **C:** Correct. A data drift monitor compares the live request distribution against the training baseline. In this case: A data drift monitor catches the changed fields, and a bias monitor watches the cohort.
- **D:** Incorrect for this question. An alarm on the endpoint metrics pages someone when the service degrades. Why the correct answer wins: A data drift monitor catches the changed fields, and a bias monitor watches the cohort.
- **E:** Correct. A bias monitor watches whether the outcome distribution shifts for a protected group. In this case: A data drift monitor catches the changed fields, and a bias monitor watches the cohort.

### Question 53 — D

Answer: Query the inference logs with CloudWatch Logs Insights. Log querying aggregates and filters to expose the pattern. Logs Insights filters and aggregates the request logs to find the failing pattern. Local study-map skill 4.2 (Metrics and Dashboards), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Incorrect for this question. A dashboard puts the operating metrics in one view for the team. Why the correct answer wins: Log querying aggregates and filters to expose the pattern.
- **B:** Incorrect for this question. An alarm on the endpoint metrics pages someone when the service degrades. Why the correct answer wins: Log querying aggregates and filters to expose the pattern.
- **C:** Incorrect for this question. X-Ray shows where a request spends its time across the services it touches. Why the correct answer wins: Log querying aggregates and filters to expose the pattern.
- **D:** Correct. Logs Insights filters and aggregates the request logs to find the failing pattern. In this case: Log querying aggregates and filters to expose the pattern.

### Question 54 — C

Answer: Alarm on the CloudWatch latency and error metrics. An alarm on the error metric pages when the threshold is crossed. An alarm on the endpoint metrics pages someone when the service degrades. Local study-map skill 4.2 (Metrics and Dashboards), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Incorrect for this question. X-Ray shows where a request spends its time across the services it touches. Why the correct answer wins: An alarm on the error metric pages when the threshold is crossed.
- **B:** Incorrect for this question. Logs Insights filters and aggregates the request logs to find the failing pattern. Why the correct answer wins: An alarm on the error metric pages when the threshold is crossed.
- **C:** Correct. An alarm on the endpoint metrics pages someone when the service degrades. In this case: An alarm on the error metric pages when the threshold is crossed.
- **D:** Incorrect for this question. A dashboard puts the operating metrics in one view for the team. Why the correct answer wins: An alarm on the error metric pages when the threshold is crossed.

### Question 55 — A

Answer: Enable CloudWatch generative AI observability for the model calls. Generative AI observability records tokens, prompts and latency per call. Local study-map skill 4.3 (GenAI Observability), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Correct. In this case: Generative AI observability records tokens, prompts and latency per call.
- **B:** Incorrect for this question. An alarm on the endpoint metrics pages someone when the service degrades. Why the correct answer wins: Generative AI observability records tokens, prompts and latency per call.
- **C:** Incorrect for this question. X-Ray shows where a request spends its time across the services it touches. Why the correct answer wins: Generative AI observability records tokens, prompts and latency per call.
- **D:** Incorrect for this question. Agent tracing shows which tool call failed or stalled inside a multi-step task. Why the correct answer wins: Generative AI observability records tokens, prompts and latency per call.

### Question 56 — B

Answer: Break the spend down by endpoint with AWS Cost Explorer. Cost analysis grouped by service and tag attributes the change. Cost Explorer groups the bill by service and by tag so the expensive resource is visible. Local study-map skill 4.4 (Cost Optimisation and Purchasing), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Incorrect for this question. A Savings Plan discounts a predictable hourly spend on eligible compute. Why the correct answer wins: Cost analysis grouped by service and tag attributes the change.
- **B:** Correct. Cost Explorer groups the bill by service and by tag so the expensive resource is visible. In this case: Cost analysis grouped by service and tag attributes the change.
- **C:** Incorrect for this question. Matching the family to the measured workload avoids paying for capacity the model cannot use. Why the correct answer wins: Cost analysis grouped by service and tag attributes the change.
- **D:** Incorrect for this question. Batch scoring removes the idle endpoint that an always-on deployment would keep. Why the correct answer wins: Cost analysis grouped by service and tag attributes the change.

### Question 57 — C, D

Answers: Move the offline scoring to batch transform; Right-size the instance family against the measured latency. Batch scoring removes the idle endpoint, and right-sizing matches capacity. Batch scoring removes the idle endpoint that an always-on deployment would keep. Matching the family to the measured workload avoids paying for capacity the model cannot use. Local study-map skill 4.4 (Cost Optimisation and Purchasing), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Incorrect for this question. Sizing every request for the hardest case spends latency and money on easy requests. Why the correct answer wins: Batch scoring removes the idle endpoint, and right-sizing matches capacity.
- **B:** Incorrect for this question. A Savings Plan discounts a predictable hourly spend on eligible compute. Why the correct answer wins: Batch scoring removes the idle endpoint, and right-sizing matches capacity.
- **C:** Correct. Batch scoring removes the idle endpoint that an always-on deployment would keep. In this case: Batch scoring removes the idle endpoint, and right-sizing matches capacity.
- **D:** Correct. Matching the family to the measured workload avoids paying for capacity the model cannot use. In this case: Batch scoring removes the idle endpoint, and right-sizing matches capacity.
- **E:** Incorrect for this question. A scale-to-zero policy removes the idle cost when nothing calls the endpoint. Why the correct answer wins: Batch scoring removes the idle endpoint, and right-sizing matches capacity.

### Question 58 — B

Answer: Trim the retrieved context sent to the model. Sending fewer retrieved tokens lowers cost and latency per call. Local study-map skill 4.5 (Inference Cost and Token Usage), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Incorrect for this question. Routing easy requests to a cheaper model keeps the large model for hard cases. Why the correct answer wins: Sending fewer retrieved tokens lowers cost and latency per call.
- **B:** Correct. In this case: Sending fewer retrieved tokens lowers cost and latency per call.
- **C:** Incorrect for this question. Re-embedding an unchanged document is wasted spend on every refresh. Why the correct answer wins: Sending fewer retrieved tokens lowers cost and latency per call.
- **D:** Incorrect for this question. Output tokens dominate generation cost, so a cap bounds the spend per call. Why the correct answer wins: Sending fewer retrieved tokens lowers cost and latency per call.

### Question 59 — A

Answer: Route routine requests to a smaller model. Routing the trivial share to a smaller model leaves the large one for the hard cases. Routing easy requests to a cheaper model keeps the large model for hard cases. Local study-map skill 4.5 (Inference Cost and Token Usage), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Correct. Routing easy requests to a cheaper model keeps the large model for hard cases. In this case: Routing the trivial share to a smaller model leaves the large one for the hard cases.
- **B:** Incorrect for this question. Sending fewer retrieved tokens lowers both cost and latency on every call. Why the correct answer wins: Routing the trivial share to a smaller model leaves the large one for the hard cases.
- **C:** Incorrect for this question. Output tokens dominate generation cost, so a cap bounds the spend per call. Why the correct answer wins: Routing the trivial share to a smaller model leaves the large one for the hard cases.
- **D:** Incorrect for this question. Re-embedding an unchanged document is wasted spend on every refresh. Why the correct answer wins: Routing the trivial share to a smaller model leaves the large one for the hard cases.

### Question 60 — B, D

Answers: Deny access to the bucket unless the request comes through the VPC endpoint; Attach a policy scoped to the one bucket prefix. The endpoint condition blocks every other path, and the prefix policy scopes the job. A condition on the endpoint keeps the data off every path except the private one. Scoping to the prefix stops a compromised job from reaching the rest of the data lake. Local study-map skill 4.6 (IAM and Credentials), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Incorrect for this question. A group policy keeps the shared permission set in one reviewable place. Why the correct answer wins: The endpoint condition blocks every other path, and the prefix policy scopes the job.
- **B:** Correct. Scoping to the prefix stops a compromised job from reaching the rest of the data lake. In this case: The endpoint condition blocks every other path, and the prefix policy scopes the job.
- **C:** Incorrect for this question. The root user cannot be limited by policy, so daily use magnifies any mistake. Why the correct answer wins: The endpoint condition blocks every other path, and the prefix policy scopes the job.
- **D:** Correct. A condition on the endpoint keeps the data off every path except the private one. In this case: The endpoint condition blocks every other path, and the prefix policy scopes the job.
- **E:** Incorrect for this question. A long-lived key keeps working after the project ends unless someone retires it. Why the correct answer wins: The endpoint condition blocks every other path, and the prefix policy scopes the job.

### Question 61 — B

Answer: Issue a Bedrock API key for the calling application. A scoped API key avoids embedding long-lived credentials. An API key gives short-lived programmatic access without embedding IAM credentials. Local study-map skill 4.6 (IAM and Credentials), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Incorrect for this question. The root user cannot be limited by policy, so daily use magnifies any mistake. Why the correct answer wins: A scoped API key avoids embedding long-lived credentials.
- **B:** Correct. An API key gives short-lived programmatic access without embedding IAM credentials. In this case: A scoped API key avoids embedding long-lived credentials.
- **C:** Incorrect for this question. A long-lived key keeps working after the project ends unless someone retires it. Why the correct answer wins: A scoped API key avoids embedding long-lived credentials.
- **D:** Incorrect for this question. A group policy keeps the shared permission set in one reviewable place. Why the correct answer wins: A scoped API key avoids embedding long-lived credentials.

### Question 62 — D

Answer: Restrict the security group to the application subnet. Scoping the group to the caller subnet admits only the intended traffic. Local study-map skill 4.7 (Network Isolation), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Incorrect for this question. A private endpoint keeps the service traffic inside the VPC without a NAT gateway. Why the correct answer wins: Scoping the group to the caller subnet admits only the intended traffic.
- **B:** Incorrect for this question. An open ingress rule exposes the model to anything that can reach the VPC. Why the correct answer wins: Scoping the group to the caller subnet admits only the intended traffic.
- **C:** Incorrect for this question. Private subnets remove the inbound internet path to the model hosts. Why the correct answer wins: Scoping the group to the caller subnet admits only the intended traffic.
- **D:** Correct. In this case: Scoping the group to the caller subnet admits only the intended traffic.

### Question 63 — A

Answer: Encrypt the artefacts with a customer managed KMS key. A customer managed key lets the studio disable access itself. A customer managed key lets the team control the key policy and revoke access. Local study-map skill 4.8 (Encryption and Secrets), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Correct. A customer managed key lets the team control the key policy and revoke access. In this case: A customer managed key lets the studio disable access itself.
- **B:** Incorrect for this question. Secrets Manager holds the credential centrally and can rotate it. Why the correct answer wins: A customer managed key lets the studio disable access itself.
- **C:** Incorrect for this question. Config records how each resource was configured and evaluates it against rules. Why the correct answer wins: A customer managed key lets the studio disable access itself.
- **D:** Incorrect for this question. Guardrails filters denied topics, sensitive data and unsafe content in the response path. Why the correct answer wins: A customer managed key lets the studio disable access itself.

### Question 64 — C

Answer: Apply Amazon Bedrock Guardrails to the model responses. Guardrails covers denied topics and sensitive data in the response path. Local study-map skill 4.9 (Guardrails and Responsible AI), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Incorrect for this question. A denied-topics policy refuses the subject areas the business has ruled out. Why the correct answer wins: Guardrails covers denied topics and sensitive data in the response path.
- **B:** Incorrect for this question. Safety screening keeps prohibited material out of the model weights. Why the correct answer wins: Guardrails covers denied topics and sensitive data in the response path.
- **C:** Correct. In this case: Guardrails covers denied topics and sensitive data in the response path.
- **D:** Incorrect for this question. Redaction at the boundary keeps personal data out of the model request entirely. Why the correct answer wins: Guardrails covers denied topics and sensitive data in the response path.

### Question 65 — B

Answer: Track resource configuration with AWS Config. Configuration history records each resource's settings over time. Config records how each resource was configured and evaluates it against rules. Local study-map skill 4.10 (Audit and Vulnerability Scanning), mapped to the official guide: AWS Certified Machine Learning Engineer – Associate (MLA-C02) exam guide. Primary reference: MLA-C02 exam guide, content domain 4 (operating, monitoring, and securing ML and AI solutions, 24 percent): https://docs.aws.amazon.com/aws-certification/latest/machine-learning-engineer-associate-02/machine-learning-engineer-associate-02-domain4.html.

- **A:** Incorrect for this question. Inspector reports known vulnerabilities in the image before it is deployed. Why the correct answer wins: Configuration history records each resource's settings over time.
- **B:** Correct. Config records how each resource was configured and evaluates it against rules. In this case: Configuration history records each resource's settings over time.
- **C:** Incorrect for this question. Logs Insights filters and aggregates the request logs to find the failing pattern. Why the correct answer wins: Configuration history records each resource's settings over time.
- **D:** Incorrect for this question. CloudTrail records who called which API, when and from where. Why the correct answer wins: Configuration history records each resource's settings over time.
