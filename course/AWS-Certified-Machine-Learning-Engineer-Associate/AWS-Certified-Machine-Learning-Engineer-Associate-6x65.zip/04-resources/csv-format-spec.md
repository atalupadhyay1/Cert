# CSV format specification

## File shape

- Four official domains: data preparation for ML and AI; ML model and foundation-model development; deployment and orchestration of ML and AI workflows; operating, monitoring, and securing ML and AI solutions.
- One file per mock exam: `practice-set-1.csv` through `practice-set-6.csv`. There is no case-embedded variant, because this exam has no case studies.
- UTF-8 with BOM, LF line endings, comma-delimited, 17 columns, 65 data rows.
- Header order is fixed and validated; reordering is rejected.

## Columns

| # | Column | Content |
|---:|---|---|
| 1 | Question | Question stem; ends in a question mark, or in "Select two." for a multiple-response item |
| 2 | Question Type | `multiple-choice` or `multi-select` only (Udemy importer constraint) |
| 3–4 | Answer Option 1 / Explanation 1 | First populated option and its explanation |
| 5–6 | Answer Option 2 / Explanation 2 | Second populated option and its explanation |
| 7–8 | Answer Option 3 / Explanation 3 | Third populated option and its explanation |
| 9–10 | Answer Option 4 / Explanation 4 | Fourth populated option and its explanation |
| 11–12 | Answer Option 5 / Explanation 5 | Fifth option for multiple-response items; blank otherwise |
| 13–14 | Answer Option 6 / Explanation 6 | Reserved; blank in this package |
| 15 | Correct Answers | One index (`1`–`4`) or a comma-separated pair (`1,5`) |
| 16 | Overall Explanation | Answer label, rationale, option meanings, exam-guide reference, local skill, primary reference |
| 17 | Domain | Exact official domain label |

The exported header has **17 columns** because the six option/explanation pairs count as twelve fields. Validate against generated files rather than editing the header by hand.

## Item-type rules enforced

| Type | Options | Correct Answers | Extra rule |
|---|---:|---|---|
| `multiple-choice` | 4 | exactly one index, `1`–`4` | balanced across the four slots per exam |
| `multi-select` | 5 | exactly two comma-separated indices | stem must contain "Select two" matching the key |

No other item type exists in this package. AWS publishes both item types and no split between them, so the 50 / 15 mix per exam is an authoring choice.

## Content rules enforced

- Four or five contiguous non-empty options; no gaps and no sixth option.
- No duplicate option text inside an item.
- Every populated option has an explanation; an option without one fails validation.
- The stem ends in `?` or in `Select two.`, and a multiple-response stem must state the selection count.
- The overall explanation must cite the exam guide (`sources.GUIDE`) and the domain reference.
- No stem or explanation may contain the phrase `case study`; `build.py`, `validate.py`, and `package.py` each reject it.
- No stem or explanation may become a console recipe: the test suite rejects `click`, `navigate to`, and `in the console, select`. Items describe a requirement and a choice, never a click path.
- No arrow character may appear in an option; this exam publishes no sequencing item type.
- Stems must be unique across all 390 items, and no pair of stems may exceed 0.72 token overlap on content words.

## Authoring source

Items are authored in `04-resources/questions/1.txt` … `6.txt`, one row per item, pipe-delimited:

```text
skill|kind|answer keys|distractor keys|stem|reason
```

`S` is one answer plus three distractors; `M2` is two answers plus three distractors and requires "Select two." in the stem. Option text lives in `terms.py` and is never written into the CSV by hand, so a label change propagates to every set on the next build. Every option is an AWS service, a named modelling decision or an operational practice, so an item can ask which one fits a stated requirement rather than what a term means.

## Regenerating

```bash
cd course/AWS-Certified-Machine-Learning-Engineer-Associate/04-resources
python3 build.py                                      # writes the six CSVs, review copies, manifest
python3 make_sample.py                                # rebuilds the 12-item sample
python3 validate.py --report validation-report.json   # rewrites the validation report
```

Do not hand-edit a generated CSV. Edit the authored row, then rebuild; the tests compare each CSV against the builder output and fail on drift.
