# Full-Length Mock Exam 1: VPC Design, IP Planning, and Load Balancer Choice

100 original items · passing score not published by Google · blueprint-weighted.

| Official domain | Weight | Questions |
|---|---:|---:|
| Designing and Planning a Google Cloud VPC Network | ~21% | 21 |
| Implementing a VPC Network | ~20% | 20 |
| Configuring Managed Network Services | ~16% | 16 |
| Configuring and Implementing Hybrid and Multicloud Interconnectivity | ~16% | 16 |
| Managing, Monitoring, and Troubleshooting Network Operations | ~14% | 14 |
| Configuring, Implementing, and Managing a Cloud Network Security Solution | ~13% | 13 |

Item mix: 84 multiple-choice, 16 multi-select. Google publishes a 50-60 question range of multiple-choice and multiple-select items; this set is 100 items, an expanded bank for broader coverage. The live exam has no case-study component, so none is imitated here.

The live exam allows two hours, so at 50-60 items it gives roughly 120-144 seconds per item. This 100-item set gives about 72 seconds per item in the same two hours, so the bank runs slower than the live paper and is a comfortable rehearsal rather than a speed test.

Upload `practice-set-1.csv`; use `practice-set-1.md` for offline review.

Google does not publish a passing score, so no target percentage is stated here and a practice percentage is not a scaled score.
