# Google Cloud Professional Cloud Network Engineer — Full-Length Mock Exam 6

Professional Cloud Network Engineer · 100 questions · expanded practice bank · passing score not published

Blueprint-weighted mock exam. Item mix: 84 multiple-choice and 16 multiple-select items (the selection count is stated in each multi-select stem). The live exam publishes 50-60 multiple-choice and multiple-select questions and has no case-study component, so this set is larger on purpose and no case-study item is reproduced. The live paper allows two hours for 50-60 items, so this 100-item set is a slower-per-item rehearsal: about 72 seconds per item here against roughly 120-144 seconds live. Use it to build a habit of finishing with time to review. See the README for the exact fidelity boundary.

Original educational content, not actual, recalled, or copied Google exam items.

## Questions

---

## Domain 1 — Designing and Planning a Google Cloud VPC Network (VPC Design, IP Planning, and Load Balancer Choice)

### 1. An insurer's quote engine serves four continents from one region and the sales team measures page load. What should the front end use?

- A. Use the Standard network service tier
- B. Use the Premium network service tier
- C. Deploy a regional external Application Load Balancer
- D. Enable Cloud CDN on the backend service

### 2. A council's rates portal is read only inside its own state and the budget is fixed. What should the front end use?

- A. Use the Premium network service tier
- B. Use an external proxy Network Load Balancer with TLS termination
- C. Use the Standard network service tier
- D. Assign a manual static Cloud NAT address

### 3. An outage lasted twenty minutes because a broken pool kept receiving traffic until someone deleted it. What would have prevented that?

- A. Switch the balancing mode to connections per instance
- B. Enable session affinity on the backend service
- C. Enable connection draining with a timeout
- D. Attach a health check to the backend service

### 4. A streaming service needs one address across two continents, and a continent must be emptied without cutting viewers. Which two components fit? Select two.

- A. Deploy an internal passthrough Network Load Balancer
- B. Enable session affinity on the backend service
- C. Deploy a regional external Application Load Balancer
- D. Deploy a global external Application Load Balancer
- E. Enable connection draining with a timeout

### 5. A manufacturer's datacentre resolvers are to query names that live only in Cloud DNS. What must be published for them?

- A. Create a DNS peering zone to the other project
- B. Serve split-horizon answers from separate private and public zones
- C. Create an inbound forwarding policy with a forwarding address
- D. Configure a DNS forwarding policy for the on-premises domain

### 6. A logistics firm's workloads must resolve a domain that is authoritative on its own datacentre resolvers. What should be configured?

- A. Configure a DNS forwarding policy for the on-premises domain
- B. Create a DNS peering zone to the other project
- C. Enable DNSSEC on the zone
- D. Create an inbound forwarding policy with a forwarding address

### 7. An HR system must be callable from other workloads in the same network and from nowhere else. Which front end fits?

- A. Deploy an internal passthrough Network Load Balancer
- B. Use a proxy Network Load Balancer
- C. Use a passthrough Network Load Balancer
- D. Deploy a global external Application Load Balancer

### 8. A microservice speaks gRPC and needs per-request balancing with TLS ended in front. Which shape fits?

- A. Use a passthrough Network Load Balancer
- B. Deploy an internal passthrough Network Load Balancer
- C. Use a proxy Network Load Balancer
- D. Route by URL path in the URL map

### 9. A cluster design review asks where pod addresses will come from if the node subnet is already tight. What answers that?

- A. Add a second pod range to the cluster
- B. Expand the existing subnet range
- C. Create a GKE network policy for the namespace
- D. Plan secondary ranges for pods and services

### 10. A public control plane endpoint must be reachable from the office and the CI system and nowhere else. What should be configured?

- A. Use a private control plane endpoint
- B. Add the office range to the authorised networks
- C. Use the DNS-based control plane endpoint
- D. Use private nodes with no external addresses

### 11. A public-sector cluster must hold no externally addressed node, and pod addresses must be separable from node addresses. Which two settings fit? Select two.

- A. Add the office range to the authorised networks
- B. Use private nodes with no external addresses
- C. Configure an IP masquerade policy on the node pool
- D. Add a second pod range to the cluster
- E. Plan secondary ranges for pods and services

### 12. A bank's network team must hold exclusive rights to create and change networks and subnets. Which role fits?

- A. Grant the subnet user role on the specific shared subnets
- B. Grant the basic editor role to the automation
- C. Create a custom role with only the required network permissions
- D. Grant the network administrator role in the host project

### 13. A compliance review wants one identity that only reads firewall policy and another that only uses a single shared subnet. Which two grants fit? Select two.

- A. Grant Shared VPC Admin on the host project
- B. Grant the subnet user role on the specific shared subnets
- C. Create a custom role with only the required network permissions
- D. Grant the basic editor role to the automation
- E. Grant the network administrator role in the host project

### 14. A managed message broker must be created with an internal address inside the company network. What must be reserved first?

- A. Enable Private Google Access on the subnet
- B. Attach the service to Serverless VPC Access
- C. Allocate a private services access range
- D. Create a Private Service Connect endpoint

### 15. A media group must consume an agency's published service privately and let a serverless worker reach an internal API. Which two mechanisms fit? Select two.

- A. Reach the API through its public interface
- B. Attach the service to Serverless VPC Access
- C. Enable Private Google Access on the subnet
- D. Create a Private Service Connect endpoint
- E. Allocate a private services access range

### 16. A retailer's store networks must reach the central network and must never reach one another. What topology fits?

- A. Build the network as a Shared VPC with host and service projects
- B. Peer every VPC network with every other VPC network
- C. Connect the networks as a hub-and-spoke peering topology
- D. Connect the VPC networks through a Network Connectivity Center hub

### 17. Four laboratory networks of equal standing must all reach each other with no central network. What topology fits?

- A. Connect the networks as a hub-and-spoke peering topology
- B. Connect the VPC networks through a Network Connectivity Center hub
- C. Create a VPC Network Peering connection between the two networks
- D. Peer every VPC network with every other VPC network

### 18. An acquisition brought two plants that both use 172.16.0.0/12 and neither will renumber. What fits?

- A. Use non-RFC 1918 space for the internal network
- B. Accept the overlapping subnet ranges as configured
- C. Deploy Private NAT for the overlapping ranges
- D. Use privately used public IP address ranges

### 19. A telco's public prefixes are already advertised elsewhere and must now be served from Google Cloud. What fits?

- A. Bring your own public IP prefixes
- B. Automate address allocation from a central IPAM plan
- C. Use non-RFC 1918 space for the internal network
- D. Use privately used public IP address ranges

### 20. A nightly copy works between zones and stalls at a predictable point once it crosses a tunnel, with no error logged. What is wrong?

- A. Raise the VPC MTU to 8896 bytes
- B. Lower the tunnel MTU to 1460 bytes
- C. Keep the default 1500-byte MTU
- D. Leave the MTU mismatch unfixed

### 21. A defence programme must inspect traffic between two enclaves that refuse to be peered. What should be deployed?

- A. Add a policy-based route that matches the source and destination
- B. Use the internal load balancer as the next hop
- C. Deploy a multi-NIC appliance VM between the two networks
- D. Create a static route with a tag-scoped next hop

---

## Domain 2 — Implementing a VPC Network (VPC Implementation, Routing, and GKE Networking)

### 22. A subnet is full and its instances must keep running through the fix. What should be done?

- A. Use privately used public IP address ranges
- B. Enable dual-stack IPv6 on the subnet
- C. Accept the overlapping subnet ranges as configured
- D. Expand the existing subnet range

### 23. A freight operator is out of IPv4 space on a subnet it cannot recreate, and its new tracking service needs IPv6 too. Which two changes fix both? Select two.

- A. Bring your own public IP prefixes
- B. Expand the existing subnet range
- C. Use privately used public IP address ranges
- D. Accept the overlapping subnet ranges as configured
- E. Enable dual-stack IPv6 on the subnet

### 24. A vendor reaches its direct peer but never the peer's other partner, and the vendor blames routing. What is the actual cause?

- A. Assume peered networks can reach each other transitively
- B. Connect the VPC networks through a Network Connectivity Center hub
- C. Create a VPC Network Peering connection between the two networks
- D. Peer every VPC network with every other VPC network

### 25. An agency needs a direct path to exactly one supplier network and nothing more. What provides it?

- A. Create a VPC Network Peering connection between the two networks
- B. Connect the VPC networks through a Network Connectivity Center hub
- C. Peer every VPC network with every other VPC network
- D. Build the network as a Shared VPC with host and service projects

### 26. A startup's first deployment into a shared subnet is refused for lack of permission. What should be granted?

- A. Grant Shared VPC Admin on the host project
- B. Grant the basic editor role to the automation
- C. Grant the network administrator role in the host project
- D. Grant the subnet user role on the specific shared subnets

### 27. A conglomerate wants one address plan across its divisions, each confined to its own subnet. Which two choices fit? Select two.

- A. Grant the basic editor role to the automation
- B. Grant the subnet user role on the specific shared subnets
- C. Build the network as a Shared VPC with host and service projects
- D. Grant the network administrator role in the host project
- E. Give each team its own standalone VPC network

### 28. A regulated fleet has no external addresses at all and still has to call Google APIs. What should be enabled?

- A. Attach the service to Serverless VPC Access
- B. Reach the API through its public interface
- C. Create a Private Service Connect endpoint
- D. Enable Private Google Access on the subnet

### 29. Clinical data must stay unreachable from any project the compliance group has not approved. Which control enforces that boundary?

- A. Enable Private Google Access on the subnet
- B. Enclose the project in a VPC Service Controls perimeter
- C. Create a hierarchical firewall policy at the organisation
- D. Review Firewall Insights for shadowed rules

### 30. A local static route must beat an imported route that carries the same prefix. What decides it?

- A. Set the Cloud Router ASN to a private value that differs from the peer
- B. Give the static route a lower priority number than the learned route
- C. Prefer the path with the lower multi-exit discriminator
- D. Enable Bidirectional Forwarding Detection with a short interval

### 31. A single hub router must serve workloads in three regions. What should be enabled?

- A. Keep the Cloud Router in regional dynamic routing mode
- B. Switch the Cloud Router to global dynamic routing mode
- C. Prefer the path with the lower multi-exit discriminator
- D. Advertise only the ranges the peer needs

### 32. Two circuits advertise equal prefixes, and the older selection order is choosing the wrong one. Which two settings decide the outcome? Select two.

- A. Give the static route a lower priority number than the learned route
- B. Set the Cloud Router ASN to a private value that differs from the peer
- C. Switch best path selection back to the legacy behaviour
- D. Enable Bidirectional Forwarding Detection with a short interval
- E. Prefer the path with the lower multi-exit discriminator

### 33. Only traffic to one regulatory body must pass through the inspection appliance. What fits?

- A. Use the internal load balancer as the next hop
- B. Create a static route with a tag-scoped next hop
- C. Add a policy-based route that matches the source and destination
- D. Deploy a multi-NIC appliance VM between the two networks

### 34. A pilot group of instances alone must use the inspection path, and nothing else may change. What should be created?

- A. Create a static route with a tag-scoped next hop
- B. Add a policy-based route that matches the source and destination
- C. Give the static route a lower priority number than the learned route
- D. Use the internal load balancer as the next hop

### 35. Appliance instances are recycled weekly and the route table must stay untouched. What should the next hop be?

- A. Add a policy-based route that matches the source and destination
- B. Create a static route with a tag-scoped next hop
- C. Use the internal load balancer as the next hop
- D. Deploy a multi-NIC appliance VM between the two networks

### 36. A newly built tunnel to a distribution centre must be published into the hub. Which spoke type fits?

- A. Add the published service as a producer spoke
- B. Add the attachment as a hybrid spoke
- C. Add the VPC network as a VPC spoke
- D. Apply a CIDR range filter to the spoke

### 37. A spoke must export only two of its blocks and keep the rest private. What should be applied?

- A. Expect spoke-to-spoke reachability through the hub
- B. Add the VPC network as a VPC spoke
- C. Add the attachment as a hybrid spoke
- D. Apply a CIDR range filter to the spoke

### 38. A cluster will not create another service address although pods keep scheduling. What should be resized?

- A. Add a second pod range to the cluster
- B. Plan secondary ranges for pods and services
- C. Resize the service range allocation
- D. Create a GKE network policy for the namespace

### 39. Compliance requires that only the reporting namespace may reach the analytics pods. What should be created?

- A. Create a GKE network policy for the namespace
- B. Enable GKE Dataplane V2
- C. Configure an IP masquerade policy on the node pool
- D. Add a second pod range to the cluster

### 40. An external system rejects pod source addresses that it was never told to expect. What should be configured?

- A. Create a GKE network policy for the namespace
- B. Add a second pod range to the cluster
- C. Configure an IP masquerade policy on the node pool
- D. Enable GKE Dataplane V2

### 41. A cost review needs byte counts for traffic emerging from a subnet. What should be enabled?

- A. Enable VPC Flow Logs on the subnet
- B. Enable Cloud DNS query logging
- C. Enable firewall rules logging
- D. Enable Cloud NAT logging

---

## Domain 3 — Configuring Managed Network Services (Load Balancing, Cloud CDN, and Cloud DNS)

### 42. A pool must drop members that stop answering, and a stateful client must stay where its state lives. Which two settings fit? Select two.

- A. Enable session affinity on the backend service
- B. Enable connection draining with a timeout
- C. Register the backends as a zonal network endpoint group
- D. Attach a health check to the backend service
- E. Switch the balancing mode to connections per instance

### 43. Replacing a group of instances interrupted uploads that had already started. Which backend setting avoids that?

- A. Enable session affinity on the backend service
- B. Switch the balancing mode to connections per instance
- C. Autoscale a managed instance group behind the backend service
- D. Enable connection draining with a timeout

### 44. The instance group stayed at four members through a tenfold traffic rise. What should be configured?

- A. Autoscale a managed instance group behind the backend service
- B. Register the backends as a zonal network endpoint group
- C. Register the serverless service as a serverless network endpoint group
- D. Enable connection draining with a timeout

### 45. Paths beginning with one prefix must reach a separate service from the rest of the hostname. What should be configured?

- A. Rewrite the request path before it reaches the backend
- B. Route by URL path in the URL map
- C. Mirror a copy of the traffic to a second backend
- D. Split traffic between two backend services by weight

### 46. Five percent of live requests must be answered by the replacement service before launch. What should be configured?

- A. Rewrite the request path before it reaches the backend
- B. Split traffic between two backend services by weight
- C. Route by URL path in the URL map
- D. Mirror a copy of the traffic to a second backend

### 47. A serverless container service must be a backend for the public front end. How should it be registered?

- A. Register the third-party origins as an internet network endpoint group
- B. Register the serverless service as a serverless network endpoint group
- C. Autoscale a managed instance group behind the backend service
- D. Register the backends as a zonal network endpoint group

### 48. Individual pods must appear as backends with no instance group involved. What should be used?

- A. Register the backends as a zonal network endpoint group
- B. Register the third-party origins as an internet network endpoint group
- C. Register the serverless service as a serverless network endpoint group
- D. Autoscale a managed instance group behind the backend service

### 49. Several teams need one shared entry point with separate route-level controls. What fits?

- A. Expose the workload through the GKE Ingress controller
- B. Route by URL path in the URL map
- C. Expose the workload through the GKE Gateway controller
- D. Split traffic between two backend services by weight

### 50. A two-person squad wants a public endpoint created from one Kubernetes object, with nothing else to operate. What should the squad use?

- A. Expose the workload through the GKE Ingress controller
- B. Expose the workload through the GKE Gateway controller
- C. Route by URL path in the URL map
- D. Register the backends as a zonal network endpoint group

### 51. Assets must be served from the edge, and a corrected file must stop being served the moment it changes. Which two actions fit? Select two.

- A. Point Cloud CDN at the origins through an internet endpoint group
- B. Invalidate the cached object after the change
- C. Raise the cache time to live
- D. Serve the object through a signed URL
- E. Enable Cloud CDN on the backend service

### 52. Edge caching is in place, but the origin is still busy and the catalogue only changes nightly. What should be adjusted?

- A. Invalidate the cached object after the change
- B. Enable Cloud CDN on the backend service
- C. Raise the cache time to live
- D. Serve the object through a signed URL

### 53. A private zone must answer for a second project's network and must never be visible publicly. Which two settings fit? Select two.

- A. Migrate the zone with a staged import and a delegated test
- B. Bind the private zone to the service project networks
- C. Enable DNSSEC on the zone
- D. Create a public Cloud DNS zone
- E. Create a private Cloud DNS zone

### 54. An address change must propagate within minutes when the cutover happens. What should be done beforehand?

- A. Lower the record TTL before the cutover
- B. Enable DNSSEC on the zone
- C. Create a private Cloud DNS zone
- D. Migrate the zone with a staged import and a delegated test

### 55. Queries from each continent have to receive an address in that continent. Which routing policy does it?

- A. Lower the record TTL before the cutover
- B. Apply a geolocation routing policy to the record set
- C. Migrate the zone with a staged import and a delegated test
- D. Apply a failover routing policy with a health-checked primary

### 56. A secondary site should stay out of service unless the primary stops answering its check. Which policy behaves that way?

- A. Apply a failover routing policy with a health-checked primary
- B. Enable DNSSEC on the zone
- C. Apply a geolocation routing policy to the record set
- D. Lower the record TTL before the cutover

### 57. A resolver must be able to prove a public answer was not tampered with on the way. What should the zone use?

- A. Create a private Cloud DNS zone
- B. Enable DNSSEC on the zone
- C. Enable Cloud DNS query logging
- D. Migrate the zone with a staged import and a delegated test

---

## Domain 4 — Configuring and Implementing Hybrid and Multicloud Interconnectivity (Interconnect, VPN, and Cloud Router)

### 58. A broadcaster occupies its own cage in a Google facility and must carry one subnet to its router. Which two items fit? Select two.

- A. Order a Dedicated Interconnect connection
- B. Order a Partner Interconnect connection
- C. Enable MACsec on the interconnect
- D. Create a VLAN attachment on Cloud Router
- E. Order a Cross-Cloud Interconnect connection

### 59. A regional hospital needs a circuit quickly and a carrier already serves its estate. What fits?

- A. Order a Dedicated Interconnect connection
- B. Order a Cross-Cloud Interconnect connection
- C. Order a Partner Interconnect connection
- D. Deploy a Classic VPN with a single tunnel

### 60. A new attachment never leaves idle and both routers are numbered 64512. What must change?

- A. Prefer the path with the lower multi-exit discriminator
- B. Set the Cloud Router ASN to a private value that differs from the peer
- C. Create a VLAN attachment on Cloud Router
- D. Enable Bidirectional Forwarding Detection with a short interval

### 61. A migration must copy data to a second cloud over a private circuit. What fits?

- A. Order a Dedicated Interconnect connection
- B. Deploy an HA VPN gateway with two interfaces
- C. Order a Partner Interconnect connection
- D. Order a Cross-Cloud Interconnect connection

### 62. A regulator demands link-layer encryption on the circuit and the optics support it. What should be enabled?

- A. Enable MACsec on the interconnect
- B. Run HA VPN over Cloud Interconnect instead of MACsec
- C. Deploy an HA VPN gateway with two interfaces
- D. Create a VLAN attachment on Cloud Router

### 63. A remote plant needs tunnels that survive a gateway zone loss, and its bulk replication must fit the encapsulated path. Which two settings fit? Select two.

- A. Enable Bidirectional Forwarding Detection with a short interval
- B. Lower the tunnel MTU to 1460 bytes
- C. Create a VLAN attachment on Cloud Router
- D. Deploy an HA VPN gateway with two interfaces
- E. Deploy a Classic VPN with a single tunnel

### 64. Surviving the loss of a single gateway zone is mandatory for a remote office. Which deployment satisfies that?

- A. Order a Dedicated Interconnect connection
- B. Create a VLAN attachment on Cloud Router
- C. Deploy an HA VPN gateway with two interfaces
- D. Deploy a Classic VPN with a single tunnel

### 65. The only path to a site is one tunnel, and the agreement now demands redundant paths. What should the team deploy?

- A. Deploy an HA VPN gateway with two interfaces
- B. Set the Cloud Router ASN to a private value that differs from the peer
- C. Deploy a Classic VPN with a single tunnel
- D. Order a Dedicated Interconnect connection

### 66. A legacy device supports only policy-based tunnels and has no BGP implementation. Which VPN fits?

- A. Deploy an HA VPN gateway with two interfaces
- B. Deploy a Classic VPN with a single tunnel
- C. Order a Dedicated Interconnect connection
- D. Set the Cloud Router ASN to a private value that differs from the peer

### 67. A path dies silently and traffic keeps using it until the hold timer expires. What should be enabled?

- A. Prefer the path with the lower multi-exit discriminator
- B. Set the Cloud Router ASN to a private value that differs from the peer
- C. Switch best path selection back to the legacy behaviour
- D. Enable Bidirectional Forwarding Detection with a short interval

### 68. The carrier should receive two aggregate blocks, not the full subnet list. Which router setting does that?

- A. Give the static route a lower priority number than the learned route
- B. Prefer the path with the lower multi-exit discriminator
- C. Advertise only the ranges the peer needs
- D. Set the Cloud Router ASN to a private value that differs from the peer

### 69. A session refuses to establish, and the carrier may only be told about two summaries. Which two settings fit? Select two.

- A. Switch best path selection back to the legacy behaviour
- B. Set the Cloud Router ASN to a private value that differs from the peer
- C. Prefer the path with the lower multi-exit discriminator
- D. Advertise only the ranges the peer needs
- E. Enable Bidirectional Forwarding Detection with a short interval

### 70. A microwave hop degrades without dropping and BGP still believes it is healthy. What should be enabled?

- A. Give the static route a lower priority number than the learned route
- B. Prefer the path with the lower multi-exit discriminator
- C. Set the Cloud Router ASN to a private value that differs from the peer
- D. Enable Bidirectional Forwarding Detection with a short interval

### 71. An upgrade changed the preferred path with no change to any advertisement. What should be reviewed?

- A. Switch best path selection back to the legacy behaviour
- B. Prefer the path with the lower multi-exit discriminator
- C. Set the Cloud Router ASN to a private value that differs from the peer
- D. Give the static route a lower priority number than the learned route

### 72. A prefix learned in Europe has to be usable by workloads running in Asia. What should be turned on?

- A. Prefer the path with the lower multi-exit discriminator
- B. Keep the Cloud Router in regional dynamic routing mode
- C. Give the static route a lower priority number than the learned route
- D. Switch the Cloud Router to global dynamic routing mode

### 73. Link-layer encryption is unavailable on the chosen optics, but encryption on the circuit is still required. What should carry the traffic?

- A. Deploy an HA VPN gateway with two interfaces
- B. Run HA VPN over Cloud Interconnect instead of MACsec
- C. Create a VLAN attachment on Cloud Router
- D. Enable MACsec on the interconnect

---

## Domain 5 — Managing, Monitoring, and Troubleshooting Network Operations (Observability, Troubleshooting, and Traffic Movement)

### 74. Auditors need to know which rule accepted or rejected each connection. Which logging should be turned on?

- A. Enable Cloud NAT logging
- B. Enable VPC Flow Logs on the subnet
- C. Enable firewall rules logging
- D. Enable Cloud DNS query logging

### 75. A name lookup failed and the support team needs to know which client made it. What should be recorded?

- A. Enable Cloud DNS query logging
- B. Enable VPC Flow Logs on the subnet
- C. Enable firewall rules logging
- D. Enable Cloud NAT logging

### 76. An appliance exposes a session count that no managed metric includes. What should the team publish?

- A. Create a log-based metric from the firewall log entries
- B. Create an alert policy on the network metric
- C. Alert on the error budget of the service objective
- D. Publish a custom metric from the appliance

### 77. Alerts keep firing on link errors that no user ever experienced. What should the alerting follow instead?

- A. Create a log-based metric from the firewall log entries
- B. Create an alert policy on the network metric
- C. Publish a custom metric from the appliance
- D. Alert on the error budget of the service objective

### 78. Two engineers disagree about whether a rule blocks a flow. What settles it?

- A. Query Flow Analyzer for the top talkers
- B. Check the Performance Dashboard for packet loss
- C. Inspect the flow in Network Topology
- D. Run a Connectivity Test between the two endpoints

### 79. A blocked flow must be attributed both to a rule and to a recorded decision. Which two tools fit? Select two.

- A. Query Flow Analyzer for the top talkers
- B. Check the Performance Dashboard for packet loss
- C. Run a Connectivity Test between the two endpoints
- D. Enable firewall rules logging
- E. Inspect the flow in Network Topology

### 80. The business wants to know whether delay happens on Google's side or beyond it. Which view answers that?

- A. Inspect the flow in Network Topology
- B. Query Flow Analyzer for the top talkers
- C. Check the Performance Dashboard for packet loss
- D. Test the path with a large ping and the do-not-fragment bit

### 81. A path passes small packets and drops large ones silently. What should be tested?

- A. Test the path with a large ping and the do-not-fragment bit
- B. Check the Performance Dashboard for packet loss
- C. Leave the MTU mismatch unfixed
- D. Inspect the flow in Network Topology

### 82. Capacity and routing both need review: the subnet is close to full and one route looks wrong. Which tool covers both?

- A. Review Firewall Insights for shadowed rules
- B. Read the Network Analyzer findings
- C. Run a Connectivity Test between the two endpoints
- D. Query Flow Analyzer for the top talkers

### 83. A review must remove dead rules and surface configuration risk. Which two tools fit? Select two.

- A. Review Firewall Insights for shadowed rules
- B. Enable Cloud DNS query logging
- C. Read the Network Analyzer findings
- D. Run a Connectivity Test between the two endpoints
- E. Query Flow Analyzer for the top talkers

### 84. A design document claims a path that nobody has verified against reality. What should be opened?

- A. Run a Connectivity Test between the two endpoints
- B. Inspect the flow in Network Topology
- C. Query Flow Analyzer for the top talkers
- D. Check the Performance Dashboard for packet loss

### 85. Finance needs the biggest consumers ranked before the next budget round. What should be run?

- A. Inspect the flow in Network Topology
- B. Review Firewall Insights for shadowed rules
- C. Query Flow Analyzer for the top talkers
- D. Check the Performance Dashboard for packet loss

### 86. One side of a peering session lists many prefixes and the other lists none. Which check comes first?

- A. Run a Connectivity Test between the two endpoints
- B. Enable Bidirectional Forwarding Detection with a short interval
- C. Prefer the path with the lower multi-exit discriminator
- D. Compare the BGP session state on both peers

### 87. A front end is being replaced and its long-lived sessions must complete. What should happen first?

- A. Drain the backend before removing it
- B. Inspect the flow in Network Topology
- C. Enable connection draining with a timeout
- D. Query Flow Analyzer for the top talkers

---

## Domain 6 — Configuring, Implementing, and Managing a Cloud Network Security Solution (Cloud Armor, Cloud NGFW, NAT, and Egress Security)

### 88. A backend may serve only two countries and must reject everything else. What should be attached to it?

- A. Enable Adaptive Protection
- B. Attach a Cloud Armor backend security policy
- C. Add a preconfigured WAF rule for the attack class
- D. Attach a Cloud Armor edge security policy

### 89. A blocklisted network must never reach the proxy at all. What should be attached?

- A. Attach a Cloud Armor edge security policy
- B. Attach a Cloud Armor backend security policy
- C. Enable bot management on the policy
- D. Add a rate-based ban rule

### 90. A search box is receiving payloads that try to inject SQL. What should be enabled?

- A. Apply Google Threat Intelligence lists
- B. Enable Adaptive Protection
- C. Enable bot management on the policy
- D. Add a preconfigured WAF rule for the attack class

### 91. Partner integrations and scrapers both use automation, and only one group should be admitted. What should be enabled?

- A. Add a preconfigured WAF rule for the attack class
- B. Enable Adaptive Protection
- C. Apply Google Threat Intelligence lists
- D. Enable bot management on the policy

### 92. A flood comes from a very large number of addresses and must be absorbed without manual rules. What should be relied on?

- A. Apply Google Threat Intelligence lists
- B. Rely on the default DDoS protection and add a rate limit
- C. Add a rate-based ban rule
- D. Enable Adaptive Protection

### 93. A baseline control must bind every project, and payload inspection must also be in place. Which two choices fit? Select two.

- A. Move the inspection to NGFW Enterprise
- B. Create a hierarchical firewall policy at the organisation
- C. Reorder the rules by priority
- D. Create a regional network firewall policy
- E. Create a VPC firewall rule with a target tag

### 94. A single inspection ruleset has to follow workloads into every region they use. Which scope does that?

- A. Create a hierarchical firewall policy at the organisation
- B. Create a global network firewall policy
- C. Create a VPC firewall rule with a target tag
- D. Create a regional network firewall policy

### 95. A deny rule was added and traffic still flows, because something earlier already matched. What explains it?

- A. Leave the default allow-ingress rule in place
- B. Reorder the rules by priority
- C. Move the rules to NGFW Standard
- D. Add a deny-all egress rule with a higher priority

### 96. Nothing stops one compromised workload from reaching another today. What should replace that flat model?

- A. Divide the network into micro-segmented tiers
- B. Leave the default allow-ingress rule in place
- C. Move the inspection to NGFW Enterprise
- D. Reorder the rules by priority

### 97. Whoever creates an instance must not be able to make it match a privileged rule. What should target the rule?

- A. Use secure tags as the rule target
- B. Create a hierarchical firewall policy at the organisation
- C. Target the rule with a service account
- D. Target the rule with network tags

### 98. A partner allowlists one source address and it must never change. What should Cloud NAT use?

- A. Use dynamic port allocation
- B. Use automatic Cloud NAT IP allocation
- C. Deploy Secure Web Proxy as the egress path
- D. Assign a manual static Cloud NAT address

### 99. Egress must be blocked by site category and inspected inside the encrypted session. What should be deployed?

- A. Use dynamic port allocation
- B. Assign a manual static Cloud NAT address
- C. Deploy Secure Web Proxy as the egress path
- D. Configure Packet Mirroring on the instance group

### 100. A collector needs copies of certain flows while the live traffic continues untouched. What should be enabled?

- A. Deploy a multi-NIC appliance VM between the two networks
- B. Configure Packet Mirroring on the instance group
- C. Inspect the traffic out of band with Packet Mirroring
- D. Deploy Secure Web Proxy as the egress path

---

## Answer key and explanations

### Question 1 — B

Answer: Use the Premium network service tier. Premium enters the Google network at the nearest edge, which shortens the path to the region. Traffic enters the Google network at the edge closest to the user and crosses it to the serving region. Local study-map skill 1.1 (Network Service Tier Choice), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Traffic enters the Google network in the region that hosts the resource, so long-haul travel happens on the public internet. Why the correct answer wins: Premium enters the Google network at the nearest edge, which shortens the path to the region.
- **B:** Correct. Traffic enters the Google network at the edge closest to the user and crosses it to the serving region. In this case: Premium enters the Google network at the nearest edge, which shortens the path to the region.
- **C:** Incorrect for this question. The front end is regional, so users are served from the region the address belongs to. Why the correct answer wins: Premium enters the Google network at the nearest edge, which shortens the path to the region.
- **D:** Incorrect for this question. The edge holds a copy of the response so later requests are served closer to the user. Why the correct answer wins: Premium enters the Google network at the nearest edge, which shortens the path to the region.

### Question 2 — C

Answer: Use the Standard network service tier. Standard carries the long haul on the public internet, which is the cheaper choice here. Traffic enters the Google network in the region that hosts the resource, so long-haul travel happens on the public internet. Local study-map skill 1.1 (Network Service Tier Choice), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Traffic enters the Google network at the edge closest to the user and crosses it to the serving region. Why the correct answer wins: Standard carries the long haul on the public internet, which is the cheaper choice here.
- **B:** Incorrect for this question. The proxy terminates TLS and forwards a separate connection to the backend. Why the correct answer wins: Standard carries the long haul on the public internet, which is the cheaper choice here.
- **C:** Correct. Traffic enters the Google network in the region that hosts the resource, so long-haul travel happens on the public internet. In this case: Standard carries the long haul on the public internet, which is the cheaper choice here.
- **D:** Incorrect for this question. A fixed address lets the partner allowlist the source. Why the correct answer wins: Standard carries the long haul on the public internet, which is the cheaper choice here.

### Question 3 — D

Answer: Attach a health check to the backend service. A health check removes a pool that cannot answer without waiting for a human. The check removes a backend that cannot answer, so traffic moves to a healthy one. Local study-map skill 1.2 (High Availability, Failover, and DR Design), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The mode spreads load by connection count rather than by CPU utilisation. Why the correct answer wins: A health check removes a pool that cannot answer without waiting for a human.
- **B:** Incorrect for this question. Affinity keeps a client on the backend that already holds its session state. Why the correct answer wins: A health check removes a pool that cannot answer without waiting for a human.
- **C:** Incorrect for this question. Removing a backend waits for in-flight requests to finish before the backend is detached. Why the correct answer wins: A health check removes a pool that cannot answer without waiting for a human.
- **D:** Correct. The check removes a backend that cannot answer, so traffic moves to a healthy one. In this case: A health check removes a pool that cannot answer without waiting for a human.

### Question 4 — D, E

Answers: Deploy a global external Application Load Balancer; Enable connection draining with a timeout. The global address serves either continent, and draining finishes the viewers already connected there. A global anycast address routes each user to the closest healthy region. Removing a backend waits for in-flight requests to finish before the backend is detached. Local study-map skill 1.2 (High Availability, Failover, and DR Design), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The front end is an internal address reachable only from inside the VPC or its connected networks. Why the correct answer wins: The global address serves either continent, and draining finishes the viewers already connected there.
- **B:** Incorrect for this question. Affinity keeps a client on the backend that already holds its session state. Why the correct answer wins: The global address serves either continent, and draining finishes the viewers already connected there.
- **C:** Incorrect for this question. The front end is regional, so users are served from the region the address belongs to. Why the correct answer wins: The global address serves either continent, and draining finishes the viewers already connected there.
- **D:** Correct. A global anycast address routes each user to the closest healthy region. In this case: The global address serves either continent, and draining finishes the viewers already connected there.
- **E:** Correct. Removing a backend waits for in-flight requests to finish before the backend is detached. In this case: The global address serves either continent, and draining finishes the viewers already connected there.

### Question 5 — C

Answer: Create an inbound forwarding policy with a forwarding address. An inbound forwarding policy gives those resolvers an address to query. On-premises resolvers send queries to that address to reach Cloud DNS names. Local study-map skill 1.3 (Hybrid DNS Topology), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The consumer project resolves names from the producer project through a peering zone. Why the correct answer wins: An inbound forwarding policy gives those resolvers an address to query.
- **B:** Incorrect for this question. Internal clients resolve the internal address while external clients resolve the public one. Why the correct answer wins: An inbound forwarding policy gives those resolvers an address to query.
- **C:** Correct. On-premises resolvers send queries to that address to reach Cloud DNS names. In this case: An inbound forwarding policy gives those resolvers an address to query.
- **D:** Incorrect for this question. Queries for the corporate suffix are forwarded to the on-premises resolvers. Why the correct answer wins: An inbound forwarding policy gives those resolvers an address to query.

### Question 6 — A

Answer: Configure a DNS forwarding policy for the on-premises domain. A forwarding policy sends queries for that domain to those resolvers. Queries for the corporate suffix are forwarded to the on-premises resolvers. Local study-map skill 1.3 (Hybrid DNS Topology), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. Queries for the corporate suffix are forwarded to the on-premises resolvers. In this case: A forwarding policy sends queries for that domain to those resolvers.
- **B:** Incorrect for this question. The consumer project resolves names from the producer project through a peering zone. Why the correct answer wins: A forwarding policy sends queries for that domain to those resolvers.
- **C:** Incorrect for this question. Signatures let a resolver verify that the answer was not altered in transit. Why the correct answer wins: A forwarding policy sends queries for that domain to those resolvers.
- **D:** Incorrect for this question. On-premises resolvers send queries to that address to reach Cloud DNS names. Why the correct answer wins: A forwarding policy sends queries for that domain to those resolvers.

### Question 7 — A

Answer: Deploy an internal passthrough Network Load Balancer. An internal front end publishes no address outside the network. The front end is an internal address reachable only from inside the VPC or its connected networks. Local study-map skill 1.4 (Load Balancer Selection), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. The front end is an internal address reachable only from inside the VPC or its connected networks. In this case: An internal front end publishes no address outside the network.
- **B:** Incorrect for this question. The proxy terminates the client connection and opens a separate one to the backend. Why the correct answer wins: An internal front end publishes no address outside the network.
- **C:** Incorrect for this question. Packets keep their client source address and the backend sees the original flow. Why the correct answer wins: An internal front end publishes no address outside the network.
- **D:** Incorrect for this question. A global anycast address routes each user to the closest healthy region. Why the correct answer wins: An internal front end publishes no address outside the network.

### Question 8 — C

Answer: Use a proxy Network Load Balancer. A proxy ends TLS and balances the individual requests behind it. The proxy terminates the client connection and opens a separate one to the backend. Local study-map skill 1.4 (Load Balancer Selection), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Packets keep their client source address and the backend sees the original flow. Why the correct answer wins: A proxy ends TLS and balances the individual requests behind it.
- **B:** Incorrect for this question. The front end is an internal address reachable only from inside the VPC or its connected networks. Why the correct answer wins: A proxy ends TLS and balances the individual requests behind it.
- **C:** Correct. The proxy terminates the client connection and opens a separate one to the backend. In this case: A proxy ends TLS and balances the individual requests behind it.
- **D:** Incorrect for this question. The map selects a backend service from the request host and path. Why the correct answer wins: A proxy ends TLS and balances the individual requests behind it.

### Question 9 — D

Answer: Plan secondary ranges for pods and services. Secondary ranges give pods address space separate from the node subnet. Alias ranges give pods and services addresses that are separate from the node subnet. Local study-map skill 1.5 (GKE Network Planning), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. An additional alias range gives pods more addresses without rebuilding the cluster. Why the correct answer wins: Secondary ranges give pods address space separate from the node subnet.
- **B:** Incorrect for this question. A subnet prefix can grow within its address range, and the growth cannot shrink later. Why the correct answer wins: Secondary ranges give pods address space separate from the node subnet.
- **C:** Incorrect for this question. The policy restricts which pods may talk to the selected pods. Why the correct answer wins: Secondary ranges give pods address space separate from the node subnet.
- **D:** Correct. Alias ranges give pods and services addresses that are separate from the node subnet. In this case: Secondary ranges give pods address space separate from the node subnet.

### Question 10 — B

Answer: Add the office range to the authorised networks. Authorised networks admit those two ranges and refuse all others. The named range may reach the control plane endpoint even when it is public. Local study-map skill 1.5 (GKE Network Planning), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The API server is reachable only through the internal address or an authorised network. Why the correct answer wins: Authorised networks admit those two ranges and refuse all others.
- **B:** Correct. The named range may reach the control plane endpoint even when it is public. In this case: Authorised networks admit those two ranges and refuse all others.
- **C:** Incorrect for this question. The endpoint resolves through a private DNS name instead of a fixed address. Why the correct answer wins: Authorised networks admit those two ranges and refuse all others.
- **D:** Incorrect for this question. Nodes reach the control plane and Google APIs through internal paths only. Why the correct answer wins: Authorised networks admit those two ranges and refuse all others.

### Question 11 — B, E

Answers: Use private nodes with no external addresses; Plan secondary ranges for pods and services. Private nodes remove external addresses, and secondary ranges separate the pod space. Nodes reach the control plane and Google APIs through internal paths only. Alias ranges give pods and services addresses that are separate from the node subnet. Local study-map skill 1.5 (GKE Network Planning), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The named range may reach the control plane endpoint even when it is public. Why the correct answer wins: Private nodes remove external addresses, and secondary ranges separate the pod space.
- **B:** Correct. Nodes reach the control plane and Google APIs through internal paths only. In this case: Private nodes remove external addresses, and secondary ranges separate the pod space.
- **C:** Incorrect for this question. Outbound pod traffic is translated to the node address under the chosen conditions. Why the correct answer wins: Private nodes remove external addresses, and secondary ranges separate the pod space.
- **D:** Incorrect for this question. An additional alias range gives pods more addresses without rebuilding the cluster. Why the correct answer wins: Private nodes remove external addresses, and secondary ranges separate the pod space.
- **E:** Correct. Alias ranges give pods and services addresses that are separate from the node subnet. In this case: Private nodes remove external addresses, and secondary ranges separate the pod space.

### Question 12 — D

Answer: Grant the network administrator role in the host project. The network administrator role owns those objects inside the host project. That role creates and changes networks and subnets, which a service team should not hold. Local study-map skill 1.6 (IAM for Network Roles), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The role lets a service project deploy into the named subnets and nothing else. Why the correct answer wins: The network administrator role owns those objects inside the host project.
- **B:** Incorrect for this question. Editor spans most services, so it can delete far more than the network resources involved. Why the correct answer wins: The network administrator role owns those objects inside the host project.
- **C:** Incorrect for this question. The custom role names the exact permissions the automation needs. Why the correct answer wins: The network administrator role owns those objects inside the host project.
- **D:** Correct. That role creates and changes networks and subnets, which a service team should not hold. In this case: The network administrator role owns those objects inside the host project.

### Question 13 — B, C

Answers: Create a custom role with only the required network permissions; Grant the subnet user role on the specific shared subnets. A custom role can hold the single read permission, and subnet user covers the one subnet. The custom role names the exact permissions the automation needs. The role lets a service project deploy into the named subnets and nothing else. Local study-map skill 1.6 (IAM for Network Roles), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. That role attaches service projects and delegates subnet use. Why the correct answer wins: A custom role can hold the single read permission, and subnet user covers the one subnet.
- **B:** Correct. The role lets a service project deploy into the named subnets and nothing else. In this case: A custom role can hold the single read permission, and subnet user covers the one subnet.
- **C:** Correct. The custom role names the exact permissions the automation needs. In this case: A custom role can hold the single read permission, and subnet user covers the one subnet.
- **D:** Incorrect for this question. Editor spans most services, so it can delete far more than the network resources involved. Why the correct answer wins: A custom role can hold the single read permission, and subnet user covers the one subnet.
- **E:** Incorrect for this question. That role creates and changes networks and subnets, which a service team should not hold. Why the correct answer wins: A custom role can hold the single read permission, and subnet user covers the one subnet.

### Question 14 — C

Answer: Allocate a private services access range. A private services access range gives the provider space to place the instance. A reserved internal range lets a managed service provider peer into the VPC. Local study-map skill 1.7 (Private Service Connectivity), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Instances without external addresses reach Google APIs through internal routing. Why the correct answer wins: A private services access range gives the provider space to place the instance.
- **B:** Incorrect for this question. A serverless runtime gets a path into the VPC through a connector or direct egress. Why the correct answer wins: A private services access range gives the provider space to place the instance.
- **C:** Correct. A reserved internal range lets a managed service provider peer into the VPC. In this case: A private services access range gives the provider space to place the instance.
- **D:** Incorrect for this question. A private endpoint inside the consumer VPC targets a published service attachment. Why the correct answer wins: A private services access range gives the provider space to place the instance.

### Question 15 — B, D

Answers: Create a Private Service Connect endpoint; Attach the service to Serverless VPC Access. The private endpoint consumes the attachment, and Serverless VPC Access gives the worker a path. A private endpoint inside the consumer VPC targets a published service attachment. A serverless runtime gets a path into the VPC through a connector or direct egress. Local study-map skill 1.7 (Private Service Connectivity), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The client resolves the public endpoint and traffic leaves Google Cloud, which fails a private-only requirement. Why the correct answer wins: The private endpoint consumes the attachment, and Serverless VPC Access gives the worker a path.
- **B:** Correct. A serverless runtime gets a path into the VPC through a connector or direct egress. In this case: The private endpoint consumes the attachment, and Serverless VPC Access gives the worker a path.
- **C:** Incorrect for this question. Instances without external addresses reach Google APIs through internal routing. Why the correct answer wins: The private endpoint consumes the attachment, and Serverless VPC Access gives the worker a path.
- **D:** Correct. A private endpoint inside the consumer VPC targets a published service attachment. In this case: The private endpoint consumes the attachment, and Serverless VPC Access gives the worker a path.
- **E:** Incorrect for this question. A reserved internal range lets a managed service provider peer into the VPC. Why the correct answer wins: The private endpoint consumes the attachment, and Serverless VPC Access gives the worker a path.

### Question 16 — C

Answer: Connect the networks as a hub-and-spoke peering topology. A hub-and-spoke peering reaches the centre without joining the stores together. A central network peers with each leaf network, and the leaves do not peer with each other. Local study-map skill 1.8 (VPC Type and Interconnect Topology), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. One host project owns the network and subnets while service projects deploy into shared subnets. Why the correct answer wins: A hub-and-spoke peering reaches the centre without joining the stores together.
- **B:** Incorrect for this question. A full mesh of peering sessions gives each network a direct path to all the others. Why the correct answer wins: A hub-and-spoke peering reaches the centre without joining the stores together.
- **C:** Correct. A central network peers with each leaf network, and the leaves do not peer with each other. In this case: A hub-and-spoke peering reaches the centre without joining the stores together.
- **D:** Incorrect for this question. A hub groups spokes so the connected networks reach each other through one managed topology. Why the correct answer wins: A hub-and-spoke peering reaches the centre without joining the stores together.

### Question 17 — D

Answer: Peer every VPC network with every other VPC network. A full mesh peers every network with each of the others. A full mesh of peering sessions gives each network a direct path to all the others. Local study-map skill 1.8 (VPC Type and Interconnect Topology), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. A central network peers with each leaf network, and the leaves do not peer with each other. Why the correct answer wins: A full mesh peers every network with each of the others.
- **B:** Incorrect for this question. A hub groups spokes so the connected networks reach each other through one managed topology. Why the correct answer wins: A full mesh peers every network with each of the others.
- **C:** Incorrect for this question. Two networks exchange routes directly without a gateway or a shared project. Why the correct answer wins: A full mesh peers every network with each of the others.
- **D:** Correct. A full mesh of peering sessions gives each network a direct path to all the others. In this case: A full mesh peers every network with each of the others.

### Question 18 — C

Answer: Deploy Private NAT for the overlapping ranges. Private NAT translates the source so identical ranges can still exchange traffic. Source addresses are translated so two networks with the same private ranges can still talk. Local study-map skill 1.9 (IP Address Management), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The internal network uses address space outside the private ranges to avoid collisions later. Why the correct answer wins: Private NAT translates the source so identical ranges can still exchange traffic.
- **B:** Incorrect for this question. Two subnets with the same prefix cannot be routed to each other without translation. Why the correct answer wins: Private NAT translates the source so identical ranges can still exchange traffic.
- **C:** Correct. Source addresses are translated so two networks with the same private ranges can still talk. In this case: Private NAT translates the source so identical ranges can still exchange traffic.
- **D:** Incorrect for this question. Public ranges that are never advertised are used internally to gain address space without NAT. Why the correct answer wins: Private NAT translates the source so identical ranges can still exchange traffic.

### Question 19 — A

Answer: Bring your own public IP prefixes. Bring your own IP lets the organisation advertise prefixes it already holds. Public prefixes the organisation already owns are advertised from Google Cloud. Local study-map skill 1.9 (IP Address Management), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. Public prefixes the organisation already owns are advertised from Google Cloud. In this case: Bring your own IP lets the organisation advertise prefixes it already holds.
- **B:** Incorrect for this question. Allocation is generated from one authoritative plan instead of hand-picked ranges per team. Why the correct answer wins: Bring your own IP lets the organisation advertise prefixes it already holds.
- **C:** Incorrect for this question. The internal network uses address space outside the private ranges to avoid collisions later. Why the correct answer wins: Bring your own IP lets the organisation advertise prefixes it already holds.
- **D:** Incorrect for this question. Public ranges that are never advertised are used internally to gain address space without NAT. Why the correct answer wins: Bring your own IP lets the organisation advertise prefixes it already holds.

### Question 20 — D

Answer: Leave the MTU mismatch unfixed. The path disagrees about frame size, so oversized packets are dropped silently. A path that disagrees about frame size drops or fragments large packets, which shows up as stalled bulk transfers. Local study-map skill 1.10 (MTU Sizing), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. A larger maximum transmission unit carries more payload per packet inside the VPC. Why the correct answer wins: The path disagrees about frame size, so oversized packets are dropped silently.
- **B:** Incorrect for this question. A smaller MTU leaves room for the tunnel encapsulation headers that reduce usable payload. Why the correct answer wins: The path disagrees about frame size, so oversized packets are dropped silently.
- **C:** Incorrect for this question. The default MTU matches ordinary Ethernet frames and needs no adjustment. Why the correct answer wins: The path disagrees about frame size, so oversized packets are dropped silently.
- **D:** Correct. A path that disagrees about frame size drops or fragments large packets, which shows up as stalled bulk transfers. In this case: The path disagrees about frame size, so oversized packets are dropped silently.

### Question 21 — C

Answer: Deploy a multi-NIC appliance VM between the two networks. An appliance with an interface in each enclave inspects and forwards between them. Each interface sits in a different network, so the appliance can inspect and forward between them. Local study-map skill 1.11 (Third-Party Appliance Insertion), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 1 (designing and planning a Google Cloud VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The route forwards matching flows to the appliance even when the destination is not the appliance. Why the correct answer wins: An appliance with an interface in each enclave inspects and forwards between them.
- **B:** Incorrect for this question. Traffic reaches whichever appliance instance the internal front end selects. Why the correct answer wins: An appliance with an interface in each enclave inspects and forwards between them.
- **C:** Correct. Each interface sits in a different network, so the appliance can inspect and forward between them. In this case: An appliance with an interface in each enclave inspects and forwards between them.
- **D:** Incorrect for this question. Only instances carrying the tag send their traffic through the appliance. Why the correct answer wins: An appliance with an interface in each enclave inspects and forwards between them.

### Question 22 — D

Answer: Expand the existing subnet range. The prefix grows in place and the running instances keep their addresses. A subnet prefix can grow within its address range, and the growth cannot shrink later. Local study-map skill 2.1 (VPC and Subnet Configuration), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Public ranges that are never advertised are used internally to gain address space without NAT. Why the correct answer wins: The prefix grows in place and the running instances keep their addresses.
- **B:** Incorrect for this question. The subnet carries both an IPv4 range and an internal or external IPv6 range. Why the correct answer wins: The prefix grows in place and the running instances keep their addresses.
- **C:** Incorrect for this question. Two subnets with the same prefix cannot be routed to each other without translation. Why the correct answer wins: The prefix grows in place and the running instances keep their addresses.
- **D:** Correct. A subnet prefix can grow within its address range, and the growth cannot shrink later. In this case: The prefix grows in place and the running instances keep their addresses.

### Question 23 — B, E

Answers: Enable dual-stack IPv6 on the subnet; Expand the existing subnet range. The existing prefix can grow in place for IPv4, and dual-stack adds an IPv6 range alongside it. The subnet carries both an IPv4 range and an internal or external IPv6 range. A subnet prefix can grow within its address range, and the growth cannot shrink later. Local study-map skill 2.1 (VPC and Subnet Configuration), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Public prefixes the organisation already owns are advertised from Google Cloud. Why the correct answer wins: The existing prefix can grow in place for IPv4, and dual-stack adds an IPv6 range alongside it.
- **B:** Correct. A subnet prefix can grow within its address range, and the growth cannot shrink later. In this case: The existing prefix can grow in place for IPv4, and dual-stack adds an IPv6 range alongside it.
- **C:** Incorrect for this question. Public ranges that are never advertised are used internally to gain address space without NAT. Why the correct answer wins: The existing prefix can grow in place for IPv4, and dual-stack adds an IPv6 range alongside it.
- **D:** Incorrect for this question. Two subnets with the same prefix cannot be routed to each other without translation. Why the correct answer wins: The existing prefix can grow in place for IPv4, and dual-stack adds an IPv6 range alongside it.
- **E:** Correct. The subnet carries both an IPv4 range and an internal or external IPv6 range. In this case: The existing prefix can grow in place for IPv4, and dual-stack adds an IPv6 range alongside it.

### Question 24 — A

Answer: Assume peered networks can reach each other transitively. Peering does not forward routes to a third network, so that hop cannot exist. Peering is not transitive, so a route learned through one peer is not passed on to another. Local study-map skill 2.2 (VPC Network Peering), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. Peering is not transitive, so a route learned through one peer is not passed on to another. In this case: Peering does not forward routes to a third network, so that hop cannot exist.
- **B:** Incorrect for this question. A hub groups spokes so the connected networks reach each other through one managed topology. Why the correct answer wins: Peering does not forward routes to a third network, so that hop cannot exist.
- **C:** Incorrect for this question. Two networks exchange routes directly without a gateway or a shared project. Why the correct answer wins: Peering does not forward routes to a third network, so that hop cannot exist.
- **D:** Incorrect for this question. A full mesh of peering sessions gives each network a direct path to all the others. Why the correct answer wins: Peering does not forward routes to a third network, so that hop cannot exist.

### Question 25 — A

Answer: Create a VPC Network Peering connection between the two networks. Peering joins precisely the two networks involved. Two networks exchange routes directly without a gateway or a shared project. Local study-map skill 2.2 (VPC Network Peering), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. Two networks exchange routes directly without a gateway or a shared project. In this case: Peering joins precisely the two networks involved.
- **B:** Incorrect for this question. A hub groups spokes so the connected networks reach each other through one managed topology. Why the correct answer wins: Peering joins precisely the two networks involved.
- **C:** Incorrect for this question. A full mesh of peering sessions gives each network a direct path to all the others. Why the correct answer wins: Peering joins precisely the two networks involved.
- **D:** Incorrect for this question. One host project owns the network and subnets while service projects deploy into shared subnets. Why the correct answer wins: Peering joins precisely the two networks involved.

### Question 26 — D

Answer: Grant the subnet user role on the specific shared subnets. Subnet user on that subnet is what the deployment needs. The role lets a service project deploy into the named subnets and nothing else. Local study-map skill 2.3 (Shared VPC), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. That role attaches service projects and delegates subnet use. Why the correct answer wins: Subnet user on that subnet is what the deployment needs.
- **B:** Incorrect for this question. Editor spans most services, so it can delete far more than the network resources involved. Why the correct answer wins: Subnet user on that subnet is what the deployment needs.
- **C:** Incorrect for this question. That role creates and changes networks and subnets, which a service team should not hold. Why the correct answer wins: Subnet user on that subnet is what the deployment needs.
- **D:** Correct. The role lets a service project deploy into the named subnets and nothing else. In this case: Subnet user on that subnet is what the deployment needs.

### Question 27 — B, C

Answers: Build the network as a Shared VPC with host and service projects; Grant the subnet user role on the specific shared subnets. Shared VPC centralises the plan, and subnet user confines each division. One host project owns the network and subnets while service projects deploy into shared subnets. The role lets a service project deploy into the named subnets and nothing else. Local study-map skill 2.3 (Shared VPC), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Editor spans most services, so it can delete far more than the network resources involved. Why the correct answer wins: Shared VPC centralises the plan, and subnet user confines each division.
- **B:** Correct. The role lets a service project deploy into the named subnets and nothing else. In this case: Shared VPC centralises the plan, and subnet user confines each division.
- **C:** Correct. One host project owns the network and subnets while service projects deploy into shared subnets. In this case: Shared VPC centralises the plan, and subnet user confines each division.
- **D:** Incorrect for this question. That role creates and changes networks and subnets, which a service team should not hold. Why the correct answer wins: Shared VPC centralises the plan, and subnet user confines each division.
- **E:** Incorrect for this question. Separate projects own separate networks, and nothing is shared implicitly. Why the correct answer wins: Shared VPC centralises the plan, and subnet user confines each division.

### Question 28 — D

Answer: Enable Private Google Access on the subnet. Private Google Access routes those calls internally. Instances without external addresses reach Google APIs through internal routing. Local study-map skill 2.4 (Private Google Access and APIs), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. A serverless runtime gets a path into the VPC through a connector or direct egress. Why the correct answer wins: Private Google Access routes those calls internally.
- **B:** Incorrect for this question. The client resolves the public endpoint and traffic leaves Google Cloud, which fails a private-only requirement. Why the correct answer wins: Private Google Access routes those calls internally.
- **C:** Incorrect for this question. A private endpoint inside the consumer VPC targets a published service attachment. Why the correct answer wins: Private Google Access routes those calls internally.
- **D:** Correct. Instances without external addresses reach Google APIs through internal routing. In this case: Private Google Access routes those calls internally.

### Question 29 — B

Answer: Enclose the project in a VPC Service Controls perimeter. A perimeter refuses access to the data from outside the approved group of projects. The perimeter restricts which services the project may call and blocks data movement outside it. Local study-map skill 2.5 (VPC Service Controls Perimeters), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Instances without external addresses reach Google APIs through internal routing. Why the correct answer wins: A perimeter refuses access to the data from outside the approved group of projects.
- **B:** Correct. The perimeter restricts which services the project may call and blocks data movement outside it. In this case: A perimeter refuses access to the data from outside the approved group of projects.
- **C:** Incorrect for this question. The policy applies to every project under the organisation node. Why the correct answer wins: A perimeter refuses access to the data from outside the approved group of projects.
- **D:** Incorrect for this question. The insight names rules that never match because a broader rule already covered them. Why the correct answer wins: A perimeter refuses access to the data from outside the approved group of projects.

### Question 30 — B

Answer: Give the static route a lower priority number than the learned route. The lower priority number wins between routes for one prefix. The lower number wins when a static route and a dynamic route carry the same prefix. Local study-map skill 2.6 (Static and Dynamic Routing), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Two peers cannot form a session when both claim the same autonomous system number. Why the correct answer wins: The lower priority number wins between routes for one prefix.
- **B:** Correct. The lower number wins when a static route and a dynamic route carry the same prefix. In this case: The lower priority number wins between routes for one prefix.
- **C:** Incorrect for this question. The lower discriminator wins when the same prefix arrives over two attachments. Why the correct answer wins: The lower priority number wins between routes for one prefix.
- **D:** Incorrect for this question. The echo detects a dead path faster than the BGP hold timer allows. Why the correct answer wins: The lower priority number wins between routes for one prefix.

### Question 31 — B

Answer: Switch the Cloud Router to global dynamic routing mode. Global dynamic routing makes the learned routes available in every region. Routes learned in one region are available to subnets in every region. Local study-map skill 2.6 (Static and Dynamic Routing), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Routes stay inside the region that learned them. Why the correct answer wins: Global dynamic routing makes the learned routes available in every region.
- **B:** Correct. Routes learned in one region are available to subnets in every region. In this case: Global dynamic routing makes the learned routes available in every region.
- **C:** Incorrect for this question. The lower discriminator wins when the same prefix arrives over two attachments. Why the correct answer wins: Global dynamic routing makes the learned routes available in every region.
- **D:** Incorrect for this question. The router advertises a chosen prefix list instead of every subnet in the VPC. Why the correct answer wins: Global dynamic routing makes the learned routes available in every region.

### Question 32 — C, E

Answers: Prefer the path with the lower multi-exit discriminator; Switch best path selection back to the legacy behaviour. The discriminator ranks the circuits, and the selection order settles the remaining tie. The lower discriminator wins when the same prefix arrives over two attachments. The older selection order picks a different preferred path when the inputs tie. Local study-map skill 2.6 (Static and Dynamic Routing), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The lower number wins when a static route and a dynamic route carry the same prefix. Why the correct answer wins: The discriminator ranks the circuits, and the selection order settles the remaining tie.
- **B:** Incorrect for this question. Two peers cannot form a session when both claim the same autonomous system number. Why the correct answer wins: The discriminator ranks the circuits, and the selection order settles the remaining tie.
- **C:** Correct. The older selection order picks a different preferred path when the inputs tie. In this case: The discriminator ranks the circuits, and the selection order settles the remaining tie.
- **D:** Incorrect for this question. The echo detects a dead path faster than the BGP hold timer allows. Why the correct answer wins: The discriminator ranks the circuits, and the selection order settles the remaining tie.
- **E:** Correct. The lower discriminator wins when the same prefix arrives over two attachments. In this case: The discriminator ranks the circuits, and the selection order settles the remaining tie.

### Question 33 — C

Answer: Add a policy-based route that matches the source and destination. A policy-based route matches that destination and forwards it to the appliance. The route forwards matching flows to the appliance even when the destination is not the appliance. Local study-map skill 2.7 (Policy-Based Routing), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Traffic reaches whichever appliance instance the internal front end selects. Why the correct answer wins: A policy-based route matches that destination and forwards it to the appliance.
- **B:** Incorrect for this question. Only instances carrying the tag send their traffic through the appliance. Why the correct answer wins: A policy-based route matches that destination and forwards it to the appliance.
- **C:** Correct. The route forwards matching flows to the appliance even when the destination is not the appliance. In this case: A policy-based route matches that destination and forwards it to the appliance.
- **D:** Incorrect for this question. Each interface sits in a different network, so the appliance can inspect and forward between them. Why the correct answer wins: A policy-based route matches that destination and forwards it to the appliance.

### Question 34 — A

Answer: Create a static route with a tag-scoped next hop. A tag-scoped static route applies to the tagged instances only. Only instances carrying the tag send their traffic through the appliance. Local study-map skill 2.7 (Policy-Based Routing), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. Only instances carrying the tag send their traffic through the appliance. In this case: A tag-scoped static route applies to the tagged instances only.
- **B:** Incorrect for this question. The route forwards matching flows to the appliance even when the destination is not the appliance. Why the correct answer wins: A tag-scoped static route applies to the tagged instances only.
- **C:** Incorrect for this question. The lower number wins when a static route and a dynamic route carry the same prefix. Why the correct answer wins: A tag-scoped static route applies to the tagged instances only.
- **D:** Incorrect for this question. Traffic reaches whichever appliance instance the internal front end selects. Why the correct answer wins: A tag-scoped static route applies to the tagged instances only.

### Question 35 — C

Answer: Use the internal load balancer as the next hop. The internal load balancer hides the recycling from routing. Traffic reaches whichever appliance instance the internal front end selects. Local study-map skill 2.8 (Internal Load Balancer as Next Hop), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The route forwards matching flows to the appliance even when the destination is not the appliance. Why the correct answer wins: The internal load balancer hides the recycling from routing.
- **B:** Incorrect for this question. Only instances carrying the tag send their traffic through the appliance. Why the correct answer wins: The internal load balancer hides the recycling from routing.
- **C:** Correct. Traffic reaches whichever appliance instance the internal front end selects. In this case: The internal load balancer hides the recycling from routing.
- **D:** Incorrect for this question. Each interface sits in a different network, so the appliance can inspect and forward between them. Why the correct answer wins: The internal load balancer hides the recycling from routing.

### Question 36 — B

Answer: Add the attachment as a hybrid spoke. A hybrid spoke carries the tunnel into the hub. The spoke carries the VLAN attachment or VPN into the hub. Local study-map skill 2.9 (Network Connectivity Center), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The spoke publishes a service attachment so consumers reach it through the hub. Why the correct answer wins: A hybrid spoke carries the tunnel into the hub.
- **B:** Correct. The spoke carries the VLAN attachment or VPN into the hub. In this case: A hybrid spoke carries the tunnel into the hub.
- **C:** Incorrect for this question. The spoke exports the network subnets to the hub. Why the correct answer wins: A hybrid spoke carries the tunnel into the hub.
- **D:** Incorrect for this question. Only the matching prefixes are exchanged with the hub. Why the correct answer wins: A hybrid spoke carries the tunnel into the hub.

### Question 37 — D

Answer: Apply a CIDR range filter to the spoke. A CIDR filter limits the prefixes the spoke exchanges with the hub. Only the matching prefixes are exchanged with the hub. Local study-map skill 2.9 (Network Connectivity Center), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The hub forwards between spokes, which peering alone cannot do. Why the correct answer wins: A CIDR filter limits the prefixes the spoke exchanges with the hub.
- **B:** Incorrect for this question. The spoke exports the network subnets to the hub. Why the correct answer wins: A CIDR filter limits the prefixes the spoke exchanges with the hub.
- **C:** Incorrect for this question. The spoke carries the VLAN attachment or VPN into the hub. Why the correct answer wins: A CIDR filter limits the prefixes the spoke exchanges with the hub.
- **D:** Correct. Only the matching prefixes are exchanged with the hub. In this case: A CIDR filter limits the prefixes the spoke exchanges with the hub.

### Question 38 — C

Answer: Resize the service range allocation. The service range, not the pod range, is the pool for service addresses. The service address range must have room for the services the cluster will run. Local study-map skill 2.10 (GKE Cluster Networking), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. An additional alias range gives pods more addresses without rebuilding the cluster. Why the correct answer wins: The service range, not the pod range, is the pool for service addresses.
- **B:** Incorrect for this question. Alias ranges give pods and services addresses that are separate from the node subnet. Why the correct answer wins: The service range, not the pod range, is the pool for service addresses.
- **C:** Correct. The service address range must have room for the services the cluster will run. In this case: The service range, not the pod range, is the pool for service addresses.
- **D:** Incorrect for this question. The policy restricts which pods may talk to the selected pods. Why the correct answer wins: The service range, not the pod range, is the pool for service addresses.

### Question 39 — A

Answer: Create a GKE network policy for the namespace. A network policy restricts which pods may reach the selected pods. Local study-map skill 2.10 (GKE Cluster Networking), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. In this case: A network policy restricts which pods may reach the selected pods.
- **B:** Incorrect for this question. The eBPF dataplane handles policy and service routing inside the cluster. Why the correct answer wins: A network policy restricts which pods may reach the selected pods.
- **C:** Incorrect for this question. Outbound pod traffic is translated to the node address under the chosen conditions. Why the correct answer wins: A network policy restricts which pods may reach the selected pods.
- **D:** Incorrect for this question. An additional alias range gives pods more addresses without rebuilding the cluster. Why the correct answer wins: A network policy restricts which pods may reach the selected pods.

### Question 40 — C

Answer: Configure an IP masquerade policy on the node pool. Masquerading presents the node address in place of the pod address. Outbound pod traffic is translated to the node address under the chosen conditions. Local study-map skill 2.10 (GKE Cluster Networking), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The policy restricts which pods may talk to the selected pods. Why the correct answer wins: Masquerading presents the node address in place of the pod address.
- **B:** Incorrect for this question. An additional alias range gives pods more addresses without rebuilding the cluster. Why the correct answer wins: Masquerading presents the node address in place of the pod address.
- **C:** Correct. Outbound pod traffic is translated to the node address under the chosen conditions. In this case: Masquerading presents the node address in place of the pod address.
- **D:** Incorrect for this question. The eBPF dataplane handles policy and service routing inside the cluster. Why the correct answer wins: Masquerading presents the node address in place of the pod address.

### Question 41 — A

Answer: Enable VPC Flow Logs on the subnet. Flow logs record byte counts for sampled connections. The logs record sampled connections with source, destination, port and byte counts. Local study-map skill 2.11 (VPC Flow Logs), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 2 (implementing a VPC network): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. The logs record sampled connections with source, destination, port and byte counts. In this case: Flow logs record byte counts for sampled connections.
- **B:** Incorrect for this question. The logs record the names that clients asked for and the answers they received. Why the correct answer wins: Flow logs record byte counts for sampled connections.
- **C:** Incorrect for this question. The logs show which rule allowed or denied each connection. Why the correct answer wins: Flow logs record byte counts for sampled connections.
- **D:** Incorrect for this question. The logs record the translated address and port chosen for each flow. Why the correct answer wins: Flow logs record byte counts for sampled connections.

### Question 42 — A, D

Answers: Attach a health check to the backend service; Enable session affinity on the backend service. The health check decides membership, and affinity pins the client. The check removes a backend that cannot answer, so traffic moves to a healthy one. Affinity keeps a client on the backend that already holds its session state. Local study-map skill 3.1 (Load Balancer Backend Configuration), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. Affinity keeps a client on the backend that already holds its session state. In this case: The health check decides membership, and affinity pins the client.
- **B:** Incorrect for this question. Removing a backend waits for in-flight requests to finish before the backend is detached. Why the correct answer wins: The health check decides membership, and affinity pins the client.
- **C:** Incorrect for this question. A zonal endpoint group addresses specific endpoints such as pods or VMs in one zone. Why the correct answer wins: The health check decides membership, and affinity pins the client.
- **D:** Correct. The check removes a backend that cannot answer, so traffic moves to a healthy one. In this case: The health check decides membership, and affinity pins the client.
- **E:** Incorrect for this question. The mode spreads load by connection count rather than by CPU utilisation. Why the correct answer wins: The health check decides membership, and affinity pins the client.

### Question 43 — D

Answer: Enable connection draining with a timeout. Draining keeps the outgoing backend attached until its active requests have been answered. Removing a backend waits for in-flight requests to finish before the backend is detached. Local study-map skill 3.1 (Load Balancer Backend Configuration), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Affinity keeps a client on the backend that already holds its session state. Why the correct answer wins: Draining keeps the outgoing backend attached until its active requests have been answered.
- **B:** Incorrect for this question. The mode spreads load by connection count rather than by CPU utilisation. Why the correct answer wins: Draining keeps the outgoing backend attached until its active requests have been answered.
- **C:** Incorrect for this question. The group adds and removes instances as the autoscaling signal changes. Why the correct answer wins: Draining keeps the outgoing backend attached until its active requests have been answered.
- **D:** Correct. Removing a backend waits for in-flight requests to finish before the backend is detached. In this case: Draining keeps the outgoing backend attached until its active requests have been answered.

### Question 44 — A

Answer: Autoscale a managed instance group behind the backend service. An autoscaler adds members as its chosen signal rises. The group adds and removes instances as the autoscaling signal changes. Local study-map skill 3.1 (Load Balancer Backend Configuration), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. The group adds and removes instances as the autoscaling signal changes. In this case: An autoscaler adds members as its chosen signal rises.
- **B:** Incorrect for this question. A zonal endpoint group addresses specific endpoints such as pods or VMs in one zone. Why the correct answer wins: An autoscaler adds members as its chosen signal rises.
- **C:** Incorrect for this question. A serverless endpoint group fronts a Cloud Run service without a managed instance group. Why the correct answer wins: An autoscaler adds members as its chosen signal rises.
- **D:** Incorrect for this question. Removing a backend waits for in-flight requests to finish before the backend is detached. Why the correct answer wins: An autoscaler adds members as its chosen signal rises.

### Question 45 — B

Answer: Route by URL path in the URL map. The URL map selects a backend from the request host and path. Local study-map skill 3.2 (Traffic Management and URL Maps), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The rewrite presents the backend with the path it expects without changing the client. Why the correct answer wins: The URL map selects a backend from the request host and path.
- **B:** Correct. In this case: The URL map selects a backend from the request host and path.
- **C:** Incorrect for this question. The mirrored request is sent for inspection while the response comes only from the primary. Why the correct answer wins: The URL map selects a backend from the request host and path.
- **D:** Incorrect for this question. Weighted backends move a chosen share of traffic onto the new service. Why the correct answer wins: The URL map selects a backend from the request host and path.

### Question 46 — B

Answer: Split traffic between two backend services by weight. Weighted backends move that share onto the replacement. Weighted backends move a chosen share of traffic onto the new service. Local study-map skill 3.2 (Traffic Management and URL Maps), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The rewrite presents the backend with the path it expects without changing the client. Why the correct answer wins: Weighted backends move that share onto the replacement.
- **B:** Correct. Weighted backends move a chosen share of traffic onto the new service. In this case: Weighted backends move that share onto the replacement.
- **C:** Incorrect for this question. The map selects a backend service from the request host and path. Why the correct answer wins: Weighted backends move that share onto the replacement.
- **D:** Incorrect for this question. The mirrored request is sent for inspection while the response comes only from the primary. Why the correct answer wins: Weighted backends move that share onto the replacement.

### Question 47 — B

Answer: Register the serverless service as a serverless network endpoint group. A serverless endpoint group fronts the service without instance groups. Local study-map skill 3.3 (Network Endpoint Groups and Autoscaling), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. An internet endpoint group targets endpoints outside Google Cloud by hostname and port. Why the correct answer wins: A serverless endpoint group fronts the service without instance groups.
- **B:** Correct. In this case: A serverless endpoint group fronts the service without instance groups.
- **C:** Incorrect for this question. The group adds and removes instances as the autoscaling signal changes. Why the correct answer wins: A serverless endpoint group fronts the service without instance groups.
- **D:** Incorrect for this question. A zonal endpoint group addresses specific endpoints such as pods or VMs in one zone. Why the correct answer wins: A serverless endpoint group fronts the service without instance groups.

### Question 48 — A

Answer: Register the backends as a zonal network endpoint group. A zonal endpoint group addresses the pod endpoints directly. A zonal endpoint group addresses specific endpoints such as pods or VMs in one zone. Local study-map skill 3.3 (Network Endpoint Groups and Autoscaling), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. A zonal endpoint group addresses specific endpoints such as pods or VMs in one zone. In this case: A zonal endpoint group addresses the pod endpoints directly.
- **B:** Incorrect for this question. An internet endpoint group targets endpoints outside Google Cloud by hostname and port. Why the correct answer wins: A zonal endpoint group addresses the pod endpoints directly.
- **C:** Incorrect for this question. A serverless endpoint group fronts a Cloud Run service without a managed instance group. Why the correct answer wins: A zonal endpoint group addresses the pod endpoints directly.
- **D:** Incorrect for this question. The group adds and removes instances as the autoscaling signal changes. Why the correct answer wins: A zonal endpoint group addresses the pod endpoints directly.

### Question 49 — C

Answer: Expose the workload through the GKE Gateway controller. The Gateway controller supports shared gateways with per-route policy. A Gateway object configures the load balancer through the newer Kubernetes API. Local study-map skill 3.4 (GKE Ingress and Gateway), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. An Ingress object creates a Google Cloud load balancer from the manifest. Why the correct answer wins: The Gateway controller supports shared gateways with per-route policy.
- **B:** Incorrect for this question. The map selects a backend service from the request host and path. Why the correct answer wins: The Gateway controller supports shared gateways with per-route policy.
- **C:** Correct. A Gateway object configures the load balancer through the newer Kubernetes API. In this case: The Gateway controller supports shared gateways with per-route policy.
- **D:** Incorrect for this question. Weighted backends move a chosen share of traffic onto the new service. Why the correct answer wins: The Gateway controller supports shared gateways with per-route policy.

### Question 50 — A

Answer: Expose the workload through the GKE Ingress controller. The Ingress controller turns one object into a Google Cloud load balancer with no extra controller. An Ingress object creates a Google Cloud load balancer from the manifest. Local study-map skill 3.4 (GKE Ingress and Gateway), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. An Ingress object creates a Google Cloud load balancer from the manifest. In this case: The Ingress controller turns one object into a Google Cloud load balancer with no extra controller.
- **B:** Incorrect for this question. A Gateway object configures the load balancer through the newer Kubernetes API. Why the correct answer wins: The Ingress controller turns one object into a Google Cloud load balancer with no extra controller.
- **C:** Incorrect for this question. The map selects a backend service from the request host and path. Why the correct answer wins: The Ingress controller turns one object into a Google Cloud load balancer with no extra controller.
- **D:** Incorrect for this question. A zonal endpoint group addresses specific endpoints such as pods or VMs in one zone. Why the correct answer wins: The Ingress controller turns one object into a Google Cloud load balancer with no extra controller.

### Question 51 — B, E

Answers: Enable Cloud CDN on the backend service; Invalidate the cached object after the change. Caching shortens the fetch, and invalidation removes the corrected copy from the edge. The edge holds a copy of the response so later requests are served closer to the user. Invalidation removes the stale copy so the next request fetches the current version. Local study-map skill 3.5 (Cloud CDN), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. An internet endpoint group lets the CDN cache responses from backends outside Google Cloud. Why the correct answer wins: Caching shortens the fetch, and invalidation removes the corrected copy from the edge.
- **B:** Correct. Invalidation removes the stale copy so the next request fetches the current version. In this case: Caching shortens the fetch, and invalidation removes the corrected copy from the edge.
- **C:** Incorrect for this question. A longer lifetime reduces origin load and lengthens the window in which content can be stale. Why the correct answer wins: Caching shortens the fetch, and invalidation removes the corrected copy from the edge.
- **D:** Incorrect for this question. A signed URL authorises one object for a limited time without making the bucket public. Why the correct answer wins: Caching shortens the fetch, and invalidation removes the corrected copy from the edge.
- **E:** Correct. The edge holds a copy of the response so later requests are served closer to the user. In this case: Caching shortens the fetch, and invalidation removes the corrected copy from the edge.

### Question 52 — C

Answer: Raise the cache time to live. Extending the lifetime means each object is fetched far less often when it changes once a day. A longer lifetime reduces origin load and lengthens the window in which content can be stale. Local study-map skill 3.5 (Cloud CDN), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Invalidation removes the stale copy so the next request fetches the current version. Why the correct answer wins: Extending the lifetime means each object is fetched far less often when it changes once a day.
- **B:** Incorrect for this question. The edge holds a copy of the response so later requests are served closer to the user. Why the correct answer wins: Extending the lifetime means each object is fetched far less often when it changes once a day.
- **C:** Correct. A longer lifetime reduces origin load and lengthens the window in which content can be stale. In this case: Extending the lifetime means each object is fetched far less often when it changes once a day.
- **D:** Incorrect for this question. A signed URL authorises one object for a limited time without making the bucket public. Why the correct answer wins: Extending the lifetime means each object is fetched far less often when it changes once a day.

### Question 53 — B, E

Answers: Create a private Cloud DNS zone; Bind the private zone to the service project networks. The private zone stays internal, and the cross-project binding extends it. The zone answers only for clients inside the authorised networks. The binding makes the host project's zone answer for the service project's networks. Local study-map skill 3.6 (Cloud DNS Zones and Records), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Records are loaded and verified before the registrar points at the new name servers. Why the correct answer wins: The private zone stays internal, and the cross-project binding extends it.
- **B:** Correct. The binding makes the host project's zone answer for the service project's networks. In this case: The private zone stays internal, and the cross-project binding extends it.
- **C:** Incorrect for this question. Signatures let a resolver verify that the answer was not altered in transit. Why the correct answer wins: The private zone stays internal, and the cross-project binding extends it.
- **D:** Incorrect for this question. The zone answers queries from the internet for the domain it holds. Why the correct answer wins: The private zone stays internal, and the cross-project binding extends it.
- **E:** Correct. The zone answers only for clients inside the authorised networks. In this case: The private zone stays internal, and the cross-project binding extends it.

### Question 54 — A

Answer: Lower the record TTL before the cutover. A short TTL lets resolvers pick up the change quickly. Local study-map skill 3.6 (Cloud DNS Zones and Records), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. In this case: A short TTL lets resolvers pick up the change quickly.
- **B:** Incorrect for this question. Signatures let a resolver verify that the answer was not altered in transit. Why the correct answer wins: A short TTL lets resolvers pick up the change quickly.
- **C:** Incorrect for this question. The zone answers only for clients inside the authorised networks. Why the correct answer wins: A short TTL lets resolvers pick up the change quickly.
- **D:** Incorrect for this question. Records are loaded and verified before the registrar points at the new name servers. Why the correct answer wins: A short TTL lets resolvers pick up the change quickly.

### Question 55 — B

Answer: Apply a geolocation routing policy to the record set. The geolocation policy chooses the answer from the region the query came from. The answer depends on the source region of the query. Local study-map skill 3.7 (DNS Routing Policies), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. A short TTL lets resolvers pick up the new address quickly after the change. Why the correct answer wins: The geolocation policy chooses the answer from the region the query came from.
- **B:** Correct. The answer depends on the source region of the query. In this case: The geolocation policy chooses the answer from the region the query came from.
- **C:** Incorrect for this question. Records are loaded and verified before the registrar points at the new name servers. Why the correct answer wins: The geolocation policy chooses the answer from the region the query came from.
- **D:** Incorrect for this question. The standby answer is served when the primary fails its health check. Why the correct answer wins: The geolocation policy chooses the answer from the region the query came from.

### Question 56 — A

Answer: Apply a failover routing policy with a health-checked primary. A failover policy answers with the standby only while the primary is failing health checks. The standby answer is served when the primary fails its health check. Local study-map skill 3.7 (DNS Routing Policies), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. The standby answer is served when the primary fails its health check. In this case: A failover policy answers with the standby only while the primary is failing health checks.
- **B:** Incorrect for this question. Signatures let a resolver verify that the answer was not altered in transit. Why the correct answer wins: A failover policy answers with the standby only while the primary is failing health checks.
- **C:** Incorrect for this question. The answer depends on the source region of the query. Why the correct answer wins: A failover policy answers with the standby only while the primary is failing health checks.
- **D:** Incorrect for this question. A short TTL lets resolvers pick up the new address quickly after the change. Why the correct answer wins: A failover policy answers with the standby only while the primary is failing health checks.

### Question 57 — B

Answer: Enable DNSSEC on the zone. With signing enabled, the resolver can verify that the answer was not altered in transit. Signatures let a resolver verify that the answer was not altered in transit. Local study-map skill 3.8 (DNSSEC), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 3 (configuring managed network services): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The zone answers only for clients inside the authorised networks. Why the correct answer wins: With signing enabled, the resolver can verify that the answer was not altered in transit.
- **B:** Correct. Signatures let a resolver verify that the answer was not altered in transit. In this case: With signing enabled, the resolver can verify that the answer was not altered in transit.
- **C:** Incorrect for this question. The logs record the names that clients asked for and the answers they received. Why the correct answer wins: With signing enabled, the resolver can verify that the answer was not altered in transit.
- **D:** Incorrect for this question. Records are loaded and verified before the registrar points at the new name servers. Why the correct answer wins: With signing enabled, the resolver can verify that the answer was not altered in transit.

### Question 58 — A, D

Answers: Order a Dedicated Interconnect connection; Create a VLAN attachment on Cloud Router. The dedicated circuit uses its cage, and the VLAN attachment carries the subnet. A private physical circuit connects the premises to a Google colocation facility. The attachment carries one VLAN over the interconnect and peers with the router. Local study-map skill 4.1 (Dedicated Interconnect), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. A private physical circuit connects the premises to a Google colocation facility. In this case: The dedicated circuit uses its cage, and the VLAN attachment carries the subnet.
- **B:** Incorrect for this question. A service provider carries the circuit to Google on the customer behalf. Why the correct answer wins: The dedicated circuit uses its cage, and the VLAN attachment carries the subnet.
- **C:** Incorrect for this question. Link-layer encryption protects each hop of the circuit between the premises and Google. Why the correct answer wins: The dedicated circuit uses its cage, and the VLAN attachment carries the subnet.
- **D:** Correct. The attachment carries one VLAN over the interconnect and peers with the router. In this case: The dedicated circuit uses its cage, and the VLAN attachment carries the subnet.
- **E:** Incorrect for this question. A dedicated circuit connects Google Cloud directly to another cloud provider. Why the correct answer wins: The dedicated circuit uses its cage, and the VLAN attachment carries the subnet.

### Question 59 — C

Answer: Order a Partner Interconnect connection. A partner hands the circuit to Google from a nearby provider location. A service provider carries the circuit to Google on the customer behalf. Local study-map skill 4.1 (Dedicated Interconnect), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. A private physical circuit connects the premises to a Google colocation facility. Why the correct answer wins: A partner hands the circuit to Google from a nearby provider location.
- **B:** Incorrect for this question. A dedicated circuit connects Google Cloud directly to another cloud provider. Why the correct answer wins: A partner hands the circuit to Google from a nearby provider location.
- **C:** Correct. A service provider carries the circuit to Google on the customer behalf. In this case: A partner hands the circuit to Google from a nearby provider location.
- **D:** Incorrect for this question. One tunnel gives a single path and no automatic failover. Why the correct answer wins: A partner hands the circuit to Google from a nearby provider location.

### Question 60 — B

Answer: Set the Cloud Router ASN to a private value that differs from the peer. The two peers must not share an autonomous system number. Two peers cannot form a session when both claim the same autonomous system number. Local study-map skill 4.1 (Dedicated Interconnect), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The lower discriminator wins when the same prefix arrives over two attachments. Why the correct answer wins: The two peers must not share an autonomous system number.
- **B:** Correct. Two peers cannot form a session when both claim the same autonomous system number. In this case: The two peers must not share an autonomous system number.
- **C:** Incorrect for this question. The attachment carries one VLAN over the interconnect and peers with the router. Why the correct answer wins: The two peers must not share an autonomous system number.
- **D:** Incorrect for this question. The echo detects a dead path faster than the BGP hold timer allows. Why the correct answer wins: The two peers must not share an autonomous system number.

### Question 61 — D

Answer: Order a Cross-Cloud Interconnect connection. Cross-Cloud Interconnect is a dedicated circuit to that provider. A dedicated circuit connects Google Cloud directly to another cloud provider. Local study-map skill 4.2 (Partner and Cross-Cloud Interconnect), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. A private physical circuit connects the premises to a Google colocation facility. Why the correct answer wins: Cross-Cloud Interconnect is a dedicated circuit to that provider.
- **B:** Incorrect for this question. Two interfaces in different zones give the tunnel pair a 99.99% topology. Why the correct answer wins: Cross-Cloud Interconnect is a dedicated circuit to that provider.
- **C:** Incorrect for this question. A service provider carries the circuit to Google on the customer behalf. Why the correct answer wins: Cross-Cloud Interconnect is a dedicated circuit to that provider.
- **D:** Correct. A dedicated circuit connects Google Cloud directly to another cloud provider. In this case: Cross-Cloud Interconnect is a dedicated circuit to that provider.

### Question 62 — A

Answer: Enable MACsec on the interconnect. MACsec encrypts the circuit between the premises and the Google edge. Link-layer encryption protects each hop of the circuit between the premises and Google. Local study-map skill 4.2 (Partner and Cross-Cloud Interconnect), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. Link-layer encryption protects each hop of the circuit between the premises and Google. In this case: MACsec encrypts the circuit between the premises and the Google edge.
- **B:** Incorrect for this question. IPsec tunnels inside the interconnect give encryption where MACsec is not available. Why the correct answer wins: MACsec encrypts the circuit between the premises and the Google edge.
- **C:** Incorrect for this question. Two interfaces in different zones give the tunnel pair a 99.99% topology. Why the correct answer wins: MACsec encrypts the circuit between the premises and the Google edge.
- **D:** Incorrect for this question. The attachment carries one VLAN over the interconnect and peers with the router. Why the correct answer wins: MACsec encrypts the circuit between the premises and the Google edge.

### Question 63 — B, D

Answers: Deploy an HA VPN gateway with two interfaces; Lower the tunnel MTU to 1460 bytes. The two-interface gateway gives redundancy, and the smaller MTU fits the tunnel. Two interfaces in different zones give the tunnel pair a 99.99% topology. A smaller MTU leaves room for the tunnel encapsulation headers that reduce usable payload. Local study-map skill 4.3 (HA VPN), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The echo detects a dead path faster than the BGP hold timer allows. Why the correct answer wins: The two-interface gateway gives redundancy, and the smaller MTU fits the tunnel.
- **B:** Correct. A smaller MTU leaves room for the tunnel encapsulation headers that reduce usable payload. In this case: The two-interface gateway gives redundancy, and the smaller MTU fits the tunnel.
- **C:** Incorrect for this question. The attachment carries one VLAN over the interconnect and peers with the router. Why the correct answer wins: The two-interface gateway gives redundancy, and the smaller MTU fits the tunnel.
- **D:** Correct. Two interfaces in different zones give the tunnel pair a 99.99% topology. In this case: The two-interface gateway gives redundancy, and the smaller MTU fits the tunnel.
- **E:** Incorrect for this question. One tunnel gives a single path and no automatic failover. Why the correct answer wins: The two-interface gateway gives redundancy, and the smaller MTU fits the tunnel.

### Question 64 — C

Answer: Deploy an HA VPN gateway with two interfaces. Placing the interface pair in different zones means one zone can be lost without losing the tunnels. Two interfaces in different zones give the tunnel pair a 99.99% topology. Local study-map skill 4.3 (HA VPN), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. A private physical circuit connects the premises to a Google colocation facility. Why the correct answer wins: Placing the interface pair in different zones means one zone can be lost without losing the tunnels.
- **B:** Incorrect for this question. The attachment carries one VLAN over the interconnect and peers with the router. Why the correct answer wins: Placing the interface pair in different zones means one zone can be lost without losing the tunnels.
- **C:** Correct. Two interfaces in different zones give the tunnel pair a 99.99% topology. In this case: Placing the interface pair in different zones means one zone can be lost without losing the tunnels.
- **D:** Incorrect for this question. One tunnel gives a single path and no automatic failover. Why the correct answer wins: Placing the interface pair in different zones means one zone can be lost without losing the tunnels.

### Question 65 — C

Answer: Deploy a Classic VPN with a single tunnel. An HA VPN gateway provides the pair of tunnels the redundancy requirement describes. One tunnel gives a single path and no automatic failover. Local study-map skill 4.3 (HA VPN), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Two interfaces in different zones give the tunnel pair a 99.99% topology. Why the correct answer wins: An HA VPN gateway provides the pair of tunnels the redundancy requirement describes.
- **B:** Incorrect for this question. Two peers cannot form a session when both claim the same autonomous system number. Why the correct answer wins: An HA VPN gateway provides the pair of tunnels the redundancy requirement describes.
- **C:** Correct. One tunnel gives a single path and no automatic failover. In this case: An HA VPN gateway provides the pair of tunnels the redundancy requirement describes.
- **D:** Incorrect for this question. A private physical circuit connects the premises to a Google colocation facility. Why the correct answer wins: An HA VPN gateway provides the pair of tunnels the redundancy requirement describes.

### Question 66 — B

Answer: Deploy a Classic VPN with a single tunnel. Classic VPN supports the policy-based tunnel mode such a device requires. One tunnel gives a single path and no automatic failover. Local study-map skill 4.4 (Classic VPN), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Two interfaces in different zones give the tunnel pair a 99.99% topology. Why the correct answer wins: Classic VPN supports the policy-based tunnel mode such a device requires.
- **B:** Correct. One tunnel gives a single path and no automatic failover. In this case: Classic VPN supports the policy-based tunnel mode such a device requires.
- **C:** Incorrect for this question. A private physical circuit connects the premises to a Google colocation facility. Why the correct answer wins: Classic VPN supports the policy-based tunnel mode such a device requires.
- **D:** Incorrect for this question. Two peers cannot form a session when both claim the same autonomous system number. Why the correct answer wins: Classic VPN supports the policy-based tunnel mode such a device requires.

### Question 67 — D

Answer: Enable Bidirectional Forwarding Detection with a short interval. BFD detects the dead path before the hold timer does. The echo detects a dead path faster than the BGP hold timer allows. Local study-map skill 4.5 (Cloud Router BGP), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The lower discriminator wins when the same prefix arrives over two attachments. Why the correct answer wins: BFD detects the dead path before the hold timer does.
- **B:** Incorrect for this question. Two peers cannot form a session when both claim the same autonomous system number. Why the correct answer wins: BFD detects the dead path before the hold timer does.
- **C:** Incorrect for this question. The older selection order picks a different preferred path when the inputs tie. Why the correct answer wins: BFD detects the dead path before the hold timer does.
- **D:** Correct. The echo detects a dead path faster than the BGP hold timer allows. In this case: BFD detects the dead path before the hold timer does.

### Question 68 — C

Answer: Advertise only the ranges the peer needs. A custom advertisement list announces the chosen aggregates and hides the individual subnets. The router advertises a chosen prefix list instead of every subnet in the VPC. Local study-map skill 4.5 (Cloud Router BGP), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The lower number wins when a static route and a dynamic route carry the same prefix. Why the correct answer wins: A custom advertisement list announces the chosen aggregates and hides the individual subnets.
- **B:** Incorrect for this question. The lower discriminator wins when the same prefix arrives over two attachments. Why the correct answer wins: A custom advertisement list announces the chosen aggregates and hides the individual subnets.
- **C:** Correct. The router advertises a chosen prefix list instead of every subnet in the VPC. In this case: A custom advertisement list announces the chosen aggregates and hides the individual subnets.
- **D:** Incorrect for this question. Two peers cannot form a session when both claim the same autonomous system number. Why the correct answer wins: A custom advertisement list announces the chosen aggregates and hides the individual subnets.

### Question 69 — B, D

Answers: Set the Cloud Router ASN to a private value that differs from the peer; Advertise only the ranges the peer needs. The ASN must differ from the peer, and the advertisement list limits the prefixes. Two peers cannot form a session when both claim the same autonomous system number. The router advertises a chosen prefix list instead of every subnet in the VPC. Local study-map skill 4.5 (Cloud Router BGP), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The older selection order picks a different preferred path when the inputs tie. Why the correct answer wins: The ASN must differ from the peer, and the advertisement list limits the prefixes.
- **B:** Correct. Two peers cannot form a session when both claim the same autonomous system number. In this case: The ASN must differ from the peer, and the advertisement list limits the prefixes.
- **C:** Incorrect for this question. The lower discriminator wins when the same prefix arrives over two attachments. Why the correct answer wins: The ASN must differ from the peer, and the advertisement list limits the prefixes.
- **D:** Correct. The router advertises a chosen prefix list instead of every subnet in the VPC. In this case: The ASN must differ from the peer, and the advertisement list limits the prefixes.
- **E:** Incorrect for this question. The echo detects a dead path faster than the BGP hold timer allows. Why the correct answer wins: The ASN must differ from the peer, and the advertisement list limits the prefixes.

### Question 70 — D

Answer: Enable Bidirectional Forwarding Detection with a short interval. BFD detects the degraded path while the session still looks established. The echo detects a dead path faster than the BGP hold timer allows. Local study-map skill 4.6 (BFD and Failover Timers), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The lower number wins when a static route and a dynamic route carry the same prefix. Why the correct answer wins: BFD detects the degraded path while the session still looks established.
- **B:** Incorrect for this question. The lower discriminator wins when the same prefix arrives over two attachments. Why the correct answer wins: BFD detects the degraded path while the session still looks established.
- **C:** Incorrect for this question. Two peers cannot form a session when both claim the same autonomous system number. Why the correct answer wins: BFD detects the degraded path while the session still looks established.
- **D:** Correct. The echo detects a dead path faster than the BGP hold timer allows. In this case: BFD detects the degraded path while the session still looks established.

### Question 71 — A

Answer: Switch best path selection back to the legacy behaviour. The best path selection setting decides how ties break. The older selection order picks a different preferred path when the inputs tie. Local study-map skill 4.7 (Route Advertisement and Priority), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. The older selection order picks a different preferred path when the inputs tie. In this case: The best path selection setting decides how ties break.
- **B:** Incorrect for this question. The lower discriminator wins when the same prefix arrives over two attachments. Why the correct answer wins: The best path selection setting decides how ties break.
- **C:** Incorrect for this question. Two peers cannot form a session when both claim the same autonomous system number. Why the correct answer wins: The best path selection setting decides how ties break.
- **D:** Incorrect for this question. The lower number wins when a static route and a dynamic route carry the same prefix. Why the correct answer wins: The best path selection setting decides how ties break.

### Question 72 — D

Answer: Switch the Cloud Router to global dynamic routing mode. In global mode the learned prefixes are offered to subnets in every region, not only the learning one. Routes learned in one region are available to subnets in every region. Local study-map skill 4.7 (Route Advertisement and Priority), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The lower discriminator wins when the same prefix arrives over two attachments. Why the correct answer wins: In global mode the learned prefixes are offered to subnets in every region, not only the learning one.
- **B:** Incorrect for this question. Routes stay inside the region that learned them. Why the correct answer wins: In global mode the learned prefixes are offered to subnets in every region, not only the learning one.
- **C:** Incorrect for this question. The lower number wins when a static route and a dynamic route carry the same prefix. Why the correct answer wins: In global mode the learned prefixes are offered to subnets in every region, not only the learning one.
- **D:** Correct. Routes learned in one region are available to subnets in every region. In this case: In global mode the learned prefixes are offered to subnets in every region, not only the learning one.

### Question 73 — B

Answer: Run HA VPN over Cloud Interconnect instead of MACsec. IPsec tunnels running over the interconnect encrypt the payload even without MACsec support. IPsec tunnels inside the interconnect give encryption where MACsec is not available. Local study-map skill 4.8 (Interconnect Encryption and SLA), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 4 (configuring and implementing hybrid and multicloud network interconnectivity): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Two interfaces in different zones give the tunnel pair a 99.99% topology. Why the correct answer wins: IPsec tunnels running over the interconnect encrypt the payload even without MACsec support.
- **B:** Correct. IPsec tunnels inside the interconnect give encryption where MACsec is not available. In this case: IPsec tunnels running over the interconnect encrypt the payload even without MACsec support.
- **C:** Incorrect for this question. The attachment carries one VLAN over the interconnect and peers with the router. Why the correct answer wins: IPsec tunnels running over the interconnect encrypt the payload even without MACsec support.
- **D:** Incorrect for this question. Link-layer encryption protects each hop of the circuit between the premises and Google. Why the correct answer wins: IPsec tunnels running over the interconnect encrypt the payload even without MACsec support.

### Question 74 — C

Answer: Enable firewall rules logging. Rule logging records the specific firewall rule that decided each connection. The logs show which rule allowed or denied each connection. Local study-map skill 5.1 (Logging for Network Components), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The logs record the translated address and port chosen for each flow. Why the correct answer wins: Rule logging records the specific firewall rule that decided each connection.
- **B:** Incorrect for this question. The logs record sampled connections with source, destination, port and byte counts. Why the correct answer wins: Rule logging records the specific firewall rule that decided each connection.
- **C:** Correct. The logs show which rule allowed or denied each connection. In this case: Rule logging records the specific firewall rule that decided each connection.
- **D:** Incorrect for this question. The logs record the names that clients asked for and the answers they received. Why the correct answer wins: Rule logging records the specific firewall rule that decided each connection.

### Question 75 — A

Answer: Enable Cloud DNS query logging. Query logging keeps the client, the name asked for and the answer returned for each lookup. The logs record the names that clients asked for and the answers they received. Local study-map skill 5.1 (Logging for Network Components), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. The logs record the names that clients asked for and the answers they received. In this case: Query logging keeps the client, the name asked for and the answer returned for each lookup.
- **B:** Incorrect for this question. The logs record sampled connections with source, destination, port and byte counts. Why the correct answer wins: Query logging keeps the client, the name asked for and the answer returned for each lookup.
- **C:** Incorrect for this question. The logs show which rule allowed or denied each connection. Why the correct answer wins: Query logging keeps the client, the name asked for and the answer returned for each lookup.
- **D:** Incorrect for this question. The logs record the translated address and port chosen for each flow. Why the correct answer wins: Query logging keeps the client, the name asked for and the answer returned for each lookup.

### Question 76 — D

Answer: Publish a custom metric from the appliance. A custom metric writes that number into Monitoring. The appliance reports a signal that no managed metric covers. Local study-map skill 5.2 (Network Metrics and Dashboards), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Matching log entries become a counter the alerting policy can use. Why the correct answer wins: A custom metric writes that number into Monitoring.
- **B:** Incorrect for this question. The policy notifies on the threshold instead of waiting for a user report. Why the correct answer wins: A custom metric writes that number into Monitoring.
- **C:** Incorrect for this question. The alert fires on the reliability users experience rather than on a single resource. Why the correct answer wins: A custom metric writes that number into Monitoring.
- **D:** Correct. The appliance reports a signal that no managed metric covers. In this case: A custom metric writes that number into Monitoring.

### Question 77 — D

Answer: Alert on the error budget of the service objective. Alerting on the error budget tracks the reliability that users actually feel rather than raw counters. The alert fires on the reliability users experience rather than on a single resource. Local study-map skill 5.2 (Network Metrics and Dashboards), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Matching log entries become a counter the alerting policy can use. Why the correct answer wins: Alerting on the error budget tracks the reliability that users actually feel rather than raw counters.
- **B:** Incorrect for this question. The policy notifies on the threshold instead of waiting for a user report. Why the correct answer wins: Alerting on the error budget tracks the reliability that users actually feel rather than raw counters.
- **C:** Incorrect for this question. The appliance reports a signal that no managed metric covers. Why the correct answer wins: Alerting on the error budget tracks the reliability that users actually feel rather than raw counters.
- **D:** Correct. The alert fires on the reliability users experience rather than on a single resource. In this case: Alerting on the error budget tracks the reliability that users actually feel rather than raw counters.

### Question 78 — D

Answer: Run a Connectivity Test between the two endpoints. A connectivity test evaluates the path and names the rule that blocks it. The test evaluates the configuration along the path and names the blocking rule or missing route. Local study-map skill 5.3 (Connectivity Tests), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The analysis ranks the flows that consume the most bandwidth. Why the correct answer wins: A connectivity test evaluates the path and names the rule that blocks it.
- **B:** Incorrect for this question. The dashboard separates loss on the Google network from loss outside it. Why the correct answer wins: A connectivity test evaluates the path and names the rule that blocks it.
- **C:** Incorrect for this question. The view shows the paths and throughput between the resources that carry the traffic. Why the correct answer wins: A connectivity test evaluates the path and names the rule that blocks it.
- **D:** Correct. The test evaluates the configuration along the path and names the blocking rule or missing route. In this case: A connectivity test evaluates the path and names the rule that blocks it.

### Question 79 — C, D

Answers: Run a Connectivity Test between the two endpoints; Enable firewall rules logging. The test names the blocking rule, and the firewall log shows the decision recorded for that flow. The test evaluates the configuration along the path and names the blocking rule or missing route. The logs show which rule allowed or denied each connection. Local study-map skill 5.3 (Connectivity Tests), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The analysis ranks the flows that consume the most bandwidth. Why the correct answer wins: The test names the blocking rule, and the firewall log shows the decision recorded for that flow.
- **B:** Incorrect for this question. The dashboard separates loss on the Google network from loss outside it. Why the correct answer wins: The test names the blocking rule, and the firewall log shows the decision recorded for that flow.
- **C:** Correct. The test evaluates the configuration along the path and names the blocking rule or missing route. In this case: The test names the blocking rule, and the firewall log shows the decision recorded for that flow.
- **D:** Correct. The logs show which rule allowed or denied each connection. In this case: The test names the blocking rule, and the firewall log shows the decision recorded for that flow.
- **E:** Incorrect for this question. The view shows the paths and throughput between the resources that carry the traffic. Why the correct answer wins: The test names the blocking rule, and the firewall log shows the decision recorded for that flow.

### Question 80 — C

Answer: Check the Performance Dashboard for packet loss. The dashboard reports latency and loss per segment, so the Google portion is separated from the rest. The dashboard separates loss on the Google network from loss outside it. Local study-map skill 5.4 (Performance Dashboard and Packet Loss), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The view shows the paths and throughput between the resources that carry the traffic. Why the correct answer wins: The dashboard reports latency and loss per segment, so the Google portion is separated from the rest.
- **B:** Incorrect for this question. The analysis ranks the flows that consume the most bandwidth. Why the correct answer wins: The dashboard reports latency and loss per segment, so the Google portion is separated from the rest.
- **C:** Correct. The dashboard separates loss on the Google network from loss outside it. In this case: The dashboard reports latency and loss per segment, so the Google portion is separated from the rest.
- **D:** Incorrect for this question. The probe shows where the payload stops fitting along the path. Why the correct answer wins: The dashboard reports latency and loss per segment, so the Google portion is separated from the rest.

### Question 81 — A

Answer: Test the path with a large ping and the do-not-fragment bit. A large probe with the do-not-fragment bit shows where the payload stops fitting. The probe shows where the payload stops fitting along the path. Local study-map skill 5.4 (Performance Dashboard and Packet Loss), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. The probe shows where the payload stops fitting along the path. In this case: A large probe with the do-not-fragment bit shows where the payload stops fitting.
- **B:** Incorrect for this question. The dashboard separates loss on the Google network from loss outside it. Why the correct answer wins: A large probe with the do-not-fragment bit shows where the payload stops fitting.
- **C:** Incorrect for this question. A path that disagrees about frame size drops or fragments large packets, which shows up as stalled bulk transfers. Why the correct answer wins: A large probe with the do-not-fragment bit shows where the payload stops fitting.
- **D:** Incorrect for this question. The view shows the paths and throughput between the resources that carry the traffic. Why the correct answer wins: A large probe with the do-not-fragment bit shows where the payload stops fitting.

### Question 82 — B

Answer: Read the Network Analyzer findings. The analyser reports quota pressure and configuration faults together in one findings list. The analyser reports misconfigurations and quota risks that would otherwise surface as an outage. Local study-map skill 5.5 (Firewall Insights and Network Analyzer), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The insight names rules that never match because a broader rule already covered them. Why the correct answer wins: The analyser reports quota pressure and configuration faults together in one findings list.
- **B:** Correct. The analyser reports misconfigurations and quota risks that would otherwise surface as an outage. In this case: The analyser reports quota pressure and configuration faults together in one findings list.
- **C:** Incorrect for this question. The test evaluates the configuration along the path and names the blocking rule or missing route. Why the correct answer wins: The analyser reports quota pressure and configuration faults together in one findings list.
- **D:** Incorrect for this question. The analysis ranks the flows that consume the most bandwidth. Why the correct answer wins: The analyser reports quota pressure and configuration faults together in one findings list.

### Question 83 — A, C

Answers: Review Firewall Insights for shadowed rules; Read the Network Analyzer findings. Firewall Insights lists the dead rules, and the analyser reports the risks. The insight names rules that never match because a broader rule already covered them. The analyser reports misconfigurations and quota risks that would otherwise surface as an outage. Local study-map skill 5.5 (Firewall Insights and Network Analyzer), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. The insight names rules that never match because a broader rule already covered them. In this case: Firewall Insights lists the dead rules, and the analyser reports the risks.
- **B:** Incorrect for this question. The logs record the names that clients asked for and the answers they received. Why the correct answer wins: Firewall Insights lists the dead rules, and the analyser reports the risks.
- **C:** Correct. The analyser reports misconfigurations and quota risks that would otherwise surface as an outage. In this case: Firewall Insights lists the dead rules, and the analyser reports the risks.
- **D:** Incorrect for this question. The test evaluates the configuration along the path and names the blocking rule or missing route. Why the correct answer wins: Firewall Insights lists the dead rules, and the analyser reports the risks.
- **E:** Incorrect for this question. The analysis ranks the flows that consume the most bandwidth. Why the correct answer wins: Firewall Insights lists the dead rules, and the analyser reports the risks.

### Question 84 — B

Answer: Inspect the flow in Network Topology. The topology view renders the paths and throughput that are actually in use. The view shows the paths and throughput between the resources that carry the traffic. Local study-map skill 5.6 (Flow Analyzer and Network Topology), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The test evaluates the configuration along the path and names the blocking rule or missing route. Why the correct answer wins: The topology view renders the paths and throughput that are actually in use.
- **B:** Correct. The view shows the paths and throughput between the resources that carry the traffic. In this case: The topology view renders the paths and throughput that are actually in use.
- **C:** Incorrect for this question. The analysis ranks the flows that consume the most bandwidth. Why the correct answer wins: The topology view renders the paths and throughput that are actually in use.
- **D:** Incorrect for this question. The dashboard separates loss on the Google network from loss outside it. Why the correct answer wins: The topology view renders the paths and throughput that are actually in use.

### Question 85 — C

Answer: Query Flow Analyzer for the top talkers. Flow Analyzer orders the flows by volume so the heaviest consumers come first. The analysis ranks the flows that consume the most bandwidth. Local study-map skill 5.6 (Flow Analyzer and Network Topology), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The view shows the paths and throughput between the resources that carry the traffic. Why the correct answer wins: Flow Analyzer orders the flows by volume so the heaviest consumers come first.
- **B:** Incorrect for this question. The insight names rules that never match because a broader rule already covered them. Why the correct answer wins: Flow Analyzer orders the flows by volume so the heaviest consumers come first.
- **C:** Correct. The analysis ranks the flows that consume the most bandwidth. In this case: Flow Analyzer orders the flows by volume so the heaviest consumers come first.
- **D:** Incorrect for this question. The dashboard separates loss on the Google network from loss outside it. Why the correct answer wins: Flow Analyzer orders the flows by volume so the heaviest consumers come first.

### Question 86 — D

Answer: Compare the BGP session state on both peers. Comparing the session on both ends shows which peer is failing to send or accept prefixes. A session that is established on one side only points at the shared configuration. Local study-map skill 5.7 (BGP and VPN Troubleshooting), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The test evaluates the configuration along the path and names the blocking rule or missing route. Why the correct answer wins: Comparing the session on both ends shows which peer is failing to send or accept prefixes.
- **B:** Incorrect for this question. The echo detects a dead path faster than the BGP hold timer allows. Why the correct answer wins: Comparing the session on both ends shows which peer is failing to send or accept prefixes.
- **C:** Incorrect for this question. The lower discriminator wins when the same prefix arrives over two attachments. Why the correct answer wins: Comparing the session on both ends shows which peer is failing to send or accept prefixes.
- **D:** Correct. A session that is established on one side only points at the shared configuration. In this case: Comparing the session on both ends shows which peer is failing to send or accept prefixes.

### Question 87 — A

Answer: Drain the backend before removing it. New flows go elsewhere while the existing sessions finish. Draining lets in-flight requests finish instead of resetting the connections. Local study-map skill 5.8 (Traffic Draining and Migration), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 5 (managing, monitoring, and troubleshooting network operations): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. Draining lets in-flight requests finish instead of resetting the connections. In this case: New flows go elsewhere while the existing sessions finish.
- **B:** Incorrect for this question. The view shows the paths and throughput between the resources that carry the traffic. Why the correct answer wins: New flows go elsewhere while the existing sessions finish.
- **C:** Incorrect for this question. Removing a backend waits for in-flight requests to finish before the backend is detached. Why the correct answer wins: New flows go elsewhere while the existing sessions finish.
- **D:** Incorrect for this question. The analysis ranks the flows that consume the most bandwidth. Why the correct answer wins: New flows go elsewhere while the existing sessions finish.

### Question 88 — B

Answer: Attach a Cloud Armor backend security policy. A backend policy evaluates the request origin once traffic has reached the load balancer. The policy filters traffic that has already reached the load balancer. Local study-map skill 6.1 (Cloud Armor Policies), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The model learns the normal request pattern and suggests rules for the anomaly it detects. Why the correct answer wins: A backend policy evaluates the request origin once traffic has reached the load balancer.
- **B:** Correct. The policy filters traffic that has already reached the load balancer. In this case: A backend policy evaluates the request origin once traffic has reached the load balancer.
- **C:** Incorrect for this question. The rule matches the signatures of that class of request. Why the correct answer wins: A backend policy evaluates the request origin once traffic has reached the load balancer.
- **D:** Incorrect for this question. The policy filters traffic at the edge before it is proxied to a backend. Why the correct answer wins: A backend policy evaluates the request origin once traffic has reached the load balancer.

### Question 89 — A

Answer: Attach a Cloud Armor edge security policy. An edge policy evaluates at the edge, so the proxy never handles the blocked request. The policy filters traffic at the edge before it is proxied to a backend. Local study-map skill 6.1 (Cloud Armor Policies), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. The policy filters traffic at the edge before it is proxied to a backend. In this case: An edge policy evaluates at the edge, so the proxy never handles the blocked request.
- **B:** Incorrect for this question. The policy filters traffic that has already reached the load balancer. Why the correct answer wins: An edge policy evaluates at the edge, so the proxy never handles the blocked request.
- **C:** Incorrect for this question. Known bot categories are classified so the rule can allow or block them by intent. Why the correct answer wins: An edge policy evaluates at the edge, so the proxy never handles the blocked request.
- **D:** Incorrect for this question. A client that exceeds the threshold is blocked for the ban duration. Why the correct answer wins: An edge policy evaluates at the edge, so the proxy never handles the blocked request.

### Question 90 — D

Answer: Add a preconfigured WAF rule for the attack class. A preconfigured WAF rule recognises that injection class. The rule matches the signatures of that class of request. Local study-map skill 6.2 (WAF and Bot Management), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Requests from addresses on the threat lists are matched without writing rules by hand. Why the correct answer wins: A preconfigured WAF rule recognises that injection class.
- **B:** Incorrect for this question. The model learns the normal request pattern and suggests rules for the anomaly it detects. Why the correct answer wins: A preconfigured WAF rule recognises that injection class.
- **C:** Incorrect for this question. Known bot categories are classified so the rule can allow or block them by intent. Why the correct answer wins: A preconfigured WAF rule recognises that injection class.
- **D:** Correct. The rule matches the signatures of that class of request. In this case: A preconfigured WAF rule recognises that injection class.

### Question 91 — D

Answer: Enable bot management on the policy. Bot management sorts automated traffic into categories so policy can admit one group and refuse the other. Known bot categories are classified so the rule can allow or block them by intent. Local study-map skill 6.2 (WAF and Bot Management), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The rule matches the signatures of that class of request. Why the correct answer wins: Bot management sorts automated traffic into categories so policy can admit one group and refuse the other.
- **B:** Incorrect for this question. The model learns the normal request pattern and suggests rules for the anomaly it detects. Why the correct answer wins: Bot management sorts automated traffic into categories so policy can admit one group and refuse the other.
- **C:** Incorrect for this question. Requests from addresses on the threat lists are matched without writing rules by hand. Why the correct answer wins: Bot management sorts automated traffic into categories so policy can admit one group and refuse the other.
- **D:** Correct. Known bot categories are classified so the rule can allow or block them by intent. In this case: Bot management sorts automated traffic into categories so policy can admit one group and refuse the other.

### Question 92 — B

Answer: Rely on the default DDoS protection and add a rate limit. The always-on DDoS defence absorbs the volumetric flood before any rule is written. The always-on protection absorbs volumetric floods, and the rate limit covers application-level floods. Local study-map skill 6.3 (DDoS and Rate Limiting), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Requests from addresses on the threat lists are matched without writing rules by hand. Why the correct answer wins: The always-on DDoS defence absorbs the volumetric flood before any rule is written.
- **B:** Correct. The always-on protection absorbs volumetric floods, and the rate limit covers application-level floods. In this case: The always-on DDoS defence absorbs the volumetric flood before any rule is written.
- **C:** Incorrect for this question. A client that exceeds the threshold is blocked for the ban duration. Why the correct answer wins: The always-on DDoS defence absorbs the volumetric flood before any rule is written.
- **D:** Incorrect for this question. The model learns the normal request pattern and suggests rules for the anomaly it detects. Why the correct answer wins: The always-on DDoS defence absorbs the volumetric flood before any rule is written.

### Question 93 — A, B

Answers: Create a hierarchical firewall policy at the organisation; Move the inspection to NGFW Enterprise. An organisation policy is inherited by every project, and the enterprise tier inspects payloads. The policy applies to every project under the organisation node. The enterprise tier adds layer 7 inspection through the managed engine. Local study-map skill 6.4 (NGFW Tiers and Policies), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. The enterprise tier adds layer 7 inspection through the managed engine. In this case: An organisation policy is inherited by every project, and the enterprise tier inspects payloads.
- **B:** Correct. The policy applies to every project under the organisation node. In this case: An organisation policy is inherited by every project, and the enterprise tier inspects payloads.
- **C:** Incorrect for this question. The lowest-numbered matching rule decides, so order changes the outcome. Why the correct answer wins: An organisation policy is inherited by every project, and the enterprise tier inspects payloads.
- **D:** Incorrect for this question. The policy applies only in the region it belongs to. Why the correct answer wins: An organisation policy is inherited by every project, and the enterprise tier inspects payloads.
- **E:** Incorrect for this question. The rule applies to instances carrying the tag and allows or denies the stated traffic. Why the correct answer wins: An organisation policy is inherited by every project, and the enterprise tier inspects payloads.

### Question 94 — B

Answer: Create a global network firewall policy. A global policy is evaluated in every region of the network it is attached to. The policy is evaluated for the networks it is associated with, in every region. Local study-map skill 6.4 (NGFW Tiers and Policies), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. The policy applies to every project under the organisation node. Why the correct answer wins: A global policy is evaluated in every region of the network it is attached to.
- **B:** Correct. The policy is evaluated for the networks it is associated with, in every region. In this case: A global policy is evaluated in every region of the network it is attached to.
- **C:** Incorrect for this question. The rule applies to instances carrying the tag and allows or denies the stated traffic. Why the correct answer wins: A global policy is evaluated in every region of the network it is attached to.
- **D:** Incorrect for this question. The policy applies only in the region it belongs to. Why the correct answer wins: A global policy is evaluated in every region of the network it is attached to.

### Question 95 — B

Answer: Reorder the rules by priority. Evaluation stops at the lowest-numbered matching rule, so a broader earlier rule wins. The lowest-numbered matching rule decides, so order changes the outcome. Local study-map skill 6.4 (NGFW Tiers and Policies), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Any source may reach the instance on the default ports, which defeats the segmentation. Why the correct answer wins: Evaluation stops at the lowest-numbered matching rule, so a broader earlier rule wins.
- **B:** Correct. The lowest-numbered matching rule decides, so order changes the outcome. In this case: Evaluation stops at the lowest-numbered matching rule, so a broader earlier rule wins.
- **C:** Incorrect for this question. The standard tier adds the policy model and threat intelligence over the base rules. Why the correct answer wins: Evaluation stops at the lowest-numbered matching rule, so a broader earlier rule wins.
- **D:** Incorrect for this question. Default-allow egress is replaced by an explicit deny, and only named destinations are permitted. Why the correct answer wins: Evaluation stops at the lowest-numbered matching rule, so a broader earlier rule wins.

### Question 96 — A

Answer: Divide the network into micro-segmented tiers. Segmenting by tier means each workload carries its own tag and only the flows it needs are permitted. Each tier carries a different tag and only the required flows are allowed between tiers. Local study-map skill 6.5 (Firewall Rules and Micro-Segmentation), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. Each tier carries a different tag and only the required flows are allowed between tiers. In this case: Segmenting by tier means each workload carries its own tag and only the flows it needs are permitted.
- **B:** Incorrect for this question. Any source may reach the instance on the default ports, which defeats the segmentation. Why the correct answer wins: Segmenting by tier means each workload carries its own tag and only the flows it needs are permitted.
- **C:** Incorrect for this question. The enterprise tier adds layer 7 inspection through the managed engine. Why the correct answer wins: Segmenting by tier means each workload carries its own tag and only the flows it needs are permitted.
- **D:** Incorrect for this question. The lowest-numbered matching rule decides, so order changes the outcome. Why the correct answer wins: Segmenting by tier means each workload carries its own tag and only the flows it needs are permitted.

### Question 97 — A

Answer: Use secure tags as the rule target. Secure tags can only be applied by a principal holding the tag role. Secure tags can only be applied by principals with the tag role, so they are harder to bypass. Local study-map skill 6.5 (Firewall Rules and Micro-Segmentation), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Correct. Secure tags can only be applied by principals with the tag role, so they are harder to bypass. In this case: Secure tags can only be applied by a principal holding the tag role.
- **B:** Incorrect for this question. The policy applies to every project under the organisation node. Why the correct answer wins: Secure tags can only be applied by a principal holding the tag role.
- **C:** Incorrect for this question. The rule applies to the instances that run as that identity, which only a privileged caller can change. Why the correct answer wins: Secure tags can only be applied by a principal holding the tag role.
- **D:** Incorrect for this question. Tags identify the instances the rule applies to, and any holder can set one. Why the correct answer wins: Secure tags can only be applied by a principal holding the tag role.

### Question 98 — D

Answer: Assign a manual static Cloud NAT address. A manual static address keeps the same source for every flow. A fixed address lets the partner allowlist the source. Local study-map skill 6.6 (Cloud NAT and Port Allocation), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Ports are assigned from a shared pool as the demand arrives. Why the correct answer wins: A manual static address keeps the same source for every flow.
- **B:** Incorrect for this question. Google assigns and releases external addresses as the demand changes. Why the correct answer wins: A manual static address keeps the same source for every flow.
- **C:** Incorrect for this question. The proxy applies URL and TLS inspection policy to outbound traffic. Why the correct answer wins: A manual static address keeps the same source for every flow.
- **D:** Correct. A fixed address lets the partner allowlist the source. In this case: A manual static address keeps the same source for every flow.

### Question 99 — C

Answer: Deploy Secure Web Proxy as the egress path. Secure Web Proxy applies category rules and TLS inspection to traffic leaving the environment. The proxy applies URL and TLS inspection policy to outbound traffic. Local study-map skill 6.7 (Secure Web Proxy), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Ports are assigned from a shared pool as the demand arrives. Why the correct answer wins: Secure Web Proxy applies category rules and TLS inspection to traffic leaving the environment.
- **B:** Incorrect for this question. A fixed address lets the partner allowlist the source. Why the correct answer wins: Secure Web Proxy applies category rules and TLS inspection to traffic leaving the environment.
- **C:** Correct. The proxy applies URL and TLS inspection policy to outbound traffic. In this case: Secure Web Proxy applies category rules and TLS inspection to traffic leaving the environment.
- **D:** Incorrect for this question. Mirrored packets are delivered to the collector for analysis. Why the correct answer wins: Secure Web Proxy applies category rules and TLS inspection to traffic leaving the environment.

### Question 100 — B

Answer: Configure Packet Mirroring on the instance group. Mirroring delivers copies to the collector and the original flows are unaffected. Mirrored packets are delivered to the collector for analysis. Local study-map skill 6.8 (Multi-NIC Appliances and Packet Mirroring), mapped to the official guide: Google Cloud Professional Cloud Network Engineer exam guide (six sections, 24 April 2026 revision, retrieved October 2026). Primary reference: Professional Cloud Network Engineer exam guide section 6 (configuring, implementing, and managing a cloud network security solution): https://services.google.com/fh/files/misc/042426_professional_cloud_network_engineer_exam_guide_english.pdf.

- **A:** Incorrect for this question. Each interface sits in a different network, so the appliance can inspect and forward between them. Why the correct answer wins: Mirroring delivers copies to the collector and the original flows are unaffected.
- **B:** Correct. Mirrored packets are delivered to the collector for analysis. In this case: Mirroring delivers copies to the collector and the original flows are unaffected.
- **C:** Incorrect for this question. A copy of the traffic goes to a collector while the original flow continues untouched. Why the correct answer wins: Mirroring delivers copies to the collector and the original flows are unaffected.
- **D:** Incorrect for this question. The proxy applies URL and TLS inspection policy to outbound traffic. Why the correct answer wins: Mirroring delivers copies to the collector and the original flows are unaffected.
