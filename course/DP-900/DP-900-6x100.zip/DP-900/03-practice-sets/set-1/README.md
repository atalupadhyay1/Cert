# Practice Set 1 — Full-Length Mock Exam 1

**Theme:** Omnichannel Retail & E-Commerce — Data Formats, OLTP/OLAP, Azure SQL, Cosmos DB NoSQL, OneLake & Power BI

## Files in This Folder

- `practice-set-1.csv` — 100-question Udemy bulk-upload CSV (UTF-8 with BOM, LF line endings, 17 columns).
- `practice-set-1.md` — Human-readable review copy with full per-option rationales and official Microsoft Learn links.

## Recommended Udemy Practice-Test Settings

- **Question count:** `100` (comprehensive Fundamentals bank; live DP-900 contains zero case studies and zero live labs)
- **Recommended timer:** `75 minutes` (`45 sec/question`, matching live 45-minute / 60-question pace; `45 minutes` optional speed drill)
- **Minimum Score to Pass (Udemy):** `75%` (practice benchmark only; live DP-900 uses a `700 / 1000` criterion-referenced scaled score)
- **Randomize Question & Answer Order:** Enabled (every question is self-contained)
- **Open-book rule:** Take **closed-book** — split-screen Microsoft Learn access is **not** available on Microsoft Fundamentals exams

## Blueprint & Format Summary

- **Domain 1 (`25–30%`):** `28` questions
- **Domain 2 (`20–25%`):** `24` questions
- **Domain 3 (`15–20%`):** `20` questions
- **Domain 4 (`25–30%`):** `28` questions
- **Question Formats:** `84` `multiple-choice` (balanced `21/21/21/21` across A–D, including `8` four-step `→` sequences) + `16` `multi-select` (`13` `Select two.` + `3` `Select three.`)
- **Completion (`____`) Items:** `27` · **`Proposed solution:` Items:** `8`
