# Full-Length Mock Exam 6 — Sentinel Cyber Fusion (Security & SOC Automation) — Model Context Protocol: Servers, Clients, Transports & Security

**Theme:** SSE Deprecation → Streamable HTTP, Batching, Reconnect Resumability & Gateway Mesh

## Set Summary

- **Questions:** `100` (`84` `multiple-choice` balanced `21 A / 21 B / 21 C / 21 D` + `16` `multi-select`)
- **Ordered 4-step sequences (`→`):** `11`
- **Code / LangGraph / MCP / A2A / NIM / OTel completions (`____`):** `65`
- **`Proposed solution:` architecture evaluations:** `10`
- **Case studies:** `0` (standalone enterprise agentic engineering scenarios)
- **Recommended timer:** `120 minutes` (`closed-book` conditions)

## Domain Breakdown

| # | Agentic AI Domain | Weight Range | Set Count |
|---:|---|---:|---:|
| 1 | MCP Foundations, Architecture & Lifecycle | 16–20% | 18 |
| 2 | Tools, Resources & Resource Templates | 18–22% | 20 |
| 3 | Prompts, Sampling, Roots & Elicitation | 14–18% | 16 |
| 4 | Transports, Sessions & Protocol Evolution | 14–18% | 16 |
| 5 | Authorization, Security, Trust & Registry | 13–17% | 15 |
| 6 | SDKs, Deployment, Observability & Ecosystem | 13–17% | 15 |

## Files in This Folder

- `practice-set-6.csv` — 17-column UTF-8-BOM CSV ready for Udemy Bulk Question Upload
- `practice-set-6.md` — Full human-readable question & explanation review key
