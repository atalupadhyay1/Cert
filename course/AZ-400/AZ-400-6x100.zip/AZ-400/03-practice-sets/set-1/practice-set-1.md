# Microsoft Exam AZ-400: Designing and Implementing Microsoft DevOps Solutions — Full-Length Mock Exam 1

Exam AZ-400 (Global Payments, Core Banking Pipelines, and Regulated Treasury Monorepos) · 100 questions · 100-minute recommended timing · Microsoft scaled passing score 700 / 1000

> **Blueprint, Prerequisite & Lifecycle Notice:** Aligned to the official **July 27, 2026** AZ-400 study guide (`Microsoft Certified: DevOps Engineer Expert`). Earning the Expert badge requires passing **AZ-400** plus holding an active **AZ-104** (or active pre-retirement **AZ-204**) Associate certification. On October 15, 2026, Microsoft announced that **Exam AZ-400 and DevOps Engineer Expert will retire on February 1, 2027**, succeeded by **Exam AZ-401 (`Designing and Implementing Microsoft Agentic DevOps Solutions`)**.

Blueprint-weighted mock exam: 84 `multiple-choice` items (including 8 four-step `→` sequence items, `____` YAML/CLI/Bicep/Git/KQL completion items, and `Proposed solution:` evaluations), 16 `multi-select` items (`Select two.` / `Select three.`), and 4 original 3-question enterprise DevOps case studies (12 case items).

Platform fidelity note: Udemy CSV imports support `multiple-choice` and `multi-select` only. Interactive Microsoft exam widgets (drag-and-drop sequence tiles, inline hot-area YAML/CLI dropdowns, split-pane tabbed case exhibits, live labs, and locked non-returnable Yes/No problem-solution series) are adapted into text-complete stems and explicit candidate options. Raw practice percentages do not convert to Microsoft scaled scores (`100–1000`, pass `700`).

100% original educational content authored from official Microsoft Learn and GitHub Docs — never recalled live items or copied Microsoft named case studies.

## Questions

### 1. An aerospace supplier migrating to Azure Boards requires native work item types for formal `Requirement`, `Change Request`, `Risk`, and `Review` records without building custom inherited types from scratch. Which built-in Azure Boards process should they select?

Domain: Design and implement processes and communications

- A. Azure Boards `Agile` process (`Epic`, `Feature`, `User Story`, `Task`, `Bug`)
- B. Azure Boards `Basic` process (`Epic`, `Issue`, `Task`)
- C. Azure Boards `Scrum` process (`Epic`, `Feature`, `Product Backlog Item`, `Task`, `Bug`, `Impediment`)
- D. Azure Boards `CMMI` process (`Epic`, `Feature`, `Requirement`, `Task`, `Bug`, `Change Request`, `Review`, `Risk`)

### 2. A FinTech API squad deploys to production six times daily from a single `main` branch and wants the lightest GitHub workflow supporting automated PR checks and peer review. Which workflow model fits best?

Domain: Design and implement processes and communications

- A. GitHub Flow: create short-lived branch from `main`, open PR early for CI/review, deploy/verify, and merge to `main`
- B. Long-lived `develop`, `feature/*`, `release/*`, and `hotfix/*` branches kept unmerged for months without feature flags
- C. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- D. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts

### 3. Open-source SDK maintainers on GitHub receive vague bug reports missing runtime versions and reproduction logs. Which repository configuration enforces required dropdowns and structured fields before an Issue can be submitted?

Domain: Design and implement processes and communications

- A. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- B. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables
- C. YAML Issue Forms (`.github/ISSUE_TEMPLATE/*.yml`) enforcing required structured inputs and auto-labels
- D. Configure Azure Boards to GitHub connection using a departing contractor personal classic PAT instead of the GitHub App

### 4. A hybrid engineering org tracks portfolio roadmaps across GitHub Issues and Azure DevOps pipelines and wants full requirement-to-test visibility plus cross-repo iteration views. Which two capabilities should they implement? Select two.

Domain: Design and implement processes and communications

- A. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- B. Link commits/PRs to Azure Boards work items, enable Build/Release work-item integration, and associate automated tests with Requirements
- C. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts
- D. Configure Azure Boards to GitHub connection using a departing contractor personal classic PAT instead of the GitHub App
- E. GitHub Projects (table/board/roadmap views with custom iteration/priority fields and built-in workflow automations)

### 5. Sprint retrospectives show stories stalling in the `QA Validation` column while developers keep starting new coding tasks. Which Azure Dashboards chart visually exposes widening column work-in-progress (WIP) bottlenecks over time?

Domain: Design and implement processes and communications

- A. Velocity widget measuring completed vs planned Story Points / Effort across sprints
- B. Sprint Burndown widget plotting remaining work hours or story points against the ideal trend line within an iteration
- C. Cumulative Flow Diagram (CFD) tracking work item counts per workflow column over time to expose WIP bottlenecks
- D. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki

### 6. A PMO architect needs a Power BI report aggregating 18 months of cross-project Cycle Time and defect-escape trends across 12 Azure DevOps projects without hitting REST API rate limits. Which data source is purpose-built for this workload?

Domain: Design and implement processes and communications

- A. Azure DevOps Analytics Views / OData (`Analytics` service) feeding Power BI for cross-project historical trend reporting
- B. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- C. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- D. Configure Azure Boards to GitHub connection using a departing contractor personal classic PAT instead of the GitHub App

### 7. Which two DORA operational stability metrics quantify how often production releases cause incidents and how rapidly the SRE team restores service afterward? Select two.

Domain: Design and implement processes and communications

- A. Sprint Burndown widget plotting remaining work hours or story points against the ideal trend line within an iteration
- B. Change Failure Rate: percentage of production deployments causing degraded service, hotfix, or rollback
- C. Velocity widget measuring completed vs planned Story Points / Effort across sprints
- D. Mean Time to Recovery / Restore (MTTR): average elapsed time from production incident/failure detection until service restoration
- E. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki

### 8. Platform architects want architecture runbooks and `::: mermaid` sequence diagrams stored in `/docs` of their service Git repo so documentation updates require pull-request approval alongside code changes. Which Azure DevOps Wiki option should they configure?

Domain: Design and implement processes and communications

- A. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts
- B. Publish Code as Wiki from a Git repository branch so Markdown docs and Mermaid (`::: mermaid` / ```` ```mermaid ````) diagrams follow PR reviews
- C. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- D. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki

### 9. Release managers working in Microsoft Teams want interactive Adaptive Cards posted to `#prod-releases` whenever a YAML stage fails or pauses for manual environment approval. Which integration meets this need with zero custom webhook code?

Domain: Design and implement processes and communications

- A. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- B. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables
- C. Configure Azure Boards to GitHub connection using a departing contractor personal classic PAT instead of the GitHub App
- D. Azure Pipelines app for Microsoft Teams (`@Azure Pipelines subscribe <pipeline-url>`) with stage failure and approval cards

### 10. A payments SDK team tags releases on GitHub and wants merged pull requests automatically grouped under `Breaking Changes`, `Features`, and `Fixes` headings based on PR labels. Which configuration achieves this natively?

Domain: Design and implement processes and communications

- A. Commit production SQL passwords and PFX passphrases inside `appsettings.Production.json` encrypted only with Base64 encoding
- B. Configure `.github/release.yml` category/label mappings and run `gh release create --generate-notes` (or GitHub auto-generated release notes)
- C. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts
- D. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki

### 11. Five microservice squads suffer multi-day merge conflicts every sprint because `feature/*` branches live for three weeks before merging into `develop`. Which branching strategy reduces merge debt while keeping `main` releasable?

Domain: Design and implement a source control strategy

- A. Long-lived `develop`, `feature/*`, `release/*`, and `hotfix/*` branches kept unmerged for months without feature flags
- B. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- C. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts
- D. Trunk-based development with short-lived branches (<24h) merging frequently to `main` behind feature flags

### 12. An enterprise ISV ships quarterly on-premises appliance releases (`v4.1`, `v4.2`) that each require 12 months of security patches while cloud engineers build `v5.0` on `main`. Which branching pattern supports parallel version maintenance?

Domain: Design and implement a source control strategy

- A. Long-lived `develop`, `feature/*`, `release/*`, and `hotfix/*` branches kept unmerged for months without feature flags
- B. Release branching (`release/1.4`) cut from `main` for stabilization while `main` continues accepting next-release features; cherry-pick/merge fixes back
- C. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- D. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts

### 13. Commit `9f3a1c2` merged to protected branch `main` 20 minutes ago introduced a non-sensitive logic regression, and four other commits have already landed after it (`____`). Which Git command safely undoes `9f3a1c2` without rewriting shared history?

Domain: Design and implement a source control strategy

- A. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- B. `git filter-repo --path certs/sign.pfx --invert-paths`
- C. `git stash pop`
- D. Run `git revert <commit-sha>` to create a new inverse commit safely undoing changes on a shared protected branch without rewriting history

### 14. Developers push 15–30 "fix typo" and "WIP" commits on topic branches, cluttering `git log --first-parent main`. Which Azure Repos branch-policy merge restriction condenses each pull request into a single clean commit on `main`?

Domain: Design and implement a source control strategy

- A. Enforce `Semi-linear merge` so PR commits are rebased onto latest `main` first and then joined via an explicit merge commit
- B. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- C. Enforce `Squash merge` in branch policy so each feature PR condenses noisy WIP commits into a single clean commit on `main`
- D. Enforce `Basic merge (no fast-forward)` to preserve every individual topic-branch commit plus an explicit two-parent merge commit

### 15. Security architects require mandatory review from `@kestrel/crypto-leads` whenever files under `/src/Hsm/**` change in GitHub. Proposed solution: Commit `.github/CODEOWNERS` containing `/src/Hsm/** @kestrel/crypto-leads` without modifying branch protection or repository rulesets on `main`. Does this meet the goal?

Domain: Design and implement a source control strategy

- A. No — adding `.github/CODEOWNERS` alone only requests reviews; without enabling `Require review from Code Owners` in branch protection or a ruleset, authors can still merge without sign-off
- B. No — consuming the default `@Local` view lets production pull unvalidated CI builds before QA promotion to `@Release`
- C. No — `git rm` only removes the file from the latest commit while leaving the password exposed in prior commits and unrotated
- D. Yes — the proposed configuration satisfies every stated DevOps security, governance, and operational requirement

### 16. In a busy 120-developer GitHub repo, PR #101 and PR #102 both pass CI individually against yesterday's `main`, yet merging both breaks `main` because PR #101 renamed an interface called by PR #102. Which GitHub feature prevents this race condition?

Domain: Design and implement a source control strategy

- A. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts
- B. GitHub Merge Queue (`merge_group` trigger) validating stacked PR batches sequentially against latest `main` before merging
- C. Long-lived `develop`, `feature/*`, `release/*`, and `hotfix/*` branches kept unmerged for months without feature flags
- D. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production

### 17. Which two Azure Repos branch policy configurations ensure `main` blocks unreviewed direct pushes, resets approvals when new code is pushed, and mandates platform-team sign-off on `/bicep/**` edits? Select two.

Domain: Design and implement a source control strategy

- A. Azure Repos branch policies on `main`: minimum reviewers (disallow self-approval, reset votes on new push), Build Validation, Linked Work Items, and Comment Resolution
- B. Configure `Automatically included reviewers` on Azure Repos branch policy with path filter `/infra/**; /payments/**` Marked as `Required`
- C. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- D. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables
- E. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts

### 18. Game-UI designers must version `.psd` art assets inside Git without bloating standard packfiles (`____`). Which command registers `.psd` files in `.gitattributes` so blobs upload to Git LFS storage?

Domain: Design and implement a source control strategy

- A. `git submodule update --init`
- B. `git lfs track "*.psd"`
- C. `git rm --cached "*.psd"`
- D. `git gc --aggressive`

### 19. Which two Git optimizations minimize network transfer and disk checkout time for CI agents and microservice developers working inside a single directory of a large repository? Select two.

Domain: Design and implement a source control strategy

- A. `git clone --filter=blob:none --sparse <url>` followed by `git sparse-checkout set <service-folder>`
- B. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts
- C. Long-lived `develop`, `feature/*`, `release/*`, and `hotfix/*` branches kept unmerged for months without feature flags
- D. Set shallow fetch (`fetchDepth: 1` in Azure Pipelines `checkout: self` or `fetch-depth: 1` in `actions/checkout@v4`) for CI builds
- E. `git clone --mirror`

### 20. An Azure Storage account key was pushed to an Azure Repos branch 40 minutes ago. In which order should the DevOps security team remediate the leak completely?

Domain: Design and implement a source control strategy

- A. Run `git rm secret.json` in a new commit → push normally without rotating the secret → keep old commits intact → close the incident
- B. Force-push an empty README → reuse the exact same secret key in Key Vault → skip collaborator reclone → archive the repo
- C. Revoke and rotate the exposed credential in the vault/cloud immediately → rewrite history with `git filter-repo` to purge the blob → force-push cleaned refs and have collaborators reclone → enable secret push protection
- D. Delete the branch tag only → wait 90 days to rotate the credential → run `git revert HEAD` → disable secret scanning

### 21. An enterprise standardizes on a single private Azure DevOps artifact feed to host internal `.nupkg`, `.tgz` npm modules, Maven `.jar` libraries, Python wheels, and Cargo crates. Which service supports all of those package types in one feed?

Domain: Design and implement build and release pipelines

- A. Azure Artifacts single multi-protocol feed supporting NuGet, npm, Maven, Python (PyPI), Cargo, and Universal Packages
- B. `GitHubRelease@1`
- C. Commit production SQL passwords and PFX passphrases inside `appsettings.Production.json` encrypted only with Base64 encoding
- D. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts

### 22. A team building containerized Node.js microservices wholly in GitHub Enterprise wants to publish OCI images (`ghcr.io`) and scoped `@org/*` npm packages authenticated seamlessly via per-job `GITHUB_TOKEN`. Which registry service fits natively?

Domain: Design and implement build and release pipelines

- A. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables
- B. GitHub Packages (`ghcr.io` Container Registry, npm, NuGet, Maven, RubyGems) scoped to repository/organization permissions and `GITHUB_TOKEN`
- C. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts
- D. Azure Artifacts Universal Packages (`UniversalPackages@0`) storing large non-language binaries/bundles up to terabytes with deduplication

### 23. In which order should a platform team implement Azure Artifacts feed views so continuous integration builds publish once while production releases consume only QA-verified versions?

Domain: Design and implement build and release pipelines

- A. Publish immutable SemVer packages from CI into the feed (`@Local`) → run automated integration tests against the candidate build → promote the validated version to `@Prerelease` / `@Release` → point prod consumers to `@Release`
- B. Delete the feed before every release → upload ZIPs to email → manually edit DLL versions → grant anonymous public write access
- C. Overwrite version `1.0.0` repeatedly in `@Release` on every commit → run unit tests in production → move failed builds to `@Local` → enable upstream push
- D. Point production directly at unvalidated `@Local` → skip integration tests → recompile source code from scratch during prod release → tag `@Prerelease`

### 24. Package `Kestrel.Contracts` is currently published at `2.4.1`. The next release removes a deprecated `AuthorizeLegacy()` method from a public interface (`____`). Under Semantic Versioning 2.0.0, which version number is required?

Domain: Design and implement build and release pipelines

- A. `2.4.1-hotfix.1`
- B. `3.0.0`
- C. `2.5.0`
- D. `2.4.2`

### 25. A cloud security team publishes monthly hardened golden VM/container base images tied strictly to compliance patch cycles (`2026.10.1`) rather than library API signatures. Which versioning scheme aligns best?

Domain: Design and implement build and release pipelines

- A. Semantic Versioning (`Major.Minor.Patch-prerelease`, e.g., `2.1.0` -> `3.0.0` for breaking API changes, `2.2.0` for backward-compatible features, `2.1.1` for patches)
- B. Commit production SQL passwords and PFX passphrases inside `appsettings.Production.json` encrypted only with Base64 encoding
- C. Calendar Versioning (`YYYY.0M.Patch`, e.g., `2026.10.2`) for date-driven platform drops, OS images, or time-boxed compliance bundles
- D. `2.4.1-hotfix.1`

### 26. A developer deletes defective NuGet package `Ledger.Math@1.8.0` from an Azure Artifacts feed and tries pushing a rebuilt `Ledger.Math@1.8.0`, which fails with HTTP 409 Conflict. Why does Azure Artifacts block republishing `1.8.0`?

Domain: Design and implement build and release pipelines

- A. `git stash pop`
- B. Once a `name@version` (e.g., `Core.Auth@1.4.0`) is published to Azure Artifacts, that exact version number is permanently immutable even if deleted
- C. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- D. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal

### 27. After deploying to `Staging`, a YAML pipeline must wait 15 minutes and automatically abort `Production` promotion if any Sev0 or Sev1 Application Insights alert fires. Which Environment check accomplishes this without custom scripts?

Domain: Design and implement build and release pipelines

- A. Azure Pipelines Environment `Query Azure Monitor alerts` check verifying zero active Sev0/Sev1 alerts during a post-deploy stabilization window
- B. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- C. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- D. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production

### 28. Compliance policy prohibits promoting a release to `Production` whenever any open `Bug` tagged `release-blocker` with `Severity = 1 - Critical` exists in Azure Boards. Which automated Azure Pipelines gate enforces this?

Domain: Design and implement build and release pipelines

- A. Azure Pipelines `Query Work Items` check blocking production promotion whenever active `Severity 1` bugs exist for the release area
- B. `git gc --aggressive`
- C. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- D. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki

### 29. A bank requires production YAML deployments to verify an approved ServiceNow Change Request ticket via HTTPS API and deploy only between 09:00 and 17:00 UTC with non-self-approving sign-off. Which two Azure Pipelines Environment mechanisms meet these needs? Select two.

Domain: Design and implement build and release pipelines

- A. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- B. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- C. Azure Pipelines Environment `Invoke Azure Function` or `Invoke REST API` check polling an external health/ServiceNow change endpoint
- D. Azure Pipelines YAML `environment:` configured with Approvals (disallow requester self-approval), Business Hours check, Branch Control (`refs/heads/main`), and Exclusive Lock (`lockBehavior: sequential` or `runLatest`)
- E. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki

### 30. Pull-request builds currently take 48 minutes because end-to-end Selenium browser suites and 10,000-virtual-user load tests execute on every single commit. Which test-pyramid pipeline strategy preserves quality while restoring fast PR feedback?

Domain: Design and implement build and release pipelines

- A. Long-lived `develop`, `feature/*`, `release/*`, and `hotfix/*` branches kept unmerged for months without feature flags
- B. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- C. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- D. Run fast isolated unit tests + static linters on every PR commit, service/container integration tests post-merge, and Azure Load Testing on staging

### 31. Before major banking holidays, a YAML pipeline must generate 25,000 RPS from distributed Azure injectors using an existing JMeter `.jmx` plan and fail the build automatically if `p90(response_time_ms) > 350`. Which managed service and task feature fits?

Domain: Design and implement build and release pipelines

- A. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- B. `CopyFiles@2`
- C. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- D. Azure Load Testing (`AzureLoadTest@1` / `azure/load-testing@v1`) with YAML `failureCriteria` (`p90(response_time_ms) > 400`, `percentage(error) > 1`)

### 32. In Azure Pipelines YAML, `dotnet test` exits with code `1` whenever a single xUnit assertion fails, causing the subsequent `PublishTestResults@2` step to be skipped under default settings (`condition: ____`). Which condition ensures `.trx` results still publish unless the job was canceled?

Domain: Design and implement build and release pipelines

- A. `canceled()`
- B. `failed()`
- C. `succeeded()`
- D. `succeededOrFailed()`

### 33. Engineering leads notice overall repo coverage stays at 81%, yet newly merged pull requests routinely contain 0% unit-test coverage on new payment classes. Which pipeline and Azure Repos combination blocks untested PR diffs?

Domain: Design and implement build and release pipelines

- A. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- B. `ExtractFiles@1`
- C. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- D. `PublishCodeCoverageResults@2` (Cobertura/JaCoCo/xml) paired with Azure Repos `buildpolicy.yml` or PR status policy enforcing >= 80% diff coverage

### 34. An organization stores source code in GitHub Enterprise but relies heavily on Azure Test Plans, Azure Boards work-item query gates, and Azure Artifacts Universal Packages. How should they integrate CI/CD without migrating source code?

Domain: Design and implement build and release pipelines

- A. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts
- B. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- C. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables
- D. Use GitHub Actions for GitHub-native workflows/marketplace ecosystems, or Azure Pipelines when Azure Boards/Test Plans/Classic/Environment-gate governance is central

### 35. During a security audit of a GitHub-to-Azure-Pipelines integration, which authentication anti-pattern creates immediate outage risk whenever an engineer leaves the company?

Domain: Design and implement build and release pipelines

- A. GitHub App installed at organization/repository scope issuing short-lived (1-hour) installation tokens with granular permissions independent of individual user accounts
- B. Use GitHub Actions for GitHub-native workflows/marketplace ecosystems, or Azure Pipelines when Azure Boards/Test Plans/Classic/Environment-gate governance is central
- C. Azure Boards app for GitHub using `AB#<ID>` / `Fixes AB#<ID>` syntax in commits or pull request descriptions
- D. Configure Azure Boards to GitHub connection using a departing contractor personal classic PAT instead of the GitHub App

### 36. Private AKS API servers and Azure Container Registry have `publicNetworkAccess: Disabled` inside an isolated hub-spoke VNet. Proposed solution: Run `docker push` and `helm upgrade` directly from standard Azure DevOps Microsoft-hosted `ubuntu-latest` agents without changing VNet or pool architecture. Does this meet the goal?

Domain: Design and implement build and release pipelines

- A. No — consuming the default `@Local` view lets production pull unvalidated CI builds before QA promotion to `@Release`
- B. No — the Lead Time widget measures from work item creation (`New`) to `Closed`, whereas leadership specifically asked for active-to-closed (`Active` to `Closed`) Cycle Time
- C. Yes — the proposed configuration satisfies every stated DevOps security, governance, and operational requirement
- D. No — standard Microsoft-hosted agents run on shared public networks and cannot route to private-endpoint-only ACR/AKS without VNet-injected Managed DevOps Pools or self-hosted/VMSS agents

### 37. Platform engineers need Azure Pipelines agents connected to a private VNet subnet using standard `ubuntu-24.04` Microsoft runner images, automatic OS patching, and stateless fresh-VM execution without managing VMSS scripts manually. Which agent option fits best?

Domain: Design and implement build and release pipelines

- A. Set `publicNetworkAccess: Enabled` with `0.0.0.0/0` firewall allow rules on production AKS, ACR, SQL, and Key Vault
- B. Managed DevOps Pools: Microsoft-managed scale-set agents injected into your private Azure VNet using Azure Pipelines / custom images and stateless mode
- C. Long-lived stateful self-hosted agent where workspace directories, Docker layers, or temp credentials persist across unrelated pipeline runs
- D. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal

### 38. In which order should an infrastructure team deploy private-network Azure Pipelines capacity that reaches private-endpoint ACR/AKS resources without workspace residue between jobs?

Domain: Design and implement build and release pipelines

- A. Create a Classic deployment group on public VMs → hardcode PATs expiring in 7 days → skip subnet injection → disable TLS
- B. Open `0.0.0.0/0` inbound SSH/443 on private AKS and ACR to the public internet → use Microsoft-hosted agents without VNet → cache credentials on disk → share root shell
- C. Provision a VNet subnet with outbound 443 to Azure DevOps and private endpoints to ACR/AKS → deploy a Managed DevOps Pool or VMSS pool into that subnet → enable stateless fresh-image teardown per job → target `pool:` in YAML
- D. Target `pool:` in YAML first → block outbound port 443 to `dev.azure.com` → install agent on a developer laptop → never clean workspace

### 39. In a monorepo hosting `/src/payments-api` and `/docs`, editing `docs/architecture.md` unnecessarily triggers a 22-minute `.NET` container build in Azure Pipelines. Which YAML trigger configuration prevents doc-only builds?

Domain: Design and implement build and release pipelines

- A. Configure `trigger:` and `pr:` `branches: include: [main]` with `paths: include: [src/order-api/*]` and `exclude: [docs/*, "*.md"]`
- B. `git gc --aggressive`
- C. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- D. Set shallow fetch (`fetchDepth: 1` in Azure Pipelines `checkout: self` or `fetch-depth: 1` in `actions/checkout@v4`) for CI builds

### 40. Whenever upstream pipeline `Shared-Contracts-CI` succeeds on `main`, downstream pipeline `Settlement-Deploy` in a separate YAML file must trigger automatically (`resources: ____:`). Which YAML resource construct chains the two pipelines?

Domain: Design and implement build and release pipelines

- A. `ExtractFiles@1`
- B. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- C. Azure Pipelines `resources.pipelines` trigger (`source: CoreLib-CI`, `trigger: branches: include: [main]`) chaining downstream deployments to upstream CI completion
- D. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal

### 41. A hybrid DevOps team wants manual parameterized workflow launches plus external webhook triggers in GitHub Actions, alongside path-filtered CI in Azure Pipelines. Which two trigger configurations meet both requirements? Select two.

Domain: Design and implement build and release pipelines

- A. `on: push`, `pull_request` (with `paths-ignore: ["docs/**"]`), `schedule` (`cron`), `workflow_dispatch` (manual typed inputs), and `repository_dispatch`
- B. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables
- C. `git stash pop`
- D. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- E. Configure `trigger:` and `pr:` `branches: include: [main]` with `paths: include: [src/order-api/*]` and `exclude: [docs/*, "*.md"]`

### 42. In Azure Pipelines YAML, an author needs an `$\x7b\x7b if eq(parameters.deployDr, true) \x7d\x7d:` block evaluated during YAML template expansion BEFORE any stage starts, versus `$(Build.BuildId)` inside a bash script step. Which explanation accurately distinguishes Azure Pipelines variable expressions?

Domain: Design and implement build and release pipelines

- A. `git stash pop`
- B. Commit production SQL passwords and PFX passphrases inside `appsettings.Production.json` encrypted only with Base64 encoding
- C. Compile-time `${{ variables.Env }}` (expanded before pipeline validation) vs runtime `$[variables.Env]` vs macro `$(Env)` (expanded right before task runs)
- D. `##vso[task.setvariable variable=SigningPwd;isoutput=true]`

### 43. A regulated bank requires cryptographic proof that the exact binary tested in `QA` is deployed to `Prod`. Proposed solution: Configure `Build`, `QA`, and `Prod` stages in YAML so each stage runs `git checkout main` and `dotnet publish -c Release` independently before deploying. Does this meet the goal?

Domain: Design and implement build and release pipelines

- A. No — recompiling source code from `HEAD` inside each deployment stage violates build-once-deploy-many and can ship untested commits to production
- B. No — `git rm` only removes the file from the latest commit while leaving the password exposed in prior commits and unrotated
- C. Yes — the proposed configuration satisfies every stated DevOps security, governance, and operational requirement
- D. No — `pull_request_target` combined with checking out the untrusted fork PR HEAD exposes write `GITHUB_TOKEN` and repository secrets to arbitrary code execution

### 44. A pipeline must compile SDK binaries across 6 OS/runtime combinations concurrently in CI, then deploy to 3 Azure regions in parallel and run a final global smoke test only when all 3 regional stages succeed. Which two YAML patterns achieve this? Select two.

Domain: Design and implement build and release pipelines

- A. `lockBehavior: runLatest`
- B. Long-lived stateful self-hosted agent where workspace directories, Docker layers, or temp credentials persist across unrelated pipeline runs
- C. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- D. `strategy: matrix:` across OS/runtime combinations (`ubuntu-latest`/`windows-latest` x `net8.0`/`net9.0`) with `maxParallel` concurrency control
- E. Set `dependsOn: [Deploy_EastUS, Deploy_WestEurope, Deploy_SoutheastAsia]` and `condition: succeeded()` on the final `Global_SmokeTest` stage

### 45. To guarantee every payment microservice pipeline inherits mandatory credential scanning and SBOM generation from `central-sec.yml@templates`, which root YAML keyword (`____`) wraps the caller pipeline?

Domain: Design and implement build and release pipelines

- A. `import:`
- B. `extends:`
- C. `include:`
- D. `uses:`

### 46. A GitHub Enterprise platform team wants to share a complete multi-job container build-and-attestation pipeline (including `environment:` bindings and OIDC secrets) across 35 repositories rather than bundling shell steps inside a single runner job. Should they author a Reusable Workflow or a Composite Action, and how?

Domain: Design and implement build and release pipelines

- A. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables
- B. Use Azure Pipelines `Export to YAML` / `View YAML` on Classic builds, convert Task Groups into parameterized YAML step/job templates, and replace Release stages with YAML Environments
- C. `ExtractFiles@1`
- D. GitHub Actions reusable workflow (`on: workflow_call`) vs Composite Action (`runs: using: "composite"` bundling multi-step shell/action sequences)

### 47. In which order should security engineers configure Azure Pipelines so no repository can deploy to the `prod-payments` YAML Environment unless its pipeline extends `approved-deploy.yml` in the `sec-templates` repo?

Domain: Design and implement build and release pipelines

- A. Author the hardened YAML template in a protected repository → reference that repo via `resources.repositories` and `extends` → open target Environment Approvals and checks → add a Required template check for that template path
- B. Add a Required template check on an unreferenced Classic release → let developers copy-paste steps inline → delete `extends` → grant everyone Environment Admin
- C. Run production deployment first → add Required template check afterward → create the template repo → reference via `include` variable file only
- D. Store the template in an unprotected branch where anyone pushes → skip `extends` → add a branch filter on variable groups → run deployment

### 48. A clearinghouse API requires zero-downtime cutovers between two full-scale identical environments so traffic switches atomically at Azure Front Door and reverts in seconds if settlement errors occur. Which deployment topology is this?

Domain: Design and implement build and release pipelines

- A. Blue-Green deployment maintaining two identical production-grade environments (`Blue` live, `Green` idle/staged) and switching router/Front Door/slot VIP atomically
- B. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- C. Long-lived `develop`, `feature/*`, `release/*`, and `hotfix/*` branches kept unmerged for months without feature flags
- D. A/B testing routing user cohorts to Variant A vs Variant B coupled with Application Insights custom business conversion telemetry

### 49. Product managers want 20% of logged-in mobile users to see a redesigned wire-transfer confirmation flow while comparing completion conversion rates against the existing UI in Application Insights. Which release pattern addresses this business hypothesis?

Domain: Design and implement build and release pipelines

- A. `az deployment group what-if` previewing `Create`, `Modify`, `Delete`, `NoChange`, and `Ignore` resource mutations against live Azure state before applying
- B. A/B testing routing user cohorts to Variant A vs Variant B coupled with Application Insights custom business conversion telemetry
- C. Blue-Green deployment maintaining two identical production-grade environments (`Blue` live, `Green` idle/staged) and switching router/Front Door/slot VIP atomically
- D. Set shallow fetch (`fetchDepth: 1` in Azure Pipelines `checkout: self` or `fetch-depth: 1` in `actions/checkout@v4`) for CI builds

### 50. In which order should a release engineering team orchestrate progressive ring deployments across `Canary`, `EarlyAdopter`, and `Global` customer rings?

Domain: Design and implement build and release pipelines

- A. Create separate Git forks per ring → cherry-pick random commits → disable Application Insights → run load tests only on prod DB
- B. Deploy straight to 100% of `Global` users → deploy to `Canary` afterward → rebuild from `HEAD` per ring → check Azure Monitor next week
- C. Build once and publish one immutable artifact in CI → deploy to `Canary` targeting 5% of users → evaluate Azure Monitor alert/KQL gates over a bake window → promote the identical artifact to `EarlyAdopter` and `Global` stages
- D. Set gate evaluation timeout shorter than evaluation delay → skip artifact publishing → approve failed telemetry alerts manually → delete logs

### 51. During a canary deployment where `v1` (90% traffic) and `v2` (10% traffic) API pods query the same Azure SQL database simultaneously, `v2` needs to split column `FullName` into `GivenName` and `Surname`. Which schema rollout pattern avoids breaking live `v1` pods?

Domain: Design and implement build and release pipelines

- A. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- B. Backward-compatible Expand-and-Contract (Parallel Change) schema pattern: add nullable column/new table first, deploy dual-compatible app code, backfill, then remove the legacy column in a later release
- C. Run `az deployment group create --mode Complete` against shared resource groups without `what-if` or Deployment Stacks
- D. `AzureRmWebAppDeployment@4`

### 52. After swapping an ASP.NET Core payment API from `staging` to `Production` on App Service Premium v3, the first 90 seconds of requests suffer HTTP 503/high latency while DI caches warm up. Which App Service configuration eliminates cold-swap spikes?

Domain: Design and implement build and release pipelines

- A. `AzureFileCopy@5`
- B. Set `publicNetworkAccess: Enabled` with `0.0.0.0/0` firewall allow rules on production AKS, ACR, SQL, and Key Vault
- C. App Service `staging` deployment slot with `applicationInitialization` warm-up paths, slot-pinned connection strings, and Auto-Swap / Swap with Preview
- D. `git gc --aggressive`

### 53. Treasury operations needs a new instant-settlement fee waiver feature flag in Azure App Configuration to turn on automatically at `2026-11-27T00:00:00Z` and deactivate at `2026-11-30T23:59:59Z` without manual intervention or redeployment. Which built-in filter fits?

Domain: Design and implement build and release pipelines

- A. Azure App Configuration Feature Manager with `Microsoft.TimeWindow` filter activating a promotional feature automatically between UTC `Start` and `End` timestamps
- B. Azure Automation State Configuration (PowerShell DSC pull server compiling `.mof` node configurations and reporting VM compliance state)
- C. Annotated signed Git tag (`git tag -a v2.4.0 -s -m "Release 2.4.0"`) storing tagger identity, timestamp, message, and GPG/SSH signature
- D. `3.0.0`

### 54. In which order should developers wire and roll out a staged cohort feature using Azure App Configuration Feature Manager in an ASP.NET Core microservice?

Domain: Design and implement build and release pipelines

- A. Hardcode `const bool EnableNewCheckout = true` in C# → recompile and redeploy for every 5% ramp step → restart App Service → create App Configuration later
- B. Create feature flags in Key Vault Certificates → call `IFeatureManager` without registering middleware → delete sentinel keys → redeploy Docker image per user
- C. Create the feature flag with `Microsoft.Targeting` in App Configuration → register `AddAzureAppConfiguration` (`UseFeatureFlags`) and `AddFeatureManagement` → gate code with `IFeatureManager.IsEnabledAsync` → ramp rollout % without redeploying
- D. Maintain 10 long-lived Git branches per customer cohort → deploy 10 separate App Service plans → merge branches next year → skip `IFeatureManager`

### 55. A data engineering squad requires deterministic, version-ordered SQL change scripts capable of transforming existing encrypted column payloads via custom T-SQL batches (`dotnet ef migrations bundle --idempotent`). Which database deployment approach fits better than declarative state comparison?

Domain: Design and implement build and release pipelines

- A. `AzureFileCopy@5`
- B. Azure Automation State Configuration (PowerShell DSC pull server compiling `.mof` node configurations and reporting VM compliance state)
- C. Migration-based SQL deployment (EF Core `dotnet ef migrations bundle --idempotent` / Flyway / Liquibase) executing ordered, version-tracked SQL scripts
- D. `MysqlDeploymentOnMachineGroup@1`

### 56. Platform architects document standard Azure SQL CI/CD patterns for two teams: Team A wants declarative desired-schema diffing from Visual Studio SQL Projects, while Team B wants ordered, idempotent EF Core C# change bundles. Which two pipeline approaches match Team A and Team B respectively? Select two.

Domain: Design and implement build and release pipelines

- A. Migration-based SQL deployment (EF Core `dotnet ef migrations bundle --idempotent` / Flyway / Liquibase) executing ordered, version-tracked SQL scripts
- B. `AzureFileCopy@5`
- C. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- D. State-based SQL deployment via `SqlAzureDacpacDeployment@1` comparing a compiled `.dacpac` model against target Azure SQL to generate a differential upgrade script
- E. Commit production SQL passwords and PFX passphrases inside `appsettings.Production.json` encrypted only with Base64 encoding

### 57. Before applying a production Bicep deployment in Azure Pipelines, engineers run `az deployment group ____ --resource-group rg-pay-prod --template-file main.bicep` to inspect `Create`, `Modify`, and `Delete` diffs against live Azure state. Which subcommand completes the CLI call?

Domain: Design and implement build and release pipelines

- A. `export`
- B. `what-if`
- C. `validate`
- D. `decompile`

### 58. Forty application teams copy-paste outdated AKS and Key Vault Bicep files across repos. Which native Azure capability distributes centrally linted, versioned Bicep modules (`br:payshared.azurecr.io/bicep/kv:v2.1.0`) privately across Entra-authenticated pipelines?

Domain: Design and implement build and release pipelines

- A. Commit production SQL passwords and PFX passphrases inside `appsettings.Production.json` encrypted only with Base64 encoding
- B. Azure Container Registry Private Bicep Module Registry (`br:myacr.azurecr.io/bicep/modules/aks:v1.2.0`) sharing versioned, linted IaC building blocks
- C. `git bundle create`
- D. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts

### 59. Which three practices establish governed, drift-resistant Bicep Infrastructure-as-Code delivery for shared enterprise subscriptions? Select three.

Domain: Design and implement build and release pipelines

- A. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- B. Run `az deployment group create --mode Complete` against shared resource groups without `what-if` or Deployment Stacks
- C. Azure Container Registry Private Bicep Module Registry (`br:myacr.azurecr.io/bicep/modules/aks:v1.2.0`) sharing versioned, linted IaC building blocks
- D. Commit production SQL passwords and PFX passphrases inside `appsettings.Production.json` encrypted only with Base64 encoding
- E. `az deployment group what-if` previewing `Create`, `Modify`, `Delete`, `NoChange`, and `Ignore` resource mutations against live Azure state before applying
- F. Azure Resource Manager Deployment Stacks (`az stack group create --action-on-unmanage deleteResources --deny-settings-mode denyWriteAndDelete`)

### 60. Developers need self-service ephemeral QA environments provisioned from approved Bicep catalog templates in isolated subscriptions without ever holding direct Azure subscription `Contributor` or `Owner` RBAC. Which Azure service is built for this?

Domain: Design and implement build and release pipelines

- A. Set `publicNetworkAccess: Enabled` with `0.0.0.0/0` firewall allow rules on production AKS, ACR, SQL, and Key Vault
- B. Azure Deployment Environments (Dev Center + Catalog of Bicep/Terraform templates + Environment Types mapping managed identities per stage)
- C. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- D. Azure Automation State Configuration (PowerShell DSC pull server compiling `.mof` node configurations and reporting VM compliance state)

### 61. Security auditors require continuous OS-level compliance checks (TLS 1.2 registry keys, SSH daemon hardening, prohibited local accounts) across both Azure VMs and on-premises Azure Arc-enabled Linux servers surfaced in Azure Policy. Which service meets this requirement?

Domain: Design and implement build and release pipelines

- A. `CopyFiles@2`
- B. Deploy the retired Log Analytics MMA (`OMSAgent`) workspace extension using shared workspace keys instead of Azure Monitor Agent (AMA) DCRs
- C. Configure `Git LFS` (`git lfs install` and `git lfs track "*.psd" "*.bin"`, committing `.gitattributes`) to store large binaries as lightweight pointers
- D. Azure Machine Configuration (formerly Azure Policy Guest Configuration) auditing and remediating OS baselines inside Azure VMs and Arc-enabled servers via AMA/extension

### 62. An enterprise platform blueprint combines PowerShell MOF pull-server DSC for legacy Windows workloads, Azure Policy native guest baselines for hybrid VMs, and catalog-based developer sandboxes. Which three Azure capabilities map to those requirements? Select three.

Domain: Design and implement build and release pipelines

- A. Run `az deployment group create --mode Complete` against shared resource groups without `what-if` or Deployment Stacks
- B. Azure Deployment Environments (Dev Center + Catalog of Bicep/Terraform templates + Environment Types mapping managed identities per stage)
- C. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- D. Deploy the retired Log Analytics MMA (`OMSAgent`) workspace extension using shared workspace keys instead of Azure Monitor Agent (AMA) DCRs
- E. Azure Machine Configuration (formerly Azure Policy Guest Configuration) auditing and remediating OS baselines inside Azure VMs and Arc-enabled servers via AMA/extension
- F. Azure Automation State Configuration (PowerShell DSC pull server compiling `.mof` node configurations and reporting VM compliance state)

### 63. Pipeline telemetry shows `CheckoutTimeoutUiTest` fails randomly on 4% of PR runs and passes on immediate rerun, eroding developer trust in CI red builds. Which Azure Pipelines capability isolates this issue systematically without deleting the test?

Domain: Design and implement build and release pipelines

- A. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- B. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- C. `canceled()`
- D. Enable Azure Pipelines Flaky Test Management (detection via test reruns + optional exclusion from build failure rate until quarantined bug is fixed)

### 64. When migrating legacy Azure DevOps Classic build definitions and Classic Task Groups to Git-versioned multi-stage YAML pipelines, what is the supported refactoring path?

Domain: Design and implement build and release pipelines

- A. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts
- B. Use Azure Pipelines `Export to YAML` / `View YAML` on Classic builds, convert Task Groups into parameterized YAML step/job templates, and replace Release stages with YAML Environments
- C. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- D. `uses:`

### 65. Restoring 420 MB of NuGet packages from feeds takes 4 minutes on every clean Microsoft-hosted build (`- task: ____` keyed on `Agent.OS` and `**/packages.lock.json`). Which Azure Pipelines task restores cached package directories across runs?

Domain: Design and implement build and release pipelines

- A. `DownloadBuildArtifacts@1`
- B. `PublishPipelineArtifact@1`
- C. `CopyFiles@2`
- D. `Cache@2`

### 66. A SaaS org wants to abort superseded GitHub Actions PR runs immediately when developers push rapid follow-up commits AND keep production release artifacts for 1 year while expiring noisy PR build outputs after 7 days. Which two configurations solve this? Select two.

Domain: Design and implement build and release pipelines

- A. `lockBehavior: runLatest`
- B. Configure GitHub Actions `concurrency: group: ${{ github.workflow }}-${{ github.ref }}` with `cancel-in-progress: true` on non-prod PR workflows
- C. Configure short project default run/artifact retention (e.g., 7–30 days for PR builds) and add automated retention leases (`365+` days) on production release runs
- D. Long-lived stateful self-hosted agent where workspace directories, Docker layers, or temp credentials persist across unrelated pipeline runs
- E. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production

### 67. Which three pipeline maintenance controls directly reduce CI/CD billable runner minutes, queue wait times, and artifact storage charges? Select three.

Domain: Design and implement build and release pipelines

- A. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables
- B. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- C. Long-lived stateful self-hosted agent where workspace directories, Docker layers, or temp credentials persist across unrelated pipeline runs
- D. `Cache@2` (Azure Pipelines) or `actions/cache@v4` (GitHub Actions) keyed on immutable lockfile hashes (`**/packages.lock.json`, `package-lock.json`) with `restoreKeys` fallback
- E. Configure GitHub Actions `concurrency: group: ${{ github.workflow }}-${{ github.ref }}` with `cancel-in-progress: true` on non-prod PR workflows
- F. Configure short project default run/artifact retention (e.g., 7–30 days for PR builds) and add automated retention leases (`365+` days) on production release runs

### 68. An internal developer portal needs automated cross-repository webhook events and short-lived 1-hour installation tokens in GitHub Enterprise that never break when individual engineers leave the company. Which authentication mechanism should it use?

Domain: Develop a security and compliance plan

- A. Configure Azure Boards to GitHub connection using a departing contractor personal classic PAT instead of the GitHub App
- B. Entra Application Service Principal authenticated via a manually rotated client secret or PFX certificate when non-OIDC legacy tooling cannot federate
- C. GitHub App installed at organization/repository scope issuing short-lived (1-hour) installation tokens with granular permissions independent of individual user accounts
- D. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables

### 69. Public repository `kestrel-dotnet-sdk` accepts pull requests from external forks. Proposed solution: Trigger CI via `on: pull_request_target`, run `actions/checkout@v4` with `ref: $\x7b\x7b github.event.pull_request.head.sha \x7d\x7d`, and execute `./build.sh` with NuGet publishing secrets in scope. Does this meet security requirements?

Domain: Develop a security and compliance plan

- A. No — consuming the default `@Local` view lets production pull unvalidated CI builds before QA promotion to `@Release`
- B. No — the Lead Time widget measures from work item creation (`New`) to `Closed`, whereas leadership specifically asked for active-to-closed (`Active` to `Closed`) Cycle Time
- C. Yes — the proposed configuration satisfies every stated DevOps security, governance, and operational requirement
- D. No — `pull_request_target` combined with checking out the untrusted fork PR HEAD exposes write `GITHUB_TOKEN` and repository secrets to arbitrary code execution

### 70. Compliance forbids storing expiring 24-month Entra client secrets inside Azure DevOps service connections used to deploy Bicep to Azure Resource Groups. Which service connection type eliminates stored secrets completely?

Domain: Develop a security and compliance plan

- A. Azure Resource Manager service connection using Workload Identity Federation (automatic/manual OIDC) scoped to a single Resource Group and locked via pipeline permissions
- B. Commit production SQL passwords and PFX passphrases inside `appsettings.Production.json` encrypted only with Base64 encoding
- C. Entra Application Service Principal authenticated via a manually rotated client secret or PFX certificate when non-OIDC legacy tooling cannot federate
- D. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables

### 71. Which two identity practices enforce zero-standing-secret least privilege across Azure runtime compute and GitHub Actions workflow jobs? Select two.

Domain: Develop a security and compliance plan

- A. Azure Managed Identity (system-assigned tied to resource lifecycle, or user-assigned shared across resources/federated credentials) with zero developer-managed passwords
- B. Automatic per-job `GITHUB_TOKEN` restricted to `permissions: contents: read` by default and elevated per job only as required (e.g., `packages: write`, `id-token: write`)
- C. Commit production SQL passwords and PFX passphrases inside `appsettings.Production.json` encrypted only with Base64 encoding
- D. Entra Application Service Principal authenticated via a manually rotated client secret or PFX certificate when non-OIDC legacy tooling cannot federate
- E. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables

### 72. Product owners and external compliance auditors need to view Azure Dashboards, submit bugs, and comment on Azure Boards Epics without viewing Azure Repos source code or incurring per-seat license charges. Which Azure DevOps access level should they receive?

Domain: Develop a security and compliance plan

- A. Azure DevOps `Basic + Test Plans` access level (or Visual Studio Enterprise/Test Pro): required to create/manage manual test plans, test suites, and exploratory sessions
- B. Azure DevOps `Basic` access level (first 5 free, paid thereafter; included with Visual Studio Subscriptions: Azure Boards + Azure Repos + Azure Pipelines)
- C. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- D. Azure DevOps `Stakeholder` access level (free, unlimited seats: create/edit/view Azure Boards work items, dashboards, and wikis; NO Azure Repos code access)

### 73. Four QA engineers already hold `Basic` access in Azure DevOps, yet they cannot create new manual Test Plans, author static/query-based Test Suites, or run the Test & Feedback exploratory runner fully. Which access level upgrade is required?

Domain: Develop a security and compliance plan

- A. Azure DevOps `Basic` access level (first 5 free, paid thereafter; included with Visual Studio Subscriptions: Azure Boards + Azure Repos + Azure Pipelines)
- B. Azure DevOps `Basic + Test Plans` access level (or Visual Studio Enterprise/Test Pro): required to create/manage manual test plans, test suites, and exploratory sessions
- C. GitHub `Outside collaborator` (or Azure DevOps custom Project-scoped security group restricted via `Project-Scoped Users` preview/repo ACLs) with access to a single repository only
- D. Azure DevOps `Stakeholder` access level (free, unlimited seats: create/edit/view Azure Boards work items, dashboards, and wikis; NO Azure Repos code access)

### 74. A project admin sets `Delete repository = Deny` on the built-in `Contributors` group, then adds Alice to a custom `Repo-Leads` group with `Delete repository = Allow`, yet Alice still cannot delete stale repos. Why?

Domain: Develop a security and compliance plan

- A. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- B. Azure DevOps `Stakeholder` access level (free, unlimited seats: create/edit/view Azure Boards work items, dashboards, and wikis; NO Azure Repos code access)
- C. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- D. In Azure DevOps permissions, explicit `Deny` always overrides `Allow` across inherited security groups (unless the user belongs to `Project Collection Administrators`)

### 75. A bash step fetches a one-time signing passphrase from an internal HSM API and passes it to subsequent tasks in the same Azure Pipelines job (`echo "____$PASS"`). Which logging command masks `$PASS` as `***` across all task logs?

Domain: Develop a security and compliance plan

- A. `##vso[task.setvariable variable=SigningPwd;isreadonly=true]`
- B. `##vso[task.setvariable variable=SigningPwd;isoutput=true]`
- C. `##vso[task.setvariable variable=SigningPwd;issecret=true]`
- D. `##vso[task.logissue type=warning]`

### 76. Mobile release pipelines require an encrypted Apple `.p12` distribution certificate stored inside Azure Pipelines Library `Secure Files` (`- task: ____`). Which task decrypts the file into `$(Agent.TempDirectory)` for the job and deletes it afterward?

Domain: Develop a security and compliance plan

- A. `DownloadSecureFile@1`
- B. `cURLUploader@2`
- C. `ExtractFiles@1`
- D. `GitHubRelease@1`

### 77. How should an Azure Pipelines YAML job consume centralized secrets stored in Azure Key Vault so secret rotations in Key Vault take effect automatically without copying secret values into Git?

Domain: Develop a security and compliance plan

- A. Link an Azure Pipelines Variable Group to Azure Key Vault (or use `AzureKeyVault@2` task) granting the WIF service connection `Key Vault Secrets User` RBAC
- B. Commit production SQL passwords and PFX passphrases inside `appsettings.Production.json` encrypted only with Base64 encoding
- C. `##vso[task.setvariable variable=SigningPwd;isoutput=true]`
- D. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables

### 78. A CISO wants a single cloud security posture plane in Azure correlating CodeQL SAST findings and Bicep IaC misconfigurations in GitHub and Azure DevOps repos with internet-exposed AKS attack paths. Which service provides this integration?

Domain: Develop a security and compliance plan

- A. `ExtractFiles@1`
- B. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- C. Microsoft Defender for Cloud DevOps Security connecting GitHub Enterprise and Azure DevOps via connectors to correlate code/IaC/container vulnerabilities with live cloud runtime exposure (CSPM)
- D. Deploy the retired Log Analytics MMA (`OMSAgent`) workspace extension using shared workspace keys instead of Azure Monitor Agent (AMA) DCRs

### 79. Legal counsel requires GitHub pull requests to fail automatically whenever a developer adds a NuGet or npm transitive dependency matching `deny-licenses: [AGPL-3.0, GPL-3.0]` (`uses: ____`). Which native GitHub Actions check enforces this on PRs?

Domain: Develop a security and compliance plan

- A. `git gc --aggressive`
- B. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- C. GitHub Dependency Review Action (`actions/dependency-review-action` with `deny-licenses: [GPL-3.0, AGPL-3.0]`) failing PRs that introduce copyleft license obligations
- D. Dynamic Application Security Testing (DAST, e.g., OWASP ZAP baseline/full scan) executed against a deployed staging App Service / ephemeral environment before production swap

### 80. Operations engineers are onboarding 60 new Linux payment-gateway VMs to Azure Monitor VM Insights in 2026 and must filter performance counters and syslog streams before ingestion into Log Analytics. Which agent architecture should they deploy?

Domain: Implement an instrumentation strategy

- A. Set `publicNetworkAccess: Enabled` with `0.0.0.0/0` firewall allow rules on production AKS, ACR, SQL, and Key Vault
- B. VM Insights using Azure Monitor Agent (AMA) + Data Collection Rules (DCRs) + Dependency Agent collecting guest OS performance and process network maps
- C. Deploy the retired Log Analytics MMA (`OMSAgent`) workspace extension using shared workspace keys instead of Azure Monitor Agent (AMA) DCRs
- D. `CopyFiles@2`

### 81. SREs investigating latency regressions in Application Insights want visual markers automatically plotted on Performance and Failure timelines at the exact timestamp each Azure Pipelines release finishes. Which feature provides this?

Domain: Implement an instrumentation strategy

- A. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- B. Grant all 90 developers permanent `Owner` RBAC on the production Azure subscription to edit resources manually in the Azure Portal
- C. Create Application Insights Release Annotations from CI/CD pipelines so deployment markers appear directly on Performance and Failure charts
- D. `git stash pop`

### 82. KestrelPay deploys .NET microservices to AKS and needs unified KQL correlation across HTTP request exceptions (`AppExceptions`) and Kubernetes pod `OOMKilled` / CPU-throttling metrics (`KubePodInventory`, `ContainerLogV2`). Which two monitoring configurations should they enable? Select two.

Domain: Implement an instrumentation strategy

- A. Azure Monitor Container Insights (`ContainerLogV2`, `KubePodInventory`, `InsightsMetrics`) monitoring AKS/Arc pod restarts, `OOMKilled` events, and node CPU/memory throttling
- B. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- C. Workspace-based Application Insights backed by a central Azure Monitor Log Analytics workspace collecting requests, dependencies, exceptions, traces, and custom metrics
- D. Deploy the retired Log Analytics MMA (`OMSAgent`) workspace extension using shared workspace keys instead of Azure Monitor Agent (AMA) DCRs
- E. Commit production SQL passwords and PFX passphrases inside `appsettings.Production.json` encrypted only with Base64 encoding

### 83. Engineering Finance notices monthly GitHub Actions billable minutes spiked 240% and wants built-in visibility into which workflows, runner OS SKUs, and repositories consume the most runtime and queue time. Where should they inspect this?

Domain: Implement an instrumentation strategy

- A. GitHub Repository/Organization Insights (Pulse, Traffic, Dependency Graph, Actions Usage Metrics & Performance) tracking workflow queue time, job runtime, and billable minutes
- B. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- C. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts
- D. `git bundle create`

### 84. Nightly scheduled CodeQL and production deployment workflows occasionally fail at 02:00 UTC unnoticed until morning standup. How should DevOps engineers trigger immediate on-call PagerDuty and Teams escalations on failed pipeline runs?

Domain: Implement an instrumentation strategy

- A. Configure Azure DevOps Service Hooks / Notifications or GitHub Webhook + Azure Monitor Action Group (Logic App / Function / PagerDuty / Teams) triggering on pipeline run or deployment failures
- B. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- C. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- D. `git stash pop`

### 85. A distributed SRE squad uses Microsoft Teams and wants real-time channel cards for GitHub Enterprise deployment review requests, check-suite failures, and security alert notifications (`@GitHub subscribe org/repo`). Which native integration fits?

Domain: Implement an instrumentation strategy

- A. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts
- B. Configure Azure Boards to GitHub connection using a departing contractor personal classic PAT instead of the GitHub App
- C. GitHub app for Microsoft Teams (`@GitHub subscribe owner/repo`) delivering PR, deployment, check-failure, and issue notifications
- D. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables

### 86. An SRE writes a Log Analytics query against `AppRequests` to compare 95th-percentile API latency per deployed version (`summarize p95 = ____ by AppVersion`). Which KQL aggregation function completes the query?

Domain: Implement an instrumentation strategy

- A. `percentile(DurationMs, 95)`
- B. `top(DurationMs, 95)`
- C. `p95(DurationMs)`
- D. `stdev(DurationMs, 95)`

### 87. A payment checkout call traverses `Gateway-API -> Fraud-Grpc -> Ledger-Worker -> Azure SQL`. How does Application Insights stitch all four hops onto a single Application Map and End-to-End Transaction view?

Domain: Implement an instrumentation strategy

- A. Deploy the retired Log Analytics MMA (`OMSAgent`) workspace extension using shared workspace keys instead of Azure Monitor Agent (AMA) DCRs
- B. `git gc --aggressive`
- C. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- D. W3C Trace Context (`traceparent` / `OperationId`) across Application Insights Application Map & End-to-End Transaction Diagnostics correlating frontend -> API -> SQL/Service Bus calls

### 88. Which two Application Insights capabilities help SREs isolate release-specific tail-latency spikes in KQL AND automatically detect abnormal exception-rate surges across diurnal traffic cycles without static thresholds? Select two.

Domain: Implement an instrumentation strategy

- A. `p95(DurationMs)`
- B. Save the WIQL query inside personal `My Queries` and paste a browser localhost screenshot onto the team wiki
- C. Deploy the retired Log Analytics MMA (`OMSAgent`) workspace extension using shared workspace keys instead of Azure Monitor Agent (AMA) DCRs
- D. Application Insights Smart Detection & Dynamic Threshold metric alerts (`Failure Anomalies`) baselining historical seasonality to alert on sudden exception spikes
- E. `AppRequests | where TimeGenerated > ago(1h) | summarize p95=percentile(DurationMs, 95), err=countif(Success == false) by AppVersion, bin(TimeGenerated, 5m)`

---

## Case study — KestrelPay

KestrelPay Clearing runs 40 .NET 8 payment microservices in GitHub Enterprise Cloud while tracking regulatory change requests, risks, and formal reviews in Azure Boards. Pull requests must link to an active work item, pass CodeQL and secret push protection, and deploy to private-VNet AKS clusters via GitHub Actions without storing long-lived client secrets.

The next 3 questions refer to **KestrelPay**. Read the scenario brief once, then answer each item independently.

### 89. After installing the Azure Boards app on GitHub Enterprise, a payment engineer opens a pull request that must automatically transition Azure Boards regulatory work item `412` to `Done` upon merge (`____`). Which syntax belongs in the PR description?

Domain: Design and implement processes and communications

- A. `WI#412`
- B. `Fixes AB#412`
- C. `AZDO-412`
- D. `Closes #412`

### 90. In which order should platform engineers configure secretless OpenID Connect (OIDC) authentication from KestrelPay's GitHub Actions workflows to private-VNet AKS deployment subscriptions?

Domain: Develop a security and compliance plan

- A. Add federated credential with wildcard `*` subject → run `azure/login` → create the Entra identity → grant RBAC after deployment fails
- B. Set `permissions: contents: write` only → store storage keys in plaintext YAML → run `az login --username` → add federated credential last
- C. Run `azure/login@v2` without `id-token: write` → create a 5-year client secret → add federated credential → assign Azure RBAC afterward
- D. Create an Entra app or Managed Identity with Azure RBAC → add a federated credential matching the repo/environment subject → set `permissions: id-token: write` in YAML → run `azure/login@v2` with client, tenant, and subscription IDs

### 91. Which two GitHub Advanced Security capabilities directly satisfy KestrelPay's pre-merge source scanning and credential-blocking mandates on pull requests? Select two.

Domain: Develop a security and compliance plan

- A. Generate an non-expiring Organization Owner classic Personal Access Token (`*` full scopes) and paste it into repository `README.md` variables
- B. CodeQL semantic SAST analysis building compiled languages (C#/.NET, Java, C++) or running buildless/containerized extraction and publishing SARIF findings to the Security tab
- C. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- D. GitHub Advanced Security (or GHAzDO) Secret Scanning with Push Protection blocking `git push` synchronously when high-confidence credentials/tokens are detected
- E. Dynamic Application Security Testing (DAST, e.g., OWASP ZAP baseline/full scan) executed against a deployed staging App Service / ephemeral environment before production swap

---

## Case study — MintLedger

MintLedger maintains an internal NuGet library suite in Azure Artifacts consumed by 18 squads. Unverified packages from nuget.org must be cached reliably, only QA-validated packages may appear to production release pipelines, and emergency production hotfixes must ship from isolated release tags without including unfinished trunk features.

The next 3 questions refer to **MintLedger**. Read the scenario brief once, then answer each item independently.

### 92. A critical rounding defect appears in production release `v3.2.0` while `main` already contains nine unfinished ledger features. Which Git workflow ships the emergency fix safely without leaking unfinished trunk work?

Domain: Design and implement a source control strategy

- A. Disable branch policies and status checks on `main` during release weeks so developers can `git push --force` directly to production
- B. Migrate all Git repositories back to centralized Team Foundation Version Control (TFVC) with exclusive server-side file checkouts
- C. Create a `hotfix/*` branch directly from the production release Git tag (e.g., `v2.3.0`), ship the tested patch `v2.3.1`, and cherry-pick/PR the fix to `main`
- D. Long-lived `develop`, `feature/*`, `release/*`, and `hotfix/*` branches kept unmerged for months without feature flags

### 93. Production release YAML pipelines must restore only QA-validated NuGet packages. Proposed solution: Configure `nuget.config` in production release pipelines to restore from `MintLedgerCore@Local` with `nuget.org` enabled as an upstream source. Does this meet the goal?

Domain: Design and implement build and release pipelines

- A. No — standard Microsoft-hosted agents run on shared public networks and cannot route to private-endpoint-only ACR/AKS without VNet-injected Managed DevOps Pools or self-hosted/VMSS agents
- B. No — consuming the default `@Local` view lets production pull unvalidated CI builds before QA promotion to `@Release`
- C. No — recompiling source code from `HEAD` inside each deployment stage violates build-once-deploy-many and can ship untested commits to production
- D. Yes — the proposed configuration satisfies every stated DevOps security, governance, and operational requirement

### 94. Which feed identifier (`feedsToUse: 'select'`, `vstsFeed: '____'`) in `DotNetCoreCLI@2` restricts production restore jobs exclusively to QA-promoted NuGet package versions?

Domain: Design and implement build and release pipelines

- A. `MintLedgerCore@Local`
- B. `MintLedgerCore@Upstream`
- C. `MintLedgerCore@Prerelease`
- D. `MintLedgerCore@Release`

---

## Case study — SilverCrest Treasury

SilverCrest Treasury stores a 65 GB monorepo containing CAD vault schematics and C++ risk libraries in Azure Repos. Clones take 45 minutes on developer laptops, a junior engineer accidentally committed a PFX signing password three commits ago on a shared branch, and engineering leadership wants a dashboard tracking active-to-closed work item duration.

The next 3 questions refer to **SilverCrest Treasury**. Read the scenario brief once, then answer each item independently.

### 95. Engineering leadership wants an Azure Boards dashboard widget measuring elapsed time strictly from when an engineer moves a work item to `Active` until `Closed`. Proposed solution: Add the Azure Boards **Lead Time** widget scoped to the Treasury team backlog. Does this meet the goal?

Domain: Design and implement processes and communications

- A. No — adding `.github/CODEOWNERS` alone only requests reviews; without enabling `Require review from Code Owners` in branch protection or a ruleset, authors can still merge without sign-off
- B. No — `git rm` only removes the file from the latest commit while leaving the password exposed in prior commits and unrotated
- C. No — the Lead Time widget measures from work item creation (`New`) to `Closed`, whereas leadership specifically asked for active-to-closed (`Active` to `Closed`) Cycle Time
- D. Yes — the proposed configuration satisfies every stated DevOps security, governance, and operational requirement

### 96. To cut 45-minute laptop clone times on the 65 GB Azure Repos monorepo, engineers run `____ https://dev.azure.com/silvercrest/Treasury/_git/CoreMono` to enable partial clone, cone sparse-checkout, and background maintenance automatically. Which CLI command completes the setup?

Domain: Design and implement a source control strategy

- A. `scalar clone`
- B. `git bundle create`
- C. `git clone --mirror`
- D. `git archive HEAD`

### 97. To remediate the PFX signing password committed three commits ago on a shared branch, an engineer plans to act. Proposed solution: Run `git rm certs/signing-pass.txt`, commit, and push to the shared branch without rotating the PFX password. Does this meet the goal?

Domain: Design and implement a source control strategy

- A. No — `git rm` only removes the file from the latest commit while leaving the password exposed in prior commits and unrotated
- B. No — `pull_request_target` combined with checking out the untrusted fork PR HEAD exposes write `GITHUB_TOKEN` and repository secrets to arbitrary code execution
- C. No — the Lead Time widget measures from work item creation (`New`) to `Closed`, whereas leadership specifically asked for active-to-closed (`Active` to `Closed`) Cycle Time
- D. Yes — the proposed configuration satisfies every stated DevOps security, governance, and operational requirement

---

## Case study — VaultWire

VaultWire migrates 25 Classic release pipelines to multi-stage Azure Pipelines YAML deploying Bicep templates and SQL Azure schema changes. Production deployments require manual approval from a separate compliance group during weekday business hours, an exclusive lock preventing concurrent runs, and zero-downtime App Service slot swaps with automatic rollback if error rates spike.

The next 3 questions refer to **VaultWire**. Read the scenario brief once, then answer each item independently.

### 98. Every queued schema and Bicep deployment targeting the `prod-vault` Azure Pipelines Environment must run strictly one at a time in FIFO order without canceling intermediate runs (`____`). Which YAML property should be set alongside the Exclusive Lock check?

Domain: Design and implement build and release pipelines

- A. `lockBehavior: bypass`
- B. `lockBehavior: parallel`
- C. `lockBehavior: sequential`
- D. `lockBehavior: runLatest`

### 99. In which order should VaultWire execute App Service deployment-slot releases so production traffic experiences zero cold-start downtime and instant rollback if error rates spike?

Domain: Design and implement build and release pipelines

- A. Provision a Free F1 plan → create 5 deployment slots → run VIP swap → enable metric autoscale
- B. Pin slot-sticky settings on `Production` and `staging` → deploy the immutable artifact to the `staging` slot → run warm-up and smoke probes against `staging` → swap `staging` into `Production` (swapping back on gate failure)
- C. Stop the `Production` web app → copy files via FTP over 10 minutes → start `Production` → create `staging` slot afterward
- D. Swap an empty `staging` slot into `Production` → deploy untested binaries directly to `Production` → run smoke tests → pin slot settings last

### 100. VaultWire compiles SQL Server Database Projects into `.dacpac` artifacts and applies state-based schema diffs to Azure SQL using Workload Identity Federation (`- task: ____`). Which Azure Pipelines task completes the YAML step?

Domain: Design and implement build and release pipelines

- A. `SqlAzureDacpacDeployment@1`
- B. `AzureRmWebAppDeployment@4`
- C. `AzureFileCopy@5`
- D. `MysqlDeploymentOnMachineGroup@1`

---

## Answer key and explanations

### Question 1 — D

Answer: Azure Boards `CMMI` process (`Epic`, `Feature`, `Requirement`, `Task`, `Bug`, `Change Request`, `Review`, `Risk`). The `CMMI` process natively provides `Requirement`, `Change Request`, `Risk`, and `Review` work item types tailored to formal change-control and audit governance. `CMMI` adds formal `Requirement`, `Change Request`, `Risk`, and `Review` work item types required by regulated audit frameworks. Local study-map skill 1.1 (Design and Implement Traceability and Flow of Work (GitHub Flow, Issues, Projects, Azure Boards Basic/Agile/Scrum/CMMI)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/boards/ & https://docs.github.com/en/issues

- **A:** Incorrect for this requirement. `Agile` tracks User Stories in story points alongside separate `Bug` items configurable on backlogs or taskboards. Why the keyed choice wins: The `CMMI` process natively provides `Requirement`, `Change Request`, `Risk`, and `Review` work item types tailored to formal change-control and audit governance.
- **B:** Incorrect for this requirement. The `Basic` process is the simplest Azure Boards model with three work item types (`Epic`, `Issue`, `Task`) for lightweight teams. Why the keyed choice wins: The `CMMI` process natively provides `Requirement`, `Change Request`, `Risk`, and `Review` work item types tailored to formal change-control and audit governance.
- **C:** Incorrect for this requirement. `Scrum` uses Product Backlog Items (PBIs) estimated in Effort, dedicated `Impediment` tracking, and Commitment/Done workflow states. Why the keyed choice wins: The `CMMI` process natively provides `Requirement`, `Change Request`, `Risk`, and `Review` work item types tailored to formal change-control and audit governance.
- **D:** Correct. `CMMI` adds formal `Requirement`, `Change Request`, `Risk`, and `Review` work item types required by regulated audit frameworks. In this scenario: The `CMMI` process natively provides `Requirement`, `Change Request`, `Risk`, and `Review` work item types tailored to formal change-control and audit governance.

### Question 2 — A

Answer: GitHub Flow: create short-lived branch from `main`, open PR early for CI/review, deploy/verify, and merge to `main`. GitHub Flow keeps `main` continuously deployable via short-lived topic branches, early pull requests with automated CI checks, and immediate merge/deploy cycles. GitHub Flow keeps `main` always deployable using short-lived topic branches, pull-request collaboration, automated checks, and rapid merges. Local study-map skill 1.1 (Design and Implement Traceability and Flow of Work (GitHub Flow, Issues, Projects, Azure Boards Basic/Agile/Scrum/CMMI)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/boards/ & https://docs.github.com/en/issues

- **A:** Correct. GitHub Flow keeps `main` always deployable using short-lived topic branches, pull-request collaboration, automated checks, and rapid merges. In this scenario: GitHub Flow keeps `main` continuously deployable via short-lived topic branches, early pull requests with automated CI checks, and immediate merge/deploy cycles.
- **B:** Incorrect for this requirement. Multi-month unmerged branches create severe integration conflicts and delay continuous delivery compared to trunk-based workflows. Why the keyed choice wins: GitHub Flow keeps `main` continuously deployable via short-lived topic branches, early pull requests with automated CI checks, and immediate merge/deploy cycles.
- **C:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: GitHub Flow keeps `main` continuously deployable via short-lived topic branches, early pull requests with automated CI checks, and immediate merge/deploy cycles.
- **D:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: GitHub Flow keeps `main` continuously deployable via short-lived topic branches, early pull requests with automated CI checks, and immediate merge/deploy cycles.

### Question 3 — C

Answer: YAML Issue Forms (`.github/ISSUE_TEMPLATE/*.yml`) enforcing required structured inputs and auto-labels. YAML Issue Forms (`.github/ISSUE_TEMPLATE/*.yml`) render validated web form controls with `required: true` fields and automatic triage labels. YAML Issue Forms validate required dropdown/input fields before submission so bug and feedback reports arrive with reproducible metadata. Local study-map skill 1.1 (Design and Implement Traceability and Flow of Work (GitHub Flow, Issues, Projects, Azure Boards Basic/Agile/Scrum/CMMI)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/boards/ & https://docs.github.com/en/issues

- **A:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: YAML Issue Forms (`.github/ISSUE_TEMPLATE/*.yml`) render validated web form controls with `required: true` fields and automatic triage labels.
- **B:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: YAML Issue Forms (`.github/ISSUE_TEMPLATE/*.yml`) render validated web form controls with `required: true` fields and automatic triage labels.
- **C:** Correct. YAML Issue Forms validate required dropdown/input fields before submission so bug and feedback reports arrive with reproducible metadata. In this scenario: YAML Issue Forms (`.github/ISSUE_TEMPLATE/*.yml`) render validated web form controls with `required: true` fields and automatic triage labels.
- **D:** Incorrect for this requirement. Personal PAT connections break when the user loses access or the token expires; Microsoft recommends the Azure Boards GitHub App. Why the keyed choice wins: YAML Issue Forms (`.github/ISSUE_TEMPLATE/*.yml`) render validated web form controls with `required: true` fields and automatic triage labels.

### Question 4 — B, E

Answers: Link commits/PRs to Azure Boards work items, enable Build/Release work-item integration, and associate automated tests with Requirements; GitHub Projects (table/board/roadmap views with custom iteration/priority fields and built-in workflow automations). Linking commits/PRs/builds/tests to Boards items delivers end-to-end audit traceability, while GitHub Projects provides cross-repository iteration, table, and roadmap planning views. Local study-map skill 1.1 (Design and Implement Traceability and Flow of Work (GitHub Flow, Issues, Projects, Azure Boards Basic/Agile/Scrum/CMMI)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/boards/ & https://docs.github.com/en/issues

- **A:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Linking commits/PRs/builds/tests to Boards items delivers end-to-end audit traceability, while GitHub Projects provides cross-repository iteration, table, and roadmap planning views.
- **B:** Correct. End-to-end traceability in Azure DevOps connects Requirements -> branches/PRs -> CI builds -> TRX test results -> deployed release stages. In this scenario: Linking commits/PRs/builds/tests to Boards items delivers end-to-end audit traceability, while GitHub Projects provides cross-repository iteration, table, and roadmap planning views.
- **C:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: Linking commits/PRs/builds/tests to Boards items delivers end-to-end audit traceability, while GitHub Projects provides cross-repository iteration, table, and roadmap planning views.
- **D:** Incorrect for this requirement. Personal PAT connections break when the user loses access or the token expires; Microsoft recommends the Azure Boards GitHub App. Why the keyed choice wins: Linking commits/PRs/builds/tests to Boards items delivers end-to-end audit traceability, while GitHub Projects provides cross-repository iteration, table, and roadmap planning views.
- **E:** Correct. GitHub Projects links Issues and PRs across repositories with custom fields, iteration planning, and automated status transitions. In this scenario: Linking commits/PRs/builds/tests to Boards items delivers end-to-end audit traceability, while GitHub Projects provides cross-repository iteration, table, and roadmap planning views.

### Question 5 — C

Answer: Cumulative Flow Diagram (CFD) tracking work item counts per workflow column over time to expose WIP bottlenecks. A Cumulative Flow Diagram (CFD) plots item counts per board column across dates so a widening `QA Validation` band immediately highlights WIP congestion. Widening bands in a Cumulative Flow Diagram immediately reveal stages where work-in-progress (WIP) accumulates faster than completion. Local study-map skill 1.2 (Design and Implement DevOps Metrics, Dashboards, Cycle/Lead Time, CFD, DORA KPIs, WIQL, and Analytics Views), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/boards/ & https://docs.github.com/en/issues

- **A:** Incorrect for this requirement. Velocity helps Scrum/Agile teams forecast sprint capacity from historical completed Effort/Story Points — not active-to-closed item duration. Why the keyed choice wins: A Cumulative Flow Diagram (CFD) plots item counts per board column across dates so a widening `QA Validation` band immediately highlights WIP congestion.
- **B:** Incorrect for this requirement. Sprint Burndown tracks intra-sprint progress toward the sprint goal rather than end-to-end lead or cycle time distributions. Why the keyed choice wins: A Cumulative Flow Diagram (CFD) plots item counts per board column across dates so a widening `QA Validation` band immediately highlights WIP congestion.
- **C:** Correct. Widening bands in a Cumulative Flow Diagram immediately reveal stages where work-in-progress (WIP) accumulates faster than completion. In this scenario: A Cumulative Flow Diagram (CFD) plots item counts per board column across dates so a widening `QA Validation` band immediately highlights WIP congestion.
- **D:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: A Cumulative Flow Diagram (CFD) plots item counts per board column across dates so a widening `QA Validation` band immediately highlights WIP congestion.

### Question 6 — A

Answer: Azure DevOps Analytics Views / OData (`Analytics` service) feeding Power BI for cross-project historical trend reporting. Azure DevOps Analytics Views and OData endpoints expose pre-aggregated reporting models optimized for Power BI historical analytics across projects. Analytics Views and OData endpoints are optimized for aggregated historical reporting without throttling operational REST APIs. Local study-map skill 1.2 (Design and Implement DevOps Metrics, Dashboards, Cycle/Lead Time, CFD, DORA KPIs, WIQL, and Analytics Views), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/boards/ & https://docs.github.com/en/issues

- **A:** Correct. Analytics Views and OData endpoints are optimized for aggregated historical reporting without throttling operational REST APIs. In this scenario: Azure DevOps Analytics Views and OData endpoints expose pre-aggregated reporting models optimized for Power BI historical analytics across projects.
- **B:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Azure DevOps Analytics Views and OData endpoints expose pre-aggregated reporting models optimized for Power BI historical analytics across projects.
- **C:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Azure DevOps Analytics Views and OData endpoints expose pre-aggregated reporting models optimized for Power BI historical analytics across projects.
- **D:** Incorrect for this requirement. Personal PAT connections break when the user loses access or the token expires; Microsoft recommends the Azure Boards GitHub App. Why the keyed choice wins: Azure DevOps Analytics Views and OData endpoints expose pre-aggregated reporting models optimized for Power BI historical analytics across projects.

### Question 7 — B, D

Answers: Mean Time to Recovery / Restore (MTTR): average elapsed time from production incident/failure detection until service restoration; Change Failure Rate: percentage of production deployments causing degraded service, hotfix, or rollback. Change Failure Rate measures the percentage of deployments causing incidents/rollbacks, while Mean Time to Recovery (MTTR) tracks elapsed time to restore service. Local study-map skill 1.2 (Design and Implement DevOps Metrics, Dashboards, Cycle/Lead Time, CFD, DORA KPIs, WIQL, and Analytics Views), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/boards/ & https://docs.github.com/en/issues

- **A:** Incorrect for this requirement. Sprint Burndown tracks intra-sprint progress toward the sprint goal rather than end-to-end lead or cycle time distributions. Why the keyed choice wins: Change Failure Rate measures the percentage of deployments causing incidents/rollbacks, while Mean Time to Recovery (MTTR) tracks elapsed time to restore service.
- **B:** Correct. Change Failure Rate tracks release quality alongside deployment frequency, lead time for changes, and MTTR. In this scenario: Change Failure Rate measures the percentage of deployments causing incidents/rollbacks, while Mean Time to Recovery (MTTR) tracks elapsed time to restore service.
- **C:** Incorrect for this requirement. Velocity helps Scrum/Agile teams forecast sprint capacity from historical completed Effort/Story Points — not active-to-closed item duration. Why the keyed choice wins: Change Failure Rate measures the percentage of deployments causing incidents/rollbacks, while Mean Time to Recovery (MTTR) tracks elapsed time to restore service.
- **D:** Correct. MTTR is a core DORA stability metric quantifying how rapidly teams recover from production incidents via rollback or hotfix. In this scenario: Change Failure Rate measures the percentage of deployments causing incidents/rollbacks, while Mean Time to Recovery (MTTR) tracks elapsed time to restore service.
- **E:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Change Failure Rate measures the percentage of deployments causing incidents/rollbacks, while Mean Time to Recovery (MTTR) tracks elapsed time to restore service.

### Question 8 — B

Answer: Publish Code as Wiki from a Git repository branch so Markdown docs and Mermaid (`::: mermaid` / ```` ```mermaid ````) diagrams follow PR reviews. `Publish code as wiki` renders Markdown and Mermaid diagrams directly from a versioned Git branch governed by pull requests and branch policies. Publishing Markdown from Git as Wiki keeps architecture docs versioned alongside code branches, pull requests, and branch policies. Local study-map skill 1.3 (Configure Collaboration, Wikis, Mermaid Diagrams, Automated Release Docs, Webhooks, Boards-GitHub Links, and Microsoft Teams), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/boards/ & https://docs.github.com/en/issues

- **A:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: `Publish code as wiki` renders Markdown and Mermaid diagrams directly from a versioned Git branch governed by pull requests and branch policies.
- **B:** Correct. Publishing Markdown from Git as Wiki keeps architecture docs versioned alongside code branches, pull requests, and branch policies. In this scenario: `Publish code as wiki` renders Markdown and Mermaid diagrams directly from a versioned Git branch governed by pull requests and branch policies.
- **C:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: `Publish code as wiki` renders Markdown and Mermaid diagrams directly from a versioned Git branch governed by pull requests and branch policies.
- **D:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: `Publish code as wiki` renders Markdown and Mermaid diagrams directly from a versioned Git branch governed by pull requests and branch policies.

### Question 9 — D

Answer: Azure Pipelines app for Microsoft Teams (`@Azure Pipelines subscribe <pipeline-url>`) with stage failure and approval cards. Installing the official Azure Pipelines app for Microsoft Teams (`@Azure Pipelines subscribe`) delivers stage notifications and inline Approve/Reject actions. The official Azure Pipelines Teams app posts real-time stage status notifications and lets approvers approve/reject directly in Teams. Local study-map skill 1.3 (Configure Collaboration, Wikis, Mermaid Diagrams, Automated Release Docs, Webhooks, Boards-GitHub Links, and Microsoft Teams), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/boards/ & https://docs.github.com/en/issues

- **A:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Installing the official Azure Pipelines app for Microsoft Teams (`@Azure Pipelines subscribe`) delivers stage notifications and inline Approve/Reject actions.
- **B:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: Installing the official Azure Pipelines app for Microsoft Teams (`@Azure Pipelines subscribe`) delivers stage notifications and inline Approve/Reject actions.
- **C:** Incorrect for this requirement. Personal PAT connections break when the user loses access or the token expires; Microsoft recommends the Azure Boards GitHub App. Why the keyed choice wins: Installing the official Azure Pipelines app for Microsoft Teams (`@Azure Pipelines subscribe`) delivers stage notifications and inline Approve/Reject actions.
- **D:** Correct. The official Azure Pipelines Teams app posts real-time stage status notifications and lets approvers approve/reject directly in Teams. In this scenario: Installing the official Azure Pipelines app for Microsoft Teams (`@Azure Pipelines subscribe`) delivers stage notifications and inline Approve/Reject actions.

### Question 10 — B

Answer: Configure `.github/release.yml` category/label mappings and run `gh release create --generate-notes` (or GitHub auto-generated release notes). Defining label categories in `.github/release.yml` and running `gh release create --generate-notes` (or UI auto-notes) builds categorized Markdown release notes automatically. GitHub automatically groups merged pull requests and contributors into categorized Markdown release notes using `.github/release.yml`. Local study-map skill 1.3 (Configure Collaboration, Wikis, Mermaid Diagrams, Automated Release Docs, Webhooks, Boards-GitHub Links, and Microsoft Teams), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/boards/ & https://docs.github.com/en/issues

- **A:** Incorrect for this requirement. Base64 is trivial reversible encoding, not encryption; secrets belong in Azure Key Vault / OIDC / Secure Files. Why the keyed choice wins: Defining label categories in `.github/release.yml` and running `gh release create --generate-notes` (or UI auto-notes) builds categorized Markdown release notes automatically.
- **B:** Correct. GitHub automatically groups merged pull requests and contributors into categorized Markdown release notes using `.github/release.yml`. In this scenario: Defining label categories in `.github/release.yml` and running `gh release create --generate-notes` (or UI auto-notes) builds categorized Markdown release notes automatically.
- **C:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: Defining label categories in `.github/release.yml` and running `gh release create --generate-notes` (or UI auto-notes) builds categorized Markdown release notes automatically.
- **D:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Defining label categories in `.github/release.yml` and running `gh release create --generate-notes` (or UI auto-notes) builds categorized Markdown release notes automatically.

### Question 11 — D

Answer: Trunk-based development with short-lived branches (<24h) merging frequently to `main` behind feature flags. Trunk-based development merges small, short-lived branches (<24 hours) continuously into `main` while hiding unfinished capabilities behind feature flags. Trunk-based development minimizes merge hell, accelerates CI feedback, and relies on feature flags to hide incomplete features in production. Local study-map skill 2.1 (Design and Implement Trunk-Based, Feature, Release, and Hotfix Branching Strategies), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Incorrect for this requirement. Multi-month unmerged branches create severe integration conflicts and delay continuous delivery compared to trunk-based workflows. Why the keyed choice wins: Trunk-based development merges small, short-lived branches (<24 hours) continuously into `main` while hiding unfinished capabilities behind feature flags.
- **B:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: Trunk-based development merges small, short-lived branches (<24 hours) continuously into `main` while hiding unfinished capabilities behind feature flags.
- **C:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: Trunk-based development merges small, short-lived branches (<24 hours) continuously into `main` while hiding unfinished capabilities behind feature flags.
- **D:** Correct. Trunk-based development minimizes merge hell, accelerates CI feedback, and relies on feature flags to hide incomplete features in production. In this scenario: Trunk-based development merges small, short-lived branches (<24 hours) continuously into `main` while hiding unfinished capabilities behind feature flags.

### Question 12 — B

Answer: Release branching (`release/1.4`) cut from `main` for stabilization while `main` continues accepting next-release features; cherry-pick/merge fixes back. Dedicated `release/*` branches cut from `main` isolate per-version servicing (`release/4.1`, `release/4.2`), with fixes cherry-picked from `main` as needed. Release branches isolate versioned stabilization and hotfixes (`v1.4.x`) when multiple major/minor versions must be supported concurrently. Local study-map skill 2.1 (Design and Implement Trunk-Based, Feature, Release, and Hotfix Branching Strategies), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Incorrect for this requirement. Multi-month unmerged branches create severe integration conflicts and delay continuous delivery compared to trunk-based workflows. Why the keyed choice wins: Dedicated `release/*` branches cut from `main` isolate per-version servicing (`release/4.1`, `release/4.2`), with fixes cherry-picked from `main` as needed.
- **B:** Correct. Release branches isolate versioned stabilization and hotfixes (`v1.4.x`) when multiple major/minor versions must be supported concurrently. In this scenario: Dedicated `release/*` branches cut from `main` isolate per-version servicing (`release/4.1`, `release/4.2`), with fixes cherry-picked from `main` as needed.
- **C:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: Dedicated `release/*` branches cut from `main` isolate per-version servicing (`release/4.1`, `release/4.2`), with fixes cherry-picked from `main` as needed.
- **D:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: Dedicated `release/*` branches cut from `main` isolate per-version servicing (`release/4.1`, `release/4.2`), with fixes cherry-picked from `main` as needed.

### Question 13 — D

Answer: Run `git revert <commit-sha>` to create a new inverse commit safely undoing changes on a shared protected branch without rewriting history. `git revert 9f3a1c2` creates a new forward commit inverting the defective diff cleanly while preserving immutable commit SHAs on `main`. `git revert` preserves immutable branch history on shared branches (`main`), whereas `git reset --hard` + force-push breaks collaborator trees. Local study-map skill 2.1 (Design and Implement Trunk-Based, Feature, Release, and Hotfix Branching Strategies), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: `git revert 9f3a1c2` creates a new forward commit inverting the defective diff cleanly while preserving immutable commit SHAs on `main`.
- **B:** Incorrect for this requirement. `git filter-repo` with `--invert-paths` rewrites all reachable commits to expunge `certs/sign.pfx` completely from repository history. Why the keyed choice wins: `git revert 9f3a1c2` creates a new forward commit inverting the defective diff cleanly while preserving immutable commit SHAs on `main`.
- **C:** Incorrect for this requirement. `git stash` shelves uncommitted local working-tree edits and has zero effect on pushed commit history. Why the keyed choice wins: `git revert 9f3a1c2` creates a new forward commit inverting the defective diff cleanly while preserving immutable commit SHAs on `main`.
- **D:** Correct. `git revert` preserves immutable branch history on shared branches (`main`), whereas `git reset --hard` + force-push breaks collaborator trees. In this scenario: `git revert 9f3a1c2` creates a new forward commit inverting the defective diff cleanly while preserving immutable commit SHAs on `main`.

### Question 14 — C

Answer: Enforce `Squash merge` in branch policy so each feature PR condenses noisy WIP commits into a single clean commit on `main`. Enforcing `Squash merge` collapses all topic-branch commits into one atomic commit on `main` per completed pull request. Squash merge produces a linear one-commit-per-PR history on `main` while deleting or retiring the source topic branch. Local study-map skill 2.2 (Configure PR Workflows, Merge Types, Azure Repos Branch Policies, GitHub Rulesets, Merge Queues, and CODEOWNERS), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Incorrect for this requirement. Semi-linear merge combines rebased up-to-date commit linearity with explicit PR merge commit grouping. Why the keyed choice wins: Enforcing `Squash merge` collapses all topic-branch commits into one atomic commit on `main` per completed pull request.
- **B:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: Enforcing `Squash merge` collapses all topic-branch commits into one atomic commit on `main` per completed pull request.
- **C:** Correct. Squash merge produces a linear one-commit-per-PR history on `main` while deleting or retiring the source topic branch. In this scenario: Enforcing `Squash merge` collapses all topic-branch commits into one atomic commit on `main` per completed pull request.
- **D:** Incorrect for this requirement. No-fast-forward keeps granular feature commit history intact and records exact PR merge boundaries. Why the keyed choice wins: Enforcing `Squash merge` collapses all topic-branch commits into one atomic commit on `main` per completed pull request.

### Question 15 — A

Answer: No — adding `.github/CODEOWNERS` alone only requests reviews; without enabling `Require review from Code Owners` in branch protection or a ruleset, authors can still merge without sign-off. No — `.github/CODEOWNERS` alone auto-requests reviews, but unless `Require review from Code Owners` is enabled in branch protection or a ruleset, PRs can still merge without their approval. `CODEOWNERS` enforces blocking sign-off only when paired with `Require pull request reviews` + `Require review from Code Owners` on the target branch. Local study-map skill 2.2 (Configure PR Workflows, Merge Types, Azure Repos Branch Policies, GitHub Rulesets, Merge Queues, and CODEOWNERS), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Correct. `CODEOWNERS` enforces blocking sign-off only when paired with `Require pull request reviews` + `Require review from Code Owners` on the target branch. In this scenario: No — `.github/CODEOWNERS` alone auto-requests reviews, but unless `Require review from Code Owners` is enabled in branch protection or a ruleset, PRs can still merge without their approval.
- **B:** Incorrect for this requirement. Production pipelines must consume `feed@Release` so unverified `@Local` or `@Prerelease` packages are invisible to production restores. Why the keyed choice wins: No — `.github/CODEOWNERS` alone auto-requests reviews, but unless `Require review from Code Owners` is enabled in branch protection or a ruleset, PRs can still merge without their approval.
- **C:** Incorrect for this requirement. Deleting a secret in a new commit leaves the cleartext blob inside historical commits (`git log -p`) and fails to revoke the leaked credential. Why the keyed choice wins: No — `.github/CODEOWNERS` alone auto-requests reviews, but unless `Require review from Code Owners` is enabled in branch protection or a ruleset, PRs can still merge without their approval.
- **D:** Incorrect for this requirement. Every functional, networking, licensing, and security constraint in the scenario is satisfied natively. Why the keyed choice wins: No — `.github/CODEOWNERS` alone auto-requests reviews, but unless `Require review from Code Owners` is enabled in branch protection or a ruleset, PRs can still merge without their approval.

### Question 16 — B

Answer: GitHub Merge Queue (`merge_group` trigger) validating stacked PR batches sequentially against latest `main` before merging. GitHub Merge Queue (`merge_group` trigger) rebases/merges queued PRs cumulatively in order and validates each combined state on CI before updating `main`. Merge queues prevent semantic conflicts where two PRs pass CI individually against stale `main` but break `main` when combined. Local study-map skill 2.2 (Configure PR Workflows, Merge Types, Azure Repos Branch Policies, GitHub Rulesets, Merge Queues, and CODEOWNERS), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: GitHub Merge Queue (`merge_group` trigger) rebases/merges queued PRs cumulatively in order and validates each combined state on CI before updating `main`.
- **B:** Correct. Merge queues prevent semantic conflicts where two PRs pass CI individually against stale `main` but break `main` when combined. In this scenario: GitHub Merge Queue (`merge_group` trigger) rebases/merges queued PRs cumulatively in order and validates each combined state on CI before updating `main`.
- **C:** Incorrect for this requirement. Multi-month unmerged branches create severe integration conflicts and delay continuous delivery compared to trunk-based workflows. Why the keyed choice wins: GitHub Merge Queue (`merge_group` trigger) rebases/merges queued PRs cumulatively in order and validates each combined state on CI before updating `main`.
- **D:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: GitHub Merge Queue (`merge_group` trigger) rebases/merges queued PRs cumulatively in order and validates each combined state on CI before updating `main`.

### Question 17 — A, B

Answers: Azure Repos branch policies on `main`: minimum reviewers (disallow self-approval, reset votes on new push), Build Validation, Linked Work Items, and Comment Resolution; Configure `Automatically included reviewers` on Azure Repos branch policy with path filter `/infra/**; /payments/**` Marked as `Required`. Enabling minimum-reviewer + vote-reset + build/work-item/comment policies protects `main`, while path-filtered `Automatically included reviewers` enforces `/bicep/**` sign-off. Local study-map skill 2.2 (Configure PR Workflows, Merge Types, Azure Repos Branch Policies, GitHub Rulesets, Merge Queues, and CODEOWNERS), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Correct. Azure Repos protects branches by blocking direct pushes and enforcing PR build validation, work item linkage, reviewer resets, and resolved comments. In this scenario: Enabling minimum-reviewer + vote-reset + build/work-item/comment policies protects `main`, while path-filtered `Automatically included reviewers` enforces `/bicep/**` sign-off.
- **B:** Correct. Path-scoped required reviewers in Azure Repos ensure security or platform owners must sign off whenever protected directories change. In this scenario: Enabling minimum-reviewer + vote-reset + build/work-item/comment policies protects `main`, while path-filtered `Automatically included reviewers` enforces `/bicep/**` sign-off.
- **C:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: Enabling minimum-reviewer + vote-reset + build/work-item/comment policies protects `main`, while path-filtered `Automatically included reviewers` enforces `/bicep/**` sign-off.
- **D:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: Enabling minimum-reviewer + vote-reset + build/work-item/comment policies protects `main`, while path-filtered `Automatically included reviewers` enforces `/bicep/**` sign-off.
- **E:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: Enabling minimum-reviewer + vote-reset + build/work-item/comment policies protects `main`, while path-filtered `Automatically included reviewers` enforces `/bicep/**` sign-off.

### Question 18 — B

Answer: `git lfs track "*.psd"`. `git lfs track "*.psd"` writes the LFS filter attribute to `.gitattributes` so matching binary files are stored as small text pointers in Git commits. `git lfs track` writes the `filter=lfs diff=lfs merge=lfs -text` entry into `.gitattributes` so matching binaries use Git LFS pointers. Local study-map skill 2.3 (Manage Large Files and Optimize Git Scale (Git LFS, Scalar, Partial/Shallow Clone, Sparse-Checkout, Submodules)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Incorrect for this requirement. `git submodule` manages nested repositories, not large binary files within a single repo. Why the keyed choice wins: `git lfs track "*.psd"` writes the LFS filter attribute to `.gitattributes` so matching binary files are stored as small text pointers in Git commits.
- **B:** Correct. `git lfs track` writes the `filter=lfs diff=lfs merge=lfs -text` entry into `.gitattributes` so matching binaries use Git LFS pointers. In this scenario: `git lfs track "*.psd"` writes the LFS filter attribute to `.gitattributes` so matching binary files are stored as small text pointers in Git commits.
- **C:** Incorrect for this requirement. `git rm --cached` untrack files from the index without configuring Git LFS pointer storage. Why the keyed choice wins: `git lfs track "*.psd"` writes the LFS filter attribute to `.gitattributes` so matching binary files are stored as small text pointers in Git commits.
- **D:** Incorrect for this requirement. `git gc` repacks local objects but keeps huge binaries inside Git packfiles rather than moving them to LFS storage. Why the keyed choice wins: `git lfs track "*.psd"` writes the LFS filter attribute to `.gitattributes` so matching binary files are stored as small text pointers in Git commits.

### Question 19 — A, D

Answers: Set shallow fetch (`fetchDepth: 1` in Azure Pipelines `checkout: self` or `fetch-depth: 1` in `actions/checkout@v4`) for CI builds; `git clone --filter=blob:none --sparse <url>` followed by `git sparse-checkout set <service-folder>`. Shallow CI checkout (`fetchDepth: 1`) avoids downloading historical commits, while blobless partial clone (`--filter=blob:none`) + `sparse-checkout` materializes only the target folder. Local study-map skill 2.3 (Manage Large Files and Optimize Git Scale (Git LFS, Scalar, Partial/Shallow Clone, Sparse-Checkout, Submodules)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Correct. Blobless partial clone (`--filter=blob:none`) fetches trees/commits first and downloads file blobs lazily only for sparse-checked-out directories. In this scenario: Shallow CI checkout (`fetchDepth: 1`) avoids downloading historical commits, while blobless partial clone (`--filter=blob:none`) + `sparse-checkout` materializes only the target folder.
- **B:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: Shallow CI checkout (`fetchDepth: 1`) avoids downloading historical commits, while blobless partial clone (`--filter=blob:none`) + `sparse-checkout` materializes only the target folder.
- **C:** Incorrect for this requirement. Multi-month unmerged branches create severe integration conflicts and delay continuous delivery compared to trunk-based workflows. Why the keyed choice wins: Shallow CI checkout (`fetchDepth: 1`) avoids downloading historical commits, while blobless partial clone (`--filter=blob:none`) + `sparse-checkout` materializes only the target folder.
- **D:** Correct. Fetching only the single target commit (`fetchDepth: 1`) drastically cuts network transfer and checkout time on large repositories. In this scenario: Shallow CI checkout (`fetchDepth: 1`) avoids downloading historical commits, while blobless partial clone (`--filter=blob:none`) + `sparse-checkout` materializes only the target folder.
- **E:** Incorrect for this requirement. `--mirror` creates a bare server replica downloading every object and ref, maximizing disk/network usage rather than shrinking laptop clones. Why the keyed choice wins: Shallow CI checkout (`fetchDepth: 1`) avoids downloading historical commits, while blobless partial clone (`--filter=blob:none`) + `sparse-checkout` materializes only the target folder.

### Question 20 — C

Answer: Revoke and rotate the exposed credential in the vault/cloud immediately → rewrite history with `git filter-repo` to purge the blob → force-push cleaned refs and have collaborators reclone → enable secret push protection. Rotating the compromised key in Azure comes first to neutralize active risk, followed by `git filter-repo` history cleanup, force-pushing cleaned refs, and enabling push protection. Once a secret touches a shared remote it must be treated as compromised and rotated first, followed by history rewrite (`git filter-repo`), ref cleanup, and push protection. Local study-map skill 2.4 (Configure Repository Permissions, Annotated Tags, Reflog/Revert Recovery, and Secret History Removal (git filter-repo)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Incorrect for this requirement. `git rm` only removes the file from HEAD while leaving the cleartext secret readable in prior commit objects. Why the keyed choice wins: Rotating the compromised key in Azure comes first to neutralize active risk, followed by `git filter-repo` history cleanup, force-pushing cleaned refs, and enabling push protection.
- **B:** Incorrect for this requirement. Reusing a leaked secret keeps systems vulnerable regardless of Git rewrites because clones or logs may already hold the value. Why the keyed choice wins: Rotating the compromised key in Azure comes first to neutralize active risk, followed by `git filter-repo` history cleanup, force-pushing cleaned refs, and enabling push protection.
- **C:** Correct. Once a secret touches a shared remote it must be treated as compromised and rotated first, followed by history rewrite (`git filter-repo`), ref cleanup, and push protection. In this scenario: Rotating the compromised key in Azure comes first to neutralize active risk, followed by `git filter-repo` history cleanup, force-pushing cleaned refs, and enabling push protection.
- **D:** Incorrect for this requirement. `git revert` adds another commit without erasing history, and delaying rotation leaves the leaked credential exploitable. Why the keyed choice wins: Rotating the compromised key in Azure comes first to neutralize active risk, followed by `git filter-repo` history cleanup, force-pushing cleaned refs, and enabling push protection.

### Question 21 — A

Answer: Azure Artifacts single multi-protocol feed supporting NuGet, npm, Maven, Python (PyPI), Cargo, and Universal Packages. A single Azure Artifacts feed natively hosts NuGet, npm, Maven, Python (PyPI), Cargo, and Universal Packages with unified permissions and views. Local study-map skill 3.1 (Recommend Package Management Tools Across GitHub Packages and Azure Artifacts (NuGet, npm, Maven, PyPI, Universal)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Correct. In this scenario: A single Azure Artifacts feed natively hosts NuGet, npm, Maven, Python (PyPI), Cargo, and Universal Packages with unified permissions and views.
- **B:** Incorrect for this requirement. `GitHubRelease@1` manages public/repo GitHub Release assets, not encrypted pipeline signing certificates. Why the keyed choice wins: A single Azure Artifacts feed natively hosts NuGet, npm, Maven, Python (PyPI), Cargo, and Universal Packages with unified permissions and views.
- **C:** Incorrect for this requirement. Base64 is trivial reversible encoding, not encryption; secrets belong in Azure Key Vault / OIDC / Secure Files. Why the keyed choice wins: A single Azure Artifacts feed natively hosts NuGet, npm, Maven, Python (PyPI), Cargo, and Universal Packages with unified permissions and views.
- **D:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: A single Azure Artifacts feed natively hosts NuGet, npm, Maven, Python (PyPI), Cargo, and Universal Packages with unified permissions and views.

### Question 22 — B

Answer: GitHub Packages (`ghcr.io` Container Registry, npm, NuGet, Maven, RubyGems) scoped to repository/organization permissions and `GITHUB_TOKEN`. GitHub Packages hosts container images (`ghcr.io`), npm, NuGet, Maven, and RubyGems integrated directly with repository permissions and `GITHUB_TOKEN`. GitHub Packages integrates natively with GitHub Actions using `packages: write` on `GITHUB_TOKEN` without managing external registry credentials. Local study-map skill 3.1 (Recommend Package Management Tools Across GitHub Packages and Azure Artifacts (NuGet, npm, Maven, PyPI, Universal)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: GitHub Packages hosts container images (`ghcr.io`), npm, NuGet, Maven, and RubyGems integrated directly with repository permissions and `GITHUB_TOKEN`.
- **B:** Correct. GitHub Packages integrates natively with GitHub Actions using `packages: write` on `GITHUB_TOKEN` without managing external registry credentials. In this scenario: GitHub Packages hosts container images (`ghcr.io`), npm, NuGet, Maven, and RubyGems integrated directly with repository permissions and `GITHUB_TOKEN`.
- **C:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: GitHub Packages hosts container images (`ghcr.io`), npm, NuGet, Maven, and RubyGems integrated directly with repository permissions and `GITHUB_TOKEN`.
- **D:** Incorrect for this requirement. Universal Packages efficiently deduplicate and version multi-gigabyte cross-platform toolchains, game assets, or firmware drops. Why the keyed choice wins: GitHub Packages hosts container images (`ghcr.io`), npm, NuGet, Maven, and RubyGems integrated directly with repository permissions and `GITHUB_TOKEN`.

### Question 23 — A

Answer: Publish immutable SemVer packages from CI into the feed (`@Local`) → run automated integration tests against the candidate build → promote the validated version to `@Prerelease` / `@Release` → point prod consumers to `@Release`. CI publishes immutable SemVer packages to `@Local`, automated tests validate them, quality gates promote versions to `@Prerelease`/`@Release`, and prod consumes `@Release`. Feed views expose quality milestones (`@Prerelease`, `@Release`) without rebuilding binaries, ensuring production consumes only promoted immutable artifacts. Local study-map skill 3.2 (Design and Implement Package Feeds, Upstream Sources, and Promotion Views (@Local, @Prerelease, @Release)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Correct. Feed views expose quality milestones (`@Prerelease`, `@Release`) without rebuilding binaries, ensuring production consumes only promoted immutable artifacts. In this scenario: CI publishes immutable SemVer packages to `@Local`, automated tests validate them, quality gates promote versions to `@Prerelease`/`@Release`, and prod consumes `@Release`.
- **B:** Incorrect for this requirement. Manual binary edits and feed deletion destroy provenance, caching, and access governance. Why the keyed choice wins: CI publishes immutable SemVer packages to `@Local`, automated tests validate them, quality gates promote versions to `@Prerelease`/`@Release`, and prod consumes `@Release`.
- **C:** Incorrect for this requirement. Azure Artifacts versions are immutable once published; rebuilding or overwriting `1.0.0` violates artifact provenance. Why the keyed choice wins: CI publishes immutable SemVer packages to `@Local`, automated tests validate them, quality gates promote versions to `@Prerelease`/`@Release`, and prod consumes `@Release`.
- **D:** Incorrect for this requirement. Recompiling source during release breaks build-once-deploy-many integrity, and `@Local` exposes unvalidated CI builds. Why the keyed choice wins: CI publishes immutable SemVer packages to `@Local`, automated tests validate them, quality gates promote versions to `@Prerelease`/`@Release`, and prod consumes `@Release`.

### Question 24 — B

Answer: `3.0.0`. Removing a public API member breaks backward source/binary compatibility and mandates incrementing the `MAJOR` version (`2.4.1` -> `3.0.0`). Under SemVer 2.0.0, removing or incompatibly altering a public method signature is a breaking change requiring a `MAJOR` bump (`2.4.1` -> `3.0.0`). Local study-map skill 3.3 (Design and Implement Dependency and Pipeline Artifact Versioning Strategies (SemVer, CalVer, Immutability)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `2.4.1-hotfix.1` actually sorts LOWER than `2.4.1` in SemVer precedence and does not signal a breaking API change. Why the keyed choice wins: Removing a public API member breaks backward source/binary compatibility and mandates incrementing the `MAJOR` version (`2.4.1` -> `3.0.0`).
- **B:** Correct. Under SemVer 2.0.0, removing or incompatibly altering a public method signature is a breaking change requiring a `MAJOR` bump (`2.4.1` -> `3.0.0`). In this scenario: Removing a public API member breaks backward source/binary compatibility and mandates incrementing the `MAJOR` version (`2.4.1` -> `3.0.0`).
- **C:** Incorrect for this requirement. `MINOR` (`2.5.0`) is reserved strictly for backward-compatible new functionality. Why the keyed choice wins: Removing a public API member breaks backward source/binary compatibility and mandates incrementing the `MAJOR` version (`2.4.1` -> `3.0.0`).
- **D:** Incorrect for this requirement. `PATCH` (`2.4.2`) is reserved strictly for backward-compatible bug fixes. Why the keyed choice wins: Removing a public API member breaks backward source/binary compatibility and mandates incrementing the `MAJOR` version (`2.4.1` -> `3.0.0`).

### Question 25 — C

Answer: Calendar Versioning (`YYYY.0M.Patch`, e.g., `2026.10.2`) for date-driven platform drops, OS images, or time-boxed compliance bundles. Calendar Versioning (`CalVer`, e.g., `YYYY.0M.Patch`) communicates time-bound patch currency immediately for OS images and compliance bundles. CalVer encodes release chronology directly into version identifiers when release cadence matters more than library API compatibility. Local study-map skill 3.3 (Design and Implement Dependency and Pipeline Artifact Versioning Strategies (SemVer, CalVer, Immutability)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. SemVer communicates compatibility guarantees: increment `MAJOR` on breaking changes, `MINOR` on additive features, `PATCH` on bug fixes, `-rc.1` for prereleases. Why the keyed choice wins: Calendar Versioning (`CalVer`, e.g., `YYYY.0M.Patch`) communicates time-bound patch currency immediately for OS images and compliance bundles.
- **B:** Incorrect for this requirement. Base64 is trivial reversible encoding, not encryption; secrets belong in Azure Key Vault / OIDC / Secure Files. Why the keyed choice wins: Calendar Versioning (`CalVer`, e.g., `YYYY.0M.Patch`) communicates time-bound patch currency immediately for OS images and compliance bundles.
- **C:** Correct. CalVer encodes release chronology directly into version identifiers when release cadence matters more than library API compatibility. In this scenario: Calendar Versioning (`CalVer`, e.g., `YYYY.0M.Patch`) communicates time-bound patch currency immediately for OS images and compliance bundles.
- **D:** Incorrect for this requirement. `2.4.1-hotfix.1` actually sorts LOWER than `2.4.1` in SemVer precedence and does not signal a breaking API change. Why the keyed choice wins: Calendar Versioning (`CalVer`, e.g., `YYYY.0M.Patch`) communicates time-bound patch currency immediately for OS images and compliance bundles.

### Question 26 — B

Answer: Once a `name@version` (e.g., `Core.Auth@1.4.0`) is published to Azure Artifacts, that exact version number is permanently immutable even if deleted. Published `package@version` coordinates in Azure Artifacts are permanently immutable to prevent dependency cache poisoning; fixes must increment to `1.8.1`. Immutability prevents supply-chain cache poisoning; fixes must always publish a new incremented version (`1.4.1`). Local study-map skill 3.3 (Design and Implement Dependency and Pipeline Artifact Versioning Strategies (SemVer, CalVer, Immutability)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `git stash` shelves uncommitted local working-tree edits and has zero effect on pushed commit history. Why the keyed choice wins: Published `package@version` coordinates in Azure Artifacts are permanently immutable to prevent dependency cache poisoning; fixes must increment to `1.8.1`.
- **B:** Correct. Immutability prevents supply-chain cache poisoning; fixes must always publish a new incremented version (`1.4.1`). In this scenario: Published `package@version` coordinates in Azure Artifacts are permanently immutable to prevent dependency cache poisoning; fixes must increment to `1.8.1`.
- **C:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: Published `package@version` coordinates in Azure Artifacts are permanently immutable to prevent dependency cache poisoning; fixes must increment to `1.8.1`.
- **D:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Published `package@version` coordinates in Azure Artifacts are permanently immutable to prevent dependency cache poisoning; fixes must increment to `1.8.1`.

### Question 27 — A

Answer: Azure Pipelines Environment `Query Azure Monitor alerts` check verifying zero active Sev0/Sev1 alerts during a post-deploy stabilization window. The built-in `Query Azure Monitor alerts` check evaluates active Azure Monitor alert states across a configurable stabilization window before allowing stage progression. Automated Azure Monitor checks halt ring promotion when newly deployed builds trigger production error or latency alerts. Local study-map skill 3.4 (Design and Implement Automated Quality, Governance, Work-Item, REST/Function, and Azure Monitor Release Gates), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Correct. Automated Azure Monitor checks halt ring promotion when newly deployed builds trigger production error or latency alerts. In this scenario: The built-in `Query Azure Monitor alerts` check evaluates active Azure Monitor alert states across a configurable stabilization window before allowing stage progression.
- **B:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: The built-in `Query Azure Monitor alerts` check evaluates active Azure Monitor alert states across a configurable stabilization window before allowing stage progression.
- **C:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: The built-in `Query Azure Monitor alerts` check evaluates active Azure Monitor alert states across a configurable stabilization window before allowing stage progression.
- **D:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: The built-in `Query Azure Monitor alerts` check evaluates active Azure Monitor alert states across a configurable stabilization window before allowing stage progression.

### Question 28 — A

Answer: Azure Pipelines `Query Work Items` check blocking production promotion whenever active `Severity 1` bugs exist for the release area. An Environment `Query Work Items` check executes a shared WIQL query and fails the gate whenever matching blocker bug count exceeds the configured threshold (`0`). Work Item Query checks enforce zero critical open defects automatically before promoting stages. Local study-map skill 3.4 (Design and Implement Automated Quality, Governance, Work-Item, REST/Function, and Azure Monitor Release Gates), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Correct. Work Item Query checks enforce zero critical open defects automatically before promoting stages. In this scenario: An Environment `Query Work Items` check executes a shared WIQL query and fails the gate whenever matching blocker bug count exceeds the configured threshold (`0`).
- **B:** Incorrect for this requirement. `git gc` repacks local objects but keeps huge binaries inside Git packfiles rather than moving them to LFS storage. Why the keyed choice wins: An Environment `Query Work Items` check executes a shared WIQL query and fails the gate whenever matching blocker bug count exceeds the configured threshold (`0`).
- **C:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: An Environment `Query Work Items` check executes a shared WIQL query and fails the gate whenever matching blocker bug count exceeds the configured threshold (`0`).
- **D:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: An Environment `Query Work Items` check executes a shared WIQL query and fails the gate whenever matching blocker bug count exceeds the configured threshold (`0`).

### Question 29 — C, D

Answers: Azure Pipelines Environment `Invoke Azure Function` or `Invoke REST API` check polling an external health/ServiceNow change endpoint; Azure Pipelines YAML `environment:` configured with Approvals (disallow requester self-approval), Business Hours check, Branch Control (`refs/heads/main`), and Exclusive Lock (`lockBehavior: sequential` or `runLatest`). `Invoke REST API` / `Invoke Azure Function` checks validate external ServiceNow change state, while Environment Approvals + Business Hours checks enforce governance windows. Local study-map skill 3.4 (Design and Implement Automated Quality, Governance, Work-Item, REST/Function, and Azure Monitor Release Gates), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: `Invoke REST API` / `Invoke Azure Function` checks validate external ServiceNow change state, while Environment Approvals + Business Hours checks enforce governance windows.
- **B:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: `Invoke REST API` / `Invoke Azure Function` checks validate external ServiceNow change state, while Environment Approvals + Business Hours checks enforce governance windows.
- **C:** Correct. Custom REST API / Azure Function checks integrate external ITSM change tickets (ServiceNow), synthetic probes, or compliance APIs into YAML gates. In this scenario: `Invoke REST API` / `Invoke Azure Function` checks validate external ServiceNow change state, while Environment Approvals + Business Hours checks enforce governance windows.
- **D:** Correct. Environment checks live in Azure DevOps UI/security outside repo edit permissions so developers cannot remove production approvals via a PR. In this scenario: `Invoke REST API` / `Invoke Azure Function` checks validate external ServiceNow change state, while Environment Approvals + Business Hours checks enforce governance windows.
- **E:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: `Invoke REST API` / `Invoke Azure Function` checks validate external ServiceNow change state, while Environment Approvals + Business Hours checks enforce governance windows.

### Question 30 — D

Answer: Run fast isolated unit tests + static linters on every PR commit, service/container integration tests post-merge, and Azure Load Testing on staging. Running fast isolated unit tests and static analysis on every PR commit while deferring integration/UI and cloud load tests to post-merge staging pipelines optimizes feedback speed. Test-pyramid staging keeps PR feedback under minutes while catching contract and scale bottlenecks before production. Local study-map skill 3.5 (Design Pipeline Testing Strategies (Unit, Integration, Functional UI, and Azure Load Testing Failure Criteria)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Multi-month unmerged branches create severe integration conflicts and delay continuous delivery compared to trunk-based workflows. Why the keyed choice wins: Running fast isolated unit tests and static analysis on every PR commit while deferring integration/UI and cloud load tests to post-merge staging pipelines optimizes feedback speed.
- **B:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Running fast isolated unit tests and static analysis on every PR commit while deferring integration/UI and cloud load tests to post-merge staging pipelines optimizes feedback speed.
- **C:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: Running fast isolated unit tests and static analysis on every PR commit while deferring integration/UI and cloud load tests to post-merge staging pipelines optimizes feedback speed.
- **D:** Correct. Test-pyramid staging keeps PR feedback under minutes while catching contract and scale bottlenecks before production. In this scenario: Running fast isolated unit tests and static analysis on every PR commit while deferring integration/UI and cloud load tests to post-merge staging pipelines optimizes feedback speed.

### Question 31 — D

Answer: Azure Load Testing (`AzureLoadTest@1` / `azure/load-testing@v1`) with YAML `failureCriteria` (`p90(response_time_ms) > 400`, `percentage(error) > 1`). Azure Load Testing (`AzureLoadTest@1`) executes JMeter/Locust tests at cloud scale and evaluates declarative `failureCriteria` to pass or fail CI/CD stages automatically. Managed Azure Load Testing executes JMeter/Locust scripts at cloud scale and fails the pipeline automatically when declarative `failureCriteria` breach. Local study-map skill 3.5 (Design Pipeline Testing Strategies (Unit, Integration, Functional UI, and Azure Load Testing Failure Criteria)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Azure Load Testing (`AzureLoadTest@1`) executes JMeter/Locust tests at cloud scale and evaluates declarative `failureCriteria` to pass or fail CI/CD stages automatically.
- **B:** Incorrect for this requirement. `CopyFiles@2` copies files between directories on the same agent during a single job. Why the keyed choice wins: Azure Load Testing (`AzureLoadTest@1`) executes JMeter/Locust tests at cloud scale and evaluates declarative `failureCriteria` to pass or fail CI/CD stages automatically.
- **C:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Azure Load Testing (`AzureLoadTest@1`) executes JMeter/Locust tests at cloud scale and evaluates declarative `failureCriteria` to pass or fail CI/CD stages automatically.
- **D:** Correct. Managed Azure Load Testing executes JMeter/Locust scripts at cloud scale and fails the pipeline automatically when declarative `failureCriteria` breach. In this scenario: Azure Load Testing (`AzureLoadTest@1`) executes JMeter/Locust tests at cloud scale and evaluates declarative `failureCriteria` to pass or fail CI/CD stages automatically.

### Question 32 — D

Answer: `succeededOrFailed()`. `succeededOrFailed()` runs `PublishTestResults@2` whether preceding test steps succeeded or exited non-zero, populating the Pipelines `Tests` tab on broken builds. `succeededOrFailed()` executes the task whether prior tasks succeeded or failed (skipping only if the job was canceled), ideal for `PublishTestResults@2`. Local study-map skill 3.6 (Configure Pipeline Test Execution, Parallel Slicing, JUnit/TRX Result Publishing, and Code Coverage Policies), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `canceled()` runs exclusively when a user or timeout aborts the pipeline job. Why the keyed choice wins: `succeededOrFailed()` runs `PublishTestResults@2` whether preceding test steps succeeded or exited non-zero, populating the Pipelines `Tests` tab on broken builds.
- **B:** Incorrect for this requirement. `failed()` skips publishing test results whenever all tests pass, leaving successful runs with empty test tabs. Why the keyed choice wins: `succeededOrFailed()` runs `PublishTestResults@2` whether preceding test steps succeeded or exited non-zero, populating the Pipelines `Tests` tab on broken builds.
- **C:** Incorrect for this requirement. `succeeded()` is the default condition and skips `PublishTestResults@2` whenever `dotnet test` exits non-zero on a failed assertion! Why the keyed choice wins: `succeededOrFailed()` runs `PublishTestResults@2` whether preceding test steps succeeded or exited non-zero, populating the Pipelines `Tests` tab on broken builds.
- **D:** Correct. `succeededOrFailed()` executes the task whether prior tasks succeeded or failed (skipping only if the job was canceled), ideal for `PublishTestResults@2`. In this scenario: `succeededOrFailed()` runs `PublishTestResults@2` whether preceding test steps succeeded or exited non-zero, populating the Pipelines `Tests` tab on broken builds.

### Question 33 — D

Answer: `PublishCodeCoverageResults@2` (Cobertura/JaCoCo/xml) paired with Azure Repos `buildpolicy.yml` or PR status policy enforcing >= 80% diff coverage. Publishing Cobertura/JaCoCo XML via `PublishCodeCoverageResults@2` paired with an Azure Repos `azurepipelines-coverage.yml` PR diff coverage status policy enforces >= 80% coverage on changed lines. Publishing Cobertura/JaCoCo reports plus PR diff coverage checks stops untested code paths from merging silently. Local study-map skill 3.6 (Configure Pipeline Test Execution, Parallel Slicing, JUnit/TRX Result Publishing, and Code Coverage Policies), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Publishing Cobertura/JaCoCo XML via `PublishCodeCoverageResults@2` paired with an Azure Repos `azurepipelines-coverage.yml` PR diff coverage status policy enforces >= 80% coverage on changed lines.
- **B:** Incorrect for this requirement. `ExtractFiles@1` unzips archives already on disk and cannot access encrypted Library Secure Files. Why the keyed choice wins: Publishing Cobertura/JaCoCo XML via `PublishCodeCoverageResults@2` paired with an Azure Repos `azurepipelines-coverage.yml` PR diff coverage status policy enforces >= 80% coverage on changed lines.
- **C:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: Publishing Cobertura/JaCoCo XML via `PublishCodeCoverageResults@2` paired with an Azure Repos `azurepipelines-coverage.yml` PR diff coverage status policy enforces >= 80% coverage on changed lines.
- **D:** Correct. Publishing Cobertura/JaCoCo reports plus PR diff coverage checks stops untested code paths from merging silently. In this scenario: Publishing Cobertura/JaCoCo XML via `PublishCodeCoverageResults@2` paired with an Azure Repos `azurepipelines-coverage.yml` PR diff coverage status policy enforces >= 80% coverage on changed lines.

### Question 34 — D

Answer: Use GitHub Actions for GitHub-native workflows/marketplace ecosystems, or Azure Pipelines when Azure Boards/Test Plans/Classic/Environment-gate governance is central. Connect GitHub Enterprise repositories to Azure Pipelines via the official Azure Pipelines GitHub App, combining GitHub PR status checks with Azure DevOps Environments and Artifacts. Both support multi-stage YAML and OIDC; Azure Pipelines adds deep Azure Boards/Test Plans/Environments integration while GitHub Actions unifies repo-native automation. Local study-map skill 3.7 (Select GitHub Actions vs. Azure Pipelines and Integrate GitHub Repositories with Azure Pipelines), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: Connect GitHub Enterprise repositories to Azure Pipelines via the official Azure Pipelines GitHub App, combining GitHub PR status checks with Azure DevOps Environments and Artifacts.
- **B:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Connect GitHub Enterprise repositories to Azure Pipelines via the official Azure Pipelines GitHub App, combining GitHub PR status checks with Azure DevOps Environments and Artifacts.
- **C:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: Connect GitHub Enterprise repositories to Azure Pipelines via the official Azure Pipelines GitHub App, combining GitHub PR status checks with Azure DevOps Environments and Artifacts.
- **D:** Correct. Both support multi-stage YAML and OIDC; Azure Pipelines adds deep Azure Boards/Test Plans/Environments integration while GitHub Actions unifies repo-native automation. In this scenario: Connect GitHub Enterprise repositories to Azure Pipelines via the official Azure Pipelines GitHub App, combining GitHub PR status checks with Azure DevOps Environments and Artifacts.

### Question 35 — D

Answer: Configure Azure Boards to GitHub connection using a departing contractor personal classic PAT instead of the GitHub App. Binding the repository service connection to an individual engineer's personal classic PAT causes webhook and checkout failures the moment their account is deprovisioned; use the GitHub App instead. Personal PAT connections break when the user loses access or the token expires; Microsoft recommends the Azure Boards GitHub App. Local study-map skill 3.7 (Select GitHub Actions vs. Azure Pipelines and Integrate GitHub Repositories with Azure Pipelines), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Unlike personal access tokens tied to a human employee seat, GitHub Apps survive employee offboarding and mint short-lived scoped tokens. Why the keyed choice wins: Binding the repository service connection to an individual engineer's personal classic PAT causes webhook and checkout failures the moment their account is deprovisioned; use the GitHub App instead.
- **B:** Incorrect for this requirement. Both support multi-stage YAML and OIDC; Azure Pipelines adds deep Azure Boards/Test Plans/Environments integration while GitHub Actions unifies repo-native automation. Why the keyed choice wins: Binding the repository service connection to an individual engineer's personal classic PAT causes webhook and checkout failures the moment their account is deprovisioned; use the GitHub App instead.
- **C:** Incorrect for this requirement. `AB#<ID>` creates a Development link on the Azure Boards work item, and `Fixes AB#<ID>` transitions it to Resolved/Done upon merge to default branch. Why the keyed choice wins: Binding the repository service connection to an individual engineer's personal classic PAT causes webhook and checkout failures the moment their account is deprovisioned; use the GitHub App instead.
- **D:** Correct. Personal PAT connections break when the user loses access or the token expires; Microsoft recommends the Azure Boards GitHub App. In this scenario: Binding the repository service connection to an individual engineer's personal classic PAT causes webhook and checkout failures the moment their account is deprovisioned; use the GitHub App instead.

### Question 36 — D

Answer: No — standard Microsoft-hosted agents run on shared public networks and cannot route to private-endpoint-only ACR/AKS without VNet-injected Managed DevOps Pools or self-hosted/VMSS agents. No — standard Microsoft-hosted agents run on shared public networks without private VNet routing; use VNet-injected Managed DevOps Pools, VMSS agents, or ARC self-hosted runners. Private-endpoint resources with `publicNetworkAccess: Disabled` reject public Microsoft-hosted agent traffic; VNet-integrated agent pools are required. Local study-map skill 3.8 (Design Hosted, Self-Hosted, Ephemeral ARC, VMSS, and VNet-Injected Managed DevOps Pool Runners/Agents), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Production pipelines must consume `feed@Release` so unverified `@Local` or `@Prerelease` packages are invisible to production restores. Why the keyed choice wins: No — standard Microsoft-hosted agents run on shared public networks without private VNet routing; use VNet-injected Managed DevOps Pools, VMSS agents, or ARC self-hosted runners.
- **B:** Incorrect for this requirement. Lead Time includes backlog queue time in `New`; Cycle Time specifically starts the clock when an item enters an `In Progress`/`Active` state category. Why the keyed choice wins: No — standard Microsoft-hosted agents run on shared public networks without private VNet routing; use VNet-injected Managed DevOps Pools, VMSS agents, or ARC self-hosted runners.
- **C:** Incorrect for this requirement. Every functional, networking, licensing, and security constraint in the scenario is satisfied natively. Why the keyed choice wins: No — standard Microsoft-hosted agents run on shared public networks without private VNet routing; use VNet-injected Managed DevOps Pools, VMSS agents, or ARC self-hosted runners.
- **D:** Correct. Private-endpoint resources with `publicNetworkAccess: Disabled` reject public Microsoft-hosted agent traffic; VNet-integrated agent pools are required. In this scenario: No — standard Microsoft-hosted agents run on shared public networks without private VNet routing; use VNet-injected Managed DevOps Pools, VMSS agents, or ARC self-hosted runners.

### Question 37 — B

Answer: Managed DevOps Pools: Microsoft-managed scale-set agents injected into your private Azure VNet using Azure Pipelines / custom images and stateless mode. Managed DevOps Pools deliver Microsoft-managed stateless/stateful scale-set agents injected directly into customer VNet subnets with zero manual VM image patching. Managed DevOps Pools combine zero VM patching/maintenance overhead of Microsoft-hosted agents with private VNet connectivity and custom SKUs. Local study-map skill 3.8 (Design Hosted, Self-Hosted, Ephemeral ARC, VMSS, and VNet-Injected Managed DevOps Pool Runners/Agents), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Exposing regulated production data planes to all public internet IPs violates private-VNet security requirements. Why the keyed choice wins: Managed DevOps Pools deliver Microsoft-managed stateless/stateful scale-set agents injected directly into customer VNet subnets with zero manual VM image patching.
- **B:** Correct. Managed DevOps Pools combine zero VM patching/maintenance overhead of Microsoft-hosted agents with private VNet connectivity and custom SKUs. In this scenario: Managed DevOps Pools deliver Microsoft-managed stateless/stateful scale-set agents injected directly into customer VNet subnets with zero manual VM image patching.
- **C:** Incorrect for this requirement. Persistent self-hosted agents require explicit workspace cleanup (`workspace: clean: all`) and credential hygiene to avoid cross-job leakage. Why the keyed choice wins: Managed DevOps Pools deliver Microsoft-managed stateless/stateful scale-set agents injected directly into customer VNet subnets with zero manual VM image patching.
- **D:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Managed DevOps Pools deliver Microsoft-managed stateless/stateful scale-set agents injected directly into customer VNet subnets with zero manual VM image patching.

### Question 38 — C

Answer: Provision a VNet subnet with outbound 443 to Azure DevOps and private endpoints to ACR/AKS → deploy a Managed DevOps Pool or VMSS pool into that subnet → enable stateless fresh-image teardown per job → target `pool:` in YAML. Provision the VNet subnet with outbound 443 to Azure DevOps and private endpoints to ACR/AKS, inject a Managed DevOps Pool or VMSS pool, enable per-job fresh reimaging, and reference `pool:` in YAML. VNet-injected Managed DevOps Pools or VMSS agents reach private ACR/AKS endpoints privately while ephemeral image resets prevent cross-build workspace contamination. Local study-map skill 3.8 (Design Hosted, Self-Hosted, Ephemeral ARC, VMSS, and VNet-Injected Managed DevOps Pool Runners/Agents), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Expired user PATs break automation and un-injected public VMs still cannot route to private endpoints. Why the keyed choice wins: Provision the VNet subnet with outbound 443 to Azure DevOps and private endpoints to ACR/AKS, inject a Managed DevOps Pool or VMSS pool, enable per-job fresh reimaging, and reference `pool:` in YAML.
- **B:** Incorrect for this requirement. Opening private clusters to all internet IPs breaks network isolation when VNet-integrated agent pools solve private reachability cleanly. Why the keyed choice wins: Provision the VNet subnet with outbound 443 to Azure DevOps and private endpoints to ACR/AKS, inject a Managed DevOps Pool or VMSS pool, enable per-job fresh reimaging, and reference `pool:` in YAML.
- **C:** Correct. VNet-injected Managed DevOps Pools or VMSS agents reach private ACR/AKS endpoints privately while ephemeral image resets prevent cross-build workspace contamination. In this scenario: Provision the VNet subnet with outbound 443 to Azure DevOps and private endpoints to ACR/AKS, inject a Managed DevOps Pool or VMSS pool, enable per-job fresh reimaging, and reference `pool:` in YAML.
- **D:** Incorrect for this requirement. Agents require outbound HTTPS 443 connectivity to Azure DevOps to poll job queues, and developer laptops violate build reproducibility. Why the keyed choice wins: Provision the VNet subnet with outbound 443 to Azure DevOps and private endpoints to ACR/AKS, inject a Managed DevOps Pool or VMSS pool, enable per-job fresh reimaging, and reference `pool:` in YAML.

### Question 39 — A

Answer: Configure `trigger:` and `pr:` `branches: include: [main]` with `paths: include: [src/order-api/*]` and `exclude: [docs/*, "*.md"]`. Adding `paths: include: [src/payments-api/*]` and `exclude: [docs/*, "*.md"]` under `trigger:` and `pr:` restricts CI runs to relevant code changes. Path filters in multi-service repos ensure Markdown edits (`docs/**`) do not waste build minutes while code changes trigger targeted CI. Local study-map skill 3.9 (Develop CI, PR, Path-Filtered, Scheduled Cron, Manual Dispatch, and Chained Pipeline Resource Triggers), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Correct. Path filters in multi-service repos ensure Markdown edits (`docs/**`) do not waste build minutes while code changes trigger targeted CI. In this scenario: Adding `paths: include: [src/payments-api/*]` and `exclude: [docs/*, "*.md"]` under `trigger:` and `pr:` restricts CI runs to relevant code changes.
- **B:** Incorrect for this requirement. `git gc` repacks local objects but keeps huge binaries inside Git packfiles rather than moving them to LFS storage. Why the keyed choice wins: Adding `paths: include: [src/payments-api/*]` and `exclude: [docs/*, "*.md"]` under `trigger:` and `pr:` restricts CI runs to relevant code changes.
- **C:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: Adding `paths: include: [src/payments-api/*]` and `exclude: [docs/*, "*.md"]` under `trigger:` and `pr:` restricts CI runs to relevant code changes.
- **D:** Incorrect for this requirement. Fetching only the single target commit (`fetchDepth: 1`) drastically cuts network transfer and checkout time on large repositories. Why the keyed choice wins: Adding `paths: include: [src/payments-api/*]` and `exclude: [docs/*, "*.md"]` under `trigger:` and `pr:` restricts CI runs to relevant code changes.

### Question 40 — C

Answer: Azure Pipelines `resources.pipelines` trigger (`source: CoreLib-CI`, `trigger: branches: include: [main]`) chaining downstream deployments to upstream CI completion. Declaring `resources: pipelines: - pipeline: contracts` with `source: Shared-Contracts-CI` and `trigger: branches: include: [main]` chains multi-pipeline execution cleanly. Pipeline resource triggers decouple upstream build YAML from downstream deployment pipelines cleanly. Local study-map skill 3.9 (Develop CI, PR, Path-Filtered, Scheduled Cron, Manual Dispatch, and Chained Pipeline Resource Triggers), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `ExtractFiles@1` unzips archives already on disk and cannot access encrypted Library Secure Files. Why the keyed choice wins: Declaring `resources: pipelines: - pipeline: contracts` with `source: Shared-Contracts-CI` and `trigger: branches: include: [main]` chains multi-pipeline execution cleanly.
- **B:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Declaring `resources: pipelines: - pipeline: contracts` with `source: Shared-Contracts-CI` and `trigger: branches: include: [main]` chains multi-pipeline execution cleanly.
- **C:** Correct. Pipeline resource triggers decouple upstream build YAML from downstream deployment pipelines cleanly. In this scenario: Declaring `resources: pipelines: - pipeline: contracts` with `source: Shared-Contracts-CI` and `trigger: branches: include: [main]` chains multi-pipeline execution cleanly.
- **D:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Declaring `resources: pipelines: - pipeline: contracts` with `source: Shared-Contracts-CI` and `trigger: branches: include: [main]` chains multi-pipeline execution cleanly.

### Question 41 — A, E

Answers: `on: push`, `pull_request` (with `paths-ignore: ["docs/**"]`), `schedule` (`cron`), `workflow_dispatch` (manual typed inputs), and `repository_dispatch`; Configure `trigger:` and `pr:` `branches: include: [main]` with `paths: include: [src/order-api/*]` and `exclude: [docs/*, "*.md"]`. `workflow_dispatch` (manual typed inputs) + `repository_dispatch` (external API events) handle GitHub custom triggers, while `paths: include/exclude` filters Azure Pipelines runs. Local study-map skill 3.9 (Develop CI, PR, Path-Filtered, Scheduled Cron, Manual Dispatch, and Chained Pipeline Resource Triggers), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Correct. `workflow_dispatch` adds manual parameterized UI/API runs, `repository_dispatch` accepts external webhook triggers, and `paths-ignore` skips doc-only pushes. In this scenario: `workflow_dispatch` (manual typed inputs) + `repository_dispatch` (external API events) handle GitHub custom triggers, while `paths: include/exclude` filters Azure Pipelines runs.
- **B:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: `workflow_dispatch` (manual typed inputs) + `repository_dispatch` (external API events) handle GitHub custom triggers, while `paths: include/exclude` filters Azure Pipelines runs.
- **C:** Incorrect for this requirement. `git stash` shelves uncommitted local working-tree edits and has zero effect on pushed commit history. Why the keyed choice wins: `workflow_dispatch` (manual typed inputs) + `repository_dispatch` (external API events) handle GitHub custom triggers, while `paths: include/exclude` filters Azure Pipelines runs.
- **D:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: `workflow_dispatch` (manual typed inputs) + `repository_dispatch` (external API events) handle GitHub custom triggers, while `paths: include/exclude` filters Azure Pipelines runs.
- **E:** Correct. Path filters in multi-service repos ensure Markdown edits (`docs/**`) do not waste build minutes while code changes trigger targeted CI. In this scenario: `workflow_dispatch` (manual typed inputs) + `repository_dispatch` (external API events) handle GitHub custom triggers, while `paths: include/exclude` filters Azure Pipelines runs.

### Question 42 — C

Answer: Compile-time `${{ variables.Env }}` (expanded before pipeline validation) vs runtime `$[variables.Env]` vs macro `$(Env)` (expanded right before task runs). Compile-time `$\x7b\x7b \x7d\x7d` expands during template parsing before validation, runtime `$[ ]` evaluates stage/job conditions, and macro `$( )` expands right before each task executes. Template structure (`stages`/`jobs` conditionals) requires compile-time `${{ }}`, stage/job `condition:` uses runtime `$[ ]`, and script steps use `$( )`. Local study-map skill 3.10 (Implement Multi-Stage YAML Job Execution Order, Fan-Out/Fan-In dependsOn, Conditions, and Matrix Parallelism), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `git stash` shelves uncommitted local working-tree edits and has zero effect on pushed commit history. Why the keyed choice wins: Compile-time `$\x7b\x7b \x7d\x7d` expands during template parsing before validation, runtime `$[ ]` evaluates stage/job conditions, and macro `$( )` expands right before each task executes.
- **B:** Incorrect for this requirement. Base64 is trivial reversible encoding, not encryption; secrets belong in Azure Key Vault / OIDC / Secure Files. Why the keyed choice wins: Compile-time `$\x7b\x7b \x7d\x7d` expands during template parsing before validation, runtime `$[ ]` evaluates stage/job conditions, and macro `$( )` expands right before each task executes.
- **C:** Correct. Template structure (`stages`/`jobs` conditionals) requires compile-time `${{ }}`, stage/job `condition:` uses runtime `$[ ]`, and script steps use `$( )`. In this scenario: Compile-time `$\x7b\x7b \x7d\x7d` expands during template parsing before validation, runtime `$[ ]` evaluates stage/job conditions, and macro `$( )` expands right before each task executes.
- **D:** Incorrect for this requirement. `isoutput=true` exposes the variable to downstream jobs/stages in cleartext without masking it as a secret in build logs! Why the keyed choice wins: Compile-time `$\x7b\x7b \x7d\x7d` expands during template parsing before validation, runtime `$[ ]` evaluates stage/job conditions, and macro `$( )` expands right before each task executes.

### Question 43 — A

Answer: No — recompiling source code from `HEAD` inside each deployment stage violates build-once-deploy-many and can ship untested commits to production. No — rebuilding source in every stage risks compiling newer commits or updated floating transitive dependencies; compile once in `Build`, publish an immutable artifact, and deploy that artifact across `QA` and `Prod`. Multi-stage YAML should compile and package ONCE in the Build stage (`PublishPipelineArtifact`), then download and deploy that exact immutable artifact in QA and Prod. Local study-map skill 3.10 (Implement Multi-Stage YAML Job Execution Order, Fan-Out/Fan-In dependsOn, Conditions, and Matrix Parallelism), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Correct. Multi-stage YAML should compile and package ONCE in the Build stage (`PublishPipelineArtifact`), then download and deploy that exact immutable artifact in QA and Prod. In this scenario: No — rebuilding source in every stage risks compiling newer commits or updated floating transitive dependencies; compile once in `Build`, publish an immutable artifact, and deploy that artifact across `QA` and `Prod`.
- **B:** Incorrect for this requirement. Deleting a secret in a new commit leaves the cleartext blob inside historical commits (`git log -p`) and fails to revoke the leaked credential. Why the keyed choice wins: No — rebuilding source in every stage risks compiling newer commits or updated floating transitive dependencies; compile once in `Build`, publish an immutable artifact, and deploy that artifact across `QA` and `Prod`.
- **C:** Incorrect for this requirement. Every functional, networking, licensing, and security constraint in the scenario is satisfied natively. Why the keyed choice wins: No — rebuilding source in every stage risks compiling newer commits or updated floating transitive dependencies; compile once in `Build`, publish an immutable artifact, and deploy that artifact across `QA` and `Prod`.
- **D:** Incorrect for this requirement. `pull_request_target` runs in the context of the base repository with secret access; checking out untrusted fork code inside it creates a critical pwn-request vulnerability. Why the keyed choice wins: No — rebuilding source in every stage risks compiling newer commits or updated floating transitive dependencies; compile once in `Build`, publish an immutable artifact, and deploy that artifact across `QA` and `Prod`.

### Question 44 — D, E

Answers: Set `dependsOn: [Deploy_EastUS, Deploy_WestEurope, Deploy_SoutheastAsia]` and `condition: succeeded()` on the final `Global_SmokeTest` stage; `strategy: matrix:` across OS/runtime combinations (`ubuntu-latest`/`windows-latest` x `net8.0`/`net9.0`) with `maxParallel` concurrency control. `strategy: matrix:` runs concurrent OS/runtime build permutations, and `dependsOn: [EastUS, WestEurope, SoutheastAsia]` with `condition: succeeded()` implements the regional fan-in barrier. Local study-map skill 3.10 (Implement Multi-Stage YAML Job Execution Order, Fan-Out/Fan-In dependsOn, Conditions, and Matrix Parallelism), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `lockBehavior: runLatest` executes only the newest queued run and cancels intermediate waiting runs — unsuitable when sequential ordered migrations must all run. Why the keyed choice wins: `strategy: matrix:` runs concurrent OS/runtime build permutations, and `dependsOn: [EastUS, WestEurope, SoutheastAsia]` with `condition: succeeded()` implements the regional fan-in barrier.
- **B:** Incorrect for this requirement. Persistent self-hosted agents require explicit workspace cleanup (`workspace: clean: all`) and credential hygiene to avoid cross-job leakage. Why the keyed choice wins: `strategy: matrix:` runs concurrent OS/runtime build permutations, and `dependsOn: [EastUS, WestEurope, SoutheastAsia]` with `condition: succeeded()` implements the regional fan-in barrier.
- **C:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: `strategy: matrix:` runs concurrent OS/runtime build permutations, and `dependsOn: [EastUS, WestEurope, SoutheastAsia]` with `condition: succeeded()` implements the regional fan-in barrier.
- **D:** Correct. Matrix strategies expand one job definition into concurrent platform/version permutations without duplicating YAML steps. In this scenario: `strategy: matrix:` runs concurrent OS/runtime build permutations, and `dependsOn: [EastUS, WestEurope, SoutheastAsia]` with `condition: succeeded()` implements the regional fan-in barrier.
- **E:** Correct. Listing multiple upstream stages in `dependsOn` creates a fan-in barrier that runs only when all parallel regional stages succeed. In this scenario: `strategy: matrix:` runs concurrent OS/runtime build permutations, and `dependsOn: [EastUS, WestEurope, SoutheastAsia]` with `condition: succeeded()` implements the regional fan-in barrier.

### Question 45 — B

Answer: `extends:`. Top-level `extends:` forces the pipeline to execute inside the governed template structure, which can be cryptographically enforced by Environment `Required template` checks. Top-level `extends:` forces the pipeline to inherit required stages/jobs/steps from a governed YAML template enforceable by Environment `Required template` checks. Local study-map skill 3.11 (Develop Reusable YAML Templates (extends/include), Reusable Workflows, Composite Actions, Task Groups, and Variables), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `import:` is not a valid Azure Pipelines YAML keyword. Why the keyed choice wins: Top-level `extends:` forces the pipeline to execute inside the governed template structure, which can be cryptographically enforced by Environment `Required template` checks.
- **B:** Correct. Top-level `extends:` forces the pipeline to inherit required stages/jobs/steps from a governed YAML template enforceable by Environment `Required template` checks. In this scenario: Top-level `extends:` forces the pipeline to execute inside the governed template structure, which can be cryptographically enforced by Environment `Required template` checks.
- **C:** Incorrect for this requirement. Azure Pipelines YAML has no top-level `include:` pipeline wrapper keyword (`template:` is used inside `steps`/`jobs`/`stages`/`variables` lists). Why the keyed choice wins: Top-level `extends:` forces the pipeline to execute inside the governed template structure, which can be cryptographically enforced by Environment `Required template` checks.
- **D:** Incorrect for this requirement. `uses:` is GitHub Actions syntax for invoking an action or reusable workflow, not Azure Pipelines root template inheritance. Why the keyed choice wins: Top-level `extends:` forces the pipeline to execute inside the governed template structure, which can be cryptographically enforced by Environment `Required template` checks.

### Question 46 — D

Answer: GitHub Actions reusable workflow (`on: workflow_call`) vs Composite Action (`runs: using: "composite"` bundling multi-step shell/action sequences). A GitHub Reusable Workflow (`on: workflow_call`) supports full jobs, matrices, `environment:` gates, and `secrets: inherit`, whereas Composite Actions only bundle steps within an existing job. Reusable workflows (`workflow_call`) encapsulate full jobs/environments/secrets, whereas composite actions bundle reusable steps inside a single job. Local study-map skill 3.11 (Develop Reusable YAML Templates (extends/include), Reusable Workflows, Composite Actions, Task Groups, and Variables), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: A GitHub Reusable Workflow (`on: workflow_call`) supports full jobs, matrices, `environment:` gates, and `secrets: inherit`, whereas Composite Actions only bundle steps within an existing job.
- **B:** Incorrect for this requirement. Migrating Classic pipelines brings CI/CD under Git pull-request review, branch history, and template enforcement. Why the keyed choice wins: A GitHub Reusable Workflow (`on: workflow_call`) supports full jobs, matrices, `environment:` gates, and `secrets: inherit`, whereas Composite Actions only bundle steps within an existing job.
- **C:** Incorrect for this requirement. `ExtractFiles@1` unzips archives already on disk and cannot access encrypted Library Secure Files. Why the keyed choice wins: A GitHub Reusable Workflow (`on: workflow_call`) supports full jobs, matrices, `environment:` gates, and `secrets: inherit`, whereas Composite Actions only bundle steps within an existing job.
- **D:** Correct. Reusable workflows (`workflow_call`) encapsulate full jobs/environments/secrets, whereas composite actions bundle reusable steps inside a single job. In this scenario: A GitHub Reusable Workflow (`on: workflow_call`) supports full jobs, matrices, `environment:` gates, and `secrets: inherit`, whereas Composite Actions only bundle steps within an existing job.

### Question 47 — A

Answer: Author the hardened YAML template in a protected repository → reference that repo via `resources.repositories` and `extends` → open target Environment Approvals and checks → add a Required template check for that template path. Author the template in a protected repo, reference it via `resources.repositories` and `extends`, open `prod-payments` Environment checks, and add a `Required template` check. Environment Required template checks verify at deployment time that the pipeline extends the exact mandated YAML template from the specified repository/ref. Local study-map skill 3.12 (Configure YAML Environments with Approvals, Business Hours, Branch Control, Exclusive Locks, and Required Templates), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Correct. Environment Required template checks verify at deployment time that the pipeline extends the exact mandated YAML template from the specified repository/ref. In this scenario: Author the template in a protected repo, reference it via `resources.repositories` and `extends`, open `prod-payments` Environment checks, and add a `Required template` check.
- **B:** Incorrect for this requirement. Inline copy-pasted steps fail the Required template check because the pipeline must formally `extends` the protected YAML template. Why the keyed choice wins: Author the template in a protected repo, reference it via `resources.repositories` and `extends`, open `prod-payments` Environment checks, and add a `Required template` check.
- **C:** Incorrect for this requirement. Variable-only `include` does not satisfy a Required template check (`extends`), and checks must precede production deployment. Why the keyed choice wins: Author the template in a protected repo, reference it via `resources.repositories` and `extends`, open `prod-payments` Environment checks, and add a `Required template` check.
- **D:** Incorrect for this requirement. An unprotected template branch allows tampering, and omitting `extends` bypasses template structure enforcement. Why the keyed choice wins: Author the template in a protected repo, reference it via `resources.repositories` and `extends`, open `prod-payments` Environment checks, and add a `Required template` check.

### Question 48 — A

Answer: Blue-Green deployment maintaining two identical production-grade environments (`Blue` live, `Green` idle/staged) and switching router/Front Door/slot VIP atomically. Blue-Green deployment provisions two identical production environments (`Blue` active, `Green` staged) and flips router/VIP traffic atomically with instant cutback capability. Blue-Green eliminates in-place upgrade downtime and enables instantaneous rollback by routing traffic back to `Blue`. Local study-map skill 3.13 (Design Progressive Exposure Deployment Strategies (Blue-Green, Canary, Rings, Traffic Routing, and A/B Testing)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Correct. Blue-Green eliminates in-place upgrade downtime and enables instantaneous rollback by routing traffic back to `Blue`. In this scenario: Blue-Green deployment provisions two identical production environments (`Blue` active, `Green` staged) and flips router/VIP traffic atomically with instant cutback capability.
- **B:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Blue-Green deployment provisions two identical production environments (`Blue` active, `Green` staged) and flips router/VIP traffic atomically with instant cutback capability.
- **C:** Incorrect for this requirement. Multi-month unmerged branches create severe integration conflicts and delay continuous delivery compared to trunk-based workflows. Why the keyed choice wins: Blue-Green deployment provisions two identical production environments (`Blue` active, `Green` staged) and flips router/VIP traffic atomically with instant cutback capability.
- **D:** Incorrect for this requirement. Unlike canary (technical health validation), A/B testing measures product/business conversion outcomes across cohorts. Why the keyed choice wins: Blue-Green deployment provisions two identical production environments (`Blue` active, `Green` staged) and flips router/VIP traffic atomically with instant cutback capability.

### Question 49 — B

Answer: A/B testing routing user cohorts to Variant A vs Variant B coupled with Application Insights custom business conversion telemetry. A/B testing routes segmented user cohorts to Variant A vs Variant B while measuring business/product conversion metrics rather than purely infrastructure error rates. Unlike canary (technical health validation), A/B testing measures product/business conversion outcomes across cohorts. Local study-map skill 3.13 (Design Progressive Exposure Deployment Strategies (Blue-Green, Canary, Rings, Traffic Routing, and A/B Testing)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Running `what-if` in pre-deployment CI/CD surfaces unintended destructive changes or manual portal drift before `create` executes. Why the keyed choice wins: A/B testing routes segmented user cohorts to Variant A vs Variant B while measuring business/product conversion metrics rather than purely infrastructure error rates.
- **B:** Correct. Unlike canary (technical health validation), A/B testing measures product/business conversion outcomes across cohorts. In this scenario: A/B testing routes segmented user cohorts to Variant A vs Variant B while measuring business/product conversion metrics rather than purely infrastructure error rates.
- **C:** Incorrect for this requirement. Blue-Green eliminates in-place upgrade downtime and enables instantaneous rollback by routing traffic back to `Blue`. Why the keyed choice wins: A/B testing routes segmented user cohorts to Variant A vs Variant B while measuring business/product conversion metrics rather than purely infrastructure error rates.
- **D:** Incorrect for this requirement. Fetching only the single target commit (`fetchDepth: 1`) drastically cuts network transfer and checkout time on large repositories. Why the keyed choice wins: A/B testing routes segmented user cohorts to Variant A vs Variant B while measuring business/product conversion metrics rather than purely infrastructure error rates.

### Question 50 — C

Answer: Build once and publish one immutable artifact in CI → deploy to `Canary` targeting 5% of users → evaluate Azure Monitor alert/KQL gates over a bake window → promote the identical artifact to `EarlyAdopter` and `Global` stages. Build one immutable artifact in CI, deploy to `Canary` (5%), evaluate automated Azure Monitor health gates over a bake window, and promote the same artifact to `EarlyAdopter` and `Global`. Progressive exposure deploys one immutable build across widening blast-radius rings gated by automated live telemetry health checks. Local study-map skill 3.13 (Design Progressive Exposure Deployment Strategies (Blue-Green, Canary, Rings, Traffic Routing, and A/B Testing)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Separate forks per ring create severe code divergence instead of promoting one immutable artifact through environment rings. Why the keyed choice wins: Build one immutable artifact in CI, deploy to `Canary` (5%), evaluate automated Azure Monitor health gates over a bake window, and promote the same artifact to `EarlyAdopter` and `Global`.
- **B:** Incorrect for this requirement. Deploying to 100% first defeats blast-radius containment, and rebuilding per ring risks shipping different commits. Why the keyed choice wins: Build one immutable artifact in CI, deploy to `Canary` (5%), evaluate automated Azure Monitor health gates over a bake window, and promote the same artifact to `EarlyAdopter` and `Global`.
- **C:** Correct. Progressive exposure deploys one immutable build across widening blast-radius rings gated by automated live telemetry health checks. In this scenario: Build one immutable artifact in CI, deploy to `Canary` (5%), evaluate automated Azure Monitor health gates over a bake window, and promote the same artifact to `EarlyAdopter` and `Global`.
- **D:** Incorrect for this requirement. Azure Pipelines rejects gates whose timeout is shorter than initial delay/interval, and overriding failed health signals propagates incidents. Why the keyed choice wins: Build one immutable artifact in CI, deploy to `Canary` (5%), evaluate automated Azure Monitor health gates over a bake window, and promote the same artifact to `EarlyAdopter` and `Global`.

### Question 51 — B

Answer: Backward-compatible Expand-and-Contract (Parallel Change) schema pattern: add nullable column/new table first, deploy dual-compatible app code, backfill, then remove the legacy column in a later release. The Expand-and-Contract (Parallel Change) pattern adds nullable `GivenName`/`Surname` columns first, dual-writes across `v1`/`v2`, backfills existing rows, and removes `FullName` only after `v1` retires. Zero-downtime blue-green/canary rollouts break if a DB deployment renames or removes columns still queried by active N-1 app instances. Local study-map skill 3.14 (Plan Ordered Dependency Rollouts, Zero-Downtime Slot Swaps, Warm-Up, Rollback Resiliency, and Hotfix Paths), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: The Expand-and-Contract (Parallel Change) pattern adds nullable `GivenName`/`Surname` columns first, dual-writes across `v1`/`v2`, backfills existing rows, and removes `FullName` only after `v1` retires.
- **B:** Correct. Zero-downtime blue-green/canary rollouts break if a DB deployment renames or removes columns still queried by active N-1 app instances. In this scenario: The Expand-and-Contract (Parallel Change) pattern adds nullable `GivenName`/`Surname` columns first, dual-writes across `v1`/`v2`, backfills existing rows, and removes `FullName` only after `v1` retires.
- **C:** Incorrect for this requirement. ARM `Complete` mode deletes every existing resource in the target resource group omitted from the current template! Why the keyed choice wins: The Expand-and-Contract (Parallel Change) pattern adds nullable `GivenName`/`Surname` columns first, dual-writes across `v1`/`v2`, backfills existing rows, and removes `FullName` only after `v1` retires.
- **D:** Incorrect for this requirement. `AzureRmWebAppDeployment@4` deploys App Service web packages rather than standalone multi-stage SQL `.dacpac` schema diffs. Why the keyed choice wins: The Expand-and-Contract (Parallel Change) pattern adds nullable `GivenName`/`Surname` columns first, dual-writes across `v1`/`v2`, backfills existing rows, and removes `FullName` only after `v1` retires.

### Question 52 — C

Answer: App Service `staging` deployment slot with `applicationInitialization` warm-up paths, slot-pinned connection strings, and Auto-Swap / Swap with Preview. Configuring `applicationInitialization` warm-up paths (or `WEBSITE_SWAP_WARMUP_PING_PATH` + expected status codes) with slot-pinned settings warms worker processes completely before traffic swaps. Warm-up hits internal HTTP paths before VIP swap so cold-start JIT latencies never affect live traffic. Local study-map skill 3.14 (Plan Ordered Dependency Rollouts, Zero-Downtime Slot Swaps, Warm-Up, Rollback Resiliency, and Hotfix Paths), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `AzureFileCopy@5` copies blobs or VM files via AzCopy and cannot compare or apply `.dacpac` SQL schemas. Why the keyed choice wins: Configuring `applicationInitialization` warm-up paths (or `WEBSITE_SWAP_WARMUP_PING_PATH` + expected status codes) with slot-pinned settings warms worker processes completely before traffic swaps.
- **B:** Incorrect for this requirement. Exposing regulated production data planes to all public internet IPs violates private-VNet security requirements. Why the keyed choice wins: Configuring `applicationInitialization` warm-up paths (or `WEBSITE_SWAP_WARMUP_PING_PATH` + expected status codes) with slot-pinned settings warms worker processes completely before traffic swaps.
- **C:** Correct. Warm-up hits internal HTTP paths before VIP swap so cold-start JIT latencies never affect live traffic. In this scenario: Configuring `applicationInitialization` warm-up paths (or `WEBSITE_SWAP_WARMUP_PING_PATH` + expected status codes) with slot-pinned settings warms worker processes completely before traffic swaps.
- **D:** Incorrect for this requirement. `git gc` repacks local objects but keeps huge binaries inside Git packfiles rather than moving them to LFS storage. Why the keyed choice wins: Configuring `applicationInitialization` warm-up paths (or `WEBSITE_SWAP_WARMUP_PING_PATH` + expected status codes) with slot-pinned settings warms worker processes completely before traffic swaps.

### Question 53 — A

Answer: Azure App Configuration Feature Manager with `Microsoft.TimeWindow` filter activating a promotional feature automatically between UTC `Start` and `End` timestamps. `Microsoft.TimeWindow` evaluates UTC `Start` and `End` timestamps dynamically inside `Microsoft.FeatureManagement` without redeploying application binaries. `Microsoft.TimeWindow` enables scheduled flash-sale or cutover windows without manual toggles or redeployments. Local study-map skill 3.15 (Implement Dynamic Feature Flags with Azure App Configuration Feature Manager (Targeting, Percentage, TimeWindow)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Correct. `Microsoft.TimeWindow` enables scheduled flash-sale or cutover windows without manual toggles or redeployments. In this scenario: `Microsoft.TimeWindow` evaluates UTC `Start` and `End` timestamps dynamically inside `Microsoft.FeatureManagement` without redeploying application binaries.
- **B:** Incorrect for this requirement. Azure Automation State Configuration compiles PowerShell DSC configurations into MOF artifacts to audit or remediate OS state. Why the keyed choice wins: `Microsoft.TimeWindow` evaluates UTC `Start` and `End` timestamps dynamically inside `Microsoft.FeatureManagement` without redeploying application binaries.
- **C:** Incorrect for this requirement. Annotated tags are full immutable Git objects ideal for auditable production releases, unlike lightweight tags which are bare commit pointers. Why the keyed choice wins: `Microsoft.TimeWindow` evaluates UTC `Start` and `End` timestamps dynamically inside `Microsoft.FeatureManagement` without redeploying application binaries.
- **D:** Incorrect for this requirement. Under SemVer 2.0.0, removing or incompatibly altering a public method signature is a breaking change requiring a `MAJOR` bump (`2.4.1` -> `3.0.0`). Why the keyed choice wins: `Microsoft.TimeWindow` evaluates UTC `Start` and `End` timestamps dynamically inside `Microsoft.FeatureManagement` without redeploying application binaries.

### Question 54 — C

Answer: Create the feature flag with `Microsoft.Targeting` in App Configuration → register `AddAzureAppConfiguration` (`UseFeatureFlags`) and `AddFeatureManagement` → gate code with `IFeatureManager.IsEnabledAsync` → ramp rollout % without redeploying. Define the flag with `Microsoft.Targeting` in App Configuration, register `AddAzureAppConfiguration` (`UseFeatureFlags`) + `AddFeatureManagement`, guard code with `IFeatureManager.IsEnabledAsync`, and ramp cohort percentages dynamically. Decoupling deployment from release via `Microsoft.FeatureManagement` lets teams toggle or ramp user cohorts dynamically without new builds. Local study-map skill 3.15 (Implement Dynamic Feature Flags with Azure App Configuration Feature Manager (Targeting, Percentage, TimeWindow)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Compile-time constants require full redeployments and restarts for every cohort change or rollback. Why the keyed choice wins: Define the flag with `Microsoft.Targeting` in App Configuration, register `AddAzureAppConfiguration` (`UseFeatureFlags`) + `AddFeatureManagement`, guard code with `IFeatureManager.IsEnabledAsync`, and ramp cohort percentages dynamically.
- **B:** Incorrect for this requirement. Feature flags live in Azure App Configuration (`.appconfig.featureflag/*`), not X.509 certificates, and require `UseAzureAppConfiguration` refresh middleware. Why the keyed choice wins: Define the flag with `Microsoft.Targeting` in App Configuration, register `AddAzureAppConfiguration` (`UseFeatureFlags`) + `AddFeatureManagement`, guard code with `IFeatureManager.IsEnabledAsync`, and ramp cohort percentages dynamically.
- **C:** Correct. Decoupling deployment from release via `Microsoft.FeatureManagement` lets teams toggle or ramp user cohorts dynamically without new builds. In this scenario: Define the flag with `Microsoft.Targeting` in App Configuration, register `AddAzureAppConfiguration` (`UseFeatureFlags`) + `AddFeatureManagement`, guard code with `IFeatureManager.IsEnabledAsync`, and ramp cohort percentages dynamically.
- **D:** Incorrect for this requirement. Branch-per-cohort explodes merge debt and infrastructure cost compared to trunk-based code behind a targeting feature flag. Why the keyed choice wins: Define the flag with `Microsoft.Targeting` in App Configuration, register `AddAzureAppConfiguration` (`UseFeatureFlags`) + `AddFeatureManagement`, guard code with `IFeatureManager.IsEnabledAsync`, and ramp cohort percentages dynamically.

### Question 55 — C

Answer: Migration-based SQL deployment (EF Core `dotnet ef migrations bundle --idempotent` / Flyway / Liquibase) executing ordered, version-tracked SQL scripts. Migration-based deployments execute explicit ordered scripts (`__EFMigrationsHistory` / Flyway) with idempotent guards, handling complex data backfills and renames deterministically. Ordered migration scripts give explicit control over complex data transformations, column renames, and idempotent transactional upgrades. Local study-map skill 3.16 (Implement Container, Binary, Script, and Database Deployments (SQL DACPAC vs. Idempotent EF/SQL Migrations)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `AzureFileCopy@5` copies blobs or VM files via AzCopy and cannot compare or apply `.dacpac` SQL schemas. Why the keyed choice wins: Migration-based deployments execute explicit ordered scripts (`__EFMigrationsHistory` / Flyway) with idempotent guards, handling complex data backfills and renames deterministically.
- **B:** Incorrect for this requirement. Azure Automation State Configuration compiles PowerShell DSC configurations into MOF artifacts to audit or remediate OS state. Why the keyed choice wins: Migration-based deployments execute explicit ordered scripts (`__EFMigrationsHistory` / Flyway) with idempotent guards, handling complex data backfills and renames deterministically.
- **C:** Correct. Ordered migration scripts give explicit control over complex data transformations, column renames, and idempotent transactional upgrades. In this scenario: Migration-based deployments execute explicit ordered scripts (`__EFMigrationsHistory` / Flyway) with idempotent guards, handling complex data backfills and renames deterministically.
- **D:** Incorrect for this requirement. `MysqlDeploymentOnMachineGroup@1` targets MySQL databases, not Azure SQL `.dacpac` state models. Why the keyed choice wins: Migration-based deployments execute explicit ordered scripts (`__EFMigrationsHistory` / Flyway) with idempotent guards, handling complex data backfills and renames deterministically.

### Question 56 — A, D

Answers: State-based SQL deployment via `SqlAzureDacpacDeployment@1` comparing a compiled `.dacpac` model against target Azure SQL to generate a differential upgrade script; Migration-based SQL deployment (EF Core `dotnet ef migrations bundle --idempotent` / Flyway / Liquibase) executing ordered, version-tracked SQL scripts. State-based `SqlAzureDacpacDeployment@1` computes differential upgrades from `.dacpac` models for Team A, while idempotent EF Core migration bundles execute ordered scripts for Team B. Local study-map skill 3.16 (Implement Container, Binary, Script, and Database Deployments (SQL DACPAC vs. Idempotent EF/SQL Migrations)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Correct. Ordered migration scripts give explicit control over complex data transformations, column renames, and idempotent transactional upgrades. In this scenario: State-based `SqlAzureDacpacDeployment@1` computes differential upgrades from `.dacpac` models for Team A, while idempotent EF Core migration bundles execute ordered scripts for Team B.
- **B:** Incorrect for this requirement. `AzureFileCopy@5` copies blobs or VM files via AzCopy and cannot compare or apply `.dacpac` SQL schemas. Why the keyed choice wins: State-based `SqlAzureDacpacDeployment@1` computes differential upgrades from `.dacpac` models for Team A, while idempotent EF Core migration bundles execute ordered scripts for Team B.
- **C:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: State-based `SqlAzureDacpacDeployment@1` computes differential upgrades from `.dacpac` models for Team A, while idempotent EF Core migration bundles execute ordered scripts for Team B.
- **D:** Correct. State-based DACPAC deployments declare the desired end-state schema, automatically computing `ALTER` diffs against target databases. In this scenario: State-based `SqlAzureDacpacDeployment@1` computes differential upgrades from `.dacpac` models for Team A, while idempotent EF Core migration bundles execute ordered scripts for Team B.
- **E:** Incorrect for this requirement. Base64 is trivial reversible encoding, not encryption; secrets belong in Azure Key Vault / OIDC / Secure Files. Why the keyed choice wins: State-based `SqlAzureDacpacDeployment@1` computes differential upgrades from `.dacpac` models for Team A, while idempotent EF Core migration bundles execute ordered scripts for Team B.

### Question 57 — B

Answer: `what-if`. `what-if` calculates live resource mutations against Azure Resource Manager without modifying deployed resources, unlike `validate` which checks schema/preflight rules only. `az deployment group what-if` simulates the Bicep/ARM deployment against live Azure Resource Manager state and prints predicted resource diffs without mutating infrastructure. Local study-map skill 3.17 (Test and Deploy Infrastructure as Code Using Bicep Modules, Linting, ARM what-if, and Deployment Stacks), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `az deployment group export` downloads the template of a past deployment rather than previewing pending Bicep changes. Why the keyed choice wins: `what-if` calculates live resource mutations against Azure Resource Manager without modifying deployed resources, unlike `validate` which checks schema/preflight rules only.
- **B:** Correct. `az deployment group what-if` simulates the Bicep/ARM deployment against live Azure Resource Manager state and prints predicted resource diffs without mutating infrastructure. In this scenario: `what-if` calculates live resource mutations against Azure Resource Manager without modifying deployed resources, unlike `validate` which checks schema/preflight rules only.
- **C:** Incorrect for this requirement. `az deployment group validate` checks syntactic/preflight ARM schema validity but does NOT calculate live resource diff mutations (`Create`/`Modify`/`Delete`). Why the keyed choice wins: `what-if` calculates live resource mutations against Azure Resource Manager without modifying deployed resources, unlike `validate` which checks schema/preflight rules only.
- **D:** Incorrect for this requirement. `az bicep decompile` converts legacy ARM JSON to Bicep locally without contacting Azure Resource Manager. Why the keyed choice wins: `what-if` calculates live resource mutations against Azure Resource Manager without modifying deployed resources, unlike `validate` which checks schema/preflight rules only.

### Question 58 — B

Answer: Azure Container Registry Private Bicep Module Registry (`br:myacr.azurecr.io/bicep/modules/aks:v1.2.0`) sharing versioned, linted IaC building blocks. An Azure Container Registry Private Bicep Module Registry hosts immutable, RBAC-governed OCI Bicep modules referenced directly via `br:` syntax. Private Bicep registries distribute organization-approved, versioned infrastructure modules across application repositories. Local study-map skill 3.17 (Test and Deploy Infrastructure as Code Using Bicep Modules, Linting, ARM what-if, and Deployment Stacks), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Base64 is trivial reversible encoding, not encryption; secrets belong in Azure Key Vault / OIDC / Secure Files. Why the keyed choice wins: An Azure Container Registry Private Bicep Module Registry hosts immutable, RBAC-governed OCI Bicep modules referenced directly via `br:` syntax.
- **B:** Correct. Private Bicep registries distribute organization-approved, versioned infrastructure modules across application repositories. In this scenario: An Azure Container Registry Private Bicep Module Registry hosts immutable, RBAC-governed OCI Bicep modules referenced directly via `br:` syntax.
- **C:** Incorrect for this requirement. `git bundle` packages history into an offline archive file rather than optimizing daily developer working trees. Why the keyed choice wins: An Azure Container Registry Private Bicep Module Registry hosts immutable, RBAC-governed OCI Bicep modules referenced directly via `br:` syntax.
- **D:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: An Azure Container Registry Private Bicep Module Registry hosts immutable, RBAC-governed OCI Bicep modules referenced directly via `br:` syntax.

### Question 59 — C, E, F

Answers: `az deployment group what-if` previewing `Create`, `Modify`, `Delete`, `NoChange`, and `Ignore` resource mutations against live Azure state before applying; Azure Resource Manager Deployment Stacks (`az stack group create --action-on-unmanage deleteResources --deny-settings-mode denyWriteAndDelete`); Azure Container Registry Private Bicep Module Registry (`br:myacr.azurecr.io/bicep/modules/aks:v1.2.0`) sharing versioned, linted IaC building blocks. Consuming versioned Private Bicep Registry modules, previewing changes via `az deployment group what-if`, and enforcing lifecycle/denySettings via ARM Deployment Stacks prevent drift and accidental deletions. Local study-map skill 3.17 (Test and Deploy Infrastructure as Code Using Bicep Modules, Linting, ARM what-if, and Deployment Stacks), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Consuming versioned Private Bicep Registry modules, previewing changes via `az deployment group what-if`, and enforcing lifecycle/denySettings via ARM Deployment Stacks prevent drift and accidental deletions.
- **B:** Incorrect for this requirement. ARM `Complete` mode deletes every existing resource in the target resource group omitted from the current template! Why the keyed choice wins: Consuming versioned Private Bicep Registry modules, previewing changes via `az deployment group what-if`, and enforcing lifecycle/denySettings via ARM Deployment Stacks prevent drift and accidental deletions.
- **C:** Correct. Private Bicep registries distribute organization-approved, versioned infrastructure modules across application repositories. In this scenario: Consuming versioned Private Bicep Registry modules, previewing changes via `az deployment group what-if`, and enforcing lifecycle/denySettings via ARM Deployment Stacks prevent drift and accidental deletions.
- **D:** Incorrect for this requirement. Base64 is trivial reversible encoding, not encryption; secrets belong in Azure Key Vault / OIDC / Secure Files. Why the keyed choice wins: Consuming versioned Private Bicep Registry modules, previewing changes via `az deployment group what-if`, and enforcing lifecycle/denySettings via ARM Deployment Stacks prevent drift and accidental deletions.
- **E:** Correct. Running `what-if` in pre-deployment CI/CD surfaces unintended destructive changes or manual portal drift before `create` executes. In this scenario: Consuming versioned Private Bicep Registry modules, previewing changes via `az deployment group what-if`, and enforcing lifecycle/denySettings via ARM Deployment Stacks prevent drift and accidental deletions.
- **F:** Correct. Deployment Stacks manage multi-resource lifecycles atomically with safe cleanup of detached resources and guardrails (`denySettings`) blocking manual portal drift. In this scenario: Consuming versioned Private Bicep Registry modules, previewing changes via `az deployment group what-if`, and enforcing lifecycle/denySettings via ARM Deployment Stacks prevent drift and accidental deletions.

### Question 60 — B

Answer: Azure Deployment Environments (Dev Center + Catalog of Bicep/Terraform templates + Environment Types mapping managed identities per stage). Azure Deployment Environments (Dev Center + Catalog + Environment Types) provisions governed templates on behalf of developers using dedicated Managed Identities. Azure Deployment Environments lets developers self-provision governed sandbox/PR environments via Managed Identity RBAC without direct subscription Owner permissions. Local study-map skill 3.18 (Implement Desired State Configuration (Automation DSC, Azure Machine Configuration) and Azure Deployment Environments), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Exposing regulated production data planes to all public internet IPs violates private-VNet security requirements. Why the keyed choice wins: Azure Deployment Environments (Dev Center + Catalog + Environment Types) provisions governed templates on behalf of developers using dedicated Managed Identities.
- **B:** Correct. Azure Deployment Environments lets developers self-provision governed sandbox/PR environments via Managed Identity RBAC without direct subscription Owner permissions. In this scenario: Azure Deployment Environments (Dev Center + Catalog + Environment Types) provisions governed templates on behalf of developers using dedicated Managed Identities.
- **C:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Azure Deployment Environments (Dev Center + Catalog + Environment Types) provisions governed templates on behalf of developers using dedicated Managed Identities.
- **D:** Incorrect for this requirement. Azure Automation State Configuration compiles PowerShell DSC configurations into MOF artifacts to audit or remediate OS state. Why the keyed choice wins: Azure Deployment Environments (Dev Center + Catalog + Environment Types) provisions governed templates on behalf of developers using dedicated Managed Identities.

### Question 61 — D

Answer: Azure Machine Configuration (formerly Azure Policy Guest Configuration) auditing and remediating OS baselines inside Azure VMs and Arc-enabled servers via AMA/extension. Azure Machine Configuration (formerly Azure Policy Guest Configuration) audits and remediates inside-VM OS settings natively across Azure and Arc servers. Azure Machine Configuration integrates desired-state OS auditing/remediation natively into Azure Policy across cloud and hybrid Arc servers. Local study-map skill 3.18 (Implement Desired State Configuration (Automation DSC, Azure Machine Configuration) and Azure Deployment Environments), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `CopyFiles@2` copies files between directories on the same agent during a single job. Why the keyed choice wins: Azure Machine Configuration (formerly Azure Policy Guest Configuration) audits and remediates inside-VM OS settings natively across Azure and Arc servers.
- **B:** Incorrect for this requirement. Microsoft retired the legacy Log Analytics MMA agent in August 2024; Azure Monitor Agent (AMA) with Data Collection Rules is the supported architecture. Why the keyed choice wins: Azure Machine Configuration (formerly Azure Policy Guest Configuration) audits and remediates inside-VM OS settings natively across Azure and Arc servers.
- **C:** Incorrect for this requirement. Git LFS stores binary blobs on remote LFS object storage and downloads only blobs needed for the checked-out commit, keeping Git packfiles small. Why the keyed choice wins: Azure Machine Configuration (formerly Azure Policy Guest Configuration) audits and remediates inside-VM OS settings natively across Azure and Arc servers.
- **D:** Correct. Azure Machine Configuration integrates desired-state OS auditing/remediation natively into Azure Policy across cloud and hybrid Arc servers. In this scenario: Azure Machine Configuration (formerly Azure Policy Guest Configuration) audits and remediates inside-VM OS settings natively across Azure and Arc servers.

### Question 62 — B, E, F

Answers: Azure Automation State Configuration (PowerShell DSC pull server compiling `.mof` node configurations and reporting VM compliance state); Azure Machine Configuration (formerly Azure Policy Guest Configuration) auditing and remediating OS baselines inside Azure VMs and Arc-enabled servers via AMA/extension; Azure Deployment Environments (Dev Center + Catalog of Bicep/Terraform templates + Environment Types mapping managed identities per stage). Azure Automation State Configuration provides DSC MOF pull services, Azure Machine Configuration enforces Policy guest baselines, and Azure Deployment Environments delivers catalog sandboxes. Local study-map skill 3.18 (Implement Desired State Configuration (Automation DSC, Azure Machine Configuration) and Azure Deployment Environments), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. ARM `Complete` mode deletes every existing resource in the target resource group omitted from the current template! Why the keyed choice wins: Azure Automation State Configuration provides DSC MOF pull services, Azure Machine Configuration enforces Policy guest baselines, and Azure Deployment Environments delivers catalog sandboxes.
- **B:** Correct. Azure Deployment Environments lets developers self-provision governed sandbox/PR environments via Managed Identity RBAC without direct subscription Owner permissions. In this scenario: Azure Automation State Configuration provides DSC MOF pull services, Azure Machine Configuration enforces Policy guest baselines, and Azure Deployment Environments delivers catalog sandboxes.
- **C:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Azure Automation State Configuration provides DSC MOF pull services, Azure Machine Configuration enforces Policy guest baselines, and Azure Deployment Environments delivers catalog sandboxes.
- **D:** Incorrect for this requirement. Microsoft retired the legacy Log Analytics MMA agent in August 2024; Azure Monitor Agent (AMA) with Data Collection Rules is the supported architecture. Why the keyed choice wins: Azure Automation State Configuration provides DSC MOF pull services, Azure Machine Configuration enforces Policy guest baselines, and Azure Deployment Environments delivers catalog sandboxes.
- **E:** Correct. Azure Machine Configuration integrates desired-state OS auditing/remediation natively into Azure Policy across cloud and hybrid Arc servers. In this scenario: Azure Automation State Configuration provides DSC MOF pull services, Azure Machine Configuration enforces Policy guest baselines, and Azure Deployment Environments delivers catalog sandboxes.
- **F:** Correct. Azure Automation State Configuration compiles PowerShell DSC configurations into MOF artifacts to audit or remediate OS state. In this scenario: Azure Automation State Configuration provides DSC MOF pull services, Azure Machine Configuration enforces Policy guest baselines, and Azure Deployment Environments delivers catalog sandboxes.

### Question 63 — D

Answer: Enable Azure Pipelines Flaky Test Management (detection via test reruns + optional exclusion from build failure rate until quarantined bug is fixed). Azure Pipelines Flaky Test Management detects pass-on-rerun flakiness automatically, tags flaky tests with linked bug tracking, and optionally excludes them from failure gates while quarantined. Flaky test detection flags non-deterministic tests automatically and tracks resolution via linked bugs without blinding teams to deterministic regressions. Local study-map skill 3.19 (Monitor Pipeline Health (Failure Rate, Duration, Flaky Test Management) and Migrate Classic Pipelines to YAML), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: Azure Pipelines Flaky Test Management detects pass-on-rerun flakiness automatically, tags flaky tests with linked bug tracking, and optionally excludes them from failure gates while quarantined.
- **B:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Azure Pipelines Flaky Test Management detects pass-on-rerun flakiness automatically, tags flaky tests with linked bug tracking, and optionally excludes them from failure gates while quarantined.
- **C:** Incorrect for this requirement. `canceled()` runs exclusively when a user or timeout aborts the pipeline job. Why the keyed choice wins: Azure Pipelines Flaky Test Management detects pass-on-rerun flakiness automatically, tags flaky tests with linked bug tracking, and optionally excludes them from failure gates while quarantined.
- **D:** Correct. Flaky test detection flags non-deterministic tests automatically and tracks resolution via linked bugs without blinding teams to deterministic regressions. In this scenario: Azure Pipelines Flaky Test Management detects pass-on-rerun flakiness automatically, tags flaky tests with linked bug tracking, and optionally excludes them from failure gates while quarantined.

### Question 64 — B

Answer: Use Azure Pipelines `Export to YAML` / `View YAML` on Classic builds, convert Task Groups into parameterized YAML step/job templates, and replace Release stages with YAML Environments. Use `Export to YAML` / `View YAML` as a baseline, refactor Classic Task Groups into parameterized YAML `steps:`/`jobs:` templates, and replace Classic Release stages with YAML `Environments`. Migrating Classic pipelines brings CI/CD under Git pull-request review, branch history, and template enforcement. Local study-map skill 3.19 (Monitor Pipeline Health (Failure Rate, Duration, Flaky Test Management) and Migrate Classic Pipelines to YAML), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: Use `Export to YAML` / `View YAML` as a baseline, refactor Classic Task Groups into parameterized YAML `steps:`/`jobs:` templates, and replace Classic Release stages with YAML `Environments`.
- **B:** Correct. Migrating Classic pipelines brings CI/CD under Git pull-request review, branch history, and template enforcement. In this scenario: Use `Export to YAML` / `View YAML` as a baseline, refactor Classic Task Groups into parameterized YAML `steps:`/`jobs:` templates, and replace Classic Release stages with YAML `Environments`.
- **C:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Use `Export to YAML` / `View YAML` as a baseline, refactor Classic Task Groups into parameterized YAML `steps:`/`jobs:` templates, and replace Classic Release stages with YAML `Environments`.
- **D:** Incorrect for this requirement. `uses:` is GitHub Actions syntax for invoking an action or reusable workflow, not Azure Pipelines root template inheritance. Why the keyed choice wins: Use `Export to YAML` / `View YAML` as a baseline, refactor Classic Task Groups into parameterized YAML `steps:`/`jobs:` templates, and replace Classic Release stages with YAML `Environments`.

### Question 65 — D

Answer: `Cache@2`. `Cache@2` hashes immutable `packages.lock.json` files to save and restore NuGet/npm/pip package folders across stateless hosted agent runs. `Cache@2` restores and saves immutable build dependency directories (NuGet, npm, pip, Gradle) keyed on lockfile hashes in Azure Pipelines. Local study-map skill 3.20 (Optimize Pipeline Cost, Dependency Caching, Workflow Concurrency Cancellation, and Tiered Artifact Retention), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `DownloadBuildArtifacts@1` fetches artifacts from a specified build ID rather than hash-keyed dependency caches. Why the keyed choice wins: `Cache@2` hashes immutable `packages.lock.json` files to save and restore NuGet/npm/pip package folders across stateless hosted agent runs.
- **B:** Incorrect for this requirement. `PublishPipelineArtifact@1` uploads build outputs attached to a specific run rather than restoring keyed cross-run dependency caches. Why the keyed choice wins: `Cache@2` hashes immutable `packages.lock.json` files to save and restore NuGet/npm/pip package folders across stateless hosted agent runs.
- **C:** Incorrect for this requirement. `CopyFiles@2` copies files between directories on the same agent during a single job. Why the keyed choice wins: `Cache@2` hashes immutable `packages.lock.json` files to save and restore NuGet/npm/pip package folders across stateless hosted agent runs.
- **D:** Correct. `Cache@2` restores and saves immutable build dependency directories (NuGet, npm, pip, Gradle) keyed on lockfile hashes in Azure Pipelines. In this scenario: `Cache@2` hashes immutable `packages.lock.json` files to save and restore NuGet/npm/pip package folders across stateless hosted agent runs.

### Question 66 — B, C

Answers: Configure GitHub Actions `concurrency: group: ${{ github.workflow }}-${{ github.ref }}` with `cancel-in-progress: true` on non-prod PR workflows; Configure short project default run/artifact retention (e.g., 7–30 days for PR builds) and add automated retention leases (`365+` days) on production release runs. GitHub Actions `concurrency:` with `cancel-in-progress: true` aborts obsolete PR runs, while short default retention paired with 365-day release retention leases optimizes storage costs. Local study-map skill 3.20 (Optimize Pipeline Cost, Dependency Caching, Workflow Concurrency Cancellation, and Tiered Artifact Retention), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `lockBehavior: runLatest` executes only the newest queued run and cancels intermediate waiting runs — unsuitable when sequential ordered migrations must all run. Why the keyed choice wins: GitHub Actions `concurrency:` with `cancel-in-progress: true` aborts obsolete PR runs, while short default retention paired with 365-day release retention leases optimizes storage costs.
- **B:** Correct. `concurrency` with `cancel-in-progress: true` immediately aborts superseded PR builds when new commits arrive on the same branch, freeing runners. In this scenario: GitHub Actions `concurrency:` with `cancel-in-progress: true` aborts obsolete PR runs, while short default retention paired with 365-day release retention leases optimizes storage costs.
- **C:** Correct. Tiered retention controls artifact storage costs on noisy PR runs while preserving regulated production build provenance and symbols. In this scenario: GitHub Actions `concurrency:` with `cancel-in-progress: true` aborts obsolete PR runs, while short default retention paired with 365-day release retention leases optimizes storage costs.
- **D:** Incorrect for this requirement. Persistent self-hosted agents require explicit workspace cleanup (`workspace: clean: all`) and credential hygiene to avoid cross-job leakage. Why the keyed choice wins: GitHub Actions `concurrency:` with `cancel-in-progress: true` aborts obsolete PR runs, while short default retention paired with 365-day release retention leases optimizes storage costs.
- **E:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: GitHub Actions `concurrency:` with `cancel-in-progress: true` aborts obsolete PR runs, while short default retention paired with 365-day release retention leases optimizes storage costs.

### Question 67 — D, E, F

Answers: `Cache@2` (Azure Pipelines) or `actions/cache@v4` (GitHub Actions) keyed on immutable lockfile hashes (`**/packages.lock.json`, `package-lock.json`) with `restoreKeys` fallback; Configure GitHub Actions `concurrency: group: ${{ github.workflow }}-${{ github.ref }}` with `cancel-in-progress: true` on non-prod PR workflows; Configure short project default run/artifact retention (e.g., 7–30 days for PR builds) and add automated retention leases (`365+` days) on production release runs. Lockfile-keyed dependency caching (`Cache@2`/`actions/cache`), `concurrency` `cancel-in-progress: true` on PR branches, and tiered artifact retention policies cut runtime, queue contention, and storage spend. Local study-map skill 3.20 (Optimize Pipeline Cost, Dependency Caching, Workflow Concurrency Cancellation, and Tiered Artifact Retention), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: Lockfile-keyed dependency caching (`Cache@2`/`actions/cache`), `concurrency` `cancel-in-progress: true` on PR branches, and tiered artifact retention policies cut runtime, queue contention, and storage spend.
- **B:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Lockfile-keyed dependency caching (`Cache@2`/`actions/cache`), `concurrency` `cancel-in-progress: true` on PR branches, and tiered artifact retention policies cut runtime, queue contention, and storage spend.
- **C:** Incorrect for this requirement. Persistent self-hosted agents require explicit workspace cleanup (`workspace: clean: all`) and credential hygiene to avoid cross-job leakage. Why the keyed choice wins: Lockfile-keyed dependency caching (`Cache@2`/`actions/cache`), `concurrency` `cancel-in-progress: true` on PR branches, and tiered artifact retention policies cut runtime, queue contention, and storage spend.
- **D:** Correct. Hashing the dependency lockfile invalidates caches precisely when dependencies change while serving warm hits on unchanged builds. In this scenario: Lockfile-keyed dependency caching (`Cache@2`/`actions/cache`), `concurrency` `cancel-in-progress: true` on PR branches, and tiered artifact retention policies cut runtime, queue contention, and storage spend.
- **E:** Correct. `concurrency` with `cancel-in-progress: true` immediately aborts superseded PR builds when new commits arrive on the same branch, freeing runners. In this scenario: Lockfile-keyed dependency caching (`Cache@2`/`actions/cache`), `concurrency` `cancel-in-progress: true` on PR branches, and tiered artifact retention policies cut runtime, queue contention, and storage spend.
- **F:** Correct. Tiered retention controls artifact storage costs on noisy PR runs while preserving regulated production build provenance and symbols. In this scenario: Lockfile-keyed dependency caching (`Cache@2`/`actions/cache`), `concurrency` `cancel-in-progress: true` on PR branches, and tiered artifact retention policies cut runtime, queue contention, and storage spend.

### Question 68 — C

Answer: GitHub App installed at organization/repository scope issuing short-lived (1-hour) installation tokens with granular permissions independent of individual user accounts. A GitHub App is installed at org/repo level independent of human user seats and issues scoped 1-hour installation access tokens automatically. Unlike personal access tokens tied to a human employee seat, GitHub Apps survive employee offboarding and mint short-lived scoped tokens. Local study-map skill 4.1 (Implement Entra Managed Identities, Service Principals, GitHub Apps, Scoped GITHUB_TOKEN, Fine-Grained PATs, and Service Connections), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Incorrect for this requirement. Personal PAT connections break when the user loses access or the token expires; Microsoft recommends the Azure Boards GitHub App. Why the keyed choice wins: A GitHub App is installed at org/repo level independent of human user seats and issues scoped 1-hour installation access tokens automatically.
- **B:** Incorrect for this requirement. Service principals with client secrets require strict vault storage and rotation policies whenever OIDC workload identity federation is unavailable. Why the keyed choice wins: A GitHub App is installed at org/repo level independent of human user seats and issues scoped 1-hour installation access tokens automatically.
- **C:** Correct. Unlike personal access tokens tied to a human employee seat, GitHub Apps survive employee offboarding and mint short-lived scoped tokens. In this scenario: A GitHub App is installed at org/repo level independent of human user seats and issues scoped 1-hour installation access tokens automatically.
- **D:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: A GitHub App is installed at org/repo level independent of human user seats and issues scoped 1-hour installation access tokens automatically.

### Question 69 — D

Answer: No — `pull_request_target` combined with checking out the untrusted fork PR HEAD exposes write `GITHUB_TOKEN` and repository secrets to arbitrary code execution. No — checking out and executing untrusted fork code under `pull_request_target` grants arbitrary attacker scripts access to repository secrets and a write-scoped `GITHUB_TOKEN`. `pull_request_target` runs in the context of the base repository with secret access; checking out untrusted fork code inside it creates a critical pwn-request vulnerability. Local study-map skill 4.1 (Implement Entra Managed Identities, Service Principals, GitHub Apps, Scoped GITHUB_TOKEN, Fine-Grained PATs, and Service Connections), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Incorrect for this requirement. Production pipelines must consume `feed@Release` so unverified `@Local` or `@Prerelease` packages are invisible to production restores. Why the keyed choice wins: No — checking out and executing untrusted fork code under `pull_request_target` grants arbitrary attacker scripts access to repository secrets and a write-scoped `GITHUB_TOKEN`.
- **B:** Incorrect for this requirement. Lead Time includes backlog queue time in `New`; Cycle Time specifically starts the clock when an item enters an `In Progress`/`Active` state category. Why the keyed choice wins: No — checking out and executing untrusted fork code under `pull_request_target` grants arbitrary attacker scripts access to repository secrets and a write-scoped `GITHUB_TOKEN`.
- **C:** Incorrect for this requirement. Every functional, networking, licensing, and security constraint in the scenario is satisfied natively. Why the keyed choice wins: No — checking out and executing untrusted fork code under `pull_request_target` grants arbitrary attacker scripts access to repository secrets and a write-scoped `GITHUB_TOKEN`.
- **D:** Correct. `pull_request_target` runs in the context of the base repository with secret access; checking out untrusted fork code inside it creates a critical pwn-request vulnerability. In this scenario: No — checking out and executing untrusted fork code under `pull_request_target` grants arbitrary attacker scripts access to repository secrets and a write-scoped `GITHUB_TOKEN`.

### Question 70 — A

Answer: Azure Resource Manager service connection using Workload Identity Federation (automatic/manual OIDC) scoped to a single Resource Group and locked via pipeline permissions. An Azure Resource Manager service connection configured with Workload Identity Federation exchanges short-lived Azure DevOps OIDC tokens with Entra ID without any stored client secret. Azure DevOps Workload Identity Federation service connections exchange short-lived OIDC tokens for Entra access tokens with zero stored client secrets. Local study-map skill 4.1 (Implement Entra Managed Identities, Service Principals, GitHub Apps, Scoped GITHUB_TOKEN, Fine-Grained PATs, and Service Connections), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Correct. Azure DevOps Workload Identity Federation service connections exchange short-lived OIDC tokens for Entra access tokens with zero stored client secrets. In this scenario: An Azure Resource Manager service connection configured with Workload Identity Federation exchanges short-lived Azure DevOps OIDC tokens with Entra ID without any stored client secret.
- **B:** Incorrect for this requirement. Base64 is trivial reversible encoding, not encryption; secrets belong in Azure Key Vault / OIDC / Secure Files. Why the keyed choice wins: An Azure Resource Manager service connection configured with Workload Identity Federation exchanges short-lived Azure DevOps OIDC tokens with Entra ID without any stored client secret.
- **C:** Incorrect for this requirement. Service principals with client secrets require strict vault storage and rotation policies whenever OIDC workload identity federation is unavailable. Why the keyed choice wins: An Azure Resource Manager service connection configured with Workload Identity Federation exchanges short-lived Azure DevOps OIDC tokens with Entra ID without any stored client secret.
- **D:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: An Azure Resource Manager service connection configured with Workload Identity Federation exchanges short-lived Azure DevOps OIDC tokens with Entra ID without any stored client secret.

### Question 71 — A, B

Answers: Azure Managed Identity (system-assigned tied to resource lifecycle, or user-assigned shared across resources/federated credentials) with zero developer-managed passwords; Automatic per-job `GITHUB_TOKEN` restricted to `permissions: contents: read` by default and elevated per job only as required (e.g., `packages: write`, `id-token: write`). Azure Managed Identities authenticate Azure workloads without stored credentials, and setting `GITHUB_TOKEN` default permissions to `contents: read` (elevating per job only as needed) enforces least privilege. Local study-map skill 4.1 (Implement Entra Managed Identities, Service Principals, GitHub Apps, Scoped GITHUB_TOKEN, Fine-Grained PATs, and Service Connections), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Correct. Managed Identities eliminate secret rotation entirely on Azure compute and can serve as backing identities for Azure DevOps / GitHub OIDC Workload Identity Federation. In this scenario: Azure Managed Identities authenticate Azure workloads without stored credentials, and setting `GITHUB_TOKEN` default permissions to `contents: read` (elevating per job only as needed) enforces least privilege.
- **B:** Correct. `GITHUB_TOKEN` expires automatically when the job finishes; restricting default org/repo workflow permissions to read-only implements least privilege. In this scenario: Azure Managed Identities authenticate Azure workloads without stored credentials, and setting `GITHUB_TOKEN` default permissions to `contents: read` (elevating per job only as needed) enforces least privilege.
- **C:** Incorrect for this requirement. Base64 is trivial reversible encoding, not encryption; secrets belong in Azure Key Vault / OIDC / Secure Files. Why the keyed choice wins: Azure Managed Identities authenticate Azure workloads without stored credentials, and setting `GITHUB_TOKEN` default permissions to `contents: read` (elevating per job only as needed) enforces least privilege.
- **D:** Incorrect for this requirement. Service principals with client secrets require strict vault storage and rotation policies whenever OIDC workload identity federation is unavailable. Why the keyed choice wins: Azure Managed Identities authenticate Azure workloads without stored credentials, and setting `GITHUB_TOKEN` default permissions to `contents: read` (elevating per job only as needed) enforces least privilege.
- **E:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: Azure Managed Identities authenticate Azure workloads without stored credentials, and setting `GITHUB_TOKEN` default permissions to `contents: read` (elevating per job only as needed) enforces least privilege.

### Question 72 — D

Answer: Azure DevOps `Stakeholder` access level (free, unlimited seats: create/edit/view Azure Boards work items, dashboards, and wikis; NO Azure Repos code access). `Stakeholder` access is free for unlimited users, grants Azure Boards and Dashboard participation, and natively blocks Azure Repos code access. Assigning `Stakeholder` to external business/hospital advisors grants Boards bug/backlog participation at zero license cost while blocking source repository access. Local study-map skill 4.2 (Manage GitHub Roles/Outside Collaborators and Azure DevOps Permissions, Security Groups, and Access Levels (Stakeholder/Basic/Test Plans)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Incorrect for this requirement. While `Basic` users can execute certain tests, authoring and managing Test Plans and Test Suites requires `Basic + Test Plans`. Why the keyed choice wins: `Stakeholder` access is free for unlimited users, grants Azure Boards and Dashboard participation, and natively blocks Azure Repos code access.
- **B:** Incorrect for this requirement. `Basic` grants full source control (`Azure Repos`), pipeline authoring, and boards capabilities without exploratory/manual Test Plan authoring. Why the keyed choice wins: `Stakeholder` access is free for unlimited users, grants Azure Boards and Dashboard participation, and natively blocks Azure Repos code access.
- **C:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: `Stakeholder` access is free for unlimited users, grants Azure Boards and Dashboard participation, and natively blocks Azure Repos code access.
- **D:** Correct. Assigning `Stakeholder` to external business/hospital advisors grants Boards bug/backlog participation at zero license cost while blocking source repository access. In this scenario: `Stakeholder` access is free for unlimited users, grants Azure Boards and Dashboard participation, and natively blocks Azure Repos code access.

### Question 73 — B

Answer: Azure DevOps `Basic + Test Plans` access level (or Visual Studio Enterprise/Test Pro): required to create/manage manual test plans, test suites, and exploratory sessions. Creating and managing Test Plans and Test Suites requires `Basic + Test Plans` (or an eligible Visual Studio Enterprise / Test Professional subscription). While `Basic` users can execute certain tests, authoring and managing Test Plans and Test Suites requires `Basic + Test Plans`. Local study-map skill 4.2 (Manage GitHub Roles/Outside Collaborators and Azure DevOps Permissions, Security Groups, and Access Levels (Stakeholder/Basic/Test Plans)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Incorrect for this requirement. `Basic` grants full source control (`Azure Repos`), pipeline authoring, and boards capabilities without exploratory/manual Test Plan authoring. Why the keyed choice wins: Creating and managing Test Plans and Test Suites requires `Basic + Test Plans` (or an eligible Visual Studio Enterprise / Test Professional subscription).
- **B:** Correct. While `Basic` users can execute certain tests, authoring and managing Test Plans and Test Suites requires `Basic + Test Plans`. In this scenario: Creating and managing Test Plans and Test Suites requires `Basic + Test Plans` (or an eligible Visual Studio Enterprise / Test Professional subscription).
- **C:** Incorrect for this requirement. Outside collaborators receive repository-specific `Read`/`Triage`/`Write` roles without gaining Organization Member visibility into internal private repos. Why the keyed choice wins: Creating and managing Test Plans and Test Suites requires `Basic + Test Plans` (or an eligible Visual Studio Enterprise / Test Professional subscription).
- **D:** Incorrect for this requirement. Assigning `Stakeholder` to external business/hospital advisors grants Boards bug/backlog participation at zero license cost while blocking source repository access. Why the keyed choice wins: Creating and managing Test Plans and Test Suites requires `Basic + Test Plans` (or an eligible Visual Studio Enterprise / Test Professional subscription).

### Question 74 — D

Answer: In Azure DevOps permissions, explicit `Deny` always overrides `Allow` across inherited security groups (unless the user belongs to `Project Collection Administrators`). In Azure DevOps ACL evaluation, explicit `Deny` on any inherited group (`Contributors`) overrides `Allow` for everyone except `Project Collection Administrators`; use `Not set` instead of `Deny`. Use `Not set` rather than blanket `Deny` on broad base groups like `Contributors` so targeted `Allow` grants on specialist subgroups still function. Local study-map skill 4.2 (Manage GitHub Roles/Outside Collaborators and Azure DevOps Permissions, Security Groups, and Access Levels (Stakeholder/Basic/Test Plans)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: In Azure DevOps ACL evaluation, explicit `Deny` on any inherited group (`Contributors`) overrides `Allow` for everyone except `Project Collection Administrators`; use `Not set` instead of `Deny`.
- **B:** Incorrect for this requirement. Assigning `Stakeholder` to external business/hospital advisors grants Boards bug/backlog participation at zero license cost while blocking source repository access. Why the keyed choice wins: In Azure DevOps ACL evaluation, explicit `Deny` on any inherited group (`Contributors`) overrides `Allow` for everyone except `Project Collection Administrators`; use `Not set` instead of `Deny`.
- **C:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: In Azure DevOps ACL evaluation, explicit `Deny` on any inherited group (`Contributors`) overrides `Allow` for everyone except `Project Collection Administrators`; use `Not set` instead of `Deny`.
- **D:** Correct. Use `Not set` rather than blanket `Deny` on broad base groups like `Contributors` so targeted `Allow` grants on specialist subgroups still function. In this scenario: In Azure DevOps ACL evaluation, explicit `Deny` on any inherited group (`Contributors`) overrides `Allow` for everyone except `Project Collection Administrators`; use `Not set` instead of `Deny`.

### Question 75 — C

Answer: `##vso[task.setvariable variable=SigningPwd;issecret=true]`. Emitting `##vso[task.setvariable variable=SigningPwd;issecret=true]$PASS` registers the dynamic value with the agent secret masker so stdout echoes are redacted to `***`. Adding `;issecret=true` instructs the Azure Pipelines agent to encrypt the runtime variable in memory and mask its value as `***` across all subsequent task logs. Local study-map skill 4.3 (Manage Secrets with Azure Key Vault, Workload Identity Federation (OIDC), Secure Files, and Pipeline Log Secret Masking), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Incorrect for this requirement. `isreadonly=true` prevents overwriting the variable later in the job but still logs the value in cleartext without `issecret=true`. Why the keyed choice wins: Emitting `##vso[task.setvariable variable=SigningPwd;issecret=true]$PASS` registers the dynamic value with the agent secret masker so stdout echoes are redacted to `***`.
- **B:** Incorrect for this requirement. `isoutput=true` exposes the variable to downstream jobs/stages in cleartext without masking it as a secret in build logs! Why the keyed choice wins: Emitting `##vso[task.setvariable variable=SigningPwd;issecret=true]$PASS` registers the dynamic value with the agent secret masker so stdout echoes are redacted to `***`.
- **C:** Correct. Adding `;issecret=true` instructs the Azure Pipelines agent to encrypt the runtime variable in memory and mask its value as `***` across all subsequent task logs. In this scenario: Emitting `##vso[task.setvariable variable=SigningPwd;issecret=true]$PASS` registers the dynamic value with the agent secret masker so stdout echoes are redacted to `***`.
- **D:** Incorrect for this requirement. `task.logissue` prints a warning banner directly into the public pipeline console log! Why the keyed choice wins: Emitting `##vso[task.setvariable variable=SigningPwd;issecret=true]$PASS` registers the dynamic value with the agent secret masker so stdout echoes are redacted to `***`.

### Question 76 — A

Answer: `DownloadSecureFile@1`. `DownloadSecureFile@1` fetches authorized Library Secure Files onto the agent temp folder during job execution and cleans them up during post-job teardown. `DownloadSecureFile@1` retrieves an encrypted file from Azure Pipelines Secure Files into `$(Agent.TempDirectory)` for the duration of the job and purges it post-job. Local study-map skill 4.3 (Manage Secrets with Azure Key Vault, Workload Identity Federation (OIDC), Secure Files, and Pipeline Log Secret Masking), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Correct. `DownloadSecureFile@1` retrieves an encrypted file from Azure Pipelines Secure Files into `$(Agent.TempDirectory)` for the duration of the job and purges it post-job. In this scenario: `DownloadSecureFile@1` fetches authorized Library Secure Files onto the agent temp folder during job execution and cleans them up during post-job teardown.
- **B:** Incorrect for this requirement. `cURLUploader@2` uploads local files to remote FTP/HTTP endpoints. Why the keyed choice wins: `DownloadSecureFile@1` fetches authorized Library Secure Files onto the agent temp folder during job execution and cleans them up during post-job teardown.
- **C:** Incorrect for this requirement. `ExtractFiles@1` unzips archives already on disk and cannot access encrypted Library Secure Files. Why the keyed choice wins: `DownloadSecureFile@1` fetches authorized Library Secure Files onto the agent temp folder during job execution and cleans them up during post-job teardown.
- **D:** Incorrect for this requirement. `GitHubRelease@1` manages public/repo GitHub Release assets, not encrypted pipeline signing certificates. Why the keyed choice wins: `DownloadSecureFile@1` fetches authorized Library Secure Files onto the agent temp folder during job execution and cleans them up during post-job teardown.

### Question 77 — A

Answer: Link an Azure Pipelines Variable Group to Azure Key Vault (or use `AzureKeyVault@2` task) granting the WIF service connection `Key Vault Secrets User` RBAC. Link an Azure Pipelines Variable Group (or `AzureKeyVault@2` task) to Azure Key Vault via a Workload Identity Federation service connection granted `Key Vault Secrets User` RBAC. Key Vault-linked variable groups fetch only selected secrets just-in-time at job execution and automatically register values for log masking. Local study-map skill 4.3 (Manage Secrets with Azure Key Vault, Workload Identity Federation (OIDC), Secure Files, and Pipeline Log Secret Masking), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Correct. Key Vault-linked variable groups fetch only selected secrets just-in-time at job execution and automatically register values for log masking. In this scenario: Link an Azure Pipelines Variable Group (or `AzureKeyVault@2` task) to Azure Key Vault via a Workload Identity Federation service connection granted `Key Vault Secrets User` RBAC.
- **B:** Incorrect for this requirement. Base64 is trivial reversible encoding, not encryption; secrets belong in Azure Key Vault / OIDC / Secure Files. Why the keyed choice wins: Link an Azure Pipelines Variable Group (or `AzureKeyVault@2` task) to Azure Key Vault via a Workload Identity Federation service connection granted `Key Vault Secrets User` RBAC.
- **C:** Incorrect for this requirement. `isoutput=true` exposes the variable to downstream jobs/stages in cleartext without masking it as a secret in build logs! Why the keyed choice wins: Link an Azure Pipelines Variable Group (or `AzureKeyVault@2` task) to Azure Key Vault via a Workload Identity Federation service connection granted `Key Vault Secrets User` RBAC.
- **D:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: Link an Azure Pipelines Variable Group (or `AzureKeyVault@2` task) to Azure Key Vault via a Workload Identity Federation service connection granted `Key Vault Secrets User` RBAC.

### Question 78 — C

Answer: Microsoft Defender for Cloud DevOps Security connecting GitHub Enterprise and Azure DevOps via connectors to correlate code/IaC/container vulnerabilities with live cloud runtime exposure (CSPM). Microsoft Defender for Cloud DevOps Security connects GitHub Enterprise and Azure DevOps organizations to correlate code-to-cloud vulnerabilities and publish PR security annotations. Defender for Cloud DevOps Security bridges CI/CD posture (GHAS/GHAzDO SARIF, IaC misconfigurations) with cloud attack-path analysis and PR security annotations. Local study-map skill 4.4 (Automate DevSecOps Scanning (GHAS/GHAzDO, Push Protection, CodeQL, Dependabot, Defender for Cloud DevOps, Container & OSS License Scans)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Incorrect for this requirement. `ExtractFiles@1` unzips archives already on disk and cannot access encrypted Library Secure Files. Why the keyed choice wins: Microsoft Defender for Cloud DevOps Security connects GitHub Enterprise and Azure DevOps organizations to correlate code-to-cloud vulnerabilities and publish PR security annotations.
- **B:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Microsoft Defender for Cloud DevOps Security connects GitHub Enterprise and Azure DevOps organizations to correlate code-to-cloud vulnerabilities and publish PR security annotations.
- **C:** Correct. Defender for Cloud DevOps Security bridges CI/CD posture (GHAS/GHAzDO SARIF, IaC misconfigurations) with cloud attack-path analysis and PR security annotations. In this scenario: Microsoft Defender for Cloud DevOps Security connects GitHub Enterprise and Azure DevOps organizations to correlate code-to-cloud vulnerabilities and publish PR security annotations.
- **D:** Incorrect for this requirement. Microsoft retired the legacy Log Analytics MMA agent in August 2024; Azure Monitor Agent (AMA) with Data Collection Rules is the supported architecture. Why the keyed choice wins: Microsoft Defender for Cloud DevOps Security connects GitHub Enterprise and Azure DevOps organizations to correlate code-to-cloud vulnerabilities and publish PR security annotations.

### Question 79 — C

Answer: GitHub Dependency Review Action (`actions/dependency-review-action` with `deny-licenses: [GPL-3.0, AGPL-3.0]`) failing PRs that introduce copyleft license obligations. `actions/dependency-review-action` inspects dependency manifest/lockfile diffs on pull requests and fails when newly introduced packages match `deny-licenses` or CVE severity thresholds. Automated SCA license checks prevent incompatible copyleft dependencies from merging into proprietary commercial software. Local study-map skill 4.4 (Automate DevSecOps Scanning (GHAS/GHAzDO, Push Protection, CodeQL, Dependabot, Defender for Cloud DevOps, Container & OSS License Scans)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Incorrect for this requirement. `git gc` repacks local objects but keeps huge binaries inside Git packfiles rather than moving them to LFS storage. Why the keyed choice wins: `actions/dependency-review-action` inspects dependency manifest/lockfile diffs on pull requests and fails when newly introduced packages match `deny-licenses` or CVE severity thresholds.
- **B:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: `actions/dependency-review-action` inspects dependency manifest/lockfile diffs on pull requests and fails when newly introduced packages match `deny-licenses` or CVE severity thresholds.
- **C:** Correct. Automated SCA license checks prevent incompatible copyleft dependencies from merging into proprietary commercial software. In this scenario: `actions/dependency-review-action` inspects dependency manifest/lockfile diffs on pull requests and fails when newly introduced packages match `deny-licenses` or CVE severity thresholds.
- **D:** Incorrect for this requirement. Unlike SAST (CodeQL reading source), DAST probes live running HTTP endpoints to uncover missing security headers, auth misconfigurations, and runtime XSS/CORS flaws. Why the keyed choice wins: `actions/dependency-review-action` inspects dependency manifest/lockfile diffs on pull requests and fails when newly introduced packages match `deny-licenses` or CVE severity thresholds.

### Question 80 — B

Answer: VM Insights using Azure Monitor Agent (AMA) + Data Collection Rules (DCRs) + Dependency Agent collecting guest OS performance and process network maps. Deploy the Azure Monitor Agent (AMA) governed by Data Collection Rules (DCRs) + Dependency Agent; the legacy Log Analytics MMA (`OMSAgent`) is retired. AMA with Data Collection Rules replaces the retired Log Analytics MMA agent, providing multi-homing, transformation KQL filtering, and VM Insights health. Local study-map skill 5.1 (Configure Azure Monitor, Workspace Application Insights, VM Insights (AMA/DCR), Container Insights, and Storage/Network Monitoring), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/azure-monitor/ & https://docs.github.com/en/enterprise-cloud@latest/admin/monitoring-activity-in-your-enterprise

- **A:** Incorrect for this requirement. Exposing regulated production data planes to all public internet IPs violates private-VNet security requirements. Why the keyed choice wins: Deploy the Azure Monitor Agent (AMA) governed by Data Collection Rules (DCRs) + Dependency Agent; the legacy Log Analytics MMA (`OMSAgent`) is retired.
- **B:** Correct. AMA with Data Collection Rules replaces the retired Log Analytics MMA agent, providing multi-homing, transformation KQL filtering, and VM Insights health. In this scenario: Deploy the Azure Monitor Agent (AMA) governed by Data Collection Rules (DCRs) + Dependency Agent; the legacy Log Analytics MMA (`OMSAgent`) is retired.
- **C:** Incorrect for this requirement. Microsoft retired the legacy Log Analytics MMA agent in August 2024; Azure Monitor Agent (AMA) with Data Collection Rules is the supported architecture. Why the keyed choice wins: Deploy the Azure Monitor Agent (AMA) governed by Data Collection Rules (DCRs) + Dependency Agent; the legacy Log Analytics MMA (`OMSAgent`) is retired.
- **D:** Incorrect for this requirement. `CopyFiles@2` copies files between directories on the same agent during a single job. Why the keyed choice wins: Deploy the Azure Monitor Agent (AMA) governed by Data Collection Rules (DCRs) + Dependency Agent; the legacy Log Analytics MMA (`OMSAgent`) is retired.

### Question 81 — C

Answer: Create Application Insights Release Annotations from CI/CD pipelines so deployment markers appear directly on Performance and Failure charts. Publishing Application Insights Release Annotations from the deployment pipeline places clickable build/release markers directly onto telemetry charts. Release annotations visually correlate exact build numbers and deployment timestamps with sudden latency or error-rate shifts. Local study-map skill 5.1 (Configure Azure Monitor, Workspace Application Insights, VM Insights (AMA/DCR), Container Insights, and Storage/Network Monitoring), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/azure-monitor/ & https://docs.github.com/en/enterprise-cloud@latest/admin/monitoring-activity-in-your-enterprise

- **A:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Publishing Application Insights Release Annotations from the deployment pipeline places clickable build/release markers directly onto telemetry charts.
- **B:** Incorrect for this requirement. Direct subscription `Owner` rights bypass IaC review, cause untracked configuration drift, and violate least privilege. Why the keyed choice wins: Publishing Application Insights Release Annotations from the deployment pipeline places clickable build/release markers directly onto telemetry charts.
- **C:** Correct. Release annotations visually correlate exact build numbers and deployment timestamps with sudden latency or error-rate shifts. In this scenario: Publishing Application Insights Release Annotations from the deployment pipeline places clickable build/release markers directly onto telemetry charts.
- **D:** Incorrect for this requirement. `git stash` shelves uncommitted local working-tree edits and has zero effect on pushed commit history. Why the keyed choice wins: Publishing Application Insights Release Annotations from the deployment pipeline places clickable build/release markers directly onto telemetry charts.

### Question 82 — A, C

Answers: Workspace-based Application Insights backed by a central Azure Monitor Log Analytics workspace collecting requests, dependencies, exceptions, traces, and custom metrics; Azure Monitor Container Insights (`ContainerLogV2`, `KubePodInventory`, `InsightsMetrics`) monitoring AKS/Arc pod restarts, `OOMKilled` events, and node CPU/memory throttling. Workspace-based Application Insights stores app telemetry in Log Analytics alongside Azure Monitor Container Insights pod/node metrics and container stdout logs. Local study-map skill 5.1 (Configure Azure Monitor, Workspace Application Insights, VM Insights (AMA/DCR), Container Insights, and Storage/Network Monitoring), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/azure-monitor/ & https://docs.github.com/en/enterprise-cloud@latest/admin/monitoring-activity-in-your-enterprise

- **A:** Correct. Container Insights captures Kubernetes control/data-plane metrics, pod lifecycle anomalies (`OOMKilled`, `CrashLoopBackOff`), and structured stdout logs. In this scenario: Workspace-based Application Insights stores app telemetry in Log Analytics alongside Azure Monitor Container Insights pod/node metrics and container stdout logs.
- **B:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Workspace-based Application Insights stores app telemetry in Log Analytics alongside Azure Monitor Container Insights pod/node metrics and container stdout logs.
- **C:** Correct. Workspace-based Application Insights unifies app telemetry (`AppRequests`, `AppDependencies`, `AppExceptions`) with infra logs (`InsightsMetrics`, `ContainerLogV2`) in one KQL store. In this scenario: Workspace-based Application Insights stores app telemetry in Log Analytics alongside Azure Monitor Container Insights pod/node metrics and container stdout logs.
- **D:** Incorrect for this requirement. Microsoft retired the legacy Log Analytics MMA agent in August 2024; Azure Monitor Agent (AMA) with Data Collection Rules is the supported architecture. Why the keyed choice wins: Workspace-based Application Insights stores app telemetry in Log Analytics alongside Azure Monitor Container Insights pod/node metrics and container stdout logs.
- **E:** Incorrect for this requirement. Base64 is trivial reversible encoding, not encryption; secrets belong in Azure Key Vault / OIDC / Secure Files. Why the keyed choice wins: Workspace-based Application Insights stores app telemetry in Log Analytics alongside Azure Monitor Container Insights pod/node metrics and container stdout logs.

### Question 83 — A

Answer: GitHub Repository/Organization Insights (Pulse, Traffic, Dependency Graph, Actions Usage Metrics & Performance) tracking workflow queue time, job runtime, and billable minutes. GitHub Organization/Repository Actions Usage Metrics and Performance Insights chart billable minutes, job queue wait latency, and failure rates per workflow and OS. GitHub Actions Usage & Performance metrics expose runner queue wait bottlenecks, top minute-consuming workflows, and failure rates across repositories. Local study-map skill 5.2 (Configure GitHub Insights/Usage Charts and Event Alerts for GitHub Actions and Azure Pipelines), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/azure-monitor/ & https://docs.github.com/en/enterprise-cloud@latest/admin/monitoring-activity-in-your-enterprise

- **A:** Correct. GitHub Actions Usage & Performance metrics expose runner queue wait bottlenecks, top minute-consuming workflows, and failure rates across repositories. In this scenario: GitHub Organization/Repository Actions Usage Metrics and Performance Insights chart billable minutes, job queue wait latency, and failure rates per workflow and OS.
- **B:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: GitHub Organization/Repository Actions Usage Metrics and Performance Insights chart billable minutes, job queue wait latency, and failure rates per workflow and OS.
- **C:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: GitHub Organization/Repository Actions Usage Metrics and Performance Insights chart billable minutes, job queue wait latency, and failure rates per workflow and OS.
- **D:** Incorrect for this requirement. `git bundle` packages history into an offline archive file rather than optimizing daily developer working trees. Why the keyed choice wins: GitHub Organization/Repository Actions Usage Metrics and Performance Insights chart billable minutes, job queue wait latency, and failure rates per workflow and OS.

### Question 84 — A

Answer: Configure Azure DevOps Service Hooks / Notifications or GitHub Webhook + Azure Monitor Action Group (Logic App / Function / PagerDuty / Teams) triggering on pipeline run or deployment failures. Configure Azure DevOps Service Hooks / Notifications or GitHub workflow failure webhooks routed through an Azure Monitor Action Group / incident automation endpoint. Routing failed deployment events into Action Groups or incident webhooks shrinks detection latency when automated rollouts or nightly security scans fail. Local study-map skill 5.2 (Configure GitHub Insights/Usage Charts and Event Alerts for GitHub Actions and Azure Pipelines), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/azure-monitor/ & https://docs.github.com/en/enterprise-cloud@latest/admin/monitoring-activity-in-your-enterprise

- **A:** Correct. Routing failed deployment events into Action Groups or incident webhooks shrinks detection latency when automated rollouts or nightly security scans fail. In this scenario: Configure Azure DevOps Service Hooks / Notifications or GitHub workflow failure webhooks routed through an Azure Monitor Action Group / incident automation endpoint.
- **B:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Configure Azure DevOps Service Hooks / Notifications or GitHub workflow failure webhooks routed through an Azure Monitor Action Group / incident automation endpoint.
- **C:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: Configure Azure DevOps Service Hooks / Notifications or GitHub workflow failure webhooks routed through an Azure Monitor Action Group / incident automation endpoint.
- **D:** Incorrect for this requirement. `git stash` shelves uncommitted local working-tree edits and has zero effect on pushed commit history. Why the keyed choice wins: Configure Azure DevOps Service Hooks / Notifications or GitHub workflow failure webhooks routed through an Azure Monitor Action Group / incident automation endpoint.

### Question 85 — C

Answer: GitHub app for Microsoft Teams (`@GitHub subscribe owner/repo`) delivering PR, deployment, check-failure, and issue notifications. Installing the official GitHub app for Microsoft Teams connects repositories to channels with interactive deployment approval and CI failure notifications. The GitHub app for Teams streams repository PR reviews, CI workflow failures, and deployment approvals into Microsoft Teams channels. Local study-map skill 5.2 (Configure GitHub Insights/Usage Charts and Event Alerts for GitHub Actions and Azure Pipelines), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/azure-monitor/ & https://docs.github.com/en/enterprise-cloud@latest/admin/monitoring-activity-in-your-enterprise

- **A:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: Installing the official GitHub app for Microsoft Teams connects repositories to channels with interactive deployment approval and CI failure notifications.
- **B:** Incorrect for this requirement. Personal PAT connections break when the user loses access or the token expires; Microsoft recommends the Azure Boards GitHub App. Why the keyed choice wins: Installing the official GitHub app for Microsoft Teams connects repositories to channels with interactive deployment approval and CI failure notifications.
- **C:** Correct. The GitHub app for Teams streams repository PR reviews, CI workflow failures, and deployment approvals into Microsoft Teams channels. In this scenario: Installing the official GitHub app for Microsoft Teams connects repositories to channels with interactive deployment approval and CI failure notifications.
- **D:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: Installing the official GitHub app for Microsoft Teams connects repositories to channels with interactive deployment approval and CI failure notifications.

### Question 86 — A

Answer: `percentile(DurationMs, 95)`. KQL uses `percentile(DurationMs, 95)` inside `summarize` to compute the 95th-percentile duration; `p95()` is not a valid KQL function. In KQL `summarize`, `percentile(DurationMs, 95)` computes the 95th-percentile tail latency across matching request rows. Local study-map skill 5.3 (Analyze Infrastructure KPIs, Application Telemetry, W3C Distributed Tracing, Application Map, and KQL Queries), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/azure-monitor/ & https://docs.github.com/en/enterprise-cloud@latest/admin/monitoring-activity-in-your-enterprise

- **A:** Correct. In KQL `summarize`, `percentile(DurationMs, 95)` computes the 95th-percentile tail latency across matching request rows. In this scenario: KQL uses `percentile(DurationMs, 95)` inside `summarize` to compute the 95th-percentile duration; `p95()` is not a valid KQL function.
- **B:** Incorrect for this requirement. `top 95 by DurationMs` is a tabular operator returning 95 individual rows, not a `summarize` 95th-percentile statistical aggregate. Why the keyed choice wins: KQL uses `percentile(DurationMs, 95)` inside `summarize` to compute the 95th-percentile duration; `p95()` is not a valid KQL function.
- **C:** Incorrect for this requirement. KQL has no standalone `p95()` aggregation function; `percentile(expr, 95)` or `percentiles(expr, 50, 95, 99)` is required. Why the keyed choice wins: KQL uses `percentile(DurationMs, 95)` inside `summarize` to compute the 95th-percentile duration; `p95()` is not a valid KQL function.
- **D:** Incorrect for this requirement. `stdev()` takes a single column argument to compute standard deviation, not a percentile rank. Why the keyed choice wins: KQL uses `percentile(DurationMs, 95)` inside `summarize` to compute the 95th-percentile duration; `p95()` is not a valid KQL function.

### Question 87 — D

Answer: W3C Trace Context (`traceparent` / `OperationId`) across Application Insights Application Map & End-to-End Transaction Diagnostics correlating frontend -> API -> SQL/Service Bus calls. Propagating W3C Trace Context headers (`traceparent` / `tracestate`) assigns a shared `OperationId` and parent-child span IDs across HTTP, gRPC, messaging, and SQL dependencies. Distributed tracing links multi-hop microservice spans under one `OperationId`, revealing exact downstream dependency bottlenecks on the Application Map. Local study-map skill 5.3 (Analyze Infrastructure KPIs, Application Telemetry, W3C Distributed Tracing, Application Map, and KQL Queries), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/azure-monitor/ & https://docs.github.com/en/enterprise-cloud@latest/admin/monitoring-activity-in-your-enterprise

- **A:** Incorrect for this requirement. Microsoft retired the legacy Log Analytics MMA agent in August 2024; Azure Monitor Agent (AMA) with Data Collection Rules is the supported architecture. Why the keyed choice wins: Propagating W3C Trace Context headers (`traceparent` / `tracestate`) assigns a shared `OperationId` and parent-child span IDs across HTTP, gRPC, messaging, and SQL dependencies.
- **B:** Incorrect for this requirement. `git gc` repacks local objects but keeps huge binaries inside Git packfiles rather than moving them to LFS storage. Why the keyed choice wins: Propagating W3C Trace Context headers (`traceparent` / `tracestate`) assigns a shared `OperationId` and parent-child span IDs across HTTP, gRPC, messaging, and SQL dependencies.
- **C:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Propagating W3C Trace Context headers (`traceparent` / `tracestate`) assigns a shared `OperationId` and parent-child span IDs across HTTP, gRPC, messaging, and SQL dependencies.
- **D:** Correct. Distributed tracing links multi-hop microservice spans under one `OperationId`, revealing exact downstream dependency bottlenecks on the Application Map. In this scenario: Propagating W3C Trace Context headers (`traceparent` / `tracestate`) assigns a shared `OperationId` and parent-child span IDs across HTTP, gRPC, messaging, and SQL dependencies.

### Question 88 — D, E

Answers: `AppRequests | where TimeGenerated > ago(1h) | summarize p95=percentile(DurationMs, 95), err=countif(Success == false) by AppVersion, bin(TimeGenerated, 5m)`; Application Insights Smart Detection & Dynamic Threshold metric alerts (`Failure Anomalies`) baselining historical seasonality to alert on sudden exception spikes. Querying `AppRequests` with `percentile(DurationMs, 95)` by `AppVersion` isolates per-release tail latency, while Smart Detection / Dynamic Threshold alerts adapt to traffic seasonality. Local study-map skill 5.3 (Analyze Infrastructure KPIs, Application Telemetry, W3C Distributed Tracing, Application Map, and KQL Queries), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/azure-monitor/ & https://docs.github.com/en/enterprise-cloud@latest/admin/monitoring-activity-in-your-enterprise

- **A:** Incorrect for this requirement. KQL has no standalone `p95()` aggregation function; `percentile(expr, 95)` or `percentiles(expr, 50, 95, 99)` is required. Why the keyed choice wins: Querying `AppRequests` with `percentile(DurationMs, 95)` by `AppVersion` isolates per-release tail latency, while Smart Detection / Dynamic Threshold alerts adapt to traffic seasonality.
- **B:** Incorrect for this requirement. Queries under `My Queries` cannot back shared team dashboard widgets; queries must reside in `Shared Queries` with Reader permissions. Why the keyed choice wins: Querying `AppRequests` with `percentile(DurationMs, 95)` by `AppVersion` isolates per-release tail latency, while Smart Detection / Dynamic Threshold alerts adapt to traffic seasonality.
- **C:** Incorrect for this requirement. Microsoft retired the legacy Log Analytics MMA agent in August 2024; Azure Monitor Agent (AMA) with Data Collection Rules is the supported architecture. Why the keyed choice wins: Querying `AppRequests` with `percentile(DurationMs, 95)` by `AppVersion` isolates per-release tail latency, while Smart Detection / Dynamic Threshold alerts adapt to traffic seasonality.
- **D:** Correct. Dynamic thresholds adapt to diurnal/weekly traffic patterns automatically without brittle static error-count thresholds. In this scenario: Querying `AppRequests` with `percentile(DurationMs, 95)` by `AppVersion` isolates per-release tail latency, while Smart Detection / Dynamic Threshold alerts adapt to traffic seasonality.
- **E:** Correct. KQL `summarize percentile(DurationMs, 95)` grouped by `AppVersion` and 5-minute time bins pinpoints whether a newly deployed release caused tail-latency or failure spikes. In this scenario: Querying `AppRequests` with `percentile(DurationMs, 95)` by `AppVersion` isolates per-release tail latency, while Smart Detection / Dynamic Threshold alerts adapt to traffic seasonality.

### Question 89 — B

Answer: `Fixes AB#412`. With the Azure Boards GitHub App connected, `Fixes AB#412` links the GitHub PR to Azure Boards work item 412 and transitions its state when merged to the default branch. When linked via the Azure Boards GitHub App, `Fixes AB#<ID>` in a PR body links AND transitions work item `412` on merge to default branch. Local study-map skill 1.3 (Configure Collaboration, Wikis, Mermaid Diagrams, Automated Release Docs, Webhooks, Boards-GitHub Links, and Microsoft Teams), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/boards/ & https://docs.github.com/en/issues

- **A:** Incorrect for this requirement. `WI#` is not recognized by the Azure Boards GitHub App parser; `AB#` is mandatory. Why the keyed choice wins: With the Azure Boards GitHub App connected, `Fixes AB#412` links the GitHub PR to Azure Boards work item 412 and transitions its state when merged to the default branch.
- **B:** Correct. When linked via the Azure Boards GitHub App, `Fixes AB#<ID>` in a PR body links AND transitions work item `412` on merge to default branch. In this scenario: With the Azure Boards GitHub App connected, `Fixes AB#412` links the GitHub PR to Azure Boards work item 412 and transitions its state when merged to the default branch.
- **C:** Incorrect for this requirement. Azure Boards requires the literal `AB#` prefix (`AB#412`), not `AZDO-`. Why the keyed choice wins: With the Azure Boards GitHub App connected, `Fixes AB#412` links the GitHub PR to Azure Boards work item 412 and transitions its state when merged to the default branch.
- **D:** Incorrect for this requirement. Without `AB#`, `#412` targets GitHub Issue #412 inside the repository rather than Azure Boards work item 412. Why the keyed choice wins: With the Azure Boards GitHub App connected, `Fixes AB#412` links the GitHub PR to Azure Boards work item 412 and transitions its state when merged to the default branch.

### Question 90 — D

Answer: Create an Entra app or Managed Identity with Azure RBAC → add a federated credential matching the repo/environment subject → set `permissions: id-token: write` in YAML → run `azure/login@v2` with client, tenant, and subscription IDs. Workload Identity Federation requires creating the Entra identity with RBAC and a matching federated subject claim before requesting an OIDC JWT (`id-token: write`) via `azure/login@v2`. OIDC federation requires an Entra identity with RBAC and matching `sub` claim before GitHub Actions requests an OIDC JWT (`id-token: write`) for `azure/login`. Local study-map skill 4.3 (Manage Secrets with Azure Key Vault, Workload Identity Federation (OIDC), Secure Files, and Pipeline Log Secret Masking), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Incorrect for this requirement. Entra rejects wildcard `*` subjects in federated credentials, and identity + RBAC must exist before workflow execution. Why the keyed choice wins: Workload Identity Federation requires creating the Entra identity with RBAC and a matching federated subject claim before requesting an OIDC JWT (`id-token: write`) via `azure/login@v2`.
- **B:** Incorrect for this requirement. Plaintext credentials and interactive login fail security controls; OIDC requires pre-configured federated subject matching and `id-token: write`. Why the keyed choice wins: Workload Identity Federation requires creating the Entra identity with RBAC and a matching federated subject claim before requesting an OIDC JWT (`id-token: write`) via `azure/login@v2`.
- **C:** Incorrect for this requirement. Without `id-token: write`, GitHub Actions cannot mint an OIDC JWT, and creating long-lived secrets defeats workload identity federation. Why the keyed choice wins: Workload Identity Federation requires creating the Entra identity with RBAC and a matching federated subject claim before requesting an OIDC JWT (`id-token: write`) via `azure/login@v2`.
- **D:** Correct. OIDC federation requires an Entra identity with RBAC and matching `sub` claim before GitHub Actions requests an OIDC JWT (`id-token: write`) for `azure/login`. In this scenario: Workload Identity Federation requires creating the Entra identity with RBAC and a matching federated subject claim before requesting an OIDC JWT (`id-token: write`) via `azure/login@v2`.

### Question 91 — B, D

Answers: GitHub Advanced Security (or GHAzDO) Secret Scanning with Push Protection blocking `git push` synchronously when high-confidence credentials/tokens are detected; CodeQL semantic SAST analysis building compiled languages (C#/.NET, Java, C++) or running buildless/containerized extraction and publishing SARIF findings to the Security tab. Secret Scanning Push Protection blocks high-confidence credentials synchronously on `git push`, and CodeQL SAST analyzes `.NET 8` payment code on pull requests before merge. Local study-map skill 4.4 (Automate DevSecOps Scanning (GHAS/GHAzDO, Push Protection, CodeQL, Dependabot, Defender for Cloud DevOps, Container & OSS License Scans)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/security/configure-github-advanced-security-features & https://learn.microsoft.com/en-us/defender-for-cloud/devops-security-overview

- **A:** Incorrect for this requirement. Long-lived full-scope personal tokens violate least privilege, expire or break on user offboarding, and must never sit in source files. Why the keyed choice wins: Secret Scanning Push Protection blocks high-confidence credentials synchronously on `git push`, and CodeQL SAST analyzes `.NET 8` payment code on pull requests before merge.
- **B:** Correct. CodeQL treats code as queryable data to detect SQL injection, SSRF, path traversal, and deserialization flaws across call graphs. In this scenario: Secret Scanning Push Protection blocks high-confidence credentials synchronously on `git push`, and CodeQL SAST analyzes `.NET 8` payment code on pull requests before merge.
- **C:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: Secret Scanning Push Protection blocks high-confidence credentials synchronously on `git push`, and CodeQL SAST analyzes `.NET 8` payment code on pull requests before merge.
- **D:** Correct. Push protection stops secrets at the `git push` boundary before they ever enter remote repository history or require `git filter-repo` cleanup. In this scenario: Secret Scanning Push Protection blocks high-confidence credentials synchronously on `git push`, and CodeQL SAST analyzes `.NET 8` payment code on pull requests before merge.
- **E:** Incorrect for this requirement. Unlike SAST (CodeQL reading source), DAST probes live running HTTP endpoints to uncover missing security headers, auth misconfigurations, and runtime XSS/CORS flaws. Why the keyed choice wins: Secret Scanning Push Protection blocks high-confidence credentials synchronously on `git push`, and CodeQL SAST analyzes `.NET 8` payment code on pull requests before merge.

### Question 92 — C

Answer: Create a `hotfix/*` branch directly from the production release Git tag (e.g., `v2.3.0`), ship the tested patch `v2.3.1`, and cherry-pick/PR the fix to `main`. Cutting a `hotfix/3.2.1` branch directly from immutable tag `v3.2.0` isolates the emergency patch from unfinished `main` commits, followed by cherry-picking the fix back to `main`. Branching from the exact deployed tag guarantees unfinished commits on `main` never leak into an emergency production hotfix. Local study-map skill 2.1 (Design and Implement Trunk-Based, Feature, Release, and Hotfix Branching Strategies), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Incorrect for this requirement. Bypassing branch protection and allowing force-pushes on `main` destroys auditability and risks shipping uncompiled or vulnerable code. Why the keyed choice wins: Cutting a `hotfix/3.2.1` branch directly from immutable tag `v3.2.0` isolates the emergency patch from unfinished `main` commits, followed by cherry-picking the fix back to `main`.
- **B:** Incorrect for this requirement. TFVC exclusive checkouts serialize developer work and lack distributed Git branching, PR workflows, GHAS, and Scalar optimizations. Why the keyed choice wins: Cutting a `hotfix/3.2.1` branch directly from immutable tag `v3.2.0` isolates the emergency patch from unfinished `main` commits, followed by cherry-picking the fix back to `main`.
- **C:** Correct. Branching from the exact deployed tag guarantees unfinished commits on `main` never leak into an emergency production hotfix. In this scenario: Cutting a `hotfix/3.2.1` branch directly from immutable tag `v3.2.0` isolates the emergency patch from unfinished `main` commits, followed by cherry-picking the fix back to `main`.
- **D:** Incorrect for this requirement. Multi-month unmerged branches create severe integration conflicts and delay continuous delivery compared to trunk-based workflows. Why the keyed choice wins: Cutting a `hotfix/3.2.1` branch directly from immutable tag `v3.2.0` isolates the emergency patch from unfinished `main` commits, followed by cherry-picking the fix back to `main`.

### Question 93 — B

Answer: No — consuming the default `@Local` view lets production pull unvalidated CI builds before QA promotion to `@Release`. Consuming `@Local` exposes every unvalidated CI build and newly cached upstream package directly to production; production pipelines must consume the promoted `MintLedgerCore@Release` view. Production pipelines must consume `feed@Release` so unverified `@Local` or `@Prerelease` packages are invisible to production restores. Local study-map skill 3.2 (Design and Implement Package Feeds, Upstream Sources, and Promotion Views (@Local, @Prerelease, @Release)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Private-endpoint resources with `publicNetworkAccess: Disabled` reject public Microsoft-hosted agent traffic; VNet-integrated agent pools are required. Why the keyed choice wins: Consuming `@Local` exposes every unvalidated CI build and newly cached upstream package directly to production; production pipelines must consume the promoted `MintLedgerCore@Release` view.
- **B:** Correct. Production pipelines must consume `feed@Release` so unverified `@Local` or `@Prerelease` packages are invisible to production restores. In this scenario: Consuming `@Local` exposes every unvalidated CI build and newly cached upstream package directly to production; production pipelines must consume the promoted `MintLedgerCore@Release` view.
- **C:** Incorrect for this requirement. Multi-stage YAML should compile and package ONCE in the Build stage (`PublishPipelineArtifact`), then download and deploy that exact immutable artifact in QA and Prod. Why the keyed choice wins: Consuming `@Local` exposes every unvalidated CI build and newly cached upstream package directly to production; production pipelines must consume the promoted `MintLedgerCore@Release` view.
- **D:** Incorrect for this requirement. Every functional, networking, licensing, and security constraint in the scenario is satisfied natively. Why the keyed choice wins: Consuming `@Local` exposes every unvalidated CI build and newly cached upstream package directly to production; production pipelines must consume the promoted `MintLedgerCore@Release` view.

### Question 94 — D

Answer: `MintLedgerCore@Release`. Referencing `MintLedgerCore@Release` scopes package resolution strictly to versions explicitly promoted into the `@Release` view while still benefiting from cached upstream dependencies promoted there. Appending `@Release` to the Azure Artifacts feed name restricts NuGet/npm resolution strictly to versions promoted into the `@Release` view. Local study-map skill 3.2 (Design and Implement Package Feeds, Upstream Sources, and Promotion Views (@Local, @Prerelease, @Release)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `@Local` contains every raw CI package pushed directly to the feed before QA promotion. Why the keyed choice wins: Referencing `MintLedgerCore@Release` scopes package resolution strictly to versions explicitly promoted into the `@Release` view while still benefiting from cached upstream dependencies promoted there.
- **B:** Incorrect for this requirement. Azure Artifacts has no built-in `@Upstream` view; cached upstream packages appear in `@Local` (if configured) and must be promoted for `@Release`. Why the keyed choice wins: Referencing `MintLedgerCore@Release` scopes package resolution strictly to versions explicitly promoted into the `@Release` view while still benefiting from cached upstream dependencies promoted there.
- **C:** Incorrect for this requirement. `@Prerelease` includes beta/RC candidate packages not yet signed off for production. Why the keyed choice wins: Referencing `MintLedgerCore@Release` scopes package resolution strictly to versions explicitly promoted into the `@Release` view while still benefiting from cached upstream dependencies promoted there.
- **D:** Correct. Appending `@Release` to the Azure Artifacts feed name restricts NuGet/npm resolution strictly to versions promoted into the `@Release` view. In this scenario: Referencing `MintLedgerCore@Release` scopes package resolution strictly to versions explicitly promoted into the `@Release` view while still benefiting from cached upstream dependencies promoted there.

### Question 95 — C

Answer: No — the Lead Time widget measures from work item creation (`New`) to `Closed`, whereas leadership specifically asked for active-to-closed (`Active` to `Closed`) Cycle Time. No — Lead Time measures from work item creation (`New`) to `Closed` (including backlog wait time), whereas Cycle Time measures active execution from `Active`/`In Progress` to `Closed`. Lead Time includes backlog queue time in `New`; Cycle Time specifically starts the clock when an item enters an `In Progress`/`Active` state category. Local study-map skill 1.2 (Design and Implement DevOps Metrics, Dashboards, Cycle/Lead Time, CFD, DORA KPIs, WIQL, and Analytics Views), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/boards/ & https://docs.github.com/en/issues

- **A:** Incorrect for this requirement. `CODEOWNERS` enforces blocking sign-off only when paired with `Require pull request reviews` + `Require review from Code Owners` on the target branch. Why the keyed choice wins: No — Lead Time measures from work item creation (`New`) to `Closed` (including backlog wait time), whereas Cycle Time measures active execution from `Active`/`In Progress` to `Closed`.
- **B:** Incorrect for this requirement. Deleting a secret in a new commit leaves the cleartext blob inside historical commits (`git log -p`) and fails to revoke the leaked credential. Why the keyed choice wins: No — Lead Time measures from work item creation (`New`) to `Closed` (including backlog wait time), whereas Cycle Time measures active execution from `Active`/`In Progress` to `Closed`.
- **C:** Correct. Lead Time includes backlog queue time in `New`; Cycle Time specifically starts the clock when an item enters an `In Progress`/`Active` state category. In this scenario: No — Lead Time measures from work item creation (`New`) to `Closed` (including backlog wait time), whereas Cycle Time measures active execution from `Active`/`In Progress` to `Closed`.
- **D:** Incorrect for this requirement. Every functional, networking, licensing, and security constraint in the scenario is satisfied natively. Why the keyed choice wins: No — Lead Time measures from work item creation (`New`) to `Closed` (including backlog wait time), whereas Cycle Time measures active execution from `Active`/`In Progress` to `Closed`.

### Question 96 — A

Answer: `scalar clone`. `scalar clone` configures blobless partial clone, sparse-checkout, commit-graph, filesystem monitor, and background Git maintenance specifically for massive monorepos. `scalar clone` clones into a `src/` working directory and automatically enables partial clone, sparse-checkout, commit-graph, and background maintenance. Local study-map skill 2.3 (Manage Large Files and Optimize Git Scale (Git LFS, Scalar, Partial/Shallow Clone, Sparse-Checkout, Submodules)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Correct. `scalar clone` clones into a `src/` working directory and automatically enables partial clone, sparse-checkout, commit-graph, and background maintenance. In this scenario: `scalar clone` configures blobless partial clone, sparse-checkout, commit-graph, filesystem monitor, and background Git maintenance specifically for massive monorepos.
- **B:** Incorrect for this requirement. `git bundle` packages history into an offline archive file rather than optimizing daily developer working trees. Why the keyed choice wins: `scalar clone` configures blobless partial clone, sparse-checkout, commit-graph, filesystem monitor, and background Git maintenance specifically for massive monorepos.
- **C:** Incorrect for this requirement. `--mirror` creates a bare server replica downloading every object and ref, maximizing disk/network usage rather than shrinking laptop clones. Why the keyed choice wins: `scalar clone` configures blobless partial clone, sparse-checkout, commit-graph, filesystem monitor, and background Git maintenance specifically for massive monorepos.
- **D:** Incorrect for this requirement. `git archive` exports an unversioned tarball without a `.git` repository for commits or pushes. Why the keyed choice wins: `scalar clone` configures blobless partial clone, sparse-checkout, commit-graph, filesystem monitor, and background Git maintenance specifically for massive monorepos.

### Question 97 — A

Answer: No — `git rm` only removes the file from the latest commit while leaving the password exposed in prior commits and unrotated. `git rm` only removes the file from the newest commit tree while leaving the cleartext password downloadable in prior commit history (`HEAD~3`) and unrevoked. Deleting a secret in a new commit leaves the cleartext blob inside historical commits (`git log -p`) and fails to revoke the leaked credential. Local study-map skill 2.4 (Configure Repository Permissions, Annotated Tags, Reflog/Revert Recovery, and Secret History Removal (git filter-repo)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/repos/git/ & https://docs.github.com/en/repositories

- **A:** Correct. Deleting a secret in a new commit leaves the cleartext blob inside historical commits (`git log -p`) and fails to revoke the leaked credential. In this scenario: `git rm` only removes the file from the newest commit tree while leaving the cleartext password downloadable in prior commit history (`HEAD~3`) and unrevoked.
- **B:** Incorrect for this requirement. `pull_request_target` runs in the context of the base repository with secret access; checking out untrusted fork code inside it creates a critical pwn-request vulnerability. Why the keyed choice wins: `git rm` only removes the file from the newest commit tree while leaving the cleartext password downloadable in prior commit history (`HEAD~3`) and unrevoked.
- **C:** Incorrect for this requirement. Lead Time includes backlog queue time in `New`; Cycle Time specifically starts the clock when an item enters an `In Progress`/`Active` state category. Why the keyed choice wins: `git rm` only removes the file from the newest commit tree while leaving the cleartext password downloadable in prior commit history (`HEAD~3`) and unrevoked.
- **D:** Incorrect for this requirement. Every functional, networking, licensing, and security constraint in the scenario is satisfied natively. Why the keyed choice wins: `git rm` only removes the file from the newest commit tree while leaving the cleartext password downloadable in prior commit history (`HEAD~3`) and unrevoked.

### Question 98 — C

Answer: `lockBehavior: sequential`. Setting `lockBehavior: sequential` queues concurrent runs against an Exclusive Lock environment so every ordered migration executes sequentially rather than canceling superseded runs (`runLatest`). `lockBehavior: sequential` queues concurrent pipeline deployments to an Exclusive Lock environment so every run executes in FIFO order without skipping. Local study-map skill 3.12 (Configure YAML Environments with Approvals, Business Hours, Branch Control, Exclusive Locks, and Required Templates), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. `bypass` is invalid YAML syntax and would disable exclusive serialization. Why the keyed choice wins: Setting `lockBehavior: sequential` queues concurrent runs against an Exclusive Lock environment so every ordered migration executes sequentially rather than canceling superseded runs (`runLatest`).
- **B:** Incorrect for this requirement. `parallel` is not a valid `lockBehavior` value on an Azure Pipelines Exclusive Lock (`sequential` and `runLatest` are the two valid modes). Why the keyed choice wins: Setting `lockBehavior: sequential` queues concurrent runs against an Exclusive Lock environment so every ordered migration executes sequentially rather than canceling superseded runs (`runLatest`).
- **C:** Correct. `lockBehavior: sequential` queues concurrent pipeline deployments to an Exclusive Lock environment so every run executes in FIFO order without skipping. In this scenario: Setting `lockBehavior: sequential` queues concurrent runs against an Exclusive Lock environment so every ordered migration executes sequentially rather than canceling superseded runs (`runLatest`).
- **D:** Incorrect for this requirement. `lockBehavior: runLatest` executes only the newest queued run and cancels intermediate waiting runs — unsuitable when sequential ordered migrations must all run. Why the keyed choice wins: Setting `lockBehavior: sequential` queues concurrent runs against an Exclusive Lock environment so every ordered migration executes sequentially rather than canceling superseded runs (`runLatest`).

### Question 99 — B

Answer: Pin slot-sticky settings on `Production` and `staging` → deploy the immutable artifact to the `staging` slot → run warm-up and smoke probes against `staging` → swap `staging` into `Production` (swapping back on gate failure). Pinning slot settings, deploying to `staging`, warming up and probing `staging`, and swapping VIPs keeps the previous build warm in `staging` for immediate swap-back rollback. Deploying to `staging`, validating warm workers, and swapping VIP routing achieves zero downtime while keeping the prior build warm in `staging` for instant swap-back. Local study-map skill 3.14 (Plan Ordered Dependency Rollouts, Zero-Downtime Slot Swaps, Warm-Up, Rollback Resiliency, and Hotfix Paths), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Incorrect for this requirement. Free and Basic App Service plans do not support deployment slots or autoscale; Standard S1+ or Premium is required. Why the keyed choice wins: Pinning slot settings, deploying to `staging`, warming up and probing `staging`, and swapping VIPs keeps the previous build warm in `staging` for immediate swap-back rollback.
- **B:** Correct. Deploying to `staging`, validating warm workers, and swapping VIP routing achieves zero downtime while keeping the prior build warm in `staging` for instant swap-back. In this scenario: Pinning slot settings, deploying to `staging`, warming up and probing `staging`, and swapping VIPs keeps the previous build warm in `staging` for immediate swap-back rollback.
- **C:** Incorrect for this requirement. Stopping `Production` causes an outage window that deployment slots are specifically designed to eliminate. Why the keyed choice wins: Pinning slot settings, deploying to `staging`, warming up and probing `staging`, and swapping VIPs keeps the previous build warm in `staging` for immediate swap-back rollback.
- **D:** Incorrect for this requirement. Swapping before deploying pushes empty state to users, and pinning slot settings afterward leaks staging values. Why the keyed choice wins: Pinning slot settings, deploying to `staging`, warming up and probing `staging`, and swapping VIPs keeps the previous build warm in `staging` for immediate swap-back rollback.

### Question 100 — A

Answer: `SqlAzureDacpacDeployment@1`. `SqlAzureDacpacDeployment@1` runs `SqlPackage.exe` against Azure SQL using Entra / Workload Identity Federation service connections to compute and apply state-based `.dacpac` diffs. `SqlAzureDacpacDeployment@1` authenticates to Azure SQL (supporting Entra / WIF service connections) and deploys `.dacpac` packages or SQL scripts via `SqlPackage.exe`. Local study-map skill 3.16 (Implement Container, Binary, Script, and Database Deployments (SQL DACPAC vs. Idempotent EF/SQL Migrations)), aligned to the official AZ-400 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/az-400 Primary reference: https://learn.microsoft.com/en-us/azure/devops/pipelines/ & https://docs.github.com/en/actions

- **A:** Correct. `SqlAzureDacpacDeployment@1` authenticates to Azure SQL (supporting Entra / WIF service connections) and deploys `.dacpac` packages or SQL scripts via `SqlPackage.exe`. In this scenario: `SqlAzureDacpacDeployment@1` runs `SqlPackage.exe` against Azure SQL using Entra / Workload Identity Federation service connections to compute and apply state-based `.dacpac` diffs.
- **B:** Incorrect for this requirement. `AzureRmWebAppDeployment@4` deploys App Service web packages rather than standalone multi-stage SQL `.dacpac` schema diffs. Why the keyed choice wins: `SqlAzureDacpacDeployment@1` runs `SqlPackage.exe` against Azure SQL using Entra / Workload Identity Federation service connections to compute and apply state-based `.dacpac` diffs.
- **C:** Incorrect for this requirement. `AzureFileCopy@5` copies blobs or VM files via AzCopy and cannot compare or apply `.dacpac` SQL schemas. Why the keyed choice wins: `SqlAzureDacpacDeployment@1` runs `SqlPackage.exe` against Azure SQL using Entra / Workload Identity Federation service connections to compute and apply state-based `.dacpac` diffs.
- **D:** Incorrect for this requirement. `MysqlDeploymentOnMachineGroup@1` targets MySQL databases, not Azure SQL `.dacpac` state models. Why the keyed choice wins: `SqlAzureDacpacDeployment@1` runs `SqlPackage.exe` against Azure SQL using Entra / Workload Identity Federation service connections to compute and apply state-based `.dacpac` diffs.
