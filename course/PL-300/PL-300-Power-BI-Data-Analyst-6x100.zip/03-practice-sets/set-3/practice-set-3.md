# Microsoft PL-300 — Full-Length Mock Exam 3

Power BI Data Analyst · 100 questions · expanded practice bank · passing target 700/1000

Blueprint-weighted mock exam. Item mix: 84 multiple-choice (selection count stated where needed), 16 multi-select, and 4 case studies of 3 questions. 8 of the multiple-choice items ask you to choose the correct candidate sequence. Hot-area, drag-and-drop UI, labs, and adaptive problem-solution sets cannot be reproduced in a CSV; see the README for the exact fidelity boundary.

Original educational content, not actual, recalled, or copied Microsoft exam items.

## Questions

### 1. A trading desk must see intraday position values that change minute by minute, and the source can serve those queries. Which connection fits?

Domain: Prepare the data

- A. Import mode
- B. Connect to a shared semantic model instead of importing the source again
- C. DirectLake over a lakehouse
- D. DirectQuery

### 2. A risk team must use the approved capital model without restating its definitions. What should the analyst do?

Domain: Prepare the data

- A. Import mode
- B. Live connection to a published semantic model
- C. DirectQuery
- D. Connect to a shared semantic model instead of importing the source again

### 3. A bank needs a monthly regulatory extract and a live view of open exceptions. Which two storage choices fit? Select two.

Domain: Prepare the data

- A. Connect to a shared semantic model instead of importing the source again
- B. Import mode
- C. DirectLake over a lakehouse
- D. Live connection to a published semantic model
- E. DirectQuery

### 4. A query must be repointed at a renamed server while keeping every transformation step. What should be changed?

Domain: Prepare the data

- A. Change the data source settings rather than rebuilding the query
- B. Set privacy levels to isolate the sources
- C. Update the data source credentials in the semantic model settings
- D. Create a parameter for the server, path, or filter

### 5. Eight million ledger rows are analysed daily, and the core system rejects analyst queries. Which mode fits?

Domain: Prepare the data

- A. DirectQuery
- B. Dual mode table
- C. Import mode
- D. DirectLake over a lakehouse

### 6. Delta tables in a Fabric lakehouse must be queried at Import-like speed with no copy. Which mode fits?

Domain: Prepare the data

- A. Import mode
- B. DirectLake over a lakehouse
- C. Dual mode table
- D. DirectQuery

### 7. A composite model has imported dimensions and a DirectQuery fact, and dimension lookups are causing extra round trips. Which setting helps?

Domain: Prepare the data

- A. Import mode
- B. Dual mode table
- C. DirectQuery
- D. DirectLake over a lakehouse

### 8. One query has to switch from a test database to production once the build is signed off. What should be created?

Domain: Prepare the data

- A. Set privacy levels to isolate the sources
- B. Update the data source credentials in the semantic model settings
- C. Create a parameter for the server, path, or filter
- D. Change the data source settings rather than rebuilding the query

### 9. Refresh fails with an authorization error after a service principal secret was rotated. What must be updated?

Domain: Prepare the data

- A. Change the data source settings rather than rebuilding the query
- B. Create a parameter for the server, path, or filter
- C. Update the data source credentials in the semantic model settings
- D. Set privacy levels to isolate the sources

### 10. A custody extract arrives with no documentation, and nobody knows how complete it is. What should be done first?

Domain: Prepare the data

- A. Profile the column with column quality, distribution, and profile views
- B. Review column statistics and value distribution
- C. Correct the column data type before building the model
- D. Replace nulls with a defined placeholder or a filled-down value

### 11. An auditor asks whether a few counterparties dominate exposure. Which evidence answers that?

Domain: Prepare the data

- A. Review column statistics and value distribution
- B. Replace nulls with a defined placeholder or a filled-down value
- C. Correct the column data type before building the model
- D. Profile the column with column quality, distribution, and profile views

### 12. Trade dates arrive as text, so monthly grouping and year-to-date both fail. What should be corrected?

Domain: Prepare the data

- A. Review column statistics and value distribution
- B. Profile the column with column quality, distribution, and profile views
- C. Replace nulls with a defined placeholder or a filled-down value
- D. Correct the column data type before building the model

### 13. A new market-data extract must be brought in without a rebuild next month. Which sequence is correct?

Domain: Prepare the data

- A. Shape the table → delete the profiling steps → load every column
- B. Load the table → discover the type errors in the report → re-import the source
- C. Load every column → profile in the report → patch the visual
- D. Profile the source → fix types and nulls → shape the table → load only the needed columns

### 14. A fee column is blank for accounts opened this month, and fee totals dip whenever new accounts appear. What should be done?

Domain: Prepare the data

- A. Filter out the error rows and report them separately
- B. Replace nulls with a defined placeholder or a filled-down value
- C. Trim, clean, and standardize the text values
- D. Remove duplicate rows using the natural business key

### 15. A re-run batch duplicates trade rows, and a handful of rows fail to load on a currency code. Which two fixes are required? Select two.

Domain: Prepare the data

- A. Filter out the error rows and report them separately
- B. Trim, clean, and standardize the text values
- C. Remove duplicate rows using the natural business key
- D. Replace nulls with a defined placeholder or a filled-down value
- E. Use a locale-aware conversion for dates and decimals

### 16. Counterparty names differ only by trailing spaces and casing, so one client appears as three. What should be done?

Domain: Prepare the data

- A. Replace nulls with a defined placeholder or a filled-down value
- B. Filter out the error rows and report them separately
- C. Trim, clean, and standardize the text values
- D. Remove duplicate rows using the natural business key

### 17. A settlement extract has stray characters, duplicate members, and mixed formats. Which sequence is defensible?

Domain: Prepare the data

- A. Filter out the failing rows → load → ask the business later
- B. Convert types first → then look for duplicates → then trim
- C. Identify the bad values → standardize text → convert types → document what was replaced
- D. Replace all values with a default → convert types → load

### 18. Exposure must be banded into low, medium, and high using the risk policy thresholds. What should be added?

Domain: Prepare the data

- A. Add a conditional column for rule-based bucketing
- B. Split the combined column into separate fields
- C. Group by the key and aggregate the measures
- D. Add a custom column with an M expression

### 19. A transaction table must become one row per account per day with a net amount. Which two steps are required? Select two.

Domain: Prepare the data

- A. Extract the needed part of the text with a delimiter or position
- B. Group by the key and aggregate the measures
- C. Add a custom column with an M expression
- D. Add an aggregate step with the correct summarization
- E. Add a conditional column for rule-based bucketing

### 20. Instrument codes begin with a four-character asset-class prefix the report needs separately. What should be done?

Domain: Prepare the data

- A. Add an aggregate step with the correct summarization
- B. Extract the needed part of the text with a delimiter or position
- C. Add a custom column with an M expression
- D. Split the combined column into separate fields

### 21. A monthly risk extract has one column per capital ratio, and the model needs one ratio column and one value column. What should be done?

Domain: Prepare the data

- A. Transpose the table so the header becomes a column
- B. Unpivot the month columns into rows
- C. Expand the JSON record into typed columns
- D. Pivot the attribute values into columns

### 22. A source stores one row per account-attribute pair, and the report needs attributes as columns. What should be done?

Domain: Prepare the data

- A. Transpose the table so the header becomes a column
- B. Convert the XML or JSON list into a table of rows
- C. Unpivot the month columns into rows
- D. Pivot the attribute values into columns

### 23. A market feed returns a list of quotes inside a single cell. What should be done?

Domain: Prepare the data

- A. Transpose the table so the header becomes a column
- B. Expand the JSON record into typed columns
- C. Convert the XML or JSON list into a table of rows
- D. Convert the list value to a table and expand it

### 24. Twelve monthly settlement files share the same columns and must become one table. What should be used?

Domain: Prepare the data

- A. Append the queries into one table
- B. Use a fuzzy merge with a similarity threshold
- C. Merge the two queries on a matching key
- D. Use a left outer join to keep every fact row

### 25. A trade fact must gain counterparty rating, and no trade may be dropped when the rating lookup has no match. Which two choices are required? Select two.

Domain: Prepare the data

- A. Append the queries into one table
- B. Merge the two queries on a matching key
- C. Stage the raw query and build a separate clean query on it
- D. Use a fuzzy merge with a similarity threshold
- E. Use a left outer join to keep every fact row

### 26. A transformation must stay fast on a very large source table, and the team wants the source to do the filtering. Which two choices fit? Select two.

Domain: Prepare the data

- A. Duplicate the query so the two are independent
- B. Disable load on the staging query
- C. Use a native query to select only the needed rows
- D. Reference the query so later steps can diverge
- E. Keep the steps foldable so the source does the work

### 27. Authors keep dragging account identifiers onto slides, and amounts display with too many decimals. Which two actions fix that? Select two.

Domain: Model the data

- A. Build a star schema with a fact table and conformed dimensions
- B. Hide technical columns from the report view
- C. Normalize the dimension into a snowflake
- D. Set the table and column properties, including hidden keys and format strings
- E. Flatten the lookup attributes into a single dimension

### 28. A finance model must be rebuilt from one wide extract. Which sequence produces a model that scales?

Domain: Model the data

- A. Build the relationships first → decide the grain afterwards → load
- B. Keep one wide table → relate it to itself → build measures
- C. Create a dimension per column → relate each one to the fact
- D. Define the grain → separate facts from dimensions → add surrogate keys → relate dimension to fact

### 29. A sector table sits between counterparty and fact, and every filter crosses two hops. What should be done?

Domain: Model the data

- A. Set the table and column properties, including hidden keys and format strings
- B. Normalize the dimension into a snowflake
- C. Flatten the lookup attributes into a single dimension
- D. Build a star schema with a fact table and conformed dimensions

### 30. Trade date and settlement date both relate to the date table, but only one filters the visual. Why?

Domain: Model the data

- A. Single-direction filter from dimension to fact
- B. One-to-many relationship from the dimension to the fact
- C. One-to-one relationship between two tables with the same grain
- D. Inactive relationship activated with USERELATIONSHIP

### 31. Accounts have many owners and owners hold many accounts, with an ownership table between them. Which relationship shape is required?

Domain: Model the data

- A. Single-direction filter from dimension to fact
- B. One-to-one relationship between two tables with the same grain
- C. Many-to-many relationship with a bridging table
- D. One-to-many relationship from the dimension to the fact

### 32. A new exposure fact must filter from its dimensions and must never let one dimension filter another. Which two choices fit? Select two.

Domain: Model the data

- A. Many-to-many relationship with a bridging table
- B. Single-direction filter from dimension to fact
- C. Bi-directional cross-filtering on the relationship
- D. One-to-many relationship from the dimension to the fact
- E. Set the cross-filter direction on the relationship

### 33. A counterparty visual ignores a selection made in a trade visual, and the model is the suspect. Which setting decides that?

Domain: Model the data

- A. Set the cross-filter direction on the relationship
- B. Single-direction filter from dimension to fact
- C. Inactive relationship activated with USERELATIONSHIP
- D. Bi-directional cross-filtering on the relationship

### 34. Rolling balance totals skip days with no postings, and the running figure looks wrong. What is missing?

Domain: Model the data

- A. Create one date table and role-play it through several relationships
- B. Mark the table as a date table
- C. Build the fiscal periods as columns in the date table
- D. Create a dedicated date table marked as the date table

### 35. The financial year ends in March, and reports keep showing calendar quarters. What must be added?

Domain: Model the data

- A. Build the fiscal periods as columns in the date table
- B. Mark the table as a date table
- C. Create one date table and role-play it through several relationships
- D. Create a dedicated date table marked as the date table

### 36. A proper date table exists, but the engine still picks a posting date column. What should be done?

Domain: Model the data

- A. Create one date table and role-play it through several relationships
- B. Mark the table as a date table
- C. Build the fiscal periods as columns in the date table
- D. Create a dedicated date table marked as the date table

### 37. A monthly board pack needs dependable year-to-date and prior-year figures. Which sequence delivers that?

Domain: Model the data

- A. Create a contiguous date table → mark it as the date table → relate it to the fact dates → build time intelligence on it
- B. Create a date table → leave it unrelated → filter with it
- C. Use the fact date column directly → write TOTALYTD → add a date slicer
- D. Create one date table per date column → relate all of them to the fact

### 38. A net interest margin must respond to product and period slicers without adding a stored column. What should be created?

Domain: Model the data

- A. Create a calculated table
- B. Create a measure for the aggregation
- C. The filter context supplied by the visual, slicers, and page filters
- D. Create a calculated column

### 39. A calculated column needs a value from a related dimension table, and the expression fails. What explains the failure?

Domain: Model the data

- A. Create a measure for the aggregation
- B. The row context inside an iterator
- C. The filter context supplied by the visual, slicers, and page filters
- D. Create a calculated table

### 40. A report needs a cost-to-income ratio that survives a zero denominator and a weighted average that multiplies before summing. Which two functions fit? Select two.

Domain: Model the data

- A. Use an iterator function for row-level arithmetic
- B. Use DISTINCT COUNT for unique entities
- C. Use DIVIDE instead of the division operator
- D. Create a measure for the aggregation
- E. Use an iterator such as SUMX over the row-level expression

### 41. A measure must show each product's share of total revenue while the visual lists products. Which function changes the filter context?

Domain: Model the data

- A. Wrap the aggregation in CALCULATE to change the filter context
- B. Use ALL on the table to clear its filters
- C. Add KEEPFILTERS to intersect rather than replace the filter
- D. Store intermediate results in VAR and RETURN

### 42. The denominator of a share must follow the portfolio the reader picked, not the product rows drawn on the visual. Which modifier does that?

Domain: Model the data

- A. Use ALLSELECTED to respect the slicer but ignore the visual
- B. Add KEEPFILTERS to intersect rather than replace the filter
- C. Use ALL on the table to clear its filters
- D. Remove the filter with REMOVEFILTERS or ALL

### 43. A measure repeats the same denominator expression three times and is hard to review. What should be used?

Domain: Model the data

- A. Add KEEPFILTERS to intersect rather than replace the filter
- B. Use ALL on the table to clear its filters
- C. Store intermediate results in VAR and RETURN
- D. Wrap the aggregation in CALCULATE to change the filter context

### 44. A measure that must stay within the selected month is returning the whole year. Which modifier fixes it?

Domain: Model the data

- A. Use ALL on the table to clear its filters
- B. Remove the filter with REMOVEFILTERS or ALL
- C. Add KEEPFILTERS to intersect rather than replace the filter
- D. Use ALLSELECTED to respect the slicer but ignore the visual

### 45. A monthly pack needs cumulative revenue and the same figure for the equivalent month last year. Which two patterns are required? Select two.

Domain: Model the data

- A. Use TOTALYTD or DATESYTD for year-to-date
- B. Use LASTNONBLANK or LASTDATE for a semi-additive balance
- C. Use DATESINPERIOD for a windowed calculation
- D. Use AVERAGEX over a rolling date window
- E. Use SAMEPERIODLASTYEAR or DATEADD for the comparable period

### 46. A daily deposit series is too noisy to discuss with the treasury committee. What should be used?

Domain: Model the data

- A. Use AVERAGEX over a rolling date window
- B. Use DATESINPERIOD for a windowed calculation
- C. Use TOTALYTD or DATESYTD for year-to-date
- D. Use SAMEPERIODLASTYEAR or DATEADD for the comparable period

### 47. Twenty-five measures each need month-to-date, quarter-to-date, and year-to-date variants. What should be used?

Domain: Model the data

- A. Use a quick measure for the standard pattern
- B. Create a calculation group for the time-intelligence variants
- C. Create a field parameter so the author can switch the measure or axis
- D. Create a numeric range parameter for scenario analysis

### 48. One page must switch between revenue and margin and test a rate-change assumption. Which two features fit? Select two.

Domain: Model the data

- A. Create a numeric range parameter for scenario analysis
- B. Create a field parameter so the author can switch the measure or axis
- C. Create a calculation group for the time-intelligence variants
- D. Use a quick measure for the standard pattern
- E. Use PERCENTILE.INC for a distribution boundary

### 49. A compliance page takes 40 seconds, and the author must identify the visual responsible. What should be used?

Domain: Model the data

- A. Inspect the query plan in DAX query view
- B. Run Performance Analyzer to find the slow visual
- C. Reduce the granularity loaded into the model
- D. Reduce column cardinality and width to shrink the VertiPaq store

### 50. A large trade fact must stay at detail level but common summaries are slow. What should be added?

Domain: Model the data

- A. Reduce the granularity loaded into the model
- B. Run Performance Analyzer to find the slow visual
- C. Remove unnecessary rows and columns before optimizing measures
- D. Add an aggregation table for the large fact

### 51. A regional head must compare lending volume across fifteen branches. Which visual fits?

Domain: Visualize and analyze the data

- A. A pie or donut chart
- B. A treemap
- C. A line chart with a date axis
- D. A clustered bar or column chart

### 52. Two hundred product codes must be shown by contribution to revenue. Which visual fits?

Domain: Visualize and analyze the data

- A. A gauge visual
- B. A pie or donut chart
- C. A treemap
- D. A scatter chart

### 53. A risk analyst must see whether exposure relates to default rate across segments. Which visual fits?

Domain: Visualize and analyze the data

- A. A funnel chart
- B. A scatter chart
- C. A matrix visual with row and column groups
- D. A line chart with a date axis

### 54. Readers need a visible control for choosing a portfolio on the page. What should be added?

Domain: Visualize and analyze the data

- A. Set the filter pane scope by page, report, or visual
- B. Sync the slicer across the pages that share the same filter
- C. A slicer on the report page
- D. Edit the interactions so the visual does not filter the others

### 55. A chosen portfolio must stay applied across six report pages. What should be configured?

Domain: Visualize and analyze the data

- A. Set the filter pane scope by page, report, or visual
- B. Sync the slicer across the pages that share the same filter
- C. Edit the interactions so the visual does not filter the others
- D. A slicer on the report page

### 56. Selecting a branch on the page is filtering a fixed commentary card. What should be changed?

Domain: Visualize and analyze the data

- A. Set the filter pane scope by page, report, or visual
- B. Edit the interactions so the visual does not filter the others
- C. Sync the slicer across the pages that share the same filter
- D. A slicer on the report page

### 57. Readers should not have to reapply the same restriction on each page they open. Where should the filter be placed?

Domain: Visualize and analyze the data

- A. A slicer on the report page
- B. Sync the slicer across the pages that share the same filter
- C. Edit the interactions so the visual does not filter the others
- D. Set the filter pane scope by page, report, or visual

### 58. A portfolio view and a group view share one page, and readers must switch between saved states. What should be captured?

Domain: Visualize and analyze the data

- A. Use the Selection pane to group and layer visuals
- B. Capture the view in a bookmark
- C. Add a page navigator for the report
- D. Add buttons with actions that navigate or apply a bookmark

### 59. Two bookmarks exist, and readers must apply one with a click from the canvas. What should be added?

Domain: Visualize and analyze the data

- A. Add buttons with actions that navigate or apply a bookmark
- B. Capture the view in a bookmark
- C. Add a page navigator for the report
- D. Use the Selection pane to group and layer visuals

### 60. A risk page needs three saved views, each reachable from a button. Which sequence works?

Domain: Visualize and analyze the data

- A. Capture a bookmark before setting the filters → expect it to restore them
- B. Create a page per view → duplicate the visuals → maintain each page
- C. Create the views → capture each in a bookmark → add buttons → hide the visuals not in use
- D. Use buttons without actions → tell readers to click twice

### 61. The report will reach twenty pages and needs navigation that stays current. What should be used?

Domain: Visualize and analyze the data

- A. Add buttons with actions that navigate or apply a bookmark
- B. Add a page navigator for the report
- C. Capture the view in a bookmark
- D. Use the Selection pane to group and layer visuals

### 62. A reader must click a client on the summary and open a detail page about that client. What should be configured?

Domain: Visualize and analyze the data

- A. Enable drill-down through the hierarchy
- B. Set the filter pane scope by page, report, or visual
- C. Edit the interactions so the visual does not filter the others
- D. Configure a drillthrough page with the entity filter

### 63. A hover must show exposure, limit, and utilization together without adding page visuals. Which two actions deliver that? Select two.

Domain: Visualize and analyze the data

- A. Use the Selection pane to group and layer visuals
- B. Enable drill-down through the hierarchy
- C. Configure a drillthrough page with the entity filter
- D. Build a custom tooltip page
- E. Set the tooltip to a report page and size it to the hover area

### 64. A risk team is building its first drillthrough page. Which sequence works?

Domain: Visualize and analyze the data

- A. Put every field on the summary visual → expect drillthrough to work
- B. Set the drillthrough filter → publish → skip the back button
- C. Create the detail page → add a visual → tell readers to filter it manually
- D. Choose the entity field → create the drillthrough page → place the entity filter → add a back button

### 65. A chart must allow a move from portfolio to sector and then client, staying in the same visual. What should be enabled?

Domain: Visualize and analyze the data

- A. Enable drill-down through the hierarchy
- B. Edit the interactions so the visual does not filter the others
- C. Configure a drillthrough page with the entity filter
- D. Build a custom tooltip page

### 66. Relationship managers will open the report on a phone and need two measures first. What should be built?

Domain: Visualize and analyze the data

- A. Configure the export and download settings for the report
- B. Enable personalization for the visuals the reader may change
- C. Build the mobile layout in the mobile view
- D. Provide alt text for each meaningful visual

### 67. Readers want to change a visual from a table to a bar without edit rights. What should be enabled?

Domain: Visualize and analyze the data

- A. Build the mobile layout in the mobile view
- B. Configure the export and download settings for the report
- C. Provide alt text for each meaningful visual
- D. Enable personalization for the visuals the reader may change

### 68. Every page must share one palette and font without individual styling. What should be applied?

Domain: Visualize and analyze the data

- A. Apply a report theme JSON
- B. Apply conditional formatting driven by a measure
- C. Use the Selection pane to group and layer visuals
- D. Set the axis range and units explicitly

### 69. A table must colour accounts whose utilization exceeds the policy limit. What should be applied?

Domain: Visualize and analyze the data

- A. Apply conditional formatting driven by a measure
- B. Apply a report theme JSON
- C. Set the axis range and units explicitly
- D. Use the Selection pane to group and layer visuals

### 70. Layered callouts must sit above the chart, and a column axis must not start above zero. Which two settings are required? Select two.

Domain: Visualize and analyze the data

- A. Set the axis range and units explicitly
- B. Use the Selection pane to group and layer visuals
- C. Apply a report theme JSON
- D. Apply conditional formatting driven by a measure
- E. Turn on and format data labels

### 71. A monthly chart must show whether each month beat the risk appetite threshold. What should be added?

Domain: Visualize and analyze the data

- A. Create groups for the categories that matter
- B. Use the built-in forecast on a line chart
- C. Add a reference line for the target or average
- D. Add error bars to show the uncertainty range

### 72. A stable claims series must be projected two quarters ahead with a confidence band. What should be used?

Domain: Visualize and analyze the data

- A. Use the built-in forecast on a line chart
- B. Create bins for a continuous measure
- C. Add a reference line for the target or average
- D. Use clustering to find segments in the data

### 73. Loan sizes must be shown as ranges so the distribution is readable. What should be used?

Domain: Visualize and analyze the data

- A. Use clustering to find segments in the data
- B. Use the outlier detection feature on the visual
- C. Create groups for the categories that matter
- D. Create bins for a continuous measure

### 74. A root-cause page must explore any dimension in any order. Which visual fits?

Domain: Visualize and analyze the data

- A. Use Copilot to suggest a report page
- B. Use Q&A to answer a natural-language question
- C. Use the Decomposition Tree visual
- D. Use the Key Influencers visual

### 75. The team wants the factors associated with attrition and a written summary for executives. Which two features fit? Select two.

Domain: Visualize and analyze the data

- A. Use the Decomposition Tree visual
- B. Use the Key Influencers visual
- C. Use Copilot to suggest a report page
- D. Use Copilot to create a narrative visual
- E. Use Q&A to answer a natural-language question

### 76. Managers want to type a question and receive a visual without another page being built. What should be enabled?

Domain: Visualize and analyze the data

- A. Use Q&A to answer a natural-language question
- B. Use Copilot to create a narrative visual
- C. Use the Decomposition Tree visual
- D. Use the Key Influencers visual

### 77. Five analysts must publish and edit content but must not manage membership. Which role fits?

Domain: Manage and secure Power BI

- A. Workspace Admin role
- B. Workspace Contributor role
- C. Workspace Viewer role
- D. Workspace Member role

### 78. The bank's workspace owner has resigned, and the team must decide who manages membership and who may add lower-privileged users. Which two roles cover that? Select two.

Domain: Manage and secure Power BI

- A. Publish an app from the workspace
- B. Workspace Member role
- C. Workspace Viewer role
- D. Workspace Admin role
- E. Workspace Contributor role

### 79. One app must show branch pages to staff and summary pages to executives. What should be configured?

Domain: Manage and secure Power BI

- A. Update the app after changing the workspace content
- B. Define an app audience for each group of consumers
- C. Publish an app from the workspace
- D. Choose the distribution method that matches the audience

### 80. The bank is publishing its first app to two audiences. Which sequence is correct?

Domain: Manage and secure Power BI

- A. Create one app per person → assign each audience manually
- B. Publish the app before the report is finished → update it never
- C. Give every consumer the workspace Viewer role → skip the app
- D. Build in the workspace → curate the app pages → assign audiences → publish and update the app

### 81. A page was corrected in the workspace, but consumers still open the previous version. What was missed?

Domain: Manage and secure Power BI

- A. Update the app after changing the workspace content
- B. Choose the distribution method that matches the audience
- C. Define an app audience for each group of consumers
- D. Publish an app from the workspace

### 82. The executive team monitors five headline numbers taken from different reports on one canvas. What should be created?

Domain: Manage and secure Power BI

- A. Create a dashboard in the service
- B. Create a subscription for the report or dashboard
- C. Pin the visual to a dashboard tile
- D. Create a data alert on a dashboard tile

### 83. A director wants the monthly pack as an email snapshot at 6 a.m. What should be configured?

Domain: Manage and secure Power BI

- A. Create a data alert on a dashboard tile
- B. Set the alert threshold on the pinned card tile
- C. Create a subscription for the report or dashboard
- D. Pin the visual to a dashboard tile

### 84. A treasury manager must be notified when the overnight position crosses a limit. What should be created?

Domain: Manage and secure Power BI

- A. Create a subscription for the report or dashboard
- B. Create a data alert on a dashboard tile
- C. Pin the visual to a dashboard tile
- D. Set the alert threshold on the pinned card tile

### 85. A five-year transaction fact must refresh quickly and only recent partitions change. Which two steps are required? Select two.

Domain: Manage and secure Power BI

- A. Update the credentials used by the refresh schedule
- B. Install an on-premises data gateway
- C. Configure incremental refresh with the range parameters
- D. Set the RangeStart and RangeEnd parameters the refresh policy expects
- E. Configure scheduled refresh on the semantic model

### 86. A bank is scheduling refresh on a model that has never refreshed in the service. Which sequence avoids a silent failure?

Domain: Manage and secure Power BI

- A. Set the schedule → publish → wait for the first failure email
- B. Use a personal gateway → schedule → leave the team to maintain it
- C. Increase the refresh frequency to hourly → ignore the source load
- D. Confirm the gateway or cloud connection → store credentials → set the schedule → check refresh history

### 87. Relationship managers must see only their own clients in one shared report. What should be created?

Domain: Manage and secure Power BI

- A. Add the security group to the role membership
- B. Test the role with View as role in the service
- C. Define a row-level security role with a DAX filter
- D. Use a dynamic RLS rule based on USERPRINCIPALNAME

### 88. Exported files must keep their protection after they leave the workspace. What should be applied?

Domain: Manage and secure Power BI

- A. Promote the content as endorsed
- B. Grant item-level access to the specific report
- C. Apply a sensitivity label to the semantic model and report
- D. Certify the semantic model

---

## Case study — Brightwater Utilities

Brightwater Utilities models 3 million meters and publishes a board page plus an audit view. One free-text location column holds almost unique values, and it dominates the size of what is otherwise a modest model. The board page must explain the movement from opening to closing revenue across the quarter and show progress against the annual target. Internal audit needs to read the outage reports without being able to change them, and without joining the authoring workspace.

The next 3 questions refer to it. Read the scenario once, then answer all 3; each item restates the constraint it tests and is scored individually.

### 89. The meter model is dominated by one text column with almost unique values. What should be done?

Domain: Model the data

- A. Remove the high-cardinality columns the report does not use
- B. Add an aggregation table for the large fact
- C. Reduce column cardinality and width to shrink the VertiPaq store
- D. Remove unnecessary rows and columns before optimizing measures

### 90. The board page must explain the movement from opening to closing revenue and show progress against target. Which two visuals fit? Select two.

Domain: Visualize and analyze the data

- A. A funnel chart
- B. A waterfall chart
- C. A matrix visual with row and column groups
- D. A KPI visual with a target
- E. A clustered bar or column chart

### 91. Internal audit must read the outage reports without editing them. Which role fits?

Domain: Manage and secure Power BI

- A. Workspace Admin role
- B. Workspace Viewer role
- C. Workspace Member role
- D. Workspace Contributor role

---

## Case study — Coastline Logistics

Coastline Logistics runs depot operations across three countries, with the depot management system on an on-premises server. Six hundred depot staff must see only their own depot's deliveries in one shared report, and the org chart changes every few weeks. The data team wants the delivery model certified so that other teams reuse it instead of building their own. Refresh must run overnight, and the service cannot reach the depot server directly.

The next 3 questions refer to it. Read the scenario once, then answer all 3; each item restates the constraint it tests and is scored individually.

### 92. The depot extract lives on an on-premises server that the service cannot reach. What is required?

Domain: Manage and secure Power BI

- A. Personal mode gateway
- B. Install an on-premises data gateway
- C. Virtual network data gateway
- D. Configure scheduled refresh on the semantic model

### 93. Six hundred depot users must be filtered by a mapping table rather than one role per person. What should be used?

Domain: Manage and secure Power BI

- A. A static RLS role per region with fixed members
- B. Define a row-level security role with a DAX filter
- C. Use a dynamic RLS rule based on USERPRINCIPALNAME
- D. Map the signed-in user with USERPRINCIPALNAME in the filter

### 94. One delivery model should become the standard that other teams can trust. What should be done?

Domain: Manage and secure Power BI

- A. Grant item-level access to the specific report
- B. Grant Build permission on the semantic model
- C. Certify the semantic model
- D. Promote the content as endorsed

---

## Case study — Fairmont Assurance

Fairmont Assurance reports claims and reserves for a regulated insurance book. Reserve balances are captured at end of day, and the current report sums them across months, producing a peak that means nothing. The operations team must publish the claim-processing time below which 95 percent of claims are settled, not the average. The claims report is also subject to an accessibility review, because staff who use screen readers must be able to read it.

The next 3 questions refer to it. Read the scenario once, then answer all 3; each item restates the constraint it tests and is scored individually.

### 95. End-of-day reserve balances are being summed across months and producing a meaningless peak. What should the measure do?

Domain: Model the data

- A. Use AVERAGEX over a rolling date window
- B. Use TOTALYTD or DATESYTD for year-to-date
- C. Use LASTNONBLANK or LASTDATE for a semi-additive balance
- D. Use LASTNONBLANK when the balance is only recorded on some dates

### 96. The operations team must state the claim-processing time below which 95 percent of claims are settled. What should be used?

Domain: Model the data

- A. Use a quick measure for the standard pattern
- B. Use a statistical function such as STDEV.P or MEDIAN to describe the spread
- C. Create a calculation group for the time-intelligence variants
- D. Use PERCENTILE.INC for a distribution boundary

### 97. The claims report must be usable by screen-reader users, and its visuals carry no descriptions. What must be added?

Domain: Visualize and analyze the data

- A. Set a logical tab order for the interactive elements
- B. Build the mobile layout in the mobile view
- C. Enable personalization for the visuals the reader may change
- D. Provide alt text for each meaningful visual

---

## Case study — Northgate Bank

Northgate Bank reports trading and balance data from a core system that cannot accept analyst queries. One query combines client balances with payroll data, and the team is worried the engine is folding values between the two sources. The branch identifier arrives as a region prefix and a branch number in separate fields, but the report needs one combined code. The trade table repeats counterparty name, sector, and rating on every row, and filters on 40 million rows have become unusable.

The next 3 questions refer to it. Read the scenario once, then answer all 3; each item restates the constraint it tests and is scored individually.

### 98. The query combines client balances with payroll data, and the engine is folding values between the two sources. Which setting stops that?

Domain: Prepare the data

- A. Change the data source settings rather than rebuilding the query
- B. Set privacy levels to isolate the sources
- C. Create a parameter for the server, path, or filter
- D. Update the data source credentials in the semantic model settings

### 99. The branch identifier is split across region and number, and the report needs one combined code. What should be added?

Domain: Prepare the data

- A. Add a conditional column for rule-based bucketing
- B. Extract the needed part of the text with a delimiter or position
- C. Group by the key and aggregate the measures
- D. Add a custom column with an M expression

### 100. The trade table repeats counterparty name, sector, and rating on every row, and filters lag. What should be built?

Domain: Model the data

- A. Build a star schema with a fact table and conformed dimensions
- B. Flatten the lookup attributes into a single dimension
- C. Set the table and column properties, including hidden keys and format strings
- D. Normalize the dimension into a snowflake

---

## Answer key and explanations

### Question 1 — D

Answer: DirectQuery. DirectQuery reads the source at report time, which is what intraday values require. DirectQuery sends queries to the source at report time, so the report never shows stale data but the source bears the query load and some DAX is restricted. Local study-map skill 1.1 (Connecting to Data Sources and Shared Semantic Models), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Import copies the data into the semantic model at refresh, which gives the fastest queries and the most DAX flexibility but stores the data twice and needs a refresh schedule. Why the correct answer wins: DirectQuery reads the source at report time, which is what intraday values require.
- **B:** Incorrect for this question. Reusing the certified model keeps one definition of the metric and inherits its refresh and row-level security. Why the correct answer wins: DirectQuery reads the source at report time, which is what intraday values require.
- **C:** Incorrect for this question. DirectLake reads Delta tables directly, which gives Import-like speed without a copy, but it requires Fabric capacity and supported Delta tables. Why the correct answer wins: DirectQuery reads the source at report time, which is what intraday values require.
- **D:** Correct. DirectQuery sends queries to the source at report time, so the report never shows stale data but the source bears the query load and some DAX is restricted. In this case: DirectQuery reads the source at report time, which is what intraday values require.

### Question 2 — D

Answer: Connect to a shared semantic model instead of importing the source again. Connecting to the certified model inherits one definition, its refresh, and its security. Reusing the certified model keeps one definition of the metric and inherits its refresh and row-level security. Local study-map skill 1.1 (Connecting to Data Sources and Shared Semantic Models), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Import copies the data into the semantic model at refresh, which gives the fastest queries and the most DAX flexibility but stores the data twice and needs a refresh schedule. Why the correct answer wins: Connecting to the certified model inherits one definition, its refresh, and its security.
- **B:** Incorrect for this question. A live connection reuses a governed semantic model without copying it, so consistency and security are inherited and the report is not edited in Desktop. Why the correct answer wins: Connecting to the certified model inherits one definition, its refresh, and its security.
- **C:** Incorrect for this question. DirectQuery sends queries to the source at report time, so the report never shows stale data but the source bears the query load and some DAX is restricted. Why the correct answer wins: Connecting to the certified model inherits one definition, its refresh, and its security.
- **D:** Correct. Reusing the certified model keeps one definition of the metric and inherits its refresh and row-level security. In this case: Connecting to the certified model inherits one definition, its refresh, and its security.

### Question 3 — B, E

Answers: Import mode; DirectQuery. The regulatory extract is best imported, while open exceptions must query the source live. Import copies the data into the semantic model at refresh, which gives the fastest queries and the most DAX flexibility but stores the data twice and needs a refresh schedule. DirectQuery sends queries to the source at report time, so the report never shows stale data but the source bears the query load and some DAX is restricted. Local study-map skill 1.1 (Connecting to Data Sources and Shared Semantic Models), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Reusing the certified model keeps one definition of the metric and inherits its refresh and row-level security. Why the correct answer wins: The regulatory extract is best imported, while open exceptions must query the source live.
- **B:** Correct. Import copies the data into the semantic model at refresh, which gives the fastest queries and the most DAX flexibility but stores the data twice and needs a refresh schedule. In this case: The regulatory extract is best imported, while open exceptions must query the source live.
- **C:** Incorrect for this question. DirectLake reads Delta tables directly, which gives Import-like speed without a copy, but it requires Fabric capacity and supported Delta tables. Why the correct answer wins: The regulatory extract is best imported, while open exceptions must query the source live.
- **D:** Incorrect for this question. A live connection reuses a governed semantic model without copying it, so consistency and security are inherited and the report is not edited in Desktop. Why the correct answer wins: The regulatory extract is best imported, while open exceptions must query the source live.
- **E:** Correct. DirectQuery sends queries to the source at report time, so the report never shows stale data but the source bears the query load and some DAX is restricted. In this case: The regulatory extract is best imported, while open exceptions must query the source live.

### Question 4 — A

Answer: Change the data source settings rather than rebuilding the query. Data source settings repoint the connection and preserve the applied steps. Editing the connection keeps the applied steps and lets you repoint an existing query at a new location. Local study-map skill 1.1 (Connecting to Data Sources and Shared Semantic Models), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. Editing the connection keeps the applied steps and lets you repoint an existing query at a new location. In this case: Data source settings repoint the connection and preserve the applied steps.
- **B:** Incorrect for this question. Privacy levels stop the engine from folding data across sources it should not combine, which prevents accidental exposure of confidential values. Why the correct answer wins: Data source settings repoint the connection and preserve the applied steps.
- **C:** Incorrect for this question. Credentials live with the data source connection in the service, so a changed password must be updated there or refresh fails. Why the correct answer wins: Data source settings repoint the connection and preserve the applied steps.
- **D:** Incorrect for this question. A parameter lets one query point at different environments without editing the M code, which makes promotion between dev, test, and prod safe. Why the correct answer wins: Data source settings repoint the connection and preserve the applied steps.

### Question 5 — C

Answer: Import mode. Import serves reports from memory and keeps the query load off the core system. Import copies the data into the semantic model at refresh, which gives the fastest queries and the most DAX flexibility but stores the data twice and needs a refresh schedule. Local study-map skill 1.2 (Choosing Import, DirectQuery, or DirectLake), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. DirectQuery sends queries to the source at report time, so the report never shows stale data but the source bears the query load and some DAX is restricted. Why the correct answer wins: Import serves reports from memory and keeps the query load off the core system.
- **B:** Incorrect for this question. A Dual table can act as Import for some relationships and DirectQuery for others, which reduces the number of DirectQuery round trips in a composite model. Why the correct answer wins: Import serves reports from memory and keeps the query load off the core system.
- **C:** Correct. Import copies the data into the semantic model at refresh, which gives the fastest queries and the most DAX flexibility but stores the data twice and needs a refresh schedule. In this case: Import serves reports from memory and keeps the query load off the core system.
- **D:** Incorrect for this question. DirectLake reads Delta tables directly, which gives Import-like speed without a copy, but it requires Fabric capacity and supported Delta tables. Why the correct answer wins: Import serves reports from memory and keeps the query load off the core system.

### Question 6 — B

Answer: DirectLake over a lakehouse. DirectLake reads Delta tables directly when capacity and the table format allow it. DirectLake reads Delta tables directly, which gives Import-like speed without a copy, but it requires Fabric capacity and supported Delta tables. Local study-map skill 1.2 (Choosing Import, DirectQuery, or DirectLake), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Import copies the data into the semantic model at refresh, which gives the fastest queries and the most DAX flexibility but stores the data twice and needs a refresh schedule. Why the correct answer wins: DirectLake reads Delta tables directly when capacity and the table format allow it.
- **B:** Correct. DirectLake reads Delta tables directly, which gives Import-like speed without a copy, but it requires Fabric capacity and supported Delta tables. In this case: DirectLake reads Delta tables directly when capacity and the table format allow it.
- **C:** Incorrect for this question. A Dual table can act as Import for some relationships and DirectQuery for others, which reduces the number of DirectQuery round trips in a composite model. Why the correct answer wins: DirectLake reads Delta tables directly when capacity and the table format allow it.
- **D:** Incorrect for this question. DirectQuery sends queries to the source at report time, so the report never shows stale data but the source bears the query load and some DAX is restricted. Why the correct answer wins: DirectLake reads Delta tables directly when capacity and the table format allow it.

### Question 7 — B

Answer: Dual mode table. A Dual table can answer some queries from memory instead of the source. A Dual table can act as Import for some relationships and DirectQuery for others, which reduces the number of DirectQuery round trips in a composite model. Local study-map skill 1.2 (Choosing Import, DirectQuery, or DirectLake), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Import copies the data into the semantic model at refresh, which gives the fastest queries and the most DAX flexibility but stores the data twice and needs a refresh schedule. Why the correct answer wins: A Dual table can answer some queries from memory instead of the source.
- **B:** Correct. A Dual table can act as Import for some relationships and DirectQuery for others, which reduces the number of DirectQuery round trips in a composite model. In this case: A Dual table can answer some queries from memory instead of the source.
- **C:** Incorrect for this question. DirectQuery sends queries to the source at report time, so the report never shows stale data but the source bears the query load and some DAX is restricted. Why the correct answer wins: A Dual table can answer some queries from memory instead of the source.
- **D:** Incorrect for this question. DirectLake reads Delta tables directly, which gives Import-like speed without a copy, but it requires Fabric capacity and supported Delta tables. Why the correct answer wins: A Dual table can answer some queries from memory instead of the source.

### Question 8 — C

Answer: Create a parameter for the server, path, or filter. A parameter swaps the environment without editing the M code. A parameter lets one query point at different environments without editing the M code, which makes promotion between dev, test, and prod safe. Local study-map skill 1.3 (Data Source Settings, Credentials, Privacy Levels, and Parameters), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Privacy levels stop the engine from folding data across sources it should not combine, which prevents accidental exposure of confidential values. Why the correct answer wins: A parameter swaps the environment without editing the M code.
- **B:** Incorrect for this question. Credentials live with the data source connection in the service, so a changed password must be updated there or refresh fails. Why the correct answer wins: A parameter swaps the environment without editing the M code.
- **C:** Correct. A parameter lets one query point at different environments without editing the M code, which makes promotion between dev, test, and prod safe. In this case: A parameter swaps the environment without editing the M code.
- **D:** Incorrect for this question. Editing the connection keeps the applied steps and lets you repoint an existing query at a new location. Why the correct answer wins: A parameter swaps the environment without editing the M code.

### Question 9 — C

Answer: Update the data source credentials in the semantic model settings. The stored credential in the data source settings is what refresh authenticates with. Credentials live with the data source connection in the service, so a changed password must be updated there or refresh fails. Local study-map skill 1.3 (Data Source Settings, Credentials, Privacy Levels, and Parameters), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Editing the connection keeps the applied steps and lets you repoint an existing query at a new location. Why the correct answer wins: The stored credential in the data source settings is what refresh authenticates with.
- **B:** Incorrect for this question. A parameter lets one query point at different environments without editing the M code, which makes promotion between dev, test, and prod safe. Why the correct answer wins: The stored credential in the data source settings is what refresh authenticates with.
- **C:** Correct. Credentials live with the data source connection in the service, so a changed password must be updated there or refresh fails. In this case: The stored credential in the data source settings is what refresh authenticates with.
- **D:** Incorrect for this question. Privacy levels stop the engine from folding data across sources it should not combine, which prevents accidental exposure of confidential values. Why the correct answer wins: The stored credential in the data source settings is what refresh authenticates with.

### Question 10 — A

Answer: Profile the column with column quality, distribution, and profile views. Profiling reports valid, distinct, and empty values per column before shaping. Profiling shows how many values are valid, distinct, and empty before any transformation is chosen. Local study-map skill 1.4 (Evaluating Data with Profiling and Column Statistics), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. Profiling shows how many values are valid, distinct, and empty before any transformation is chosen. In this case: Profiling reports valid, distinct, and empty values per column before shaping.
- **B:** Incorrect for this question. Value distribution reveals skew, unexpected dominant values, and long tails that a simple row count hides. Why the correct answer wins: Profiling reports valid, distinct, and empty values per column before shaping.
- **C:** Incorrect for this question. A wrong data type blocks time intelligence, breaks relationships, and inflates the model through text storage of numbers and dates. Why the correct answer wins: Profiling reports valid, distinct, and empty values per column before shaping.
- **D:** Incorrect for this question. Replacing nulls makes aggregations reproducible; the placeholder must be documented so it is not mistaken for a measurement. Why the correct answer wins: Profiling reports valid, distinct, and empty values per column before shaping.

### Question 11 — A

Answer: Review column statistics and value distribution. Value distribution shows whether the measure is concentrated in a few members. Value distribution reveals skew, unexpected dominant values, and long tails that a simple row count hides. Local study-map skill 1.4 (Evaluating Data with Profiling and Column Statistics), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. Value distribution reveals skew, unexpected dominant values, and long tails that a simple row count hides. In this case: Value distribution shows whether the measure is concentrated in a few members.
- **B:** Incorrect for this question. Replacing nulls makes aggregations reproducible; the placeholder must be documented so it is not mistaken for a measurement. Why the correct answer wins: Value distribution shows whether the measure is concentrated in a few members.
- **C:** Incorrect for this question. A wrong data type blocks time intelligence, breaks relationships, and inflates the model through text storage of numbers and dates. Why the correct answer wins: Value distribution shows whether the measure is concentrated in a few members.
- **D:** Incorrect for this question. Profiling shows how many values are valid, distinct, and empty before any transformation is chosen. Why the correct answer wins: Value distribution shows whether the measure is concentrated in a few members.

### Question 12 — D

Answer: Correct the column data type before building the model. A text date cannot drive time intelligence, so the type must be fixed before modelling. A wrong data type blocks time intelligence, breaks relationships, and inflates the model through text storage of numbers and dates. Local study-map skill 1.4 (Evaluating Data with Profiling and Column Statistics), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Value distribution reveals skew, unexpected dominant values, and long tails that a simple row count hides. Why the correct answer wins: A text date cannot drive time intelligence, so the type must be fixed before modelling.
- **B:** Incorrect for this question. Profiling shows how many values are valid, distinct, and empty before any transformation is chosen. Why the correct answer wins: A text date cannot drive time intelligence, so the type must be fixed before modelling.
- **C:** Incorrect for this question. Replacing nulls makes aggregations reproducible; the placeholder must be documented so it is not mistaken for a measurement. Why the correct answer wins: A text date cannot drive time intelligence, so the type must be fixed before modelling.
- **D:** Correct. A wrong data type blocks time intelligence, breaks relationships, and inflates the model through text storage of numbers and dates. In this case: A text date cannot drive time intelligence, so the type must be fixed before modelling.

### Question 13 — D

Answer: Profile the source → fix types and nulls → shape the table → load only the needed columns. Profiling comes before shaping, and loading only the needed columns keeps the model small. Profiling first prevents wasted shaping, and typing before loading keeps the model small and time intelligence working. Local study-map skill 1.4 (Evaluating Data with Profiling and Column Statistics), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Deleting profiling removes the evidence of quality problems and loading every column inflates the model. Why the correct answer wins: Profiling comes before shaping, and loading only the needed columns keeps the model small.
- **B:** Incorrect for this question. Discovering type errors after load means the model was built on wrong data and the work restarts. Why the correct answer wins: Profiling comes before shaping, and loading only the needed columns keeps the model small.
- **C:** Incorrect for this question. Patching visuals hides the data problem instead of fixing it at the source. Why the correct answer wins: Profiling comes before shaping, and loading only the needed columns keeps the model small.
- **D:** Correct. Profiling first prevents wasted shaping, and typing before loading keeps the model small and time intelligence working. In this case: Profiling comes before shaping, and loading only the needed columns keeps the model small.

### Question 14 — B

Answer: Replace nulls with a defined placeholder or a filled-down value. Replacing blank with a defined value keeps the total stable and documents the assumption. Replacing nulls makes aggregations reproducible; the placeholder must be documented so it is not mistaken for a measurement. Local study-map skill 1.5 (Resolving Inconsistencies, Nulls, and Import Errors), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Removing errors keeps the model loadable, but the discarded rows must be reported so the business knows what is missing. Why the correct answer wins: Replacing blank with a defined value keeps the total stable and documents the assumption.
- **B:** Correct. Replacing nulls makes aggregations reproducible; the placeholder must be documented so it is not mistaken for a measurement. In this case: Replacing blank with a defined value keeps the total stable and documents the assumption.
- **C:** Incorrect for this question. Leading spaces, inconsistent casing, and stray characters create duplicate dimension members and break joins. Why the correct answer wins: Replacing blank with a defined value keeps the total stable and documents the assumption.
- **D:** Incorrect for this question. De-duplicating on the business key prevents double counting when a source system repeats records across loads. Why the correct answer wins: Replacing blank with a defined value keeps the total stable and documents the assumption.

### Question 15 — A, C

Answers: Remove duplicate rows using the natural business key; Filter out the error rows and report them separately. De-duplicating on the trade key removes the repeats, and filtering the failing rows with a separate report keeps the load moving. De-duplicating on the business key prevents double counting when a source system repeats records across loads. Removing errors keeps the model loadable, but the discarded rows must be reported so the business knows what is missing. Local study-map skill 1.5 (Resolving Inconsistencies, Nulls, and Import Errors), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. Removing errors keeps the model loadable, but the discarded rows must be reported so the business knows what is missing. In this case: De-duplicating on the trade key removes the repeats, and filtering the failing rows with a separate report keeps the load moving.
- **B:** Incorrect for this question. Leading spaces, inconsistent casing, and stray characters create duplicate dimension members and break joins. Why the correct answer wins: De-duplicating on the trade key removes the repeats, and filtering the failing rows with a separate report keeps the load moving.
- **C:** Correct. De-duplicating on the business key prevents double counting when a source system repeats records across loads. In this case: De-duplicating on the trade key removes the repeats, and filtering the failing rows with a separate report keeps the load moving.
- **D:** Incorrect for this question. Replacing nulls makes aggregations reproducible; the placeholder must be documented so it is not mistaken for a measurement. Why the correct answer wins: De-duplicating on the trade key removes the repeats, and filtering the failing rows with a separate report keeps the load moving.
- **E:** Incorrect for this question. A locale-aware conversion stops day and month being swapped and stops decimal commas being interpreted as text. Why the correct answer wins: De-duplicating on the trade key removes the repeats, and filtering the failing rows with a separate report keeps the load moving.

### Question 16 — C

Answer: Trim, clean, and standardize the text values. Standardizing text removes the invisible differences that create duplicate members. Leading spaces, inconsistent casing, and stray characters create duplicate dimension members and break joins. Local study-map skill 1.5 (Resolving Inconsistencies, Nulls, and Import Errors), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Replacing nulls makes aggregations reproducible; the placeholder must be documented so it is not mistaken for a measurement. Why the correct answer wins: Standardizing text removes the invisible differences that create duplicate members.
- **B:** Incorrect for this question. Removing errors keeps the model loadable, but the discarded rows must be reported so the business knows what is missing. Why the correct answer wins: Standardizing text removes the invisible differences that create duplicate members.
- **C:** Correct. Leading spaces, inconsistent casing, and stray characters create duplicate dimension members and break joins. In this case: Standardizing text removes the invisible differences that create duplicate members.
- **D:** Incorrect for this question. De-duplicating on the business key prevents double counting when a source system repeats records across loads. Why the correct answer wins: Standardizing text removes the invisible differences that create duplicate members.

### Question 17 — C

Answer: Identify the bad values → standardize text → convert types → document what was replaced. Standardizing before conversion fixes the cause, and documenting the replacement keeps the change auditable. Cleaning in that order fixes the cause, and documenting the replacement keeps the change auditable. Local study-map skill 1.5 (Resolving Inconsistencies, Nulls, and Import Errors), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Silently dropping rows changes the totals and the business never learns what is missing. Why the correct answer wins: Standardizing before conversion fixes the cause, and documenting the replacement keeps the change auditable.
- **B:** Incorrect for this question. Converting before trimming fails on values that only differ by whitespace and leaves duplicates behind. Why the correct answer wins: Standardizing before conversion fixes the cause, and documenting the replacement keeps the change auditable.
- **C:** Correct. Cleaning in that order fixes the cause, and documenting the replacement keeps the change auditable. In this case: Standardizing before conversion fixes the cause, and documenting the replacement keeps the change auditable.
- **D:** Incorrect for this question. Replacing everything with a default destroys real values and hides the pattern behind the error. Why the correct answer wins: Standardizing before conversion fixes the cause, and documenting the replacement keeps the change auditable.

### Question 18 — A

Answer: Add a conditional column for rule-based bucketing. A conditional column applies the published thresholds explicitly and is easy to review. A conditional column applies explicit if-then rules, which is easier to review than a hand-written expression. Local study-map skill 1.6 (Column Data Types, Custom Columns, and Grouping), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. A conditional column applies explicit if-then rules, which is easier to review than a hand-written expression. In this case: A conditional column applies the published thresholds explicitly and is easy to review.
- **B:** Incorrect for this question. Splitting separates values that are packed into one field so each can be typed, filtered, and related correctly. Why the correct answer wins: A conditional column applies the published thresholds explicitly and is easy to review.
- **C:** Incorrect for this question. Grouping reduces a transactional table to one row per key, which is the usual shape for a summary or a dimension. Why the correct answer wins: A conditional column applies the published thresholds explicitly and is easy to review.
- **D:** Incorrect for this question. A custom column derives a new value row by row, which suits logic that built-in transformations cannot express. Why the correct answer wins: A conditional column applies the published thresholds explicitly and is easy to review.

### Question 19 — B, D

Answers: Group by the key and aggregate the measures; Add an aggregate step with the correct summarization. Grouping produces one row per account and day, and an aggregate step nets the amount. Grouping reduces a transactional table to one row per key, which is the usual shape for a summary or a dimension. The summarization choice decides whether the result is a sum, count, or distinct count, and a wrong one silently changes the number. Local study-map skill 1.6 (Column Data Types, Custom Columns, and Grouping), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Extraction keeps the useful part of an identifier without importing the whole string into the model. Why the correct answer wins: Grouping produces one row per account and day, and an aggregate step nets the amount.
- **B:** Correct. Grouping reduces a transactional table to one row per key, which is the usual shape for a summary or a dimension. In this case: Grouping produces one row per account and day, and an aggregate step nets the amount.
- **C:** Incorrect for this question. A custom column derives a new value row by row, which suits logic that built-in transformations cannot express. Why the correct answer wins: Grouping produces one row per account and day, and an aggregate step nets the amount.
- **D:** Correct. The summarization choice decides whether the result is a sum, count, or distinct count, and a wrong one silently changes the number. In this case: Grouping produces one row per account and day, and an aggregate step nets the amount.
- **E:** Incorrect for this question. A conditional column applies explicit if-then rules, which is easier to review than a hand-written expression. Why the correct answer wins: Grouping produces one row per account and day, and an aggregate step nets the amount.

### Question 20 — B

Answer: Extract the needed part of the text with a delimiter or position. Extracting by position keeps the prefix without importing the full identifier twice. Extraction keeps the useful part of an identifier without importing the whole string into the model. Local study-map skill 1.6 (Column Data Types, Custom Columns, and Grouping), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. The summarization choice decides whether the result is a sum, count, or distinct count, and a wrong one silently changes the number. Why the correct answer wins: Extracting by position keeps the prefix without importing the full identifier twice.
- **B:** Correct. Extraction keeps the useful part of an identifier without importing the whole string into the model. In this case: Extracting by position keeps the prefix without importing the full identifier twice.
- **C:** Incorrect for this question. A custom column derives a new value row by row, which suits logic that built-in transformations cannot express. Why the correct answer wins: Extracting by position keeps the prefix without importing the full identifier twice.
- **D:** Incorrect for this question. Splitting separates values that are packed into one field so each can be typed, filtered, and related correctly. Why the correct answer wins: Extracting by position keeps the prefix without importing the full identifier twice.

### Question 21 — B

Answer: Unpivot the month columns into rows. Unpivoting turns the ratio columns into rows. Unpivoting turns wide period columns into a single date column and a single value column, which is what a tabular model needs. Local study-map skill 1.7 (Pivot, Unpivot, Transpose, and Semi-Structured Data), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Transposing swaps rows and columns, which repairs a report-shaped sheet whose headings run down the side. Why the correct answer wins: Unpivoting turns the ratio columns into rows.
- **B:** Correct. Unpivoting turns wide period columns into a single date column and a single value column, which is what a tabular model needs. In this case: Unpivoting turns the ratio columns into rows.
- **C:** Incorrect for this question. Expanding a JSON record exposes its fields as columns that can be typed, filtered, and related. Why the correct answer wins: Unpivoting turns the ratio columns into rows.
- **D:** Incorrect for this question. Pivoting turns row-based attribute values into columns, which suits a cross-tab source that must become a flat table. Why the correct answer wins: Unpivoting turns the ratio columns into rows.

### Question 22 — D

Answer: Pivot the attribute values into columns. Pivoting turns attribute rows into columns. Pivoting turns row-based attribute values into columns, which suits a cross-tab source that must become a flat table. Local study-map skill 1.7 (Pivot, Unpivot, Transpose, and Semi-Structured Data), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Transposing swaps rows and columns, which repairs a report-shaped sheet whose headings run down the side. Why the correct answer wins: Pivoting turns attribute rows into columns.
- **B:** Incorrect for this question. A nested list must become rows before it can be modelled, because a model cannot aggregate a cell that holds a list. Why the correct answer wins: Pivoting turns attribute rows into columns.
- **C:** Incorrect for this question. Unpivoting turns wide period columns into a single date column and a single value column, which is what a tabular model needs. Why the correct answer wins: Pivoting turns attribute rows into columns.
- **D:** Correct. Pivoting turns row-based attribute values into columns, which suits a cross-tab source that must become a flat table. In this case: Pivoting turns attribute rows into columns.

### Question 23 — D

Answer: Convert the list value to a table and expand it. Converting the list to a table keeps every quote as a row rather than only the first. Converting a list to a table preserves every element as a row instead of keeping only the first value. Local study-map skill 1.7 (Pivot, Unpivot, Transpose, and Semi-Structured Data), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Transposing swaps rows and columns, which repairs a report-shaped sheet whose headings run down the side. Why the correct answer wins: Converting the list to a table keeps every quote as a row rather than only the first.
- **B:** Incorrect for this question. Expanding a JSON record exposes its fields as columns that can be typed, filtered, and related. Why the correct answer wins: Converting the list to a table keeps every quote as a row rather than only the first.
- **C:** Incorrect for this question. A nested list must become rows before it can be modelled, because a model cannot aggregate a cell that holds a list. Why the correct answer wins: Converting the list to a table keeps every quote as a row rather than only the first.
- **D:** Correct. Converting a list to a table preserves every element as a row instead of keeping only the first value. In this case: Converting the list to a table keeps every quote as a row rather than only the first.

### Question 24 — A

Answer: Append the queries into one table. Appending stacks rows of the same shape. Appending stacks rows with the same shape, which combines monthly extracts or regions into one table. Local study-map skill 1.8 (Merge and Append, Reference and Duplicate, Relationship Keys), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. Appending stacks rows with the same shape, which combines monthly extracts or regions into one table. In this case: Appending stacks rows of the same shape.
- **B:** Incorrect for this question. A fuzzy merge matches near-spellings when keys differ, but the matches must be reviewed because a threshold can join the wrong records. Why the correct answer wins: Appending stacks rows of the same shape.
- **C:** Incorrect for this question. A merge joins columns from two queries side by side using a key, which is how a lookup is added to a fact query. Why the correct answer wins: Appending stacks rows of the same shape.
- **D:** Incorrect for this question. A left outer join keeps unmatched fact rows with null lookups, which exposes missing dimension members instead of silently dropping sales. Why the correct answer wins: Appending stacks rows of the same shape.

### Question 25 — B, E

Answers: Merge the two queries on a matching key; Use a left outer join to keep every fact row. A merge adds the rating column, and a left outer join keeps unmatched trades. A merge joins columns from two queries side by side using a key, which is how a lookup is added to a fact query. A left outer join keeps unmatched fact rows with null lookups, which exposes missing dimension members instead of silently dropping sales. Local study-map skill 1.8 (Merge and Append, Reference and Duplicate, Relationship Keys), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Appending stacks rows with the same shape, which combines monthly extracts or regions into one table. Why the correct answer wins: A merge adds the rating column, and a left outer join keeps unmatched trades.
- **B:** Correct. A merge joins columns from two queries side by side using a key, which is how a lookup is added to a fact query. In this case: A merge adds the rating column, and a left outer join keeps unmatched trades.
- **C:** Incorrect for this question. Staging separates extraction from transformation, which makes each layer easier to test and reuse. Why the correct answer wins: A merge adds the rating column, and a left outer join keeps unmatched trades.
- **D:** Incorrect for this question. A fuzzy merge matches near-spellings when keys differ, but the matches must be reviewed because a threshold can join the wrong records. Why the correct answer wins: A merge adds the rating column, and a left outer join keeps unmatched trades.
- **E:** Correct. A left outer join keeps unmatched fact rows with null lookups, which exposes missing dimension members instead of silently dropping sales. In this case: A merge adds the rating column, and a left outer join keeps unmatched trades.

### Question 26 — C, E

Answers: Keep the steps foldable so the source does the work; Use a native query to select only the needed rows. Keeping steps foldable pushes the work to the source, and a native query limits what is transferred. Query folding pushes transformations back to the source, which is faster and lets incremental refresh work. A native query reduces what is transferred, but it can break folding for later steps and must be maintained as the schema changes. Local study-map skill 1.8 (Merge and Append, Reference and Duplicate, Relationship Keys), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. A duplicate copies the full step chain, so a change in one copy does not affect the other but the work is repeated. Why the correct answer wins: Keeping steps foldable pushes the work to the source, and a native query limits what is transferred.
- **B:** Incorrect for this question. Disabling load keeps a working query out of the model, which prevents unused tables from inflating the dataset. Why the correct answer wins: Keeping steps foldable pushes the work to the source, and a native query limits what is transferred.
- **C:** Correct. A native query reduces what is transferred, but it can break folding for later steps and must be maintained as the schema changes. In this case: Keeping steps foldable pushes the work to the source, and a native query limits what is transferred.
- **D:** Incorrect for this question. A reference reuses the earlier steps of a query while allowing a different downstream shape, which avoids loading the base table twice. Why the correct answer wins: Keeping steps foldable pushes the work to the source, and a native query limits what is transferred.
- **E:** Correct. Query folding pushes transformations back to the source, which is faster and lets incremental refresh work. In this case: Keeping steps foldable pushes the work to the source, and a native query limits what is transferred.

### Question 27 — B, D

Answers: Set the table and column properties, including hidden keys and format strings; Hide technical columns from the report view. Hiding identifiers removes them from the field list, and format strings fix how amounts display. Properties control how a field behaves in the report: hidden keys disappear from the field list and format strings fix how values display. Hiding keys and helper columns stops report authors using an ID as a label and keeps the field list readable. Local study-map skill 2.1 (Designing a Star Schema and Table Properties), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. A star schema puts measurable events in one fact table surrounded by descriptive dimensions, which is the shape the engine and DAX are optimized for. Why the correct answer wins: Hiding identifiers removes them from the field list, and format strings fix how amounts display.
- **B:** Correct. Hiding keys and helper columns stops report authors using an ID as a label and keeps the field list readable. In this case: Hiding identifiers removes them from the field list, and format strings fix how amounts display.
- **C:** Incorrect for this question. Snowflaking splits a dimension into related tables, which reduces duplication but adds hops and slows filters. Why the correct answer wins: Hiding identifiers removes them from the field list, and format strings fix how amounts display.
- **D:** Correct. Properties control how a field behaves in the report: hidden keys disappear from the field list and format strings fix how values display. In this case: Hiding identifiers removes them from the field list, and format strings fix how amounts display.
- **E:** Incorrect for this question. Flattening keeps one hop between fact and filter, which is simpler for report authors and faster for the engine. Why the correct answer wins: Hiding identifiers removes them from the field list, and format strings fix how amounts display.

### Question 28 — D

Answer: Define the grain → separate facts from dimensions → add surrogate keys → relate dimension to fact. Agreeing the grain first decides what a row means, and separating descriptive attributes makes the star work. The grain decides what a row means, and separating descriptive attributes is what makes a star schema work. Local study-map skill 2.1 (Designing a Star Schema and Table Properties), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Relationships built before the grain is agreed will be wrong and must be rebuilt. Why the correct answer wins: Agreeing the grain first decides what a row means, and separating descriptive attributes makes the star work.
- **B:** Incorrect for this question. A single wide table cannot be filtered cleanly by dimension and pushes duplication into every row. Why the correct answer wins: Agreeing the grain first decides what a row means, and separating descriptive attributes makes the star work.
- **C:** Incorrect for this question. A dimension per column produces a hub of one-column tables and makes the model unmaintainable. Why the correct answer wins: Agreeing the grain first decides what a row means, and separating descriptive attributes makes the star work.
- **D:** Correct. The grain decides what a row means, and separating descriptive attributes is what makes a star schema work. In this case: Agreeing the grain first decides what a row means, and separating descriptive attributes makes the star work.

### Question 29 — C

Answer: Flatten the lookup attributes into a single dimension. Flattening the sector attributes into the counterparty dimension removes the hop. Flattening keeps one hop between fact and filter, which is simpler for report authors and faster for the engine. Local study-map skill 2.1 (Designing a Star Schema and Table Properties), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Properties control how a field behaves in the report: hidden keys disappear from the field list and format strings fix how values display. Why the correct answer wins: Flattening the sector attributes into the counterparty dimension removes the hop.
- **B:** Incorrect for this question. Snowflaking splits a dimension into related tables, which reduces duplication but adds hops and slows filters. Why the correct answer wins: Flattening the sector attributes into the counterparty dimension removes the hop.
- **C:** Correct. Flattening keeps one hop between fact and filter, which is simpler for report authors and faster for the engine. In this case: Flattening the sector attributes into the counterparty dimension removes the hop.
- **D:** Incorrect for this question. A star schema puts measurable events in one fact table surrounded by descriptive dimensions, which is the shape the engine and DAX are optimized for. Why the correct answer wins: Flattening the sector attributes into the counterparty dimension removes the hop.

### Question 30 — D

Answer: Inactive relationship activated with USERELATIONSHIP. Only one relationship can be active, so the second waits until a measure activates it. An inactive relationship exists but does not filter until a measure activates it, which is how one fact supports several dates. Local study-map skill 2.2 (Relationship Cardinality and Cross-Filter Direction), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Single direction keeps filter flow predictable and avoids ambiguous paths that the engine has to resolve. Why the correct answer wins: Only one relationship can be active, so the second waits until a measure activates it.
- **B:** Incorrect for this question. A one-to-many relationship from the unique dimension key to the repeated fact key is the standard star relationship. Why the correct answer wins: Only one relationship can be active, so the second waits until a measure activates it.
- **C:** Incorrect for this question. One-to-one suits two tables that describe the same entity, and it is usually a sign the tables could be merged. Why the correct answer wins: Only one relationship can be active, so the second waits until a measure activates it.
- **D:** Correct. An inactive relationship exists but does not filter until a measure activates it, which is how one fact supports several dates. In this case: Only one relationship can be active, so the second waits until a measure activates it.

### Question 31 — C

Answer: Many-to-many relationship with a bridging table. The ownership bridge resolves the many-to-many and keeps the filter path explicit. Many-to-many is needed when neither side is unique, and a bridge table keeps the filter path explicit rather than ambiguous. Local study-map skill 2.2 (Relationship Cardinality and Cross-Filter Direction), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Single direction keeps filter flow predictable and avoids ambiguous paths that the engine has to resolve. Why the correct answer wins: The ownership bridge resolves the many-to-many and keeps the filter path explicit.
- **B:** Incorrect for this question. One-to-one suits two tables that describe the same entity, and it is usually a sign the tables could be merged. Why the correct answer wins: The ownership bridge resolves the many-to-many and keeps the filter path explicit.
- **C:** Correct. Many-to-many is needed when neither side is unique, and a bridge table keeps the filter path explicit rather than ambiguous. In this case: The ownership bridge resolves the many-to-many and keeps the filter path explicit.
- **D:** Incorrect for this question. A one-to-many relationship from the unique dimension key to the repeated fact key is the standard star relationship. Why the correct answer wins: The ownership bridge resolves the many-to-many and keeps the filter path explicit.

### Question 32 — B, D

Answers: Single-direction filter from dimension to fact; One-to-many relationship from the dimension to the fact. Dimension-to-fact one-to-many is the standard shape, and single-direction filtering keeps it predictable. Single direction keeps filter flow predictable and avoids ambiguous paths that the engine has to resolve. A one-to-many relationship from the unique dimension key to the repeated fact key is the standard star relationship. Local study-map skill 2.2 (Relationship Cardinality and Cross-Filter Direction), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Many-to-many is needed when neither side is unique, and a bridge table keeps the filter path explicit rather than ambiguous. Why the correct answer wins: Dimension-to-fact one-to-many is the standard shape, and single-direction filtering keeps it predictable.
- **B:** Correct. Single direction keeps filter flow predictable and avoids ambiguous paths that the engine has to resolve. In this case: Dimension-to-fact one-to-many is the standard shape, and single-direction filtering keeps it predictable.
- **C:** Incorrect for this question. Bi-directional filtering lets a fact filter a dimension, which is occasionally required but can create ambiguity and slow queries. Why the correct answer wins: Dimension-to-fact one-to-many is the standard shape, and single-direction filtering keeps it predictable.
- **D:** Correct. A one-to-many relationship from the unique dimension key to the repeated fact key is the standard star relationship. In this case: Dimension-to-fact one-to-many is the standard shape, and single-direction filtering keeps it predictable.
- **E:** Incorrect for this question. Cross-filter direction decides which table filters which, and changing it is the usual fix for a filter that does not reach the visual. Why the correct answer wins: Dimension-to-fact one-to-many is the standard shape, and single-direction filtering keeps it predictable.

### Question 33 — A

Answer: Set the cross-filter direction on the relationship. Cross-filter direction decides whether the fact can filter the dimension. Cross-filter direction decides which table filters which, and changing it is the usual fix for a filter that does not reach the visual. Local study-map skill 2.2 (Relationship Cardinality and Cross-Filter Direction), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. Cross-filter direction decides which table filters which, and changing it is the usual fix for a filter that does not reach the visual. In this case: Cross-filter direction decides whether the fact can filter the dimension.
- **B:** Incorrect for this question. Single direction keeps filter flow predictable and avoids ambiguous paths that the engine has to resolve. Why the correct answer wins: Cross-filter direction decides whether the fact can filter the dimension.
- **C:** Incorrect for this question. An inactive relationship exists but does not filter until a measure activates it, which is how one fact supports several dates. Why the correct answer wins: Cross-filter direction decides whether the fact can filter the dimension.
- **D:** Incorrect for this question. Bi-directional filtering lets a fact filter a dimension, which is occasionally required but can create ambiguity and slow queries. Why the correct answer wins: Cross-filter direction decides whether the fact can filter the dimension.

### Question 34 — D

Answer: Create a dedicated date table marked as the date table. A contiguous date table supplies every date so accumulation does not skip gaps. A marked date table with contiguous dates is what time intelligence functions require and what slicers should use. Local study-map skill 2.3 (Date Tables and Role-Playing Dimensions), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Role-playing reuses a single date dimension for order, ship, and due dates, which avoids three near-identical date tables. Why the correct answer wins: A contiguous date table supplies every date so accumulation does not skip gaps.
- **B:** Incorrect for this question. Marking the date table tells the engine which table supplies the date hierarchy, which removes ambiguity when several date columns exist. Why the correct answer wins: A contiguous date table supplies every date so accumulation does not skip gaps.
- **C:** Incorrect for this question. Fiscal columns let time intelligence follow the organization's year instead of the calendar year. Why the correct answer wins: A contiguous date table supplies every date so accumulation does not skip gaps.
- **D:** Correct. A marked date table with contiguous dates is what time intelligence functions require and what slicers should use. In this case: A contiguous date table supplies every date so accumulation does not skip gaps.

### Question 35 — A

Answer: Build the fiscal periods as columns in the date table. Fiscal period columns let time intelligence follow the financial year. Fiscal columns let time intelligence follow the organization's year instead of the calendar year. Local study-map skill 2.3 (Date Tables and Role-Playing Dimensions), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. Fiscal columns let time intelligence follow the organization's year instead of the calendar year. In this case: Fiscal period columns let time intelligence follow the financial year.
- **B:** Incorrect for this question. Marking the date table tells the engine which table supplies the date hierarchy, which removes ambiguity when several date columns exist. Why the correct answer wins: Fiscal period columns let time intelligence follow the financial year.
- **C:** Incorrect for this question. Role-playing reuses a single date dimension for order, ship, and due dates, which avoids three near-identical date tables. Why the correct answer wins: Fiscal period columns let time intelligence follow the financial year.
- **D:** Incorrect for this question. A marked date table with contiguous dates is what time intelligence functions require and what slicers should use. Why the correct answer wins: Fiscal period columns let time intelligence follow the financial year.

### Question 36 — B

Answer: Mark the table as a date table. Marking the table as the date table removes the ambiguity. Marking the date table tells the engine which table supplies the date hierarchy, which removes ambiguity when several date columns exist. Local study-map skill 2.3 (Date Tables and Role-Playing Dimensions), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Role-playing reuses a single date dimension for order, ship, and due dates, which avoids three near-identical date tables. Why the correct answer wins: Marking the table as the date table removes the ambiguity.
- **B:** Correct. Marking the date table tells the engine which table supplies the date hierarchy, which removes ambiguity when several date columns exist. In this case: Marking the table as the date table removes the ambiguity.
- **C:** Incorrect for this question. Fiscal columns let time intelligence follow the organization's year instead of the calendar year. Why the correct answer wins: Marking the table as the date table removes the ambiguity.
- **D:** Incorrect for this question. A marked date table with contiguous dates is what time intelligence functions require and what slicers should use. Why the correct answer wins: Marking the table as the date table removes the ambiguity.

### Question 37 — A

Answer: Create a contiguous date table → mark it as the date table → relate it to the fact dates → build time intelligence on it. Marking and relating the date table is what makes the measures obey the date slicer. Time intelligence needs a marked, contiguous table, and relating it properly is what makes the measures respond to slicers. Local study-map skill 2.3 (Date Tables and Role-Playing Dimensions), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. Time intelligence needs a marked, contiguous table, and relating it properly is what makes the measures respond to slicers. In this case: Marking and relating the date table is what makes the measures obey the date slicer.
- **B:** Incorrect for this question. An unrelated date table filters nothing, so the slicer appears to work while the visuals ignore it. Why the correct answer wins: Marking and relating the date table is what makes the measures obey the date slicer.
- **C:** Incorrect for this question. A fact date column has gaps, so year-to-date silently skips missing days and the slicer shows no clean hierarchy. Why the correct answer wins: Marking and relating the date table is what makes the measures obey the date slicer.
- **D:** Incorrect for this question. Several date tables multiply relationships and make every time measure ambiguous. Why the correct answer wins: Marking and relating the date table is what makes the measures obey the date slicer.

### Question 38 — B

Answer: Create a measure for the aggregation. A measure is evaluated in the filter context the visual supplies, so it responds to slicers and adds nothing to the model. A measure is evaluated in the filter context of the visual, so it responds to slicers automatically and does not inflate the model. Local study-map skill 2.4 (Measures, Calculated Columns, and Filter Context), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. A calculated table materializes at refresh, which suits a small derived table such as a parameter or a bridge. Why the correct answer wins: A measure is evaluated in the filter context the visual supplies, so it responds to slicers and adds nothing to the model.
- **B:** Correct. A measure is evaluated in the filter context of the visual, so it responds to slicers automatically and does not inflate the model. In this case: A measure is evaluated in the filter context the visual supplies, so it responds to slicers and adds nothing to the model.
- **C:** Incorrect for this question. Filter context is what the visual and its slicers impose on a measure at evaluation time, and it explains most unexpected totals. Why the correct answer wins: A measure is evaluated in the filter context the visual supplies, so it responds to slicers and adds nothing to the model.
- **D:** Incorrect for this question. A calculated column is computed row by row at refresh and stored, which suits a value needed for slicing or a relationship. Why the correct answer wins: A measure is evaluated in the filter context the visual supplies, so it responds to slicers and adds nothing to the model.

### Question 39 — B

Answer: The row context inside an iterator. Row context exists in a calculated column, and RELATED is needed to reach the related table. Row context exists inside a calculated column or an iterator function and is the reason RELATED is needed to reach another table. Local study-map skill 2.4 (Measures, Calculated Columns, and Filter Context), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. A measure is evaluated in the filter context of the visual, so it responds to slicers automatically and does not inflate the model. Why the correct answer wins: Row context exists in a calculated column, and RELATED is needed to reach the related table.
- **B:** Correct. Row context exists inside a calculated column or an iterator function and is the reason RELATED is needed to reach another table. In this case: Row context exists in a calculated column, and RELATED is needed to reach the related table.
- **C:** Incorrect for this question. Filter context is what the visual and its slicers impose on a measure at evaluation time, and it explains most unexpected totals. Why the correct answer wins: Row context exists in a calculated column, and RELATED is needed to reach the related table.
- **D:** Incorrect for this question. A calculated table materializes at refresh, which suits a small derived table such as a parameter or a bridge. Why the correct answer wins: Row context exists in a calculated column, and RELATED is needed to reach the related table.

### Question 40 — C, E

Answers: Use DIVIDE instead of the division operator; Use an iterator such as SUMX over the row-level expression. DIVIDE avoids a division error, and SUMX evaluates the row-level arithmetic before aggregating. DIVIDE returns blank instead of an error when the denominator is zero, which keeps ratio visuals clean. An iterator evaluates the expression per row and then aggregates, which is required when the value to sum is not a stored column. Local study-map skill 2.4 (Measures, Calculated Columns, and Filter Context), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Iterators such as SUMX and AVERAGEX apply a calculation per row, which is the difference between an average of ratios and a ratio of totals. Why the correct answer wins: DIVIDE avoids a division error, and SUMX evaluates the row-level arithmetic before aggregating.
- **B:** Incorrect for this question. Distinct count answers how many unique customers or orders, which a plain count would overstate. Why the correct answer wins: DIVIDE avoids a division error, and SUMX evaluates the row-level arithmetic before aggregating.
- **C:** Correct. DIVIDE returns blank instead of an error when the denominator is zero, which keeps ratio visuals clean. In this case: DIVIDE avoids a division error, and SUMX evaluates the row-level arithmetic before aggregating.
- **D:** Incorrect for this question. A measure is evaluated in the filter context of the visual, so it responds to slicers automatically and does not inflate the model. Why the correct answer wins: DIVIDE avoids a division error, and SUMX evaluates the row-level arithmetic before aggregating.
- **E:** Correct. An iterator evaluates the expression per row and then aggregates, which is required when the value to sum is not a stored column. In this case: DIVIDE avoids a division error, and SUMX evaluates the row-level arithmetic before aggregating.

### Question 41 — A

Answer: Wrap the aggregation in CALCULATE to change the filter context. CALCULATE evaluates the expression under modified filters, which is how a share is built. CALCULATE evaluates an expression under modified filters, which is how ratios, shares, and prior-period values are built. Local study-map skill 2.5 (CALCULATE and Filter Modifiers), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. CALCULATE evaluates an expression under modified filters, which is how ratios, shares, and prior-period values are built. In this case: CALCULATE evaluates the expression under modified filters, which is how a share is built.
- **B:** Incorrect for this question. ALL clears filters from a table, which is the basis for share-of-total and denominator calculations. Why the correct answer wins: CALCULATE evaluates the expression under modified filters, which is how a share is built.
- **C:** Incorrect for this question. KEEPFILTERS keeps the existing filter and intersects it with the new one, which prevents a measure from reporting values outside the current selection. Why the correct answer wins: CALCULATE evaluates the expression under modified filters, which is how a share is built.
- **D:** Incorrect for this question. Variables compute once, make a measure readable, and prevent a filter modifier from being applied differently in two places. Why the correct answer wins: CALCULATE evaluates the expression under modified filters, which is how a share is built.

### Question 42 — A

Answer: Use ALLSELECTED to respect the slicer but ignore the visual. ALLSELECTED respects the reader's selection while removing the visual's grouping. ALLSELECTED computes a share within the user's chosen selection rather than the whole table, which is usually what a percent-of-total wants. Local study-map skill 2.5 (CALCULATE and Filter Modifiers), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. ALLSELECTED computes a share within the user's chosen selection rather than the whole table, which is usually what a percent-of-total wants. In this case: ALLSELECTED respects the reader's selection while removing the visual's grouping.
- **B:** Incorrect for this question. KEEPFILTERS keeps the existing filter and intersects it with the new one, which prevents a measure from reporting values outside the current selection. Why the correct answer wins: ALLSELECTED respects the reader's selection while removing the visual's grouping.
- **C:** Incorrect for this question. ALL clears filters from a table, which is the basis for share-of-total and denominator calculations. Why the correct answer wins: ALLSELECTED respects the reader's selection while removing the visual's grouping.
- **D:** Incorrect for this question. Removing a filter lets a measure compute a total or share regardless of the current slicer selection. Why the correct answer wins: ALLSELECTED respects the reader's selection while removing the visual's grouping.

### Question 43 — C

Answer: Store intermediate results in VAR and RETURN. Variables compute the expression once and make the measure readable. Variables compute once, make a measure readable, and prevent a filter modifier from being applied differently in two places. Local study-map skill 2.5 (CALCULATE and Filter Modifiers), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. KEEPFILTERS keeps the existing filter and intersects it with the new one, which prevents a measure from reporting values outside the current selection. Why the correct answer wins: Variables compute the expression once and make the measure readable.
- **B:** Incorrect for this question. ALL clears filters from a table, which is the basis for share-of-total and denominator calculations. Why the correct answer wins: Variables compute the expression once and make the measure readable.
- **C:** Correct. Variables compute once, make a measure readable, and prevent a filter modifier from being applied differently in two places. In this case: Variables compute the expression once and make the measure readable.
- **D:** Incorrect for this question. CALCULATE evaluates an expression under modified filters, which is how ratios, shares, and prior-period values are built. Why the correct answer wins: Variables compute the expression once and make the measure readable.

### Question 44 — C

Answer: Add KEEPFILTERS to intersect rather than replace the filter. KEEPFILTERS intersects the new filter with the existing one. KEEPFILTERS keeps the existing filter and intersects it with the new one, which prevents a measure from reporting values outside the current selection. Local study-map skill 2.5 (CALCULATE and Filter Modifiers), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. ALL clears filters from a table, which is the basis for share-of-total and denominator calculations. Why the correct answer wins: KEEPFILTERS intersects the new filter with the existing one.
- **B:** Incorrect for this question. Removing a filter lets a measure compute a total or share regardless of the current slicer selection. Why the correct answer wins: KEEPFILTERS intersects the new filter with the existing one.
- **C:** Correct. KEEPFILTERS keeps the existing filter and intersects it with the new one, which prevents a measure from reporting values outside the current selection. In this case: KEEPFILTERS intersects the new filter with the existing one.
- **D:** Incorrect for this question. ALLSELECTED computes a share within the user's chosen selection rather than the whole table, which is usually what a percent-of-total wants. Why the correct answer wins: KEEPFILTERS intersects the new filter with the existing one.

### Question 45 — A, E

Answers: Use TOTALYTD or DATESYTD for year-to-date; Use SAMEPERIODLASTYEAR or DATEADD for the comparable period. Year-to-date supplies the cumulative figure, and the comparable-period shift supplies last year's value. Year-to-date functions accumulate from the start of the year defined by the marked date table. The comparable-period functions shift the current selection back a year, which is how year-over-year is computed correctly. Local study-map skill 2.6 (Time Intelligence and Semi-Additive Measures), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. Year-to-date functions accumulate from the start of the year defined by the marked date table. In this case: Year-to-date supplies the cumulative figure, and the comparable-period shift supplies last year's value.
- **B:** Incorrect for this question. Balances such as inventory should not be summed across time, so the measure takes the value at the last date in the period. Why the correct answer wins: Year-to-date supplies the cumulative figure, and the comparable-period shift supplies last year's value.
- **C:** Incorrect for this question. DATESINPERIOD returns a range ending at the current date, which is the basis for rolling totals. Why the correct answer wins: Year-to-date supplies the cumulative figure, and the comparable-period shift supplies last year's value.
- **D:** Incorrect for this question. A rolling window averages a trailing number of periods, which smooths a noisy series without hiding the current value. Why the correct answer wins: Year-to-date supplies the cumulative figure, and the comparable-period shift supplies last year's value.
- **E:** Correct. The comparable-period functions shift the current selection back a year, which is how year-over-year is computed correctly. In this case: Year-to-date supplies the cumulative figure, and the comparable-period shift supplies last year's value.

### Question 46 — A

Answer: Use AVERAGEX over a rolling date window. A rolling average smooths the series without hiding the current value. A rolling window averages a trailing number of periods, which smooths a noisy series without hiding the current value. Local study-map skill 2.6 (Time Intelligence and Semi-Additive Measures), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. A rolling window averages a trailing number of periods, which smooths a noisy series without hiding the current value. In this case: A rolling average smooths the series without hiding the current value.
- **B:** Incorrect for this question. DATESINPERIOD returns a range ending at the current date, which is the basis for rolling totals. Why the correct answer wins: A rolling average smooths the series without hiding the current value.
- **C:** Incorrect for this question. Year-to-date functions accumulate from the start of the year defined by the marked date table. Why the correct answer wins: A rolling average smooths the series without hiding the current value.
- **D:** Incorrect for this question. The comparable-period functions shift the current selection back a year, which is how year-over-year is computed correctly. Why the correct answer wins: A rolling average smooths the series without hiding the current value.

### Question 47 — B

Answer: Create a calculation group for the time-intelligence variants. A calculation group applies the same variants to every measure. A calculation group applies the same set of variants to every measure, which replaces dozens of near-identical measures. Local study-map skill 2.7 (Statistical Functions, Quick Measures, and Calculation Groups), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. A quick measure generates the DAX for a common pattern such as a running total, which is faster and less error-prone than hand-writing it. Why the correct answer wins: A calculation group applies the same variants to every measure.
- **B:** Correct. A calculation group applies the same set of variants to every measure, which replaces dozens of near-identical measures. In this case: A calculation group applies the same variants to every measure.
- **C:** Incorrect for this question. A field parameter lets one visual switch between measures or dimensions without duplicating pages. Why the correct answer wins: A calculation group applies the same variants to every measure.
- **D:** Incorrect for this question. A what-if parameter feeds a measure that applies the selected value, which lets users test assumptions in the report. Why the correct answer wins: A calculation group applies the same variants to every measure.

### Question 48 — A, B

Answers: Create a field parameter so the author can switch the measure or axis; Create a numeric range parameter for scenario analysis. A field parameter switches the measure in place, and a numeric range parameter drives the assumption. A field parameter lets one visual switch between measures or dimensions without duplicating pages. A what-if parameter feeds a measure that applies the selected value, which lets users test assumptions in the report. Local study-map skill 2.7 (Statistical Functions, Quick Measures, and Calculation Groups), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. A what-if parameter feeds a measure that applies the selected value, which lets users test assumptions in the report. In this case: A field parameter switches the measure in place, and a numeric range parameter drives the assumption.
- **B:** Correct. A field parameter lets one visual switch between measures or dimensions without duplicating pages. In this case: A field parameter switches the measure in place, and a numeric range parameter drives the assumption.
- **C:** Incorrect for this question. A calculation group applies the same set of variants to every measure, which replaces dozens of near-identical measures. Why the correct answer wins: A field parameter switches the measure in place, and a numeric range parameter drives the assumption.
- **D:** Incorrect for this question. A quick measure generates the DAX for a common pattern such as a running total, which is faster and less error-prone than hand-writing it. Why the correct answer wins: A field parameter switches the measure in place, and a numeric range parameter drives the assumption.
- **E:** Incorrect for this question. A percentile returns the value below which a share of observations fall, which describes a distribution rather than an average. Why the correct answer wins: A field parameter switches the measure in place, and a numeric range parameter drives the assumption.

### Question 49 — B

Answer: Run Performance Analyzer to find the slow visual. Performance Analyzer times each visual and separates DAX, query, and rendering cost. Performance Analyzer times each visual and separates DAX, query, and rendering cost, which identifies where the delay actually is. Local study-map skill 2.8 (Model Performance and Granularity), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. DAX query view shows the generated query and its timings, which is how a slow measure is isolated from a slow visual. Why the correct answer wins: Performance Analyzer times each visual and separates DAX, query, and rendering cost.
- **B:** Correct. Performance Analyzer times each visual and separates DAX, query, and rendering cost, which identifies where the delay actually is. In this case: Performance Analyzer times each visual and separates DAX, query, and rendering cost.
- **C:** Incorrect for this question. Loading to the grain the report actually needs removes rows the visuals never use. Why the correct answer wins: Performance Analyzer times each visual and separates DAX, query, and rendering cost.
- **D:** Incorrect for this question. The in-memory store compresses repeated and narrow values well, so trimming high-cardinality text and unused columns is the main size lever. Why the correct answer wins: Performance Analyzer times each visual and separates DAX, query, and rendering cost.

### Question 50 — D

Answer: Add an aggregation table for the large fact. An aggregation table answers common summaries quickly while detail stays available. A pre-aggregated table answers common summaries quickly while the detail stays available for drillthrough. Local study-map skill 2.8 (Model Performance and Granularity), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Loading to the grain the report actually needs removes rows the visuals never use. Why the correct answer wins: An aggregation table answers common summaries quickly while detail stays available.
- **B:** Incorrect for this question. Performance Analyzer times each visual and separates DAX, query, and rendering cost, which identifies where the delay actually is. Why the correct answer wins: An aggregation table answers common summaries quickly while detail stays available.
- **C:** Incorrect for this question. Size work starts with what is loaded, because no DAX rewrite compensates for a model that stores data it never queries. Why the correct answer wins: An aggregation table answers common summaries quickly while detail stays available.
- **D:** Correct. A pre-aggregated table answers common summaries quickly while the detail stays available for drillthrough. In this case: An aggregation table answers common summaries quickly while detail stays available.

### Question 51 — D

Answer: A clustered bar or column chart. A bar chart compares a measure across categories. Bar and column charts compare a measure across categories, which is the right default for ranking or comparison. Local study-map skill 3.1 (Selecting and Formatting Visuals), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. A pie chart shows part-to-whole for a few categories; beyond about five slices the comparison becomes unreadable. Why the correct answer wins: A bar chart compares a measure across categories.
- **B:** Incorrect for this question. A treemap shows hierarchical part-to-whole through area, which suits many categories when exact comparison is secondary. Why the correct answer wins: A bar chart compares a measure across categories.
- **C:** Incorrect for this question. A line chart shows a trend over a continuous axis, which is what time series need. Why the correct answer wins: A bar chart compares a measure across categories.
- **D:** Correct. Bar and column charts compare a measure across categories, which is the right default for ranking or comparison. In this case: A bar chart compares a measure across categories.

### Question 52 — C

Answer: A treemap. A treemap shows part-to-whole through area, which suits many categories. A treemap shows hierarchical part-to-whole through area, which suits many categories when exact comparison is secondary. Local study-map skill 3.1 (Selecting and Formatting Visuals), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. A gauge shows one value against a target range, which is compact but wastes space relative to a KPI or card. Why the correct answer wins: A treemap shows part-to-whole through area, which suits many categories.
- **B:** Incorrect for this question. A pie chart shows part-to-whole for a few categories; beyond about five slices the comparison becomes unreadable. Why the correct answer wins: A treemap shows part-to-whole through area, which suits many categories.
- **C:** Correct. A treemap shows hierarchical part-to-whole through area, which suits many categories when exact comparison is secondary. In this case: A treemap shows part-to-whole through area, which suits many categories.
- **D:** Incorrect for this question. A scatter plot shows the relationship between two numeric measures and reveals clusters and outliers. Why the correct answer wins: A treemap shows part-to-whole through area, which suits many categories.

### Question 53 — B

Answer: A scatter chart. A scatter plot shows the relationship between two numeric measures. A scatter plot shows the relationship between two numeric measures and reveals clusters and outliers. Local study-map skill 3.1 (Selecting and Formatting Visuals), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. A funnel shows sequential stage attrition, which suits a sales or process pipeline. Why the correct answer wins: A scatter plot shows the relationship between two numeric measures.
- **B:** Correct. A scatter plot shows the relationship between two numeric measures and reveals clusters and outliers. In this case: A scatter plot shows the relationship between two numeric measures.
- **C:** Incorrect for this question. A matrix supports nested rows and columns with subtotals, which is the report equivalent of a pivot table. Why the correct answer wins: A scatter plot shows the relationship between two numeric measures.
- **D:** Incorrect for this question. A line chart shows a trend over a continuous axis, which is what time series need. Why the correct answer wins: A scatter plot shows the relationship between two numeric measures.

### Question 54 — C

Answer: A slicer on the report page. A slicer puts the control on the canvas. A slicer gives the reader an obvious control over the filter, which is clearer than expecting them to use the filter pane. Local study-map skill 3.2 (Slicers, Filters, and Visual Interactions), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. Filter scope decides who the filter affects, and putting it at the wrong level is a common cause of a filter that seems to be ignored. Why the correct answer wins: A slicer puts the control on the canvas.
- **B:** Incorrect for this question. Syncing keeps a selection consistent as the reader moves between pages, which prevents contradictory views. Why the correct answer wins: A slicer puts the control on the canvas.
- **C:** Correct. A slicer gives the reader an obvious control over the filter, which is clearer than expecting them to use the filter pane. In this case: A slicer puts the control on the canvas.
- **D:** Incorrect for this question. Interaction settings decide whether a selection filters, highlights, or does nothing, which is how an executive summary stays stable. Why the correct answer wins: A slicer puts the control on the canvas.

### Question 55 — B

Answer: Sync the slicer across the pages that share the same filter. Syncing the slicer keeps one selection consistent across pages. Syncing keeps a selection consistent as the reader moves between pages, which prevents contradictory views. Local study-map skill 3.2 (Slicers, Filters, and Visual Interactions), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. Filter scope decides who the filter affects, and putting it at the wrong level is a common cause of a filter that seems to be ignored. Why the correct answer wins: Syncing the slicer keeps one selection consistent across pages.
- **B:** Correct. Syncing keeps a selection consistent as the reader moves between pages, which prevents contradictory views. In this case: Syncing the slicer keeps one selection consistent across pages.
- **C:** Incorrect for this question. Interaction settings decide whether a selection filters, highlights, or does nothing, which is how an executive summary stays stable. Why the correct answer wins: Syncing the slicer keeps one selection consistent across pages.
- **D:** Incorrect for this question. A slicer gives the reader an obvious control over the filter, which is clearer than expecting them to use the filter pane. Why the correct answer wins: Syncing the slicer keeps one selection consistent across pages.

### Question 56 — B

Answer: Edit the interactions so the visual does not filter the others. Interaction settings decide whether a selection filters, highlights, or does nothing. Interaction settings decide whether a selection filters, highlights, or does nothing, which is how an executive summary stays stable. Local study-map skill 3.2 (Slicers, Filters, and Visual Interactions), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. Filter scope decides who the filter affects, and putting it at the wrong level is a common cause of a filter that seems to be ignored. Why the correct answer wins: Interaction settings decide whether a selection filters, highlights, or does nothing.
- **B:** Correct. Interaction settings decide whether a selection filters, highlights, or does nothing, which is how an executive summary stays stable. In this case: Interaction settings decide whether a selection filters, highlights, or does nothing.
- **C:** Incorrect for this question. Syncing keeps a selection consistent as the reader moves between pages, which prevents contradictory views. Why the correct answer wins: Interaction settings decide whether a selection filters, highlights, or does nothing.
- **D:** Incorrect for this question. A slicer gives the reader an obvious control over the filter, which is clearer than expecting them to use the filter pane. Why the correct answer wins: Interaction settings decide whether a selection filters, highlights, or does nothing.

### Question 57 — D

Answer: Set the filter pane scope by page, report, or visual. Filter scope decides whether a filter applies to a visual, a page, or the whole report. Filter scope decides who the filter affects, and putting it at the wrong level is a common cause of a filter that seems to be ignored. Local study-map skill 3.2 (Slicers, Filters, and Visual Interactions), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. A slicer gives the reader an obvious control over the filter, which is clearer than expecting them to use the filter pane. Why the correct answer wins: Filter scope decides whether a filter applies to a visual, a page, or the whole report.
- **B:** Incorrect for this question. Syncing keeps a selection consistent as the reader moves between pages, which prevents contradictory views. Why the correct answer wins: Filter scope decides whether a filter applies to a visual, a page, or the whole report.
- **C:** Incorrect for this question. Interaction settings decide whether a selection filters, highlights, or does nothing, which is how an executive summary stays stable. Why the correct answer wins: Filter scope decides whether a filter applies to a visual, a page, or the whole report.
- **D:** Correct. Filter scope decides who the filter affects, and putting it at the wrong level is a common cause of a filter that seems to be ignored. In this case: Filter scope decides whether a filter applies to a visual, a page, or the whole report.

### Question 58 — B

Answer: Capture the view in a bookmark. A bookmark stores filter and visibility state. A bookmark stores the current filter, slicer, and visibility state, which is how a report offers saved views or a reset button. Local study-map skill 3.3 (Bookmarks, Buttons, and Report Navigation), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. The Selection pane controls visibility and z-order, which is how a report builds layered or swapped views. Why the correct answer wins: A bookmark stores filter and visibility state.
- **B:** Correct. A bookmark stores the current filter, slicer, and visibility state, which is how a report offers saved views or a reset button. In this case: A bookmark stores filter and visibility state.
- **C:** Incorrect for this question. A page navigator generates navigation for every page automatically, which stays correct as pages are added. Why the correct answer wins: A bookmark stores filter and visibility state.
- **D:** Incorrect for this question. Buttons turn a bookmark or page change into one click, which is how a report is made to feel like an application. Why the correct answer wins: A bookmark stores filter and visibility state.

### Question 59 — A

Answer: Add buttons with actions that navigate or apply a bookmark. Buttons with bookmark actions turn a stored state into a click. Buttons turn a bookmark or page change into one click, which is how a report is made to feel like an application. Local study-map skill 3.3 (Bookmarks, Buttons, and Report Navigation), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Correct. Buttons turn a bookmark or page change into one click, which is how a report is made to feel like an application. In this case: Buttons with bookmark actions turn a stored state into a click.
- **B:** Incorrect for this question. A bookmark stores the current filter, slicer, and visibility state, which is how a report offers saved views or a reset button. Why the correct answer wins: Buttons with bookmark actions turn a stored state into a click.
- **C:** Incorrect for this question. A page navigator generates navigation for every page automatically, which stays correct as pages are added. Why the correct answer wins: Buttons with bookmark actions turn a stored state into a click.
- **D:** Incorrect for this question. The Selection pane controls visibility and z-order, which is how a report builds layered or swapped views. Why the correct answer wins: Buttons with bookmark actions turn a stored state into a click.

### Question 60 — C

Answer: Create the views → capture each in a bookmark → add buttons → hide the visuals not in use. Bookmarks store state and buttons apply it. Bookmarks store state and buttons apply it, which is what makes a single page behave like several. Local study-map skill 3.3 (Bookmarks, Buttons, and Report Navigation), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. A bookmark captures the state at the moment it is created, so filters set afterwards are not stored. Why the correct answer wins: Bookmarks store state and buttons apply it.
- **B:** Incorrect for this question. Duplicating pages multiplies maintenance and the copies drift apart. Why the correct answer wins: Bookmarks store state and buttons apply it.
- **C:** Correct. Bookmarks store state and buttons apply it, which is what makes a single page behave like several. In this case: Bookmarks store state and buttons apply it.
- **D:** Incorrect for this question. A button with no action is decoration and the report still has no navigation. Why the correct answer wins: Bookmarks store state and buttons apply it.

### Question 61 — B

Answer: Add a page navigator for the report. A page navigator generates navigation from the pages themselves. A page navigator generates navigation for every page automatically, which stays correct as pages are added. Local study-map skill 3.3 (Bookmarks, Buttons, and Report Navigation), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. Buttons turn a bookmark or page change into one click, which is how a report is made to feel like an application. Why the correct answer wins: A page navigator generates navigation from the pages themselves.
- **B:** Correct. A page navigator generates navigation for every page automatically, which stays correct as pages are added. In this case: A page navigator generates navigation from the pages themselves.
- **C:** Incorrect for this question. A bookmark stores the current filter, slicer, and visibility state, which is how a report offers saved views or a reset button. Why the correct answer wins: A page navigator generates navigation from the pages themselves.
- **D:** Incorrect for this question. The Selection pane controls visibility and z-order, which is how a report builds layered or swapped views. Why the correct answer wins: A page navigator generates navigation from the pages themselves.

### Question 62 — D

Answer: Configure a drillthrough page with the entity filter. Drillthrough passes the selected entity to a detail page through a filter. Drillthrough opens a detail page filtered to the selected entity, which is how a reader moves from a summary to the underlying rows. Local study-map skill 3.4 (Drillthrough, Drill-Down, and Tooltips), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. Drill-down moves from a summary level to the next level within the same visual, which keeps the context visible. Why the correct answer wins: Drillthrough passes the selected entity to a detail page through a filter.
- **B:** Incorrect for this question. Filter scope decides who the filter affects, and putting it at the wrong level is a common cause of a filter that seems to be ignored. Why the correct answer wins: Drillthrough passes the selected entity to a detail page through a filter.
- **C:** Incorrect for this question. Interaction settings decide whether a selection filters, highlights, or does nothing, which is how an executive summary stays stable. Why the correct answer wins: Drillthrough passes the selected entity to a detail page through a filter.
- **D:** Correct. Drillthrough opens a detail page filtered to the selected entity, which is how a reader moves from a summary to the underlying rows. In this case: Drillthrough passes the selected entity to a detail page through a filter.

### Question 63 — D, E

Answers: Build a custom tooltip page; Set the tooltip to a report page and size it to the hover area. A tooltip page holds the extra measures, and the report-page tooltip setting displays it on hover. A tooltip page shows several related measures on hover, which adds context without cluttering the visual. A report-page tooltip must be small enough to read on hover, and its filters must match the hovered data point. Local study-map skill 3.4 (Drillthrough, Drill-Down, and Tooltips), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. The Selection pane controls visibility and z-order, which is how a report builds layered or swapped views. Why the correct answer wins: A tooltip page holds the extra measures, and the report-page tooltip setting displays it on hover.
- **B:** Incorrect for this question. Drill-down moves from a summary level to the next level within the same visual, which keeps the context visible. Why the correct answer wins: A tooltip page holds the extra measures, and the report-page tooltip setting displays it on hover.
- **C:** Incorrect for this question. Drillthrough opens a detail page filtered to the selected entity, which is how a reader moves from a summary to the underlying rows. Why the correct answer wins: A tooltip page holds the extra measures, and the report-page tooltip setting displays it on hover.
- **D:** Correct. A tooltip page shows several related measures on hover, which adds context without cluttering the visual. In this case: A tooltip page holds the extra measures, and the report-page tooltip setting displays it on hover.
- **E:** Correct. A report-page tooltip must be small enough to read on hover, and its filters must match the hovered data point. In this case: A tooltip page holds the extra measures, and the report-page tooltip setting displays it on hover.

### Question 64 — D

Answer: Choose the entity field → create the drillthrough page → place the entity filter → add a back button. The drillthrough filter carries the selection, and the back button keeps the reader oriented. The drillthrough filter is what carries the selection, and the back button is what keeps the reader oriented. Local study-map skill 3.4 (Drillthrough, Drill-Down, and Tooltips), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. Too many fields on one visual makes the click target ambiguous and the drill result unpredictable. Why the correct answer wins: The drillthrough filter carries the selection, and the back button keeps the reader oriented.
- **B:** Incorrect for this question. Without a back button the reader is stranded on the detail page and loses the summary context. Why the correct answer wins: The drillthrough filter carries the selection, and the back button keeps the reader oriented.
- **C:** Incorrect for this question. A page without the drillthrough filter does not carry the selected entity, so the detail is not about what was clicked. Why the correct answer wins: The drillthrough filter carries the selection, and the back button keeps the reader oriented.
- **D:** Correct. The drillthrough filter is what carries the selection, and the back button is what keeps the reader oriented. In this case: The drillthrough filter carries the selection, and the back button keeps the reader oriented.

### Question 65 — A

Answer: Enable drill-down through the hierarchy. Drill-down moves through the hierarchy inside the same visual. Drill-down moves from a summary level to the next level within the same visual, which keeps the context visible. Local study-map skill 3.4 (Drillthrough, Drill-Down, and Tooltips), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Correct. Drill-down moves from a summary level to the next level within the same visual, which keeps the context visible. In this case: Drill-down moves through the hierarchy inside the same visual.
- **B:** Incorrect for this question. Interaction settings decide whether a selection filters, highlights, or does nothing, which is how an executive summary stays stable. Why the correct answer wins: Drill-down moves through the hierarchy inside the same visual.
- **C:** Incorrect for this question. Drillthrough opens a detail page filtered to the selected entity, which is how a reader moves from a summary to the underlying rows. Why the correct answer wins: Drill-down moves through the hierarchy inside the same visual.
- **D:** Incorrect for this question. A tooltip page shows several related measures on hover, which adds context without cluttering the visual. Why the correct answer wins: Drill-down moves through the hierarchy inside the same visual.

### Question 66 — C

Answer: Build the mobile layout in the mobile view. The mobile layout decides what appears first on a phone. The mobile layout decides what a phone shows first, which is not the same as a squeezed desktop canvas. Local study-map skill 3.5 (Accessibility, Mobile Layout, Personalization, and Export), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. Export settings decide whether readers can take data out, which is a governance decision as much as a convenience. Why the correct answer wins: The mobile layout decides what appears first on a phone.
- **B:** Incorrect for this question. Personalization lets a reader change visual type or fields without edit rights, while the author keeps the published default. Why the correct answer wins: The mobile layout decides what appears first on a phone.
- **C:** Correct. The mobile layout decides what a phone shows first, which is not the same as a squeezed desktop canvas. In this case: The mobile layout decides what appears first on a phone.
- **D:** Incorrect for this question. Alt text describes the visual for a screen reader, which is required for an accessible report. Why the correct answer wins: The mobile layout decides what appears first on a phone.

### Question 67 — D

Answer: Enable personalization for the visuals the reader may change. Personalization lets a reader change the visual while the author keeps the default. Personalization lets a reader change visual type or fields without edit rights, while the author keeps the published default. Local study-map skill 3.5 (Accessibility, Mobile Layout, Personalization, and Export), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. The mobile layout decides what a phone shows first, which is not the same as a squeezed desktop canvas. Why the correct answer wins: Personalization lets a reader change the visual while the author keeps the default.
- **B:** Incorrect for this question. Export settings decide whether readers can take data out, which is a governance decision as much as a convenience. Why the correct answer wins: Personalization lets a reader change the visual while the author keeps the default.
- **C:** Incorrect for this question. Alt text describes the visual for a screen reader, which is required for an accessible report. Why the correct answer wins: Personalization lets a reader change the visual while the author keeps the default.
- **D:** Correct. Personalization lets a reader change visual type or fields without edit rights, while the author keeps the published default. In this case: Personalization lets a reader change the visual while the author keeps the default.

### Question 68 — A

Answer: Apply a report theme JSON. A theme applies a consistent palette across the report. A theme applies a consistent palette and formatting across every visual, which is faster and more consistent than styling each visual. Local study-map skill 3.6 (Sorting, Conditional Formatting, Themes, and the Selection Pane), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Correct. A theme applies a consistent palette and formatting across every visual, which is faster and more consistent than styling each visual. In this case: A theme applies a consistent palette across the report.
- **B:** Incorrect for this question. Conditional formatting encodes a value as colour or an icon, which lets a reader scan exceptions instead of reading every number. Why the correct answer wins: A theme applies a consistent palette across the report.
- **C:** Incorrect for this question. The Selection pane controls visibility and z-order, which is how a report builds layered or swapped views. Why the correct answer wins: A theme applies a consistent palette across the report.
- **D:** Incorrect for this question. A fixed axis prevents a small change from looking dramatic, which is an integrity issue rather than a cosmetic one. Why the correct answer wins: A theme applies a consistent palette across the report.

### Question 69 — A

Answer: Apply conditional formatting driven by a measure. Conditional formatting driven by a measure encodes the exception. Conditional formatting encodes a value as colour or an icon, which lets a reader scan exceptions instead of reading every number. Local study-map skill 3.6 (Sorting, Conditional Formatting, Themes, and the Selection Pane), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Correct. Conditional formatting encodes a value as colour or an icon, which lets a reader scan exceptions instead of reading every number. In this case: Conditional formatting driven by a measure encodes the exception.
- **B:** Incorrect for this question. A theme applies a consistent palette and formatting across every visual, which is faster and more consistent than styling each visual. Why the correct answer wins: Conditional formatting driven by a measure encodes the exception.
- **C:** Incorrect for this question. A fixed axis prevents a small change from looking dramatic, which is an integrity issue rather than a cosmetic one. Why the correct answer wins: Conditional formatting driven by a measure encodes the exception.
- **D:** Incorrect for this question. The Selection pane controls visibility and z-order, which is how a report builds layered or swapped views. Why the correct answer wins: Conditional formatting driven by a measure encodes the exception.

### Question 70 — A, B

Answers: Use the Selection pane to group and layer visuals; Set the axis range and units explicitly. The Selection pane controls layering, and an explicit axis range prevents a misleading scale. The Selection pane controls visibility and z-order, which is how a report builds layered or swapped views. A fixed axis prevents a small change from looking dramatic, which is an integrity issue rather than a cosmetic one. Local study-map skill 3.6 (Sorting, Conditional Formatting, Themes, and the Selection Pane), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Correct. A fixed axis prevents a small change from looking dramatic, which is an integrity issue rather than a cosmetic one. In this case: The Selection pane controls layering, and an explicit axis range prevents a misleading scale.
- **B:** Correct. The Selection pane controls visibility and z-order, which is how a report builds layered or swapped views. In this case: The Selection pane controls layering, and an explicit axis range prevents a misleading scale.
- **C:** Incorrect for this question. A theme applies a consistent palette and formatting across every visual, which is faster and more consistent than styling each visual. Why the correct answer wins: The Selection pane controls layering, and an explicit axis range prevents a misleading scale.
- **D:** Incorrect for this question. Conditional formatting encodes a value as colour or an icon, which lets a reader scan exceptions instead of reading every number. Why the correct answer wins: The Selection pane controls layering, and an explicit axis range prevents a misleading scale.
- **E:** Incorrect for this question. Data labels put the value next to the mark, which removes the need to read an axis for a small number of categories. Why the correct answer wins: The Selection pane controls layering, and an explicit axis range prevents a misleading scale.

### Question 71 — C

Answer: Add a reference line for the target or average. A reference line gives the comparison without a second visual. A reference line gives the reader a comparison without a second visual, which turns a trend into a performance judgement. Local study-map skill 3.7 (Analyze Features, Grouping, Binning, and Forecasting), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. Grouping combines members into meaningful buckets, which reduces clutter and matches how the business talks. Why the correct answer wins: A reference line gives the comparison without a second visual.
- **B:** Incorrect for this question. Forecasting extends the series statistically and shows a confidence band, which is only meaningful on a stable, seasonally understood series. Why the correct answer wins: A reference line gives the comparison without a second visual.
- **C:** Correct. A reference line gives the reader a comparison without a second visual, which turns a trend into a performance judgement. In this case: A reference line gives the comparison without a second visual.
- **D:** Incorrect for this question. Error bars show the spread around a value, which stops a point estimate being read as certainty. Why the correct answer wins: A reference line gives the comparison without a second visual.

### Question 72 — A

Answer: Use the built-in forecast on a line chart. Forecasting extends the series statistically with a confidence band. Forecasting extends the series statistically and shows a confidence band, which is only meaningful on a stable, seasonally understood series. Local study-map skill 3.7 (Analyze Features, Grouping, Binning, and Forecasting), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Correct. Forecasting extends the series statistically and shows a confidence band, which is only meaningful on a stable, seasonally understood series. In this case: Forecasting extends the series statistically with a confidence band.
- **B:** Incorrect for this question. Binning turns a continuous value into ranges, which is how a distribution becomes readable. Why the correct answer wins: Forecasting extends the series statistically with a confidence band.
- **C:** Incorrect for this question. A reference line gives the reader a comparison without a second visual, which turns a trend into a performance judgement. Why the correct answer wins: Forecasting extends the series statistically with a confidence band.
- **D:** Incorrect for this question. Clustering groups similar rows statistically, which surfaces segments that were not defined in advance. Why the correct answer wins: Forecasting extends the series statistically with a confidence band.

### Question 73 — D

Answer: Create bins for a continuous measure. Binning turns a continuous measure into ranges. Binning turns a continuous value into ranges, which is how a distribution becomes readable. Local study-map skill 3.7 (Analyze Features, Grouping, Binning, and Forecasting), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. Clustering groups similar rows statistically, which surfaces segments that were not defined in advance. Why the correct answer wins: Binning turns a continuous measure into ranges.
- **B:** Incorrect for this question. Outlier detection finds points that sit far from the pattern, which is often the first sign of a data or process problem. Why the correct answer wins: Binning turns a continuous measure into ranges.
- **C:** Incorrect for this question. Grouping combines members into meaningful buckets, which reduces clutter and matches how the business talks. Why the correct answer wins: Binning turns a continuous measure into ranges.
- **D:** Correct. Binning turns a continuous value into ranges, which is how a distribution becomes readable. In this case: Binning turns a continuous measure into ranges.

### Question 74 — C

Answer: Use the Decomposition Tree visual. A decomposition tree supports open-ended drill paths. A decomposition tree lets the reader drill into any dimension in any order, which suits open-ended root-cause work. Local study-map skill 3.8 (AI Visuals, Anomaly Detection, Q&A, and Copilot), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. Copilot can draft a page from a prompt, which is a starting point that still needs an author to check the fields and layout. Why the correct answer wins: A decomposition tree supports open-ended drill paths.
- **B:** Incorrect for this question. Q&A maps a typed question to the model and returns a visual, which is fast for ad hoc questions if the model is well named. Why the correct answer wins: A decomposition tree supports open-ended drill paths.
- **C:** Correct. A decomposition tree lets the reader drill into any dimension in any order, which suits open-ended root-cause work. In this case: A decomposition tree supports open-ended drill paths.
- **D:** Incorrect for this question. Key Influencers ranks the factors associated with a metric, which is explanatory rather than causal. Why the correct answer wins: A decomposition tree supports open-ended drill paths.

### Question 75 — B, D

Answers: Use the Key Influencers visual; Use Copilot to create a narrative visual. Key Influencers ranks the associated factors, and a narrative visual summarizes the page. Key Influencers ranks the factors associated with a metric, which is explanatory rather than causal. A narrative visual summarizes the page in text, which helps a reader who wants the story rather than the chart. Local study-map skill 3.8 (AI Visuals, Anomaly Detection, Q&A, and Copilot), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. A decomposition tree lets the reader drill into any dimension in any order, which suits open-ended root-cause work. Why the correct answer wins: Key Influencers ranks the associated factors, and a narrative visual summarizes the page.
- **B:** Correct. Key Influencers ranks the factors associated with a metric, which is explanatory rather than causal. In this case: Key Influencers ranks the associated factors, and a narrative visual summarizes the page.
- **C:** Incorrect for this question. Copilot can draft a page from a prompt, which is a starting point that still needs an author to check the fields and layout. Why the correct answer wins: Key Influencers ranks the associated factors, and a narrative visual summarizes the page.
- **D:** Correct. A narrative visual summarizes the page in text, which helps a reader who wants the story rather than the chart. In this case: Key Influencers ranks the associated factors, and a narrative visual summarizes the page.
- **E:** Incorrect for this question. Q&A maps a typed question to the model and returns a visual, which is fast for ad hoc questions if the model is well named. Why the correct answer wins: Key Influencers ranks the associated factors, and a narrative visual summarizes the page.

### Question 76 — A

Answer: Use Q&A to answer a natural-language question. Q&A maps a typed question to the model and returns a visual. Q&A maps a typed question to the model and returns a visual, which is fast for ad hoc questions if the model is well named. Local study-map skill 3.8 (AI Visuals, Anomaly Detection, Q&A, and Copilot), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Correct. Q&A maps a typed question to the model and returns a visual, which is fast for ad hoc questions if the model is well named. In this case: Q&A maps a typed question to the model and returns a visual.
- **B:** Incorrect for this question. A narrative visual summarizes the page in text, which helps a reader who wants the story rather than the chart. Why the correct answer wins: Q&A maps a typed question to the model and returns a visual.
- **C:** Incorrect for this question. A decomposition tree lets the reader drill into any dimension in any order, which suits open-ended root-cause work. Why the correct answer wins: Q&A maps a typed question to the model and returns a visual.
- **D:** Incorrect for this question. Key Influencers ranks the factors associated with a metric, which is explanatory rather than causal. Why the correct answer wins: Q&A maps a typed question to the model and returns a visual.

### Question 77 — B

Answer: Workspace Contributor role. Contributors publish and edit without controlling membership. Contributors can publish and edit content, which is the role for authors who should not manage membership. Local study-map skill 4.1 (Workspaces and Workspace Roles), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. Admins manage the workspace, its members, and its settings, which is more than publishing content. Why the correct answer wins: Contributors publish and edit without controlling membership.
- **B:** Correct. Contributors can publish and edit content, which is the role for authors who should not manage membership. In this case: Contributors publish and edit without controlling membership.
- **C:** Incorrect for this question. Viewers can read the content but not edit it, which is the safest role for consumers who work inside the workspace. Why the correct answer wins: Contributors publish and edit without controlling membership.
- **D:** Incorrect for this question. Members can publish and edit all content and add lower-privileged users, but cannot delete the workspace. Why the correct answer wins: Contributors publish and edit without controlling membership.

### Question 78 — B, D

Answers: Workspace Admin role; Workspace Member role. Admin manages the workspace and members, and Member can publish and add lower-privileged users. Admins manage the workspace, its members, and its settings, which is more than publishing content. Members can publish and edit all content and add lower-privileged users, but cannot delete the workspace. Local study-map skill 4.1 (Workspaces and Workspace Roles), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. An app gives consumers a curated, read-only experience with its own audience list, instead of direct workspace access. Why the correct answer wins: Admin manages the workspace and members, and Member can publish and add lower-privileged users.
- **B:** Correct. Members can publish and edit all content and add lower-privileged users, but cannot delete the workspace. In this case: Admin manages the workspace and members, and Member can publish and add lower-privileged users.
- **C:** Incorrect for this question. Viewers can read the content but not edit it, which is the safest role for consumers who work inside the workspace. Why the correct answer wins: Admin manages the workspace and members, and Member can publish and add lower-privileged users.
- **D:** Correct. Admins manage the workspace, its members, and its settings, which is more than publishing content. In this case: Admin manages the workspace and members, and Member can publish and add lower-privileged users.
- **E:** Incorrect for this question. Contributors can publish and edit content, which is the role for authors who should not manage membership. Why the correct answer wins: Admin manages the workspace and members, and Member can publish and add lower-privileged users.

### Question 79 — B

Answer: Define an app audience for each group of consumers. Audiences show different content to different groups from one app. Audiences let one app show different content to different groups, which avoids maintaining several near-identical apps. Local study-map skill 4.2 (Apps and Distribution Methods), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. Consumers see the published app, so workspace edits stay invisible until the app is updated. Why the correct answer wins: Audiences show different content to different groups from one app.
- **B:** Correct. Audiences let one app show different content to different groups, which avoids maintaining several near-identical apps. In this case: Audiences show different content to different groups from one app.
- **C:** Incorrect for this question. An app gives consumers a curated, read-only experience with its own audience list, instead of direct workspace access. Why the correct answer wins: Audiences show different content to different groups from one app.
- **D:** Incorrect for this question. App, shared link, Teams, or embedded all grant different levels of control, so the choice is a governance decision. Why the correct answer wins: Audiences show different content to different groups from one app.

### Question 80 — D

Answer: Build in the workspace → curate the app pages → assign audiences → publish and update the app. Audiences control who sees what, and consumers see changes only when the app is updated. Audiences control who sees what, and consumers only see changes when the app is updated. Local study-map skill 4.2 (Apps and Distribution Methods), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. An app per person is unmaintainable and defeats the point of audiences. Why the correct answer wins: Audiences control who sees what, and consumers see changes only when the app is updated.
- **B:** Incorrect for this question. Publishing an unfinished report sets expectations you cannot meet and consumers see the version you last shipped. Why the correct answer wins: Audiences control who sees what, and consumers see changes only when the app is updated.
- **C:** Incorrect for this question. Direct workspace access exposes everything in the workspace and cannot be curated per audience. Why the correct answer wins: Audiences control who sees what, and consumers see changes only when the app is updated.
- **D:** Correct. Audiences control who sees what, and consumers only see changes when the app is updated. In this case: Audiences control who sees what, and consumers see changes only when the app is updated.

### Question 81 — A

Answer: Update the app after changing the workspace content. Consumers see the published app, so the app must be updated. Consumers see the published app, so workspace edits stay invisible until the app is updated. Local study-map skill 4.2 (Apps and Distribution Methods), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Correct. Consumers see the published app, so workspace edits stay invisible until the app is updated. In this case: Consumers see the published app, so the app must be updated.
- **B:** Incorrect for this question. App, shared link, Teams, or embedded all grant different levels of control, so the choice is a governance decision. Why the correct answer wins: Consumers see the published app, so the app must be updated.
- **C:** Incorrect for this question. Audiences let one app show different content to different groups, which avoids maintaining several near-identical apps. Why the correct answer wins: Consumers see the published app, so the app must be updated.
- **D:** Incorrect for this question. An app gives consumers a curated, read-only experience with its own audience list, instead of direct workspace access. Why the correct answer wins: Consumers see the published app, so the app must be updated.

### Question 82 — A

Answer: Create a dashboard in the service. A dashboard is a single canvas of tiles from several reports. A dashboard is a single-page canvas of pinned tiles from one or more reports, which suits monitoring rather than analysis. Local study-map skill 4.3 (Dashboards, Subscriptions, and Data Alerts), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Correct. A dashboard is a single-page canvas of pinned tiles from one or more reports, which suits monitoring rather than analysis. In this case: A dashboard is a single canvas of tiles from several reports.
- **B:** Incorrect for this question. A subscription delivers a snapshot on a schedule by email, which suits readers who will not open the report themselves. Why the correct answer wins: A dashboard is a single canvas of tiles from several reports.
- **C:** Incorrect for this question. Pinning copies the visual to the dashboard, and the tile stays linked to the underlying report for drill-through. Why the correct answer wins: A dashboard is a single canvas of tiles from several reports.
- **D:** Incorrect for this question. A data alert notifies when a single value crosses a threshold, and it only works on tiles, not on report visuals. Why the correct answer wins: A dashboard is a single canvas of tiles from several reports.

### Question 83 — C

Answer: Create a subscription for the report or dashboard. A subscription delivers a scheduled snapshot by email. A subscription delivers a snapshot on a schedule by email, which suits readers who will not open the report themselves. Local study-map skill 4.3 (Dashboards, Subscriptions, and Data Alerts), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. A data alert notifies when a single value crosses a threshold, and it only works on tiles, not on report visuals. Why the correct answer wins: A subscription delivers a scheduled snapshot by email.
- **B:** Incorrect for this question. Alerts are configured per tile value with a threshold and frequency, so the tile must expose the metric as a single number. Why the correct answer wins: A subscription delivers a scheduled snapshot by email.
- **C:** Correct. A subscription delivers a snapshot on a schedule by email, which suits readers who will not open the report themselves. In this case: A subscription delivers a scheduled snapshot by email.
- **D:** Incorrect for this question. Pinning copies the visual to the dashboard, and the tile stays linked to the underlying report for drill-through. Why the correct answer wins: A subscription delivers a scheduled snapshot by email.

### Question 84 — B

Answer: Create a data alert on a dashboard tile. A data alert notifies when a tile value crosses a threshold. A data alert notifies when a single value crosses a threshold, and it only works on tiles, not on report visuals. Local study-map skill 4.3 (Dashboards, Subscriptions, and Data Alerts), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. A subscription delivers a snapshot on a schedule by email, which suits readers who will not open the report themselves. Why the correct answer wins: A data alert notifies when a tile value crosses a threshold.
- **B:** Correct. A data alert notifies when a single value crosses a threshold, and it only works on tiles, not on report visuals. In this case: A data alert notifies when a tile value crosses a threshold.
- **C:** Incorrect for this question. Pinning copies the visual to the dashboard, and the tile stays linked to the underlying report for drill-through. Why the correct answer wins: A data alert notifies when a tile value crosses a threshold.
- **D:** Incorrect for this question. Alerts are configured per tile value with a threshold and frequency, so the tile must expose the metric as a single number. Why the correct answer wins: A data alert notifies when a tile value crosses a threshold.

### Question 85 — C, D

Answers: Configure incremental refresh with the range parameters; Set the RangeStart and RangeEnd parameters the refresh policy expects. An incremental refresh policy partitions the table, and the range parameters must filter the source query. Incremental refresh loads only new or changed partitions, which keeps refresh time and load predictable for a large fact table. Incremental refresh requires the date parameters to filter the source query, or the policy has nothing to partition. Local study-map skill 4.4 (Gateways and Scheduled Refresh), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. A scheduled refresh fails silently from the reader's point of view when the stored credential has expired. Why the correct answer wins: An incremental refresh policy partitions the table, and the range parameters must filter the source query.
- **B:** Incorrect for this question. A gateway provides the outbound connection from the service to an on-premises source, which cloud refresh requires. Why the correct answer wins: An incremental refresh policy partitions the table, and the range parameters must filter the source query.
- **C:** Correct. Incremental refresh loads only new or changed partitions, which keeps refresh time and load predictable for a large fact table. In this case: An incremental refresh policy partitions the table, and the range parameters must filter the source query.
- **D:** Correct. Incremental refresh requires the date parameters to filter the source query, or the policy has nothing to partition. In this case: An incremental refresh policy partitions the table, and the range parameters must filter the source query.
- **E:** Incorrect for this question. Scheduled refresh controls how often the imported data is updated, which is the freshness guarantee the report can make. Why the correct answer wins: An incremental refresh policy partitions the table, and the range parameters must filter the source query.

### Question 86 — D

Answer: Confirm the gateway or cloud connection → store credentials → set the schedule → check refresh history. Connectivity and credentials must be proven first, and history is how a failure is detected. Refresh depends on connectivity and credentials before the schedule matters, and history is how a failure is detected. Local study-map skill 4.4 (Gateways and Scheduled Refresh), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. Scheduling before connectivity and credentials are proven guarantees a failed first refresh. Why the correct answer wins: Connectivity and credentials must be proven first, and history is how a failure is detected.
- **B:** Incorrect for this question. A personal gateway fails when the individual is unavailable or changes machines. Why the correct answer wins: Connectivity and credentials must be proven first, and history is how a failure is detected.
- **C:** Incorrect for this question. Refreshing hourly without checking source capacity overloads the source and can exceed the refresh window. Why the correct answer wins: Connectivity and credentials must be proven first, and history is how a failure is detected.
- **D:** Correct. Refresh depends on connectivity and credentials before the schedule matters, and history is how a failure is detected. In this case: Connectivity and credentials must be proven first, and history is how a failure is detected.

### Question 87 — C

Answer: Define a row-level security role with a DAX filter. RLS roles filter the model per user at query time. An RLS role filters the model per user at query time, which is how one report serves many regions without duplication. Local study-map skill 4.5 (Row-Level Security), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. Adding a group instead of individuals keeps role membership aligned with the directory and reduces drift. Why the correct answer wins: RLS roles filter the model per user at query time.
- **B:** Incorrect for this question. View as role shows the report exactly as a member of the role sees it, which is how a security mistake is caught before release. Why the correct answer wins: RLS roles filter the model per user at query time.
- **C:** Correct. An RLS role filters the model per user at query time, which is how one report serves many regions without duplication. In this case: RLS roles filter the model per user at query time.
- **D:** Incorrect for this question. A dynamic rule matches the signed-in user to a mapping table, which avoids maintaining one role per person. Why the correct answer wins: RLS roles filter the model per user at query time.

### Question 88 — C

Answer: Apply a sensitivity label to the semantic model and report. A sensitivity label travels with the exported file. A sensitivity label travels with the exported file, which is how protection survives beyond the workspace. Local study-map skill 4.6 (Sensitivity Labels, Endorsement, and Item Access), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. Promotion signals the content is ready for reuse by the team, while certification asserts organization-wide trust. Why the correct answer wins: A sensitivity label travels with the exported file.
- **B:** Incorrect for this question. Item-level sharing grants one item without workspace membership, which limits what the recipient can discover. Why the correct answer wins: A sensitivity label travels with the exported file.
- **C:** Correct. A sensitivity label travels with the exported file, which is how protection survives beyond the workspace. In this case: A sensitivity label travels with the exported file.
- **D:** Incorrect for this question. Certification requires a designated reviewer, which is how a single trusted model becomes the organization standard. Why the correct answer wins: A sensitivity label travels with the exported file.

### Question 89 — A

Answer: Remove the high-cardinality columns the report does not use. A column with almost unique values compresses badly and can dominate model size for no benefit. A column with almost unique values compresses badly and can dominate model size for no analytical benefit. Local study-map skill 2.8 (Model Performance and Granularity), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. A column with almost unique values compresses badly and can dominate model size for no analytical benefit. In this case: A column with almost unique values compresses badly and can dominate model size for no benefit.
- **B:** Incorrect for this question. A pre-aggregated table answers common summaries quickly while the detail stays available for drillthrough. Why the correct answer wins: A column with almost unique values compresses badly and can dominate model size for no benefit.
- **C:** Incorrect for this question. The in-memory store compresses repeated and narrow values well, so trimming high-cardinality text and unused columns is the main size lever. Why the correct answer wins: A column with almost unique values compresses badly and can dominate model size for no benefit.
- **D:** Incorrect for this question. Size work starts with what is loaded, because no DAX rewrite compensates for a model that stores data it never queries. Why the correct answer wins: A column with almost unique values compresses badly and can dominate model size for no benefit.

### Question 90 — B, D

Answers: A waterfall chart; A KPI visual with a target. A waterfall explains the movement between two values, and a KPI visual shows progress against a target. A waterfall explains how a starting value moves to an ending value through additions and subtractions. A KPI visual states progress against a defined target, which a plain card cannot show. Local study-map skill 3.1 (Selecting and Formatting Visuals), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. A funnel shows sequential stage attrition, which suits a sales or process pipeline. Why the correct answer wins: A waterfall explains the movement between two values, and a KPI visual shows progress against a target.
- **B:** Correct. A waterfall explains how a starting value moves to an ending value through additions and subtractions. In this case: A waterfall explains the movement between two values, and a KPI visual shows progress against a target.
- **C:** Incorrect for this question. A matrix supports nested rows and columns with subtotals, which is the report equivalent of a pivot table. Why the correct answer wins: A waterfall explains the movement between two values, and a KPI visual shows progress against a target.
- **D:** Correct. A KPI visual states progress against a defined target, which a plain card cannot show. In this case: A waterfall explains the movement between two values, and a KPI visual shows progress against a target.
- **E:** Incorrect for this question. Bar and column charts compare a measure across categories, which is the right default for ranking or comparison. Why the correct answer wins: A waterfall explains the movement between two values, and a KPI visual shows progress against a target.

### Question 91 — B

Answer: Workspace Viewer role. Viewers read content without editing it. Viewers can read the content but not edit it, which is the safest role for consumers who work inside the workspace. Local study-map skill 4.1 (Workspaces and Workspace Roles), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. Admins manage the workspace, its members, and its settings, which is more than publishing content. Why the correct answer wins: Viewers read content without editing it.
- **B:** Correct. Viewers can read the content but not edit it, which is the safest role for consumers who work inside the workspace. In this case: Viewers read content without editing it.
- **C:** Incorrect for this question. Members can publish and edit all content and add lower-privileged users, but cannot delete the workspace. Why the correct answer wins: Viewers read content without editing it.
- **D:** Incorrect for this question. Contributors can publish and edit content, which is the role for authors who should not manage membership. Why the correct answer wins: Viewers read content without editing it.

### Question 92 — B

Answer: Install an on-premises data gateway. An on-premises data gateway provides the outbound connection for cloud refresh. A gateway provides the outbound connection from the service to an on-premises source, which cloud refresh requires. Local study-map skill 4.4 (Gateways and Scheduled Refresh), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. A personal gateway serves one author and cannot be shared, which makes it unsuitable for team-owned refresh. Why the correct answer wins: An on-premises data gateway provides the outbound connection for cloud refresh.
- **B:** Correct. A gateway provides the outbound connection from the service to an on-premises source, which cloud refresh requires. In this case: An on-premises data gateway provides the outbound connection for cloud refresh.
- **C:** Incorrect for this question. A VNet gateway connects the service to sources inside an Azure virtual network without installing software on a server. Why the correct answer wins: An on-premises data gateway provides the outbound connection for cloud refresh.
- **D:** Incorrect for this question. Scheduled refresh controls how often the imported data is updated, which is the freshness guarantee the report can make. Why the correct answer wins: An on-premises data gateway provides the outbound connection for cloud refresh.

### Question 93 — C

Answer: Use a dynamic RLS rule based on USERPRINCIPALNAME. A dynamic rule matches the signed-in identity to a mapping table. A dynamic rule matches the signed-in user to a mapping table, which avoids maintaining one role per person. Local study-map skill 4.5 (Row-Level Security), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. A static role is simple to reason about but must be maintained every time the org chart changes. Why the correct answer wins: A dynamic rule matches the signed-in identity to a mapping table.
- **B:** Incorrect for this question. An RLS role filters the model per user at query time, which is how one report serves many regions without duplication. Why the correct answer wins: A dynamic rule matches the signed-in identity to a mapping table.
- **C:** Correct. A dynamic rule matches the signed-in user to a mapping table, which avoids maintaining one role per person. In this case: A dynamic rule matches the signed-in identity to a mapping table.
- **D:** Incorrect for this question. The filter compares the model column to the identity the service passes, which is the basis of dynamic security. Why the correct answer wins: A dynamic rule matches the signed-in identity to a mapping table.

### Question 94 — C

Answer: Certify the semantic model. Certification asserts organization-wide trust after a designated review. Certification requires a designated reviewer, which is how a single trusted model becomes the organization standard. Local study-map skill 4.6 (Sensitivity Labels, Endorsement, and Item Access), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI service administration and security documentation: https://learn.microsoft.com/en-us/power-bi/admin/

- **A:** Incorrect for this question. Item-level sharing grants one item without workspace membership, which limits what the recipient can discover. Why the correct answer wins: Certification asserts organization-wide trust after a designated review.
- **B:** Incorrect for this question. Build lets another author create reports on the model without editing it, which is how reuse is enabled safely. Why the correct answer wins: Certification asserts organization-wide trust after a designated review.
- **C:** Correct. Certification requires a designated reviewer, which is how a single trusted model becomes the organization standard. In this case: Certification asserts organization-wide trust after a designated review.
- **D:** Incorrect for this question. Promotion signals the content is ready for reuse by the team, while certification asserts organization-wide trust. Why the correct answer wins: Certification asserts organization-wide trust after a designated review.

### Question 95 — C

Answer: Use LASTNONBLANK or LASTDATE for a semi-additive balance. A balance must be taken at a point in time, not added across dates. Balances such as inventory should not be summed across time, so the measure takes the value at the last date in the period. Local study-map skill 2.6 (Time Intelligence and Semi-Additive Measures), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. A rolling window averages a trailing number of periods, which smooths a noisy series without hiding the current value. Why the correct answer wins: A balance must be taken at a point in time, not added across dates.
- **B:** Incorrect for this question. Year-to-date functions accumulate from the start of the year defined by the marked date table. Why the correct answer wins: A balance must be taken at a point in time, not added across dates.
- **C:** Correct. Balances such as inventory should not be summed across time, so the measure takes the value at the last date in the period. In this case: A balance must be taken at a point in time, not added across dates.
- **D:** Incorrect for this question. LASTNONBLANK finds the most recent date that actually has a value, which handles accounts that are not updated daily. Why the correct answer wins: A balance must be taken at a point in time, not added across dates.

### Question 96 — D

Answer: Use PERCENTILE.INC for a distribution boundary. A percentile returns the boundary value, which describes the tail rather than the average. A percentile returns the value below which a share of observations fall, which describes a distribution rather than an average. Local study-map skill 2.7 (Statistical Functions, Quick Measures, and Calculation Groups), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. A quick measure generates the DAX for a common pattern such as a running total, which is faster and less error-prone than hand-writing it. Why the correct answer wins: A percentile returns the boundary value, which describes the tail rather than the average.
- **B:** Incorrect for this question. Descriptive statistics show the shape of the data, which an average alone hides. Why the correct answer wins: A percentile returns the boundary value, which describes the tail rather than the average.
- **C:** Incorrect for this question. A calculation group applies the same set of variants to every measure, which replaces dozens of near-identical measures. Why the correct answer wins: A percentile returns the boundary value, which describes the tail rather than the average.
- **D:** Correct. A percentile returns the value below which a share of observations fall, which describes a distribution rather than an average. In this case: A percentile returns the boundary value, which describes the tail rather than the average.

### Question 97 — D

Answer: Provide alt text for each meaningful visual. Alt text describes each visual for a screen reader. Alt text describes the visual for a screen reader, which is required for an accessible report. Local study-map skill 3.5 (Accessibility, Mobile Layout, Personalization, and Export), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI report visuals and analytics documentation: https://learn.microsoft.com/en-us/power-bi/visuals/

- **A:** Incorrect for this question. Tab order decides the keyboard sequence, which is how a keyboard user reaches the controls in a sensible order. Why the correct answer wins: Alt text describes each visual for a screen reader.
- **B:** Incorrect for this question. The mobile layout decides what a phone shows first, which is not the same as a squeezed desktop canvas. Why the correct answer wins: Alt text describes each visual for a screen reader.
- **C:** Incorrect for this question. Personalization lets a reader change visual type or fields without edit rights, while the author keeps the published default. Why the correct answer wins: Alt text describes each visual for a screen reader.
- **D:** Correct. Alt text describes the visual for a screen reader, which is required for an accessible report. In this case: Alt text describes each visual for a screen reader.

### Question 98 — B

Answer: Set privacy levels to isolate the sources. Privacy levels prevent values being combined across sources that must stay separate. Privacy levels stop the engine from folding data across sources it should not combine, which prevents accidental exposure of confidential values. Local study-map skill 1.3 (Data Source Settings, Credentials, Privacy Levels, and Parameters), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. Editing the connection keeps the applied steps and lets you repoint an existing query at a new location. Why the correct answer wins: Privacy levels prevent values being combined across sources that must stay separate.
- **B:** Correct. Privacy levels stop the engine from folding data across sources it should not combine, which prevents accidental exposure of confidential values. In this case: Privacy levels prevent values being combined across sources that must stay separate.
- **C:** Incorrect for this question. A parameter lets one query point at different environments without editing the M code, which makes promotion between dev, test, and prod safe. Why the correct answer wins: Privacy levels prevent values being combined across sources that must stay separate.
- **D:** Incorrect for this question. Credentials live with the data source connection in the service, so a changed password must be updated there or refresh fails. Why the correct answer wins: Privacy levels prevent values being combined across sources that must stay separate.

### Question 99 — D

Answer: Add a custom column with an M expression. A custom column concatenates the two fields row by row. A custom column derives a new value row by row, which suits logic that built-in transformations cannot express. Local study-map skill 1.6 (Column Data Types, Custom Columns, and Grouping), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI data preparation documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Incorrect for this question. A conditional column applies explicit if-then rules, which is easier to review than a hand-written expression. Why the correct answer wins: A custom column concatenates the two fields row by row.
- **B:** Incorrect for this question. Extraction keeps the useful part of an identifier without importing the whole string into the model. Why the correct answer wins: A custom column concatenates the two fields row by row.
- **C:** Incorrect for this question. Grouping reduces a transactional table to one row per key, which is the usual shape for a summary or a dimension. Why the correct answer wins: A custom column concatenates the two fields row by row.
- **D:** Correct. A custom column derives a new value row by row, which suits logic that built-in transformations cannot express. In this case: A custom column concatenates the two fields row by row.

### Question 100 — A

Answer: Build a star schema with a fact table and conformed dimensions. A star schema moves descriptive attributes into dimensions and keeps keys and measures in the fact. A star schema puts measurable events in one fact table surrounded by descriptive dimensions, which is the shape the engine and DAX are optimized for. Local study-map skill 2.1 (Designing a Star Schema and Table Properties), mapped to the official guide: Microsoft PL-300 study guide, skills measured as of April 20, 2026 Primary reference: Power BI semantic model and DAX documentation: https://learn.microsoft.com/en-us/power-bi/transform-model/

- **A:** Correct. A star schema puts measurable events in one fact table surrounded by descriptive dimensions, which is the shape the engine and DAX are optimized for. In this case: A star schema moves descriptive attributes into dimensions and keeps keys and measures in the fact.
- **B:** Incorrect for this question. Flattening keeps one hop between fact and filter, which is simpler for report authors and faster for the engine. Why the correct answer wins: A star schema moves descriptive attributes into dimensions and keeps keys and measures in the fact.
- **C:** Incorrect for this question. Properties control how a field behaves in the report: hidden keys disappear from the field list and format strings fix how values display. Why the correct answer wins: A star schema moves descriptive attributes into dimensions and keeps keys and measures in the fact.
- **D:** Incorrect for this question. Snowflaking splits a dimension into related tables, which reduces duplication but adds hops and slows filters. Why the correct answer wins: A star schema moves descriptive attributes into dimensions and keeps keys and measures in the fact.
