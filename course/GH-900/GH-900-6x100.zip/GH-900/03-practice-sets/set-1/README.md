# Full-Length Mock Exam 1 — GH-900: GitHub Foundations

**Theme:** Product Engineering & Web Platform Teams — Git vs GitHub, GitHub Flow, Key Repo Files, Issues/PRs, Actions, Copilot Agents & 2FA/Passkeys

## Set Summary

- **Questions:** `100` (`84` `multiple-choice` balanced `21 A / 21 B / 21 C / 21 D` + `16` `multi-select`)
- **Ordered 4-step sequences (`→`):** `8`
- **Command / path / syntax completions (`____`):** `21`
- **`Proposed solution:` evaluations:** `7`
- **Case studies:** `0` (matching the published GH-900 GitHub Foundations exam format)
- **Recommended timer:** `100 minutes` (matching live GH-900 exam duration; **closed-book**)

## Domain Breakdown

| # | Official GH-900 Domain | Official Weight | Set Count |
|---:|---|---:|---:|
| 1 | Understand Git and GitHub basics | 25–30% | 28 |
| 2 | Work with GitHub repositories | 10–15% | 14 |
| 3 | Collaborate using GitHub | 10–15% | 14 |
| 4 | Apply modern development practices | 10–15% | 14 |
| 5 | Manage projects with GitHub | 5–10% | 8 |
| 6 | Understand privacy, security, and administration | 10–15% | 14 |
| 7 | Explore the GitHub community | 5–10% | 8 |

## Files in This Folder

- `practice-set-1.csv` — 17-column UTF-8-BOM CSV ready for Udemy Bulk Question Upload
- `practice-set-1.md` — Full human-readable question & explanation review key
