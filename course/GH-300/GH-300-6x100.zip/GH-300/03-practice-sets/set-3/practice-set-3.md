# Microsoft / GitHub Exam GH-300: GitHub Copilot — Full-Length Mock Exam 3

**Theme:** Copilot Spaces, Spark, Custom Instructions (applyTo / excludeAgent), Prompt Files & Code Review  
**Credential:** `GitHub Copilot` *(Intermediate · **no prerequisite** · **2-year validity** transitioning to Microsoft Learn recertification)*  
**Study guide baseline:** `August 7, 2026 (Last updated July 9, 2026)` (https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300)  
**Questions:** `100` (`84` `multiple-choice` balanced `21/21/21/21` across A–D + `16` `multi-select`; `0` case studies)  
**Recommended timing:** `100 minutes` (matching Microsoft’s published `100-minute` GH-300 assessment duration · **closed-book: no Microsoft Learn or GitHub Docs access**)

> **Disclaimer:** Independent educational material authored from public Microsoft Learn and GitHub Copilot documentation — not affiliated with or endorsed by Microsoft Corporation or GitHub, Inc. Practice percentages do not equate to Microsoft’s `700 / 1000` scaled score.

## Questions

---

## Domain 1 — Use GitHub Copilot responsibly (15–20% official weight · 18 questions)

### 1. A clinical informatics developer at Clarivance Health uses GitHub Copilot to draft a Python HL7 FHIR pediatric dosage calculator and sees clean `flake8` linting. Why must a clinical domain engineer still verify every unit-conversion formula manually?

- **A.** Generative AI models predict statistically probable token sequences (`not proven correctness`), risking hallucinated APIs, outdated idioms, training-data bias, and subtle security bugs
- **B.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** Automate seat lifecycle via `GET /orgs/{org}/copilot/billing`, `GET .../billing/seats` (`last_activity_at`), and `POST`/`DELETE /orgs/{org}/copilot/billing/selected_users` or `selected_teams` (`manage_billing:copilot`)

### 2. In `clarivance/fhir-ingestor`, Copilot suggests `pip install fhir-hl7v4-sanitizer` in a `Dockerfile`. Before adding that dependency to `pyproject.toml`, what verification prevents a **slopsquatting** supply-chain compromise?

- **A.** Use **GitHub Spark** to build, iterate on, and share AI-powered full-stack micro-apps (`with natural-language prompts, live preview, managed KV persistence, and optional GitHub repository sync`)
- **B.** Verify every AI-suggested package name, publisher, and version in your trusted registry (`preventing slopsquatting / hallucinated dependency attacks`) before installing
- **C.** Inspect **Audit Logs** (`category:copilot`, e.g., `copilot.cfb_seat_created`, `copilot.content_exclusion_changed`) for admin changes and `GET /orgs/{org}/copilot/metrics` (`>=5 active users`) for aggregated usage
- **D.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free

### 3. Clarivance's quality team notices PR review times fell from 25 minutes to 90 seconds on complex RBAC authorization middleware after Copilot adoption, correlating with two authorization-check escapes in staging. Which human-factors risk occurred?

- **A.** Guard against **automation bias / complacency** (`over-trusting plausible-looking AI completions`) by reviewing edge cases, error paths, and security invariants manually
- **B.** Install `@github/copilot` via `npm install -g @github/copilot` (`Node.js 22+`), `winget install GitHub.Copilot`, or Homebrew, launch `copilot` in your repo, run `/login`, and confirm folder trust
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models

### 4. Clarivance Health's HIPAA engineering onboarding module explains common failure modes when teams adopt generative AI coding tools carelessly. Which two failure modes must engineers actively guard against? Select two.

- **A.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **B.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **C.** When assigned an Issue, the Copilot coding agent (`cloud agent`) pushes commits directly to protected `main`, bypasses branch rulesets, and merges its own PR without human review
- **D.** Verify every AI-suggested package name, publisher, and version in your trusted registry (`preventing slopsquatting / hallucinated dependency attacks`) before installing
- **E.** Guard against **automation bias / complacency** (`over-trusting plausible-looking AI completions`) by reviewing edge cases, error paths, and security invariants manually

### 5. Clarivance Health designs a patient-portal appointment scheduler with GitHub Copilot and mandates `Privacy & Security` plus `Reliability & Safety` reviews so system errors fail closed without exposing patient diagnoses. How many core Responsible AI principles anchor Microsoft and GitHub's framework? (`____` principles)

- **A.** Use `copilot -p "..."` for non-interactive runs (`-s` for clean stdout, `--output-format=json` for JSONL), `--available-tools` / `--deny-tool` for tool scoping, and `--fleet` for parallel subagents
- **B.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **C.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **D.** Apply the six Responsible AI principles—**Fairness**, **Reliability & Safety**, **Privacy & Security**, **Inclusiveness**, **Transparency**, and **Accountability**

### 6. A developer at Clarivance blames `"Copilot wrote that SQL query"` during a post-incident review after an unindexed query slowed down lab reporting. How does Responsible AI **Accountability** address this excuse?

- **A.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **B.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **C.** Maintain **Transparency** and **Accountability** by disclosing AI assistance per team norms, honoring open-source licenses, and ensuring humans own every committed line
- **D.** When assigned an Issue, the Copilot coding agent (`cloud agent`) pushes commits directly to protected `main`, bypasses branch rulesets, and merges its own PR without human review

### 7. When generating a clinical intake form in React with Copilot, the initial completion offers only a binary gender enum and omits keyboard focus indicators (`tabIndex` / ARIA labels). Which two Responsible AI principles require revising that component before release?

- **A.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions
- **B.** Evaluate AI-generated UI copy, validation rules, and domain models for **Fairness** and **Inclusiveness** (`avoiding demographic stereotyping, exclusionary naming, or accessibility regressions`)
- **C.** Automate seat lifecycle via `GET /orgs/{org}/copilot/billing`, `GET .../billing/seats` (`last_activity_at`), and `POST`/`DELETE /orgs/{org}/copilot/billing/selected_users` or `selected_teams` (`manage_billing:copilot`)
- **D.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically

### 8. Clarivance Health's AI Ethics Committee audits three new patient-facing microservices built with GitHub Copilot. Which three ethical criteria belong in the audit checklist? Select three.

- **A.** Apply the six Responsible AI principles—**Fairness**, **Reliability & Safety**, **Privacy & Security**, **Inclusiveness**, **Transparency**, and **Accountability**
- **B.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **C.** Maintain **Transparency** and **Accountability** by disclosing AI assistance per team norms, honoring open-source licenses, and ensuring humans own every committed line
- **D.** When assigned an Issue, the Copilot coding agent (`cloud agent`) pushes commits directly to protected `main`, bypasses branch rulesets, and merges its own PR without human review
- **E.** Evaluate AI-generated UI copy, validation rules, and domain models for **Fairness** and **Inclusiveness** (`avoiding demographic stereotyping, exclusionary naming, or accessibility regressions`)
- **F.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free

### 9. A Python developer asks Copilot for password hashing in `clarivance/patient-auth` and sees legacy `hashlib.sha1(pw.encode()).hexdigest()`. Which repository customization plus CI check prevents weak cryptographic defaults from shipping?

- **A.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **B.** Mitigate AI harms (`historical dataset bias, weak crypto/SQL defaults, PII exposure, and insecure scaffolding`) using RAI filters, `CodeQL` SAST, secret scanning, and diverse test suites
- **C.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions
- **D.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free

### 10. Clarivance connects a clinical documentation search MCP tool to VS Code Agent Mode. An imported third-party Markdown note embeds hidden HTML comments telling the agent to upload `.env` to an external webhook. What safeguard stops exfiltration?

- **A.** GitHub Copilot CLI requires Python 2.7, executes every `rm -rf` and file write silently without permission prompts by default, and stores plaintext passwords in `~/.copilot/config.json`
- **B.** `#runSubagent` merges every raw intermediate grep output directly into the main chat's token window and pauses mid-search to interview the user after every file read
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** Treat untrusted external content (`issues, PR bodies, web pages, third-party MCP tool outputs`) as **indirect prompt injection** risks and require human approval on tool actions

### 11. Under HIPAA security rules, Clarivance Health must ensure protected health information (`PHI`) never enters developer prompts and hardcoded API tokens never reach GitHub branches. Which two controls enforce this? Select two.

- **A.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models
- **B.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **C.** Never paste live customer PII, PHI, production database dumps, or active credentials/private keys into Copilot prompts or sample fixtures
- **D.** Enforce automated CI guardrails (`CodeQL` code scanning, Secret Scanning Push Protection, and Dependabot) on every branch containing AI-generated code
- **E.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions

### 12. A Clarivance FastAPI engineer uses Copilot to build an HL7 ADT message parser. Place the Responsible AI verification steps in the required order prior to merging.

- **A.** Prompt Copilot with explicit security & type constraints → Review logic & verify suggested packages exist in trusted registries → Run unit/edge-case tests plus `CodeQL` & secret scanning → Complete human peer PR review before merging
- **B.** Set public-code filtering to `Allow` → Paste live customer PII into Chat as sample fixtures → Run unit tests locally → Self-approve your own pull request
- **C.** Merge Copilot output directly to `main` → Run `CodeQL` weekly in production → Check package names only if builds fail → Skip human review when Copilot Code Review leaves zero comments
- **D.** Approve an empty PR branch first → Disable `CodeQL` to speed up Copilot completions → Install unfamiliar suggested packages blindly from public registries → Deploy without unit tests

### 13. Copilot generates a Python `datetime` medication-window check using naive `datetime.now()` instead of timezone-aware `datetime.now(datetime.UTC)`, causing 1-hour shifts on Daylight Saving Time transitions. How should teams catch subtle semantic bugs like this?

- **A.** Mock the function under test itself to return `200 OK` and assert `expect(true).toBe(true)` so test coverage reaches `100%` without exercising edge cases
- **B.** Treat Copilot as a **pair-programming assistant (`not an oracle`)**: review diffs line-by-line, execute unit/integration/edge-case tests, and scan with `CodeQL` and Dependabot
- **C.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **D.** When assigned an Issue, the Copilot coding agent (`cloud agent`) pushes commits directly to protected `main`, bypasses branch rulesets, and merges its own PR without human review

### 14. Why can Copilot Chat propose `pydantic.field_validator` in one session and legacy `@validator` (`Pydantic v1`) in another session when the prompt omits version details?

- **A.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **B.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **C.** Because LLM sampling is **stochastic (`non-deterministic`)**, identical prompts can yield varying implementations whose runtime behavior, complexity, and thread safety must be verified
- **D.** Automate seat lifecycle via `GET /orgs/{org}/copilot/billing`, `GET .../billing/seats` (`last_activity_at`), and `POST`/`DELETE /orgs/{org}/copilot/billing/selected_users` or `selected_teams` (`manage_billing:copilot`)

### 15. Clarivance Health's HIPAA SOC 2 control requires independent peer approval on every production pull request (`Required approvals = 1`). Proposed solution: Configure Automatic Copilot Code Review on `main` so Copilot's automated review counts as the `1` required approval when solo on-call engineers push hotfixes. Does this meet the goal?

- **A.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **B.** No — **Copilot Code Review** posts `Comment` reviews (`never Approve` reviews that satisfy required human branch-protection approver counts); a human reviewer must still approve
- **C.** Yes — this design satisfies all stated GitHub Copilot technical, governance, security, and privacy requirements
- **D.** When assigned an Issue, the Copilot coding agent (`cloud agent`) pushes commits directly to protected `main`, bypasses branch rulesets, and merges its own PR without human review

### 16. Which four operational guardrails form Clarivance Health's standard **Copilot Enterprise** operating baseline for clinical software squads?

- **A.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **B.** Operate Copilot responsibly by keeping `Suggestions matching public code = Block`, configuring Content Exclusions, omitting PII/secrets from prompts, and enforcing human PR review
- **C.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions
- **D.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits

### 17. Clarivance Health wants **Copilot Code Review** on GitHub.com PRs to check FastAPI endpoints against HIPAA logging rules (`never log MRN, SSN, or DOB`), while keeping human required reviewers active. Proposed solution: Commit concise HIPAA logging check rules to `.github/instructions/hipaa-logging.instructions.md` (`applyTo: "app/**/*.py"`, with `excludeAgent` omitted), enable Automatic Copilot Code Review via an Org Branch Ruleset, and require `1` human approval. Does this meet the goal?

- **A.** Yes — this design satisfies all stated GitHub Copilot technical, governance, security, and privacy requirements
- **B.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files
- **C.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **D.** No — setting `excludeAgent: "code-review"` in `.instructions.md` frontmatter explicitly **prevents** Copilot Code Review from using that file (`use applyTo: without excluding code-review`)

### 18. Besides developer vigilance, which repository control helps Clarivance automatically flag known vulnerable or malicious transitive dependencies if an AI-suggested package is added in a pull request?

- **A.** Verify every AI-suggested package name, publisher, and version in your trusted registry (`preventing slopsquatting / hallucinated dependency attacks`) before installing
- **B.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **C.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **D.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free

---

## Domain 2 — Use GitHub Copilot features (25–30% official weight · 28 questions)

### 19. Clarivance data scientists work in **VS Code Jupyter Notebooks (`.ipynb`)** and **JetBrains PyCharm**. After installing the GitHub Copilot extension and signing in with their SSO-linked GitHub Enterprise account, does Copilot support inline completions and Chat inside `.ipynb` notebook code cells?

- **A.** Inspect **Audit Logs** (`category:copilot`, e.g., `copilot.cfb_seat_created`, `copilot.content_exclusion_changed`) for admin changes and `GET /orgs/{org}/copilot/metrics` (`>=5 active users`) for aggregated usage
- **B.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **C.** GitHub Copilot CLI requires Python 2.7, executes every `rm -rf` and file write silently without permission prompts by default, and stores plaintext passwords in `~/.copilot/config.json`
- **D.** Install the official GitHub Copilot extension in a supported IDE (`VS Code, Visual Studio, JetBrains, Xcode, Eclipse, or Neovim`), sign in via GitHub OAuth, and verify an active seat

### 20. An independent health-tech founder evaluating prototypes personally wants the highest individual model-request allowance, access to full reasoning/frontier models, and **GitHub Spark** micro-app creation without setting up a corporate Organization. Complete the top individual plan tier: `GitHub Copilot ____`.

- **A.** Choose **Copilot Free** for capped monthly completions/chats or **Copilot Pro / Pro+** for individual developers needing unlimited completions, higher premium-model quotas, and **GitHub Spark**
- **B.** Choose **Copilot Business** (`Org policies, Content Exclusions, IP Indemnity, zero model training`) or **Copilot Enterprise** (`adds GHEC Copilot Spaces/Knowledge Bases & org-wide GitHub.com grounding`)
- **C.** No — Repository and Organization **Content Exclusions** require **Copilot Business or Copilot Enterprise**; personal Copilot Free/Pro/Pro+ plans do not support Org Content Exclusions
- **D.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models

### 21. A Clarivance developer wants to update a FHIR patient Pydantic model (`schemas.py`), its SQLAlchemy mapper (`models.py`), and its FastAPI router (`routes.py`) simultaneously while previewing coordinated file diffs in a bounded 3-file working set (`without terminal shell execution`). Which Copilot mode fits best?

- **A.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **B.** No — Copilot Chat **`Ask` mode** only answers questions and proposes snippets in chat; autonomous multi-file workspace edits with iterative terminal test execution require **Agent Mode** (`or Copilot CLI`)
- **C.** Match interaction surfaces to scope: **Inline Chat (`Ctrl+I` / `Cmd+I`)** for in-place file edits, **Chat `Ask`** for Q&A, **Copilot Edits** for multi-file working sets, and **Agent Mode / CLI** for autonomous loops
- **D.** Save prompt files as `.git/hooks/pre-commit.yml` with `on: workflow_dispatch` so Copilot Chat automatically runs them on every keystroke

### 22. Clarivance engineers choose between four Copilot triggers: `(1)` `Ask` mode, `(2)` `Inline Chat`, `(3)` `Agent Mode`, and `(4)` `GitHub Copilot CLI`. Which two statements accurately match triggers `(3)` and `(4)`? Select two.

- **A.** Match interaction surfaces to scope: **Inline Chat (`Ctrl+I` / `Cmd+I`)** for in-place file edits, **Chat `Ask`** for Q&A, **Copilot Edits** for multi-file working sets, and **Agent Mode / CLI** for autonomous loops
- **B.** No — Copilot Chat **`Ask` mode** only answers questions and proposes snippets in chat; autonomous multi-file workspace edits with iterative terminal test execution require **Agent Mode** (`or Copilot CLI`)
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** Save prompt files as `.git/hooks/pre-commit.yml` with `on: workflow_dispatch` so Copilot Chat automatically runs them on every keystroke
- **E.** GitHub Copilot CLI (`copilot`) is a terminal-native AI coding agent that understands shell context, edits files, executes commands with approval prompts, and automates multi-step repo workflows

### 23. In `clarivance/ehr-connector`, an administrator adds `- "/certs/*.pem"` and `- "/mappings/epic_proprietary_*.json"` under Repository `Settings -> Copilot -> Content exclusion`. Which pattern-matching syntax does GitHub Copilot Content Exclusion use? (`____` globs)

- **A.** Configuring Copilot Content Exclusions also blocks `git clone`, GitHub Actions runners, and `CodeQL` security scans from reading the excluded files
- **B.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files
- **C.** No — `.gitignore` only prevents untracked files from being staged by Git; excluding tracked repository files from Copilot requires **Copilot Content Exclusions** (`Settings -> Copilot -> Content exclusion`)
- **D.** Configure Repository or Organization **Content Exclusions** (`Settings -> Copilot -> Content exclusion`) so IDEs omit matched sensitive files across completions, Chat, and code review

### 24. Can an Organization Owner configure a single Organization-level **Content Exclusion** YAML mapping that targets `clarivance/ehr-connector` specifically AND another `*` wildcard entry that protects `- "**/.env*"` across **every** repository in the organization?

- **A.** Configuring Copilot Content Exclusions also blocks `git clone`, GitHub Actions runners, and `CodeQL` security scans from reading the excluded files
- **B.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **C.** Configure Repository or Organization **Content Exclusions** (`Settings -> Copilot -> Content exclusion`) so IDEs omit matched sensitive files across completions, Chat, and code review
- **D.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic

### 25. A Clarivance bioinformatics engineer runs pipelines on remote Linux workstations via `tmux` and asks whether **GitHub Copilot CLI** can inspect multiple repository files, create a new Python CLI module, run `pytest`, and open a pull request directly from the terminal. Can it?

- **A.** GitHub Copilot CLI (`copilot`) is a terminal-native AI coding agent that understands shell context, edits files, executes commands with approval prompts, and automates multi-step repo workflows
- **B.** GitHub Copilot CLI requires Python 2.7, executes every `rm -rf` and file write silently without permission prompts by default, and stores plaintext passwords in `~/.copilot/config.json`
- **C.** Inspect **Audit Logs** (`category:copilot`, e.g., `copilot.cfb_seat_created`, `copilot.content_exclusion_changed`) for admin changes and `GET /orgs/{org}/copilot/metrics` (`>=5 active users`) for aggregated usage
- **D.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic

### 26. A Clarivance DevOps engineer installs **GitHub Copilot CLI** on Ubuntu 24.04 (`with Node.js 22 LTS`) and initializes it inside `~/src/fhir-gateway`. Place the four steps in exact order.

- **A.** Run `/login` in raw Bash before installing `@github/copilot` → Pass `--allow-all` on `/` root filesystem → Write plaintext passwords into `~/.copilot/config.json` → Downgrade to Node.js `14`
- **B.** Clone the repo inside `~/.copilot/logs/` → Set `Suggestions matching public code` to `Allow` → Run `gh auth logout` → Expect silent file edits without permission prompts
- **C.** Install `@github/copilot` → Delete `~/.copilot/session-store.db` before signing in → Disable the Organization Copilot CLI policy → Run `copilot -p` unauthenticated
- **D.** Install Node.js `22+` (or WinGet/Homebrew) & `npm install -g @github/copilot` → `cd` into the project directory & launch `copilot` → Enter `/login` to complete GitHub OAuth authentication → Confirm directory trust & verify `/permissions show`

### 27. On Windows 11 developer laptops managed via WinGet (`without global npm`), complete the official WinGet package installation command for GitHub Copilot CLI: `winget install ____`.

- **A.** Install `@github/copilot` via `npm install -g @github/copilot` (`Node.js 22+`), `winget install GitHub.Copilot`, or Homebrew, launch `copilot` in your repo, run `/login`, and confirm folder trust
- **B.** Save prompt files as `.git/hooks/pre-commit.yml` with `on: workflow_dispatch` so Copilot Chat automatically runs them on every keystroke
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** GitHub Copilot CLI requires Python 2.7, executes every `rm -rf` and file write silently without permission prompts by default, and stores plaintext passwords in `~/.copilot/config.json`

### 28. In an automated local pre-PR check, a Clarivance script runs `copilot -p "Check changed SQL migrations for missing CONCURRENTLY on indexes" --____`. Which flag prevents the CLI agent from pausing mid-run to ask clarifying questions in headless mode? (`--no-ask-user`)

- **A.** Use `copilot -p "..."` for non-interactive runs (`-s` for clean stdout, `--output-format=json` for JSONL), `--available-tools` / `--deny-tool` for tool scoping, and `--fleet` for parallel subagents
- **B.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** GitHub Copilot CLI requires Python 2.7, executes every `rm -rf` and file write silently without permission prompts by default, and stores plaintext passwords in `~/.copilot/config.json`

### 29. A Clarivance security engineer hardens a non-interactive `copilot -p` compliance check so the agent `(1)` CANNOT invoke shell execution tool `bash` (`or URLs outside internal docs`) and `(2)` never exposes `FHIR_CLIENT_SECRET` in output logs. Which two CLI configurations enforce this? Select two.

- **A.** Use `copilot -p "..."` for non-interactive runs (`-s` for clean stdout, `--output-format=json` for JSONL), `--available-tools` / `--deny-tool` for tool scoping, and `--fleet` for parallel subagents
- **B.** Scope non-interactive Copilot CLI automation with `--available-tools` / `--deny-tool`, `--secret-env-vars` redaction, and single-run `--trust-folder` rather than blanket `--allow-all`
- **C.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models
- **D.** GitHub Copilot CLI requires Python 2.7, executes every `rm -rf` and file write silently without permission prompts by default, and stores plaintext passwords in `~/.copilot/config.json`
- **E.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits

### 30. During an interactive `copilot` CLI session, Copilot generates temporary scratch analysis files that shouldn't be committed to Git, plus an implementation plan. Complete the interactive slash commands to inspect those session artifacts and the plan: `/session ____` and `/session plan`.

- **A.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **B.** GitHub Copilot CLI requires Python 2.7, executes every `rm -rf` and file write silently without permission prompts by default, and stores plaintext passwords in `~/.copilot/config.json`
- **C.** Use Copilot CLI **infinite sessions** (auto-compaction under `~/.copilot/session-state/{id}/`), inspect `/session plan`, `/session checkpoints`, and `/session files`, and resume via `--resume` or `--continue`
- **D.** `#runSubagent` merges every raw intermediate grep output directly into the main chat's token window and pauses mid-search to interview the user after every file read

### 31. A Clarivance developer deletes `~/.copilot/session-state/` on their laptop expecting synced cloud session transcripts on GitHub.com to vanish automatically as well. Is that true?

- **A.** GitHub Copilot CLI requires Python 2.7, executes every `rm -rf` and file write silently without permission prompts by default, and stores plaintext passwords in `~/.copilot/config.json`
- **B.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **C.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files
- **D.** Use Copilot CLI **infinite sessions** (auto-compaction under `~/.copilot/session-state/{id}/`), inspect `/session plan`, `/session checkpoints`, and `/session files`, and resume via `--resume` or `--continue`

### 32. Which two environment variables does **GitHub Copilot CLI** automatically redact from session output **by default** (`even before you pass custom variable names to --secret-env-vars`)? (`GITHUB_TOKEN` and `____`)

- **A.** Configuring Copilot Content Exclusions also blocks `git clone`, GitHub Actions runners, and `CodeQL` security scans from reading the excluded files
- **B.** When assigned an Issue, the Copilot coding agent (`cloud agent`) pushes commits directly to protected `main`, bypasses branch rulesets, and merges its own PR without human review
- **C.** Generate scripts and edit files safely in Copilot CLI via interactive **permission prompts** (`write`, `commands`), `--add-dir` for extra paths, `--secret-env-vars` redaction, and `--share` / `--share-gist`
- **D.** GitHub Copilot CLI requires Python 2.7, executes every `rm -rf` and file write silently without permission prompts by default, and stores plaintext passwords in `~/.copilot/config.json`

### 33. A Clarivance engineer edits `~/.copilot/config.json` manually to set preferred theme and model defaults, yet Copilot CLI ignores those edits on restart. Which file in `~/.copilot/` actually holds user-editable settings (`while config.json holds internal runtime state`)? (`~/.copilot/____.json`)

- **A.** GitHub Copilot CLI requires Python 2.7, executes every `rm -rf` and file write silently without permission prompts by default, and stores plaintext passwords in `~/.copilot/config.json`
- **B.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** Inside interactive Copilot CLI, use `/permissions show` or `/permissions manual` to inspect/set approval mode, `--model` to pin a model, and `~/.copilot/settings.json` for user preferences

### 34. A Clarivance engineer wires an OpenAPI FHIR validator **MCP** server into VS Code **Agent Mode** and uses **`#runSubagent`** to catalog 45 resource endpoints before generating FastAPI routers. Order the four steps.

- **A.** Register the MCP server in `.vscode/mcp.json` & verify tools → Delegate broad codebase search to isolated `#runSubagent` → Apply multi-file edits & run terminal tests in Agent Mode → Inspect working-set diffs & `Keep` verified changes
- **B.** Define MCP servers inside `.git/HEAD` → Run `/clear` after every single edit so Agent Mode loses its plan → Skip working-set diff inspection → Force-push to `main`
- **C.** Accept (`Keep`) all generated edits before running tests → Add `.vscode/mcp.json` after closing VS Code → Attach 80 unrelated files to main chat → Switch to `Ask` mode expecting autonomous test loops
- **D.** Commit plaintext MCP API keys to `.github/copilot-instructions.md` → Expect `#runSubagent` to pause mid-run for interactive Q&A → Disable all workspace tools → Auto-push unreviewed edits to `main`

### 35. To share a team-standard **Model Context Protocol (`MCP`)** server configuration (`such as a local SQLite/Postgres schema inspector or GitHub MCP server`) in version control for VS Code Agent Mode without hardcoding secrets, which workspace file should Clarivance commit (`using ${input:...} prompts for tokens`)? (`.vscode/____.json`)

- **A.** No — Copilot Chat **`Ask` mode** only answers questions and proposes snippets in chat; autonomous multi-file workspace edits with iterative terminal test execution require **Agent Mode** (`or Copilot CLI`)
- **B.** `#runSubagent` merges every raw intermediate grep output directly into the main chat's token window and pauses mid-search to interview the user after every file read
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** Use **Agent Mode** with `.vscode/mcp.json` **Model Context Protocol (`MCP`)** servers to query external tools, edit multiple files, read compiler/terminal diagnostics, and self-heal until tests pass

### 36. Clarivance Health's architecture guild documents how VS Code **Agent Sessions**, **`#runSubagent`**, and the **Copilot coding agent** collaborate across local and cloud workflows. Which three statements are accurate? Select three.

- **A.** Monitor local IDE, CLI, and cloud coding agents from the unified **Agent Sessions** view (`steering mid-run via chat editors`) and delegate noisy codebase research to **`#runSubagent`** for isolated context
- **B.** No — Copilot Chat **`Ask` mode** only answers questions and proposes snippets in chat; autonomous multi-file workspace edits with iterative terminal test execution require **Agent Mode** (`or Copilot CLI`)
- **C.** `#runSubagent` merges every raw intermediate grep output directly into the main chat's token window and pauses mid-search to interview the user after every file read
- **D.** Assign a GitHub Issue or PR comment (`@copilot`) to the **Copilot coding agent (`cloud agent`)**, which runs in an ephemeral Actions sandbox, pushes to `copilot/*`, and opens a draft PR for human review
- **E.** When assigned an Issue, the Copilot coding agent (`cloud agent`) pushes commits directly to protected `main`, bypasses branch rulesets, and merges its own PR without human review
- **F.** Use **Agent Mode** with `.vscode/mcp.json` **Model Context Protocol (`MCP`)** servers to query external tools, edit multiple files, read compiler/terminal diagnostics, and self-heal until tests pass

### 37. A Clarivance developer opens a **Draft** pull request on GitHub.com for early architecture feedback and notices Automatic Copilot Code Review hasn't run yet. Which repository/user Code Review toggle enables reviews before a PR is marked `Ready for review`? (`Review ____ pull requests`)

- **A.** When assigned an Issue, the Copilot coding agent (`cloud agent`) pushes commits directly to protected `main`, bypasses branch rulesets, and merges its own PR without human review
- **B.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **C.** No — **Copilot Code Review** posts `Comment` reviews (`never Approve` reviews that satisfy required human branch-protection approver counts); a human reviewer must still approve
- **D.** Run **Copilot Code Review** locally on uncommitted IDE diffs or on GitHub.com PRs (`with Automatic Copilot code review, Review new pushes, and Review draft pull requests`), paired with human approval

### 38. On GitHub.com, if Automatic Copilot Code Review is NOT enabled on a repository, how can an authorized developer manually request a Copilot review on a specific pull request `#208`?

- **A.** Run **Copilot Code Review** locally on uncommitted IDE diffs or on GitHub.com PRs (`with Automatic Copilot code review, Review new pushes, and Review draft pull requests`), paired with human approval
- **B.** Automate seat lifecycle via `GET /orgs/{org}/copilot/billing`, `GET .../billing/seats` (`last_activity_at`), and `POST`/`DELETE /orgs/{org}/copilot/billing/selected_users` or `selected_teams` (`manage_billing:copilot`)
- **C.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **D.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic

### 39. Clarivance Health wants every PR in `clarivance/*` to receive automatic **Copilot Code Review** enforcing custom SQLAlchemy query parameterization rules scoped to `db/**/*.sql` (`and app/repositories/**/*.py`) alongside human approval. Order the setup steps.

- **A.** Commit a 500-page binary `.pdf` in `.github/prompts/` → Disable repository custom instructions in Settings → Trigger inline Tab completion → Expect PRs to auto-merge
- **B.** Save rules in `/tmp/review.txt` without `applyTo:` frontmatter → Block Copilot Code Review in Enterprise `AI controls` → Open a draft PR with draft reviews disabled → Expect automatic Copilot comments
- **C.** Set `excludeAgent: "code-review"` in `sql.instructions.md` → Expect Copilot Code Review to apply that file anyway → Remove human approvers so Copilot unlocks merges → Leave the instructions file untracked
- **D.** Add `.github/instructions/sql.instructions.md` (`applyTo: "db/**/*.sql"`) → Merge SQL rules to the default branch → Enable `Automatically request Copilot code review` in an Org Ruleset → Resolve Copilot comments alongside human PR approval

### 40. A Clarivance clinical operations lead wants to prototype an interactive triage-shift calculator micro-app in minutes using natural-language prompts, live visual previews, built-in key-value data persistence, and optional sync to a GitHub repository. Complete the GitHub tool name: `GitHub ____`.

- **A.** Save prompt files as `.git/hooks/pre-commit.yml` with `on: workflow_dispatch` so Copilot Chat automatically runs them on every keystroke
- **B.** Automate seat lifecycle via `GET /orgs/{org}/copilot/billing`, `GET .../billing/seats` (`last_activity_at`), and `POST`/`DELETE /orgs/{org}/copilot/billing/selected_users` or `selected_teams` (`manage_billing:copilot`)
- **C.** Curate **Copilot Spaces** on GitHub.com (`grouping specific repositories, files, PRs, issues, free-text notes, and custom instructions`) to ground team Q&A and IDE MCP queries on authoritative org context
- **D.** Use **GitHub Spark** to build, iterate on, and share AI-powered full-stack micro-apps (`with natural-language prompts, live preview, managed KV persistence, and optional GitHub repository sync`)

### 41. Clarivance wants `(1)` a centralized, shareable collection of clinical microservice repos, HL7 mapping specs, and custom instructions for cross-repo onboarding Q&A and `(2)` a repository instruction file read ONLY by the **Copilot cloud coding agent** (`skipping Copilot Code Review`). Which two configurations achieve this? Select two.

- **A.** No — setting `excludeAgent: "code-review"` in `.instructions.md` frontmatter explicitly **prevents** Copilot Code Review from using that file (`use applyTo: without excluding code-review`)
- **B.** Create modular `.github/instructions/*.instructions.md` files with YAML frontmatter `applyTo:` globs (`and optional excludeAgent: "code-review" | "cloud-agent"`) for path-specific standards
- **C.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files
- **D.** Save prompt files as `.git/hooks/pre-commit.yml` with `on: workflow_dispatch` so Copilot Chat automatically runs them on every keystroke
- **E.** Curate **Copilot Spaces** on GitHub.com (`grouping specific repositories, files, PRs, issues, free-text notes, and custom instructions`) to ground team Q&A and IDE MCP queries on authoritative org context

### 42. Compare `.github/instructions/fastapi.instructions.md` with `.github/prompts/new-fhir-route.prompt.md`: how does **activation** differ between custom instruction files and prompt files in VS Code?

- **A.** Inspect **Audit Logs** (`category:copilot`, e.g., `copilot.cfb_seat_created`, `copilot.content_exclusion_changed`) for admin changes and `GET /orgs/{org}/copilot/metrics` (`>=5 active users`) for aggregated usage
- **B.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files
- **C.** Save prompt files as `.git/hooks/pre-commit.yml` with `on: workflow_dispatch` so Copilot Chat automatically runs them on every keystroke
- **D.** Enable `"chat.promptFiles": true` and commit reusable `.github/prompts/*.prompt.md` files (`YAML frontmatter: description, agent, model, tools` + Markdown `#file:` links) invoked via `/prompt-name`

### 43. In VS Code and GitHub.com Copilot Chat, Clarivance engineers combine `@github` / `@workspace` participants with reusable `.prompt.md` files. Which two statements are accurate? Select two.

- **A.** Scope Copilot Chat with participants (`@workspace`, `@github`, `@vscode`, `@terminal`), slash commands (`/explain`, `/fix`, `/tests`, `/doc`, `/new`, `/clear`), `#file:`/`#codebase` variables, and thumbs feedback
- **B.** Store reusable `.github/prompts/*.prompt.md` templates (`enabled via "chat.promptFiles": true`) with `agent`, `model`, and `tools` frontmatter for on-demand `/prompt-name` invocation
- **C.** Save prompt files as `.git/hooks/pre-commit.yml` with `on: workflow_dispatch` so Copilot Chat automatically runs them on every keystroke
- **D.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **E.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically

### 44. Clarivance Health's CISO learns that standard Organization Copilot policies only govern users whose Copilot seat comes **from that organization**, leaving a gap if a contractor brings a personal Copilot Pro+ license into an enterprise repo. Which Enterprise control closes that gap for cloud agent and code review?

- **A.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **B.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **C.** Use Enterprise `AI controls -> Agents` (`Block Copilot cloud agent` / `Block Copilot code review`) and `Only allow Copilot code review to be triggered by authorized users` to govern enterprise repos
- **D.** No — Repository and Organization **Content Exclusions** require **Copilot Business or Copilot Enterprise**; personal Copilot Free/Pro/Pro+ plans do not support Org Content Exclusions

### 45. In GitHub Organization Audit Logs (`Settings -> Logs -> Audit log`), complete the search qualifier that filters specifically for Copilot administrative events (`seat assignments, policy updates, content-exclusion edits`): `category:____`.

- **A.** No — `GET /orgs/{org}/copilot/metrics` returns **aggregated, anonymized** team/org usage (`requiring >=5 active users`), NOT per-developer `last_activity_at` usernames; query `GET /orgs/{org}/copilot/billing/seats`
- **B.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models
- **C.** Inspect **Audit Logs** (`category:copilot`, e.g., `copilot.cfb_seat_created`, `copilot.content_exclusion_changed`) for admin changes and `GET /orgs/{org}/copilot/metrics` (`>=5 active users`) for aggregated usage
- **D.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions

### 46. Mid-way through a monthly billing cycle (`on November 12`), Clarivance's automation calls `DELETE /orgs/clarivance/copilot/billing/selected_users` to cancel departing contractor `dev-alex`'s Copilot Business seat. When does `dev-alex`'s access end, and how are mid-cycle seat cancellations billed?

- **A.** No — `GET /orgs/{org}/copilot/metrics` returns **aggregated, anonymized** team/org usage (`requiring >=5 active users`), NOT per-developer `last_activity_at` usernames; query `GET /orgs/{org}/copilot/billing/seats`
- **B.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **C.** Automate seat lifecycle via `GET /orgs/{org}/copilot/billing`, `GET .../billing/seats` (`last_activity_at`), and `POST`/`DELETE /orgs/{org}/copilot/billing/selected_users` or `selected_teams` (`manage_billing:copilot`)
- **D.** Choose **Copilot Free** for capped monthly completions/chats or **Copilot Pro / Pro+** for individual developers needing unlimited completions, higher premium-model quotas, and **GitHub Spark**

---

## Domain 3 — Understand GitHub Copilot data and architecture (10–15% official weight · 14 questions)

### 47. Clarivance Health signs a HIPAA Business Associate / Enterprise agreement on GitHub Enterprise Cloud (`Copilot Enterprise`). Are prompts sent from PyCharm or GitHub.com Chat shared with third-party model vendors to train their public foundation models?

- **A.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **B.** On **Copilot Business & Enterprise**, prompts and completions travel over `TLS 1.2+`, process ephemerally in memory for inline completions, and are **never retained to train foundational models**
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models

### 48. Which encryption standards protect Clarivance's Copilot data **(1) in transit** across the network (`TLS ____+`) and **(2) at rest** (`AES-____`) when persisted (`such as engagement telemetry or saved GitHub.com chat threads`)?

- **A.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models
- **B.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **C.** Distinguish **user engagement telemetry** (`acceptance/dismissal counts, latency, IDE version, encrypted at rest`) from **source-code prompts/suggestions** (`discarded after inline inference on Business/Enterprise`)
- **D.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions

### 49. Why is it critical that Clarivance developers sign into their IDE with their **clarivance-governed Copilot Enterprise identity** rather than a personal **Copilot `____`** account left signed in with default settings?

- **A.** Automate seat lifecycle via `GET /orgs/{org}/copilot/billing`, `GET .../billing/seats` (`last_activity_at`), and `POST`/`DELETE /orgs/{org}/copilot/billing/selected_users` or `selected_teams` (`manage_billing:copilot`)
- **B.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **C.** On Individual plans (`Copilot Free / Pro / Pro+`), disable `Allow GitHub to use my code snippets from the code editor for product improvements` in GitHub Copilot settings to opt out of model training
- **D.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models

### 50. Inside `app/services/dosage.py`, a developer writes `def calc_creatinine_clearance(age: int, weight_kg: float, scr: float) -> float:` on line 10 and `return round(crcl_ml_min, 2)` on line 22, placing the cursor on line 15. How does **Fill-in-the-Middle (`____`)** use line 22?

- **A.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **B.** The IDE extension constructs prompts from **Fill-in-the-Middle (`FIM`)** cursor prefix + suffix, language/filepath metadata, Jacobi/Jaccard-ranked snippets from open tabs, and custom instructions
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** Automate seat lifecycle via `GET /orgs/{org}/copilot/billing`, `GET .../billing/seats` (`last_activity_at`), and `POST`/`DELETE /orgs/{org}/copilot/billing/selected_users` or `selected_teams` (`manage_billing:copilot`)

### 51. When GitHub Copilot CLI or VS Code discovers both user-level instructions (`~/.copilot/copilot-instructions.md`) and repository-wide instructions (`.github/____-instructions.md` + matching `*.instructions.md`), how are they handled?

- **A.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **B.** The IDE extension constructs prompts from **Fill-in-the-Middle (`FIM`)** cursor prefix + suffix, language/filepath metadata, Jacobi/Jaccard-ranked snippets from open tabs, and custom instructions
- **C.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files
- **D.** Save prompt files as `.git/hooks/pre-commit.yml` with `on: workflow_dispatch` so Copilot Chat automatically runs them on every keystroke

### 52. Clarivance's AI engineering lead diagrams Copilot's prompt-construction pipeline across IDE inline completions and `@workspace` Chat. Which two architectural mechanisms belong in the diagram? Select two.

- **A.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **B.** For `@workspace` and GitHub.com repository chat, Copilot uses **lexical and semantic (`embedding`) retrieval (`RAG`)** to inject top-ranked code chunks into the prompt rather than sending entire gigabyte repos
- **C.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models
- **D.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **E.** Include both code **before** the cursor (`prefix`) and code **after** the cursor (`suffix`) via Fill-in-the-Middle (`FIM`) alongside matching open-tab symbols

### 53. What happens in the GitHub Copilot cloud proxy if a developer's OAuth token has expired or their Organization Copilot Business seat was revoked at the billing boundary?

- **A.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **B.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** The Copilot **cloud proxy** validates entitlement tokens, applies inbound/outbound **RAI safety filters** (`hate speech, violence, sexual content, PII, prompt injection`), and runs the `~150-char` public-code filter

### 54. Besides toxicity/harm moderation and public-code duplication checks, which sensitive-data patterns does Copilot's proxy filtering aim to suppress from accidental public-training memorization in generated completions?

- **A.** GitHub Copilot CLI requires Python 2.7, executes every `rm -rf` and file write silently without permission prompts by default, and stores plaintext passwords in `~/.copilot/config.json`
- **B.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **C.** The Copilot **cloud proxy** validates entitlement tokens, applies inbound/outbound **RAI safety filters** (`hate speech, violence, sexual content, PII, prompt injection`), and runs the `~150-char` public-code filter
- **D.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic

### 55. Clarivance's cloud security review inspects the safeguards executed inside the **GitHub Copilot proxy** on every suggestion. Which two proxy functions are verified? Select two.

- **A.** Pass generated tokens through cloud-proxy Responsible AI toxicity/harm classifiers and the `~150-character` public-code duplication filter before IDE rendering
- **B.** The Copilot **cloud proxy** validates entitlement tokens, applies inbound/outbound **RAI safety filters** (`hate speech, violence, sexual content, PII, prompt injection`), and runs the `~150-char` public-code filter
- **C.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models
- **D.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **E.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits

### 56. Place the end-to-end **inline code suggestion lifecycle** steps in order for a Clarivance developer editing `app/routers/labs.py` in PyCharm under Copilot Enterprise.

- **A.** Public-code duplication filter runs offline with network unplugged → LLM generates code before receiving file language or cursor prefix → IDE validates seat tokens once per decade → Proxy disables TLS encryption
- **B.** IDE uploads your entire disk (`~/.ssh` & closed repos) over HTTP → Cloud GPUs execute your local unit tests → Copilot commits directly to `main` without ghost text → Copilot Business trains shared base LLMs on your prompt
- **C.** IDE gathers FIM prefix/suffix & open tabs (minus exclusions) → Client sends `TLS 1.2+` prompt to proxy & checks seat token → Proxy runs RAI filters, LLM & `~150+` char duplication check → IDE renders ghost text & Business skips model training
- **D.** IDE bypasses Organization Content Exclusions → Forwards raw files to unauthenticated endpoints → Skips toxicity & prompt-injection filters → Publishes prompts to public GitHub Gists

### 57. At the end of the inline suggestion lifecycle, when a developer ignores or types over displayed ghost text instead of pressing `Tab`, what signal is emitted?

- **A.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **B.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **C.** When assigned an Issue, the Copilot coding agent (`cloud agent`) pushes commits directly to protected `main`, bypasses branch rulesets, and merges its own PR without human review
- **D.** Suggestion lifecycle: typing debounce -> IDE FIM/tab context assembly -> `TLS` request to Copilot proxy -> RAI pre-filter & LLM generation -> post-filter & duplication check -> ghost-text render -> telemetry

### 58. A Clarivance clinician-developer asks Copilot Chat `"Did FDA guidance published yesterday morning change LOINC code 718-7?"` without web/MCP grounding enabled. Why is trusting Copilot's ungrounded answer dangerous?

- **A.** Automate seat lifecycle via `GET /orgs/{org}/copilot/billing`, `GET .../billing/seats` (`last_activity_at`), and `POST`/`DELETE /orgs/{org}/copilot/billing/selected_users` or `selected_teams` (`manage_billing:copilot`)
- **B.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** Account for LLM & Copilot architectural limits: **finite context windows**, **pre-training knowledge cutoffs**, **stochastic sampling**, **no runtime execution** during inline completion, and unseen unindexed external systems

### 59. Why can GitHub Copilot generate a Python SQLAlchemy migration that passes syntax highlighting yet fails at runtime with `ForeignKeyAssociatedColumnError` against Clarivance's actual schema?

- **A.** When assigned an Issue, the Copilot coding agent (`cloud agent`) pushes commits directly to protected `main`, bypasses branch rulesets, and merges its own PR without human review
- **B.** Account for LLM & Copilot architectural limits: **finite context windows**, **pre-training knowledge cutoffs**, **stochastic sampling**, **no runtime execution** during inline completion, and unseen unindexed external systems
- **C.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models
- **D.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free

### 60. A Clarivance engineer tries to migrate 65 Django apps to FastAPI by pasting 18,000 lines of `views.py` into a single Chat message and notices half the endpoints vanish from the generated output. Proposed solution: Re-send the exact same 18,000-line prompt three times expecting the LLM's output token limit to expand automatically. Does this meet the goal?

- **A.** Yes — this design satisfies all stated GitHub Copilot technical, governance, security, and privacy requirements
- **B.** No — keeping dozens of unrelated tabs open and reusing one marathon chat thread across unrelated tasks causes **context pollution and token truncation**; close stale tabs and use `/clear` or `#runSubagent`
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically

---

## Domain 4 — Apply prompt engineering and context crafting (10–15% official weight · 13 questions)

### 61. Compare `"Write FHIR parser"` against `"As a Python 3.12 HL7 engineer, write a Pydantic v2 Observation model matching #file:BundleSchema.json; reject missing effectiveDateTime with ValueError and return ISO-8601 UTC strings."` Which structural components make the second prompt effective?

- **A.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions
- **B.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **C.** Structure effective prompts with **Role/Goal**, **Grounded Context** (`#file`, `#selection`, versions), **Explicit Constraints** (`security, error handling, edge cases`), and **Output Format** (`types, signatures`)
- **D.** Save prompt files as `.git/hooks/pre-commit.yml` with `on: workflow_dispatch` so Copilot Chat automatically runs them on every keystroke

### 62. Before implementing `mask_mrn_for_audit(mrn: str) -> str:` in `audit.py`, a Clarivance developer writes a 3-line docstring specifying `"Preserve only trailing 4 digits prefixed with '***-'; raise ValueError if len(digits) < 4"`. How does this docstring affect inline completion?

- **A.** Inspect **Audit Logs** (`category:copilot`, e.g., `copilot.cfb_seat_created`, `copilot.content_exclusion_changed`) for admin changes and `GET /orgs/{org}/copilot/metrics` (`>=5 active users`) for aggregated usage
- **B.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **C.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **D.** Guide inline completions directly inside source files using **top-of-file architecture comments**, **explicit parameter/return type annotations**, and **domain-specific function/variable names**

### 63. In VS Code Copilot Chat, a developer highlights lines `88–112` of `hl7_mllp.py` (`containing a framing bug`) and wants their prompt anchored strictly to that highlighted block. Complete the Chat context variable: `#____`.

- **A.** Curate Copilot's active context: open target interface/DTO tabs (`closing unrelated files`), attach `#file:`, `#selection`, `#sym:`, or **Copilot Spaces**, and scope `.instructions.md` with `applyTo:` globs
- **B.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models
- **C.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **D.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic

### 64. Clarivance creates `.github/instructions/pytest-hipaa.instructions.md` with frontmatter `applyTo: "tests/**/*.py"`. When a developer edits `frontend/src/App.tsx` (`with zero Python files open or referenced`), is `pytest-hipaa.instructions.md` injected into the prompt?

- **A.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **B.** Curate Copilot's active context: open target interface/DTO tabs (`closing unrelated files`), attach `#file:`, `#selection`, `#sym:`, or **Copilot Spaces**, and scope `.instructions.md` with `applyTo:` globs
- **C.** Save prompt files as `.git/hooks/pre-commit.yml` with `on: workflow_dispatch` so Copilot Chat automatically runs them on every keystroke
- **D.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files

### 65. A Clarivance developer wants Copilot Chat to generate a new `LabOrderRepository` matching team conventions across `models/lab_order.py` and `repositories/base.py`. Which two actions maximize context precision? Select two.

- **A.** Close unrelated editor tabs and open the exact target interfaces/DTOs (`or pin them via #file:`) so neighbor-tab ranking injects clean, relevant types
- **B.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **C.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files
- **D.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **E.** Curate Copilot's active context: open target interface/DTO tabs (`closing unrelated files`), attach `#file:`, `#selection`, `#sym:`, or **Copilot Spaces**, and scope `.instructions.md` with `applyTo:` globs

### 66. Clarivance maps internal lab-analyzer error codes (`"ERR_HEMOLYZED_04" -> FhirOperationOutcome(severity="error", code="processing", diagnostics="Specimen hemolyzed")`) using custom hospital taxonomy. Which prompting pattern gives the highest mapping consistency across 25 codes?

- **A.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions
- **B.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **C.** Mock the function under test itself to return `200 OK` and assert `expect(true).toBe(true)` so test coverage reaches `100%` without exercising edge cases
- **D.** Use **zero-shot prompting** for standard algorithms/APIs, and **few-shot prompting** (`1–3 concrete input -> output examples`) when teaching proprietary schemas, custom DSLs, or bespoke test conventions

### 67. Providing **exactly one** input-to-output example in a Copilot Chat prompt to demonstrate a custom JSON log-envelope structure (`before asking Copilot to log 4 events`) is called `____-shot prompting`.

- **A.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **B.** Use **zero-shot prompting** for standard algorithms/APIs, and **few-shot prompting** (`1–3 concrete input -> output examples`) when teaching proprietary schemas, custom DSLs, or bespoke test conventions
- **C.** Automate seat lifecycle via `GET /orgs/{org}/copilot/billing`, `GET .../billing/seats` (`last_activity_at`), and `POST`/`DELETE /orgs/{org}/copilot/billing/selected_users` or `selected_teams` (`manage_billing:copilot`)
- **D.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically

### 68. When asking Copilot to generate an async SQLAlchemy 2.0 repository in Python 3.12, why should you explicitly specify `"Use SQLAlchemy 2.0 select() + AsyncSession.scalars() (do NOT use legacy 1.x session.query())"`?

- **A.** No — keeping dozens of unrelated tabs open and reusing one marathon chat thread across unrelated tasks causes **context pollution and token truncation**; close stale tabs and use `/clear` or `#runSubagent`
- **B.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **C.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **D.** Decompose complex epics into small, testable steps, state exact framework/SDK versions (`preventing pre-cutoff API drift`), and iterate in follow-up turns using compiler or test output

### 69. If Copilot Chat's first response partially misunderstands how Clarivance's retry middleware propagates correlation IDs, what is the best iterative recovery action?

- **A.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **B.** Decompose complex epics into small, testable steps, state exact framework/SDK versions (`preventing pre-cutoff API drift`), and iterate in follow-up turns using compiler or test output
- **C.** Mock the function under test itself to return `200 OK` and assert `expect(true).toBe(true)` so test coverage reaches `100%` without exercising edge cases
- **D.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic

### 70. Clarivance Health creates a reusable `.github/prompts/fhir-endpoint.prompt.md` slash command in VS Code so all 9 squads scaffold HIPAA-audited FastAPI endpoints identically. Order the workflow.

- **A.** Save `prompt.txt` outside the workspace → Add `applyTo: "false"` so nothing matches → Type `@terminal` expecting inline ghost text in closed files → Commit unreviewed output
- **B.** Embed production PATs inside `.github/prompts/deploy.prompt.md` → Publish private prompts to public npm → Send one-word `'fix'` with zero file context → Skip code review
- **C.** Set `"chat.promptFiles": true` & add `.github/prompts/api.prompt.md` → Link exemplars (`#file:`) & commit to Git → Close unrelated tabs & invoke `/api` in Chat with inputs → Run `/clear` (or open a new chat) before switching topics
- **D.** Place prompt templates in `.github/workflows/prompt.yml` expecting `/prompt` in Chat → Keep 45 unrelated legacy files open in tabs → Reuse one 200-turn chat thread across 12 services → Omit output types and error rules

### 71. Inside `.github/copilot-instructions.md`, Clarivance compares writing a 4,000-word philosophical essay on software craftsmanship versus 15 concise, bulleted rules (`Python 3.12, Ruff, Pytest, SQLAlchemy 2.0 AsyncSession, zero PHI in logs`). Which style performs better and why?

- **A.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **B.** Write **positive, specific constraints** (`'use parameterized pg queries with $1 parameters'`) rather than vague negations, ground domain rules via `#file:`, and codify standards in `.prompt.md` / `.instructions.md`
- **C.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files
- **D.** Mock the function under test itself to return `200 OK` and assert `expect(true).toBe(true)` so test coverage reaches `100%` without exercising edge cases

### 72. In VS Code Copilot Chat, a developer spends 35 turns debugging Docker Compose networking, then asks in turn 36 `"Now write unit tests for #file:dosage.py"`, and Copilot injects weird Docker environment variables into the unit test. Why?

- **A.** `#runSubagent` merges every raw intermediate grep output directly into the main chat's token window and pauses mid-search to interview the user after every file read
- **B.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **C.** Copilot Chat appends prior turns from the active thread up to its **token context limit**; run `/clear` (or open a new chat) on topic switches and use `#runSubagent` to keep noisy exploration out of history
- **D.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically

### 73. Clarivance's developer guide teaches engineers how **prompt process flow and chat history** affect multi-hour coding sessions. Which two guidelines belong in the guide? Select two.

- **A.** No — keeping dozens of unrelated tabs open and reusing one marathon chat thread across unrelated tasks causes **context pollution and token truncation**; close stale tabs and use `/clear` or `#runSubagent`
- **B.** Copilot Chat appends prior turns from the active thread up to its **token context limit**; run `/clear` (or open a new chat) on topic switches and use `#runSubagent` to keep noisy exploration out of history
- **C.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **D.** Run `/clear` or start a new Chat session when pivoting to an unrelated module so stale conversation turns do not consume token budget or bias new answers
- **E.** `#runSubagent` merges every raw intermediate grep output directly into the main chat's token window and pauses mid-search to interview the user after every file read

---

## Domain 5 — Improve developer productivity with GitHub Copilot (10–15% official weight · 14 questions)

### 74. Clarivance's API gateway needs OpenAPI 3.1 response examples, Pydantic `Field(description=...)` metadata, and Google-style Python docstrings across 14 endpoints. How can Copilot deliver this with minimal manual typing?

- **A.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **B.** Mock the function under test itself to return `200 OK` and assert `expect(true).toBe(true)` so test coverage reaches `100%` without exercising edge cases
- **C.** Use `Inline Chat`, `Copilot Edits`, **Next Edit Suggestions**, and `/doc` to scaffold repetitive DTOs/validators, extract pure functions to reduce cyclomatic complexity, and generate JSDoc/OpenAPI/Mermaid docs
- **D.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free

### 75. When refactoring a 180-line FastAPI route handler that mixes HTTP parsing, HL7 validation, DB transactions, and S3 uploads, which prompt strategy yields clean testable architecture?

- **A.** Save prompt files as `.git/hooks/pre-commit.yml` with `on: workflow_dispatch` so Copilot Chat automatically runs them on every keystroke
- **B.** Use `Inline Chat`, `Copilot Edits`, **Next Edit Suggestions**, and `/doc` to scaffold repetitive DTOs/validators, extract pure functions to reduce cyclomatic complexity, and generate JSDoc/OpenAPI/Mermaid docs
- **C.** Automate seat lifecycle via `GET /orgs/{org}/copilot/billing`, `GET .../billing/seats` (`last_activity_at`), and `POST`/`DELETE /orgs/{org}/copilot/billing/selected_users` or `selected_teams` (`manage_billing:copilot`)
- **D.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic

### 76. A Clarivance engineer wants Copilot in PyCharm / VS Code to create 5 new Pydantic schema files, wire Alembic migrations, run `pytest -q`, inspect a failing import error, and fix the import loop hands-free. Proposed solution: Run the prompt inside standard **`Ask` mode** without switching to **Agent Mode** (`or Copilot CLI`). Does this meet the goal?

- **A.** When assigned an Issue, the Copilot coding agent (`cloud agent`) pushes commits directly to protected `main`, bypasses branch rulesets, and merges its own PR without human review
- **B.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **C.** Yes — this design satisfies all stated GitHub Copilot technical, governance, security, and privacy requirements
- **D.** No — Copilot Chat **`Ask` mode** only answers questions and proposes snippets in chat; autonomous multi-file workspace edits with iterative terminal test execution require **Agent Mode** (`or Copilot CLI`)

### 77. A Python backend engineer inherits a complex 45-line PostgreSQL recursive CTE (`WITH RECURSIVE care_team_tree AS ...`) and needs to verify cycle termination before adding a column. Which Chat slash command explains the CTE step-by-step right inside the IDE? (`/____`)

- **A.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions
- **B.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **C.** Minimize context switching by running `/explain` on complex regexes/SQL/legacy modules, `@terminal` + `/fix` (`or Copilot CLI`) on shell/build errors, and `@workspace` / **Spaces** for repo onboarding
- **D.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically

### 78. How do **Copilot Spaces** and `@workspace` reduce onboarding ramp-up time when a new Clarivance engineer joins a 12-repository clinical platform?

- **A.** Minimize context switching by running `/explain` on complex regexes/SQL/legacy modules, `@terminal` + `/fix` (`or Copilot CLI`) on shell/build errors, and `@workspace` / **Spaces** for repo onboarding
- **B.** Automate seat lifecycle via `GET /orgs/{org}/copilot/billing`, `GET .../billing/seats` (`last_activity_at`), and `POST`/`DELETE /orgs/{org}/copilot/billing/selected_users` or `selected_teams` (`manage_billing:copilot`)
- **C.** Save prompt files as `.git/hooks/pre-commit.yml` with `on: workflow_dispatch` so Copilot Chat automatically runs them on every keystroke
- **D.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins

### 79. Clarivance Health modernizes a 2015 Flask + Python 2/early-3 synchronous lab-report service into async FastAPI on Python 3.12 (`Pydantic v2`). Place the four modernization stages in safe engineering order.

- **A.** Map legacy behavior & invariants via `/explain` and `@workspace` → Build characterization & boundary tests (`/tests`) until green → Refactor incrementally via Copilot Edits / Agent Mode → Re-run tests, `CodeQL` & benchmarks to verify parity
- **B.** Delete the legacy repo & prompt Copilot once to rewrite 80,000 lines from scratch → Delete failing tests so CI passes → Skip null/timezone/overflow checks → Switch production traffic immediately
- **C.** Paste live customer SSNs and card numbers into Chat to build fixtures → Translate raw SQL string concatenation verbatim into the new language → Disable `CodeQL` alerts → Deploy without review
- **D.** Upgrade production servers before compiling → Generate tautological `expect(true).toBe(true)` tests → Ignore concurrency and boundary cases → Merge without running CI

### 80. A Clarivance QA engineer needs 200 HL7 FHIR `Patient` and `Observation` JSON bundles (`with realistic ICD-10 codes, vital-sign ranges, and `.example` emails`) for staging load tests. What is the HIPAA-safe way to generate them with Copilot?

- **A.** Generate schema-valid **synthetic test fixtures** (`zero real customer PII`) and modernize legacy code (`e.g., Java 8 -> 21, Python 2 -> 3.12, callbacks -> async/await`) incrementally behind characterization tests
- **B.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **C.** Mock the function under test itself to return `200 OK` and assert `expect(true).toBe(true)` so test coverage reaches `100%` without exercising edge cases
- **D.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions

### 81. When modernizing legacy jQuery AJAX patient forms in `clarivance/portal-web` to React 19 + TypeScript strict mode, why should engineers attach the backend OpenAPI/TypeScript contract (`#file:api-types.ts`) during conversion?

- **A.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions
- **B.** Generate schema-valid **synthetic test fixtures** (`zero real customer PII`) and modernize legacy code (`e.g., Java 8 -> 21, Python 2 -> 3.12, callbacks -> async/await`) incrementally behind characterization tests
- **C.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **D.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free

### 82. A Clarivance developer runs `/tests` on `InsuranceEligibilityClient.py` (`which calls an external HTTPS clearinghouse`). How should external HTTP calls be handled in unit tests versus integration tests generated with Copilot?

- **A.** Mock the function under test itself to return `200 OK` and assert `expect(true).toBe(true)` so test coverage reaches `100%` without exercising edge cases
- **B.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions
- **C.** Use `/tests` (paired with testing `.instructions.md` conventions) to generate unit and integration tests with isolated I/O mocks/stubs, parameterized table cases, and deterministic teardown
- **D.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically

### 83. Clarivance's `pytest.instructions.md` defines standards for Copilot-generated Python tests. Which two practices belong in that file? Select two.

- **A.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions
- **B.** Lock existing legacy behavior with characterization and boundary-value unit tests **before** refactoring idioms with Copilot Edits or Agent Mode
- **C.** Use `/tests` (paired with testing `.instructions.md` conventions) to generate unit and integration tests with isolated I/O mocks/stubs, parameterized table cases, and deterministic teardown
- **D.** Mock the function under test itself to return `200 OK` and assert `expect(true).toBe(true)` so test coverage reaches `100%` without exercising edge cases
- **E.** When assigned an Issue, the Copilot coding agent (`cloud agent`) pushes commits directly to protected `main`, bypasses branch rulesets, and merges its own PR without human review

### 84. Copilot generates a `pytest` suite for `parse_patient_dob(dob_str: str) -> date` testing `"1990-05-14"`. Which edge cases should the developer prompt Copilot to add before approving the PR?

- **A.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **B.** Prompt explicitly for **boundary and adversarial edge cases** (`null/empty, 0/-1/MAX_INT, leap-year/DST timestamps, Unicode, timeouts, race conditions`) and assert concrete outputs/errors (`never tautologies`)
- **C.** Mock the function under test itself to return `200 OK` and assert `expect(true).toBe(true)` so test coverage reaches `100%` without exercising edge cases
- **D.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free

### 85. Clarivance's quality gate reviews AI-assisted PRs across clinical microservices. Which three verification practices must pass before merge? Select three.

- **A.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **B.** Lock existing legacy behavior with characterization and boundary-value unit tests **before** refactoring idioms with Copilot Edits or Agent Mode
- **C.** Validate that security fixes (`such as CodeQL Copilot Autofix`) replace string-concatenated queries/commands with parameterized APIs and pass full regression + SAST checks
- **D.** Mock the function under test itself to return `200 OK` and assert `expect(true).toBe(true)` so test coverage reaches `100%` without exercising edge cases
- **E.** Prompt explicitly for **boundary and adversarial edge cases** (`null/empty, 0/-1/MAX_INT, leap-year/DST timestamps, Unicode, timeouts, race conditions`) and assert concrete outputs/errors (`never tautologies`)
- **F.** Export 10,000 real production patient PHI and credit-card records into `.github/copilot-instructions.md` so `/tests` generates realistic integration assertions

### 86. In `clarivance/patient-portal`, `CodeQL` flags a reflected Cross-Site Scripting (`XSS`) alert in a legacy Jinja2 template that used `| safe` on user-supplied search query text, and proposes a **Copilot Autofix** diff. What must the developer verify before committing the Autofix?

- **A.** Use Copilot Chat and **CodeQL Copilot Autofix** to remediate vulnerabilities (`SQLi -> parameterized queries, XSS -> encoding, path traversal, SSRF`) and eliminate `O(n^2)` loops or `N+1` ORM queries
- **B.** Configuring Copilot Content Exclusions also blocks `git clone`, GitHub Actions runners, and `CodeQL` security scans from reading the excluded files
- **C.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **D.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits

### 87. A FastAPI endpoint loads 2,000 `Encounter` rows and triggers lazy-loaded SQLAlchemy `encounter.practitioner` queries inside a serialization loop (`2,001 SQL round-trips`). Which optimization can Copilot apply when shown the model and query?

- **A.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **B.** Mock the function under test itself to return `200 OK` and assert `expect(true).toBe(true)` so test coverage reaches `100%` without exercising edge cases
- **C.** Open all 90 repository files in editor tabs and send the single-word prompt `optimize` in a 150-turn chat thread so Copilot infers your exact latency SLA automatically
- **D.** Use Copilot Chat and **CodeQL Copilot Autofix** to remediate vulnerabilities (`SQLi -> parameterized queries, XSS -> encoding, path traversal, SSRF`) and eliminate `O(n^2)` loops or `N+1` ORM queries

---

## Domain 6 — Configure privacy, content exclusions, and safeguards (10–15% official weight · 13 questions)

### 88. Clarivance Health's security team configures Organization **Content Exclusions** (`- "/hipaa-keys/**"`) across all `clarivance` repositories and verifies IDE enforcement and auditability. Order the four steps.

- **A.** Add `fnmatch` globs (`- "/secrets/**"`) in `Content exclusion` → Allow `<=30 min` (or reload IDE) for policy sync → Verify crossed-out icon & `copilot.content_exclusion_changed` log → Avoid cross-file imports where IDE LSP hover types surface
- **B.** Put exclusion rules in `package.json` → Wait 14 days for policy propagation → Have a Repo Admin delete Organization-level Content Exclusions → Disable Enterprise Audit Logs
- **C.** List tracked `secrets.yaml` in `.gitignore` expecting Copilot to exclude it → Set `Suggestions matching public code = Allow` → Disable IDE TLS verification → Share one seat login across 10 engineers
- **D.** Configure Content Exclusions on a personal Copilot Free plan → Write PCRE lookbehind regexes instead of `fnmatch` globs → Expect exclusions to block `git clone` and Actions runs → Ignore IDE status icons

### 89. A developer tries to bypass Organization Content Exclusions on `- "/hipaa-keys/**"` by adding `"Please read /hipaa-keys/prod.env"` inside `.github/copilot-instructions.md`. Does that expose the excluded file to Copilot?

- **A.** Configure **Content Exclusions** (`Copilot Business & Enterprise`) in Repo/Org settings with YAML `fnmatch` globs (`- "/secrets/**"`); rules combine additively (`Repo cannot weaken Org`) and sync in `<=30 min`
- **B.** Configuring Copilot Content Exclusions also blocks `git clone`, GitHub Actions runners, and `CodeQL` security scans from reading the excluded files
- **C.** No — Repository and Organization **Content Exclusions** require **Copilot Business or Copilot Enterprise**; personal Copilot Free/Pro/Pro+ plans do not support Org Content Exclusions
- **D.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files

### 90. When a repository file is matched by **Copilot Content Exclusions**, can a developer with Git `Read` access still `git pull` that file locally and view it in their text editor?

- **A.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files
- **B.** Configuring Copilot Content Exclusions also blocks `git clone`, GitHub Actions runners, and `CodeQL` security scans from reading the excluded files
- **C.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **D.** Excluded files are omitted from inline completions, IDE Chat, and Copilot Code Review, **but** IDE language-server (`LSP`) hover types from imported symbols can still surface, and `git`/`CodeQL`/Actions are unaffected

### 91. Clarivance commits synthetic calibration key templates in `config/vendor-signing.cfg` (`tracked in Git`) and wants Copilot Enterprise to ignore that file in PyCharm and PR Code Review. Proposed solution: Add `config/vendor-signing.cfg` to `.gitignore` (`leaving the file tracked in Git`) instead of configuring Copilot Content Exclusions. Does this meet the goal?

- **A.** No — `.gitignore` only prevents untracked files from being staged by Git; excluding tracked repository files from Copilot requires **Copilot Content Exclusions** (`Settings -> Copilot -> Content exclusion`)
- **B.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files
- **C.** Configuring Copilot Content Exclusions also blocks `git clone`, GitHub Actions runners, and `CodeQL` security scans from reading the excluded files
- **D.** Yes — this design satisfies all stated GitHub Copilot technical, governance, security, and privacy requirements

### 92. Clarivance Health's hospital customers ask whether GitHub acquires joint copyright ownership over clinical algorithms written by Clarivance engineers using Copilot Enterprise. What is GitHub's contractual position?

- **A.** No — Repository and Organization **Content Exclusions** require **Copilot Business or Copilot Enterprise**; personal Copilot Free/Pro/Pro+ plans do not support Org Content Exclusions
- **B.** Customers retain ownership of their code (`GitHub claims no copyright over suggestions`), and **Copilot Business / Enterprise** provide **IP Indemnity** when `Suggestions matching public code` is set to **`Block`**
- **C.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **D.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models

### 93. A Clarivance engineering director wants temporary access to public-code matches (`Allow`) during a hackathon in the production `clarivance` organization while keeping **GitHub Copilot IP Indemnity** active on `clarivance` repositories. Proposed solution: Switch `Suggestions matching public code` to `Allow` for two weeks and rely on Copilot Enterprise IP Indemnity for any code merged during that window. Does this meet the goal?

- **A.** No — GitHub's **Copilot IP Indemnity** on Business/Enterprise ceases to cover suggestions when `Suggestions matching public code` is set to **`Allow`**; set the filter to **`Block`**
- **B.** Yes — this design satisfies all stated GitHub Copilot technical, governance, security, and privacy requirements
- **C.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **D.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins

### 94. Even with Copilot Enterprise and `Suggestions matching public code = Block`, why must Clarivance still run SCA/license scanning (`Dependabot / Dependency Review`) on imported packages?

- **A.** Customers retain ownership of their code (`GitHub claims no copyright over suggestions`), and **Copilot Business / Enterprise** provide **IP Indemnity** when `Suggestions matching public code` is set to **`Block`**
- **B.** Because GitHub Copilot compiles and formally proves every completion inside a cloud sandbox before rendering ghost text, accepted suggestions are guaranteed deterministic and bug-free
- **C.** Copilot Business and Enterprise automatically retain every private repository prompt for 90 days to fine-tune GitHub's shared public foundational models
- **D.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits

### 95. When `Suggestions matching public code` is set to **`Allow`** in an isolated research org and **GitHub Code Referencing** detects a match against three public GitHub repositories (`one MIT, one Apache-2.0, one with no LICENSE file`), what does Code Referencing display?

- **A.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **B.** Set **`Suggestions matching public code = Block`** to suppress `~150+` char matches against public GitHub repos; when set to **`Allow`**, **Code Referencing** logs matched repo URLs and licenses in the IDE
- **C.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **D.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits

### 96. At the Enterprise level (`clarivance-ent`), an Enterprise Owner sets `Suggestions matching public code = Block`. Can an Organization Owner of child org `clarivance-labs` change `clarivance-labs` to `Allow`?

- **A.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **B.** Set **`Suggestions matching public code = Block`** to suppress `~150+` char matches against public GitHub repos; when set to **`Allow`**, **Code Referencing** logs matched repo URLs and licenses in the IDE
- **C.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **D.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits

### 97. Clarivance's open-source review board documents how public-code duplication filtering interacts with Code Referencing and IP Indemnity. Which two statements are accurate? Select two.

- **A.** Setting `Suggestions matching public code = Allow` automatically grants Apache-2.0 relicensing and full GitHub IP Indemnity over any verbatim GPL-3.0 code Copilot emits
- **B.** Set **`Suggestions matching public code = Block`** to suppress `~150+` char matches against public GitHub repos; when set to **`Allow`**, **Code Referencing** logs matched repo URLs and licenses in the IDE
- **C.** Customers retain ownership of their code (`GitHub claims no copyright over suggestions`), and **Copilot Business / Enterprise** provide **IP Indemnity** when `Suggestions matching public code` is set to **`Block`**
- **D.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins
- **E.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic

### 98. A Clarivance engineer switches Wi-Fi networks to a hospital guest VLAN that blocks `*.githubcopilot.com`, and inline ghost text stops appearing in PyCharm. Which built-in IDE command/panel quickly surfaces endpoint connectivity, auth, and proxy status? (`GitHub Copilot ____` / Output log)

- **A.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files
- **B.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **C.** Diagnose missing completions or unexpected exclusions via **Copilot Diagnostics / Output logs**: verify seat assignment, filetype toggle, active exclusion icon (`most restrictive org wins`), and TLS proxy allowlists (`*.githubcopilot.com`)
- **D.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins

### 99. A contractor signed into VS Code with their personal **GitHub Copilot Free** account (`not a member of org clarivance`) clones a local copy of a partner repo and wonders why Organization Content Exclusions from `clarivance` are not active on their personal account. Proposed solution: Expect personal **Copilot Free** accounts outside the organization to enforce Organization Content Exclusions without assigning a Copilot Business/Enterprise seat. Does this meet the goal?

- **A.** Yes — this design satisfies all stated GitHub Copilot technical, governance, security, and privacy requirements
- **B.** Choose **Copilot Free** for capped monthly completions/chats or **Copilot Pro / Pro+** for individual developers needing unlimited completions, higher premium-model quotas, and **GitHub Spark**
- **C.** No — Repository and Organization **Content Exclusions** require **Copilot Business or Copilot Enterprise**; personal Copilot Free/Pro/Pro+ plans do not support Org Content Exclusions
- **D.** Listing `- "!/secrets/**"` inside `.github/copilot-instructions.md` overrides Organization Content Exclusions and forces Copilot to read excluded credential files

### 100. Clarivance's desktop engineering team resolves ticket escalations where Copilot fails to initialize after macOS laptop imaging. Which two troubleshooting steps address the most common root causes? Select two.

- **A.** GitHub Copilot runs a 70-billion-parameter LLM and the public-code duplication index entirely offline inside the local VS Code extension with zero network traffic
- **B.** Allow outbound `HTTPS (TCP 443)` with valid TLS trust (`NODE_EXTRA_CA_CERTS` / OS trust store for SSL-inspecting proxies) to GitHub's documented `*.githubcopilot.com` and `github.com` endpoints
- **C.** Configuring Copilot Content Exclusions also blocks `git clone`, GitHub Actions runners, and `CodeQL` security scans from reading the excluded files
- **D.** Diagnose missing completions or unexpected exclusions via **Copilot Diagnostics / Output logs**: verify seat assignment, filetype toggle, active exclusion icon (`most restrictive org wins`), and TLS proxy allowlists (`*.githubcopilot.com`)
- **E.** When a developer belongs to two GitHub Organizations with conflicting Copilot policies (`one Block, one Allow`), the most permissive (`Allow`) policy always wins

---

## Answer Key and Explanations

### Question 1 — `A` (Use GitHub Copilot responsibly)

Correct answer: A (is correct). LLMs predict statistically likely token continuations (`mg/kg` vs `mcg/kg`) rather than reasoning from verified pharmacological specifications, so life-safety calculation bugs can look syntactically idiomatic. [Skill 1.1: Describe risks and limitations of Generative AI tools | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/modules/responsible-ai-with-github-copilot/)]

- **A:** Correct. Generative AI risks and limitations (`1.1`) address probabilistic next-token prediction, hallucinations, outdated APIs, and bias—not IDE installation or REST seat billing.
- **B:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Incorrect. Copilot User Management REST API (`2.15`) provisions seats, audits `last_activity_at` dormancy, and cancels seats cleanly.

### Question 2 — `B` (Use GitHub Copilot responsibly)

Correct answer: B (is correct). Confirm the package exists in Clarivance's vetted internal PyPI mirror (`or official PyPI with verified maintainer history, release provenance, and CVE scan`), since LLMs can invent package names claimed by attackers. [Skill 1.1: Describe risks and limitations of Generative AI tools | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/modules/responsible-ai-with-github-copilot/)]

- **A:** Incorrect. GitHub Spark (`2.11`) accelerates full-stack micro-app prototyping and deployment directly from natural language and visual controls.
- **B:** Correct. Package hallucination / slopsquatting verification (`1.1`, `1.4`) protects dependency supply chains—not Markdown PR summaries or status badges.
- **C:** Incorrect. Copilot Audit Logs and Metrics API (`2.14`) separate security/compliance event logs from anonymized (`>=5`-user) adoption telemetry.
- **D:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).

### Question 3 — `A` (Use GitHub Copilot responsibly)

Correct answer: A (is correct). Developers experienced **automation complacency (`automation bias`)**, treating high syntactic polish in AI-generated code as a substitute for rigorous adversarial authorization review. [Skill 1.1: Describe risks and limitations of Generative AI tools | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/modules/responsible-ai-with-github-copilot/)]

- **A:** Correct. Automation bias (`1.1`, `1.4`) occurs when developers accept syntactically clean completions without verifying business logic or security invariants.
- **B:** Incorrect. Installing GitHub Copilot CLI (`2.5`) uses `@github/copilot` (`Node 22+`), WinGet, or Homebrew, followed by `/login` OAuth and directory trust confirmation.
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).

### Question 4 — `D, E` (Use GitHub Copilot responsibly)

Correct answers: D and E (are correct). Installing hallucinated package names without registry verification (`slopsquatting`) and rubber-stamping plausible AI diffs due to automation complacency. [Skill 1.1: Describe risks and limitations of Generative AI tools | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/modules/responsible-ai-with-github-copilot/)]

- **A:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **B:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **C:** Incorrect. False: the Copilot coding agent works on an isolated `copilot/*` branch, opens a **draft pull request**, respects branch protections, and requires human review (`2.9`, `2.10`).
- **D:** Correct. Package hallucination / slopsquatting verification (`1.1`, `1.4`) protects dependency supply chains—not Markdown PR summaries or status badges.
- **E:** Correct. Automation bias (`1.1`, `1.4`) occurs when developers accept syntactically clean completions without verifying business logic or security invariants.

### Question 5 — `D` (Use GitHub Copilot responsibly)

Correct answer: D (is correct). Six core Responsible AI principles guide design and governance: **Fairness**, **Reliability & Safety**, **Privacy & Security**, **Inclusiveness**, **Transparency**, and **Accountability**. [Skill 1.2: Describe ethical and responsible AI usage | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use/copilot-code-completion)]

- **A:** Incorrect. Copilot CLI programmatic flags (`2.6`) control non-interactive scripting (`-p`, `-s`, `--output-format=json`), tool permissions, and `--fleet` parallelism.
- **B:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **C:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **D:** Correct. Microsoft/GitHub Responsible AI (`1.2`) centers on Fairness, Reliability & Safety, Privacy & Security, Inclusiveness, Transparency, and human Accountability.

### Question 6 — `C` (Use GitHub Copilot responsibly)

Correct answer: C (is correct). AI tools have no moral or legal agency; the human author and reviewing team who committed and merged the query hold `100%` engineering accountability for its production behavior. [Skill 1.2: Describe ethical and responsible AI usage | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use/copilot-code-completion)]

- **A:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **B:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **C:** Correct. Ethical AI governance (`1.2`) requires human ownership, license respect, and transparent review—never treating Copilot as an autonomous merge authority.
- **D:** Incorrect. False: the Copilot coding agent works on an isolated `copilot/*` branch, opens a **draft pull request**, respects branch protections, and requires human review (`2.9`, `2.10`).

### Question 7 — `B` (Use GitHub Copilot responsibly)

Correct answer: B (is correct). **Inclusiveness** and **Fairness** require accessible keyboard/screen-reader navigation and non-exclusionary demographic representation. [Skill 1.2: Describe ethical and responsible AI usage | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use/copilot-code-completion)]

- **A:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).
- **B:** Correct. Fairness and Inclusiveness (`1.2`, `1.3`) ensure AI-assisted software serves diverse users equitably and meets accessibility standards.
- **C:** Incorrect. Copilot User Management REST API (`2.15`) provisions seats, audits `last_activity_at` dormancy, and cancels seats cleanly.
- **D:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).

### Question 8 — `A, C, E` (Use GitHub Copilot responsibly)

Correct answers: A, C, and E (are correct). Verify alignment with all six Responsible AI principles, confirm human accountability + open-source license compliance (`Transparency`), and test demographic/accessibility equity (`Fairness & Inclusiveness`). [Skill 1.2: Describe ethical and responsible AI usage | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use/copilot-code-completion)]

- **A:** Correct. Microsoft/GitHub Responsible AI (`1.2`) centers on Fairness, Reliability & Safety, Privacy & Security, Inclusiveness, Transparency, and human Accountability.
- **B:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **C:** Correct. Ethical AI governance (`1.2`) requires human ownership, license respect, and transparent review—never treating Copilot as an autonomous merge authority.
- **D:** Incorrect. False: the Copilot coding agent works on an isolated `copilot/*` branch, opens a **draft pull request**, respects branch protections, and requires human review (`2.9`, `2.10`).
- **E:** Correct. Fairness and Inclusiveness (`1.2`, `1.3`) ensure AI-assisted software serves diverse users equitably and meets accessibility standards.
- **F:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).

### Question 9 — `B` (Use GitHub Copilot responsibly)

Correct answer: B (is correct). Specify `argon2-cffi` / `bcrypt` password-hashing standards in `.github/instructions/security.instructions.md` and enforce **`CodeQL` code scanning** on every pull request. [Skill 1.3: Identify potential harms and mitigation strategies of AI usage | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/azure/ai-foundry/responsible-ai/overview)]

- **A:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **B:** Correct. Harm mitigation (`1.3`) combines RAI safety filters, bias testing, SAST scanning, and privacy controls—not disabling code review.
- **C:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).
- **D:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).

### Question 10 — `D` (Use GitHub Copilot responsibly)

Correct answer: D (is correct). Treat external MCP documents as untrusted (**indirect prompt injection** risk), deny arbitrary external URL/shell access, and require explicit human approval before any tool writes files or makes network requests. [Skill 1.3: Identify potential harms and mitigation strategies of AI usage | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/azure/ai-foundry/responsible-ai/overview)]

- **A:** Incorrect. False: `@github/copilot` npm installs require **Node.js 22+**, prompt for explicit user permission before modifying files/running commands by default, and use OAuth `/login` (`2.5`, `2.8`).
- **B:** Incorrect. False: `#runSubagent` runs autonomously in its **own isolated context window** without pausing for user feedback, returning only the distilled result (`2.9`).
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Correct. Indirect prompt-injection defense (`1.3`, `1.5`) guards Agent Mode and MCP tool invocations against malicious instructions hidden in external data.

### Question 11 — `C, D` (Use GitHub Copilot responsibly)

Correct answers: C and D (are correct). Train engineers to use synthetic non-PHI schemas (`never pasting real PHI/secrets into prompts`) and enforce **Secret Scanning Push Protection + `CodeQL`** on all repositories. [Skill 1.3: Identify potential harms and mitigation strategies of AI usage | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/azure/ai-foundry/responsible-ai/overview)]

- **A:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).
- **B:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **C:** Correct. Data minimization in prompts (`1.3`, `1.5`) prevents accidental exposure of regulated personal data or live secrets.
- **D:** Correct. Automated security gates (`1.3`, `1.4`) catch vulnerable patterns, leaked credentials, and known CVEs introduced during rapid AI code generation.
- **E:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).

### Question 12 — `A` (Use GitHub Copilot responsibly)

Correct answer: A (is correct). Prompting with explicit security/type constraints -> inspecting logic & verifying packages in Clarivance's trusted PyPI registry -> running unit/edge-case tests + `CodeQL` -> completing human PR review. [Skill 1.4: Explain the need to validate AI output | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/best-practices-for-using-github-copilot)]

- **A:** Correct. Correct order: constrained prompt -> manual logic & dependency check (`blocking slopsquatting`) -> automated tests/SAST -> human PR review.
- **B:** Incorrect. Incorrect: pasting real PII into prompts and bypassing human review violates privacy and Responsible AI governance.
- **C:** Incorrect. Incorrect: merging unverified LLM output or replacing human peer review with Copilot Code Review violates Responsible AI accountability.
- **D:** Incorrect. Incorrect: blindly installing hallucinated package names exposes builds to dependency confusion and slopsquatting.

### Question 13 — `B` (Use GitHub Copilot responsibly)

Correct answer: B (is correct). Combine explicit timezone-aware rules in `.github/copilot-instructions.md` with deterministic DST boundary unit tests (`freezegun` / fixed UTC clocks) and careful human diff review. [Skill 1.4: Explain the need to validate AI output | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/best-practices-for-using-github-copilot)]

- **A:** Incorrect. False: mocking the unit under test or writing tautological assertions provides zero behavioral verification (`1.4`, `5.4`, `5.5`).
- **B:** Correct. Validating AI output (`1.4`) requires human code review, automated tests, and security scanning before merge.
- **C:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **D:** Incorrect. False: the Copilot coding agent works on an isolated `copilot/*` branch, opens a **draft pull request**, respects branch protections, and requires human review (`2.9`, `2.10`).

### Question 14 — `C` (Use GitHub Copilot responsibly)

Correct answer: C (is correct). LLM generation is **probabilistic (`non-deterministic`)** across pre-training eras (`Pydantic v1 and v2 both appear heavily in public code`), so pinning versions in context and running tests is mandatory. [Skill 1.4: Explain the need to validate AI output | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/best-practices-for-using-github-copilot)]

- **A:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **B:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **C:** Correct. Non-determinism (`1.4`, `3.5`) means syntactic plausibility never guarantees functional equivalence across repeated prompts.
- **D:** Incorrect. Copilot User Management REST API (`2.15`) provisions seats, audits `last_activity_at` dormancy, and cancels seats cleanly.

### Question 15 — `B` (Use GitHub Copilot responsibly)

Correct answer: B (is correct). No — Copilot Code Review intentionally leaves `Comment` reviews (`never Approve` reviews), so branch protection still blocks merge until an authorized human reviewer approves. [Skill 1.4: Explain the need to validate AI output | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/best-practices-for-using-github-copilot)]

- **A:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **B:** Correct. Copilot Code Review (`1.4`, `2.10`) supplements—never replaces—required human pull-request approvals.
- **C:** Incorrect. The proposed GitHub Copilot configuration or workflow violates at least one stated governance, privacy, or technical requirement. No — Copilot Code Review intentionally leaves `Comment` reviews (`never Approve` reviews), so branch protection still blocks merge until an authorized human reviewer approves.
- **D:** Incorrect. False: the Copilot coding agent works on an isolated `copilot/*` branch, opens a **draft pull request**, respects branch protections, and requires human review (`2.9`, `2.10`).

### Question 16 — `B` (Use GitHub Copilot responsibly)

Correct answer: B (is correct). Enforce `Suggestions matching public code = Block`, maintain Org/Repo Content Exclusions on sensitive configs, forbid real PHI/secrets in prompts, and require green CI (`pytest` + `CodeQL`) plus human PR review. [Skill 1.5: Identify how to operate GitHub Copilot responsibly | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use)]

- **A:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **B:** Correct. Responsible Copilot operation (`1.5`) pairs duplication filtering, Content Exclusions, zero-PII prompting, and mandatory human PR review.
- **C:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).
- **D:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).

### Question 17 — `A` (Use GitHub Copilot responsibly)

Correct answer: A (is correct). Yes — omitting `excludeAgent` allows both Copilot Code Review and cloud coding agent to apply `hipaa-logging.instructions.md` on matching `app/**/*.py` files while human approval remains enforced. [Skill 1.5: Identify how to operate GitHub Copilot responsibly | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use)]

- **A:** Correct. Evaluate whether every stated plan tier, CLI/IDE mechanism, context scope, and Enterprise/Org policy requirement is genuinely met.
- **B:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).
- **C:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **D:** Incorrect. `excludeAgent: "code-review"` (`2.11`) tells GitHub.com to omit that instruction file during Copilot Code Review.

### Question 18 — `A` (Use GitHub Copilot responsibly)

Correct answer: A (is correct). Enabling **Dependabot alerts / Dependency Review Action** (`actions/dependency-review-action`) alongside locking installs to Clarivance's private upstream-vetted PyPI registry. [Skill 1.5: Identify how to operate GitHub Copilot responsibly | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use)]

- **A:** Correct. Package hallucination / slopsquatting verification (`1.1`, `1.4`) protects dependency supply chains—not Markdown PR summaries or status badges.
- **B:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **C:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **D:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).

### Question 19 — `D` (Use GitHub Copilot features)

Correct answer: D (is correct). Yes — once authenticated with an active Copilot seat in VS Code or PyCharm, inline suggestions and Copilot Chat work directly inside Jupyter Notebook code cells as well as `.py` files. [Skill 2.1: Enable Copilot in the IDE | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/quickstart)]

- **A:** Incorrect. Copilot Audit Logs and Metrics API (`2.14`) separate security/compliance event logs from anonymized (`>=5`-user) adoption telemetry.
- **B:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **C:** Incorrect. False: `@github/copilot` npm installs require **Node.js 22+**, prompt for explicit user permission before modifying files/running commands by default, and use OAuth `/login` (`2.5`, `2.8`).
- **D:** Correct. Enabling Copilot in the IDE (`2.1`) requires installing the IDE extension, authenticating with GitHub, and holding an active Copilot plan.

### Question 20 — `A` (Use GitHub Copilot features)

Correct answer: A (is correct). **GitHub Copilot Pro+** (`above Free and Pro`) is the highest individual subscription tier, providing expanded premium-model allowances and **GitHub Spark** access (`without Org policy governance`). [Skill 2.1: Enable Copilot in the IDE | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/quickstart)]

- **A:** Correct. Individual Copilot tiers (`2.1`, `2.15`) serve single accounts without Organization policy management or Org Content Exclusions.
- **B:** Incorrect. Organization/Enterprise Copilot tiers (`2.1`, `2.15`, `6.2`) add centralized governance, Content Exclusions, audit logs, and IP Indemnity.
- **C:** Incorrect. Content Exclusions (`2.3`, `6.1`) are only enforced for seats governed under Copilot Business or Copilot Enterprise.
- **D:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).

### Question 21 — `C` (Use GitHub Copilot features)

Correct answer: C (is correct). Use **Copilot Edits (`Edit` mode)** with those three files added to the working set (`whereas Agent Mode adds autonomous tool discovery and terminal command execution`). [Skill 2.2: Trigger Copilot through inline suggestions, chat, CLI, and agent mode | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/getting-code-suggestions-in-your-ide-with-github-copilot)]

- **A:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **B:** Incorrect. Only **Agent Mode** (or **Copilot CLI**, `2.2`, `2.9`) autonomously edits multiple files and runs terminal verification loops.
- **C:** Correct. Triggering Copilot across surfaces (`2.2`) matches Inline Chat, `Ask`, `Edit`, Agent Mode, and Copilot CLI to task complexity.
- **D:** Incorrect. False: reusable Copilot Chat prompt files are Markdown files (`*.prompt.md`) stored in `.github/prompts/` (`with "chat.promptFiles": true`) and invoked on-demand (`2.12`).

### Question 22 — `A, E` (Use GitHub Copilot features)

Correct answers: A and E (are correct). VS Code **Agent Mode** autonomously plans multi-file edits, invokes `.vscode/mcp.json` tools, and iterates against terminal errors, while **Copilot CLI (`copilot`)** provides terminal-native agentic editing and shell execution. [Skill 2.2: Trigger Copilot through inline suggestions, chat, CLI, and agent mode | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/getting-code-suggestions-in-your-ide-with-github-copilot)]

- **A:** Correct. Triggering Copilot across surfaces (`2.2`) matches Inline Chat, `Ask`, `Edit`, Agent Mode, and Copilot CLI to task complexity.
- **B:** Incorrect. Only **Agent Mode** (or **Copilot CLI**, `2.2`, `2.9`) autonomously edits multiple files and runs terminal verification loops.
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Incorrect. False: reusable Copilot Chat prompt files are Markdown files (`*.prompt.md`) stored in `.github/prompts/` (`with "chat.promptFiles": true`) and invoked on-demand (`2.12`).
- **E:** Correct. GitHub Copilot CLI (`2.4`) brings agentic file editing, command execution, and GitHub workflow integration directly to the terminal.

### Question 23 — `D` (Use GitHub Copilot features)

Correct answer: D (is correct). Copilot Content Exclusions use case-insensitive **`fnmatch`** glob syntax (`supporting *, **, ?, and [seq]`, anchored relative to the repository root). [Skill 2.3: Configure content exclusions for specific files or repositories (app knowledge) | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/managing-copilot/configuring-and-auditing-content-exclusion)]

- **A:** Incorrect. False: Copilot Content Exclusions apply strictly to **GitHub Copilot** features—they never restrict Git repository ACLs, Actions workflows, or `CodeQL` (`6.1`).
- **B:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).
- **C:** Incorrect. Adding a tracked path to `.gitignore` (`6.1`) does NOT stop Copilot from reading that file in the IDE or on GitHub.com.
- **D:** Correct. IDE/repo content exclusion awareness (`2.3`) prevents specified paths from being read into Copilot prompts on Business and Enterprise plans.

### Question 24 — `C` (Use GitHub Copilot features)

Correct answer: C (is correct). Yes — Organization Content Exclusion YAML maps repository keys (`exact repo names or "*"` for all org repos) to lists of excluded path globs. [Skill 2.3: Configure content exclusions for specific files or repositories (app knowledge) | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/managing-copilot/configuring-and-auditing-content-exclusion)]

- **A:** Incorrect. False: Copilot Content Exclusions apply strictly to **GitHub Copilot** features—they never restrict Git repository ACLs, Actions workflows, or `CodeQL` (`6.1`).
- **B:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **C:** Correct. IDE/repo content exclusion awareness (`2.3`) prevents specified paths from being read into Copilot prompts on Business and Enterprise plans.
- **D:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).

### Question 25 — `A` (Use GitHub Copilot features)

Correct answer: A (is correct). Yes — GitHub Copilot CLI (`copilot`) is a full agentic terminal assistant capable of reading/editing files, executing shell test commands (`subject to permission prompts`), and integrating with GitHub issues/PRs. [Skill 2.4: Define GitHub Copilot CLI and how it benefits developers | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use/copilot-cli)]

- **A:** Correct. GitHub Copilot CLI (`2.4`) brings agentic file editing, command execution, and GitHub workflow integration directly to the terminal.
- **B:** Incorrect. False: `@github/copilot` npm installs require **Node.js 22+**, prompt for explicit user permission before modifying files/running commands by default, and use OAuth `/login` (`2.5`, `2.8`).
- **C:** Incorrect. Copilot Audit Logs and Metrics API (`2.14`) separate security/compliance event logs from anonymized (`>=5`-user) adoption telemetry.
- **D:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).

### Question 26 — `D` (Use GitHub Copilot features)

Correct answer: D (is correct). Installing Node.js `22+` & `npm install -g @github/copilot`, `cd`ing to `~/src/fhir-gateway` & running `copilot`, entering `/login` for GitHub OAuth, and confirming directory trust + `/permissions show` completes setup. [Skill 2.5: Identify the steps for installing GitHub Copilot CLI | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/get-started/cli-quickstart)]

- **A:** Incorrect. Incorrect: `/login` runs inside interactive `copilot`, npm installs require Node.js `22+`, and `config.json` never stores plaintext passwords.
- **B:** Incorrect. Incorrect: `~/.copilot/logs/` stores session logs, and Copilot CLI requires approval before modifying files in default mode.
- **C:** Incorrect. Incorrect: disabling the org Copilot CLI policy blocks access, and authentication must precede non-interactive execution.
- **D:** Correct. Correct order: install `@github/copilot` -> `cd` to project & start `copilot` -> authenticate via `/login` -> confirm folder trust & inspect tool permissions.

### Question 27 — `A` (Use GitHub Copilot features)

Correct answer: A (is correct). Running `winget install GitHub.Copilot` installs the official GitHub Copilot CLI binary on Windows (`alongside Homebrew on macOS/Linux and npm install -g @github/copilot on Node.js 22+`). [Skill 2.5: Identify the steps for installing GitHub Copilot CLI | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/get-started/cli-quickstart)]

- **A:** Correct. Installing GitHub Copilot CLI (`2.5`) uses `@github/copilot` (`Node 22+`), WinGet, or Homebrew, followed by `/login` OAuth and directory trust confirmation.
- **B:** Incorrect. False: reusable Copilot Chat prompt files are Markdown files (`*.prompt.md`) stored in `.github/prompts/` (`with "chat.promptFiles": true`) and invoked on-demand (`2.12`).
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Incorrect. False: `@github/copilot` npm installs require **Node.js 22+**, prompt for explicit user permission before modifying files/running commands by default, and use OAuth `/login` (`2.5`, `2.8`).

### Question 28 — `A` (Use GitHub Copilot features)

Correct answer: A (is correct). Passing `--no-ask-user` prevents Copilot CLI from pausing to prompt the user for clarifying input during non-interactive `-p` automation. [Skill 2.6: Describe key GitHub Copilot CLI features and commands | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/enterprise-cloud@latest/copilot/reference/copilot-cli-reference/cli-programmatic-reference)]

- **A:** Correct. Copilot CLI programmatic flags (`2.6`) control non-interactive scripting (`-p`, `-s`, `--output-format=json`), tool permissions, and `--fleet` parallelism.
- **B:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Incorrect. False: `@github/copilot` npm installs require **Node.js 22+**, prompt for explicit user permission before modifying files/running commands by default, and use OAuth `/login` (`2.5`, `2.8`).

### Question 29 — `A, B` (Use GitHub Copilot features)

Correct answers: A and B (are correct). Use `--deny-tool` / `--available-tools` (`plus --allow-url / --deny-url`, where `--deny-url` overrides `--allow-url`) and pass `--secret-env-vars=FHIR_CLIENT_SECRET`. [Skill 2.6: Describe key GitHub Copilot CLI features and commands | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/enterprise-cloud@latest/copilot/reference/copilot-cli-reference/cli-programmatic-reference)]

- **A:** Correct. Copilot CLI programmatic flags (`2.6`) control non-interactive scripting (`-p`, `-s`, `--output-format=json`), tool permissions, and `--fleet` parallelism.
- **B:** Correct. Least-privilege Copilot CLI flags (`2.6`, `2.8`) restrict tool execution, path writes, and secret exposure in automated scripts.
- **C:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).
- **D:** Incorrect. False: `@github/copilot` npm installs require **Node.js 22+**, prompt for explicit user permission before modifying files/running commands by default, and use OAuth `/login` (`2.5`, `2.8`).
- **E:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).

### Question 30 — `C` (Use GitHub Copilot features)

Correct answer: C (is correct). Entering `/session files` lists temporary session artifacts (`stored under ~/.copilot/session-state/{id}/files/`), `/session plan` displays `plan.md`, and `/session checkpoints NUMBER` inspects compaction checkpoints. [Skill 2.7: Use GitHub Copilot CLI interactively and in sessions | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/how-tos/copilot-cli/cli-best-practices)]

- **A:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **B:** Incorrect. False: `@github/copilot` npm installs require **Node.js 22+**, prompt for explicit user permission before modifying files/running commands by default, and use OAuth `/login` (`2.5`, `2.8`).
- **C:** Correct. Interactive Copilot CLI sessions (`2.7`) persist plans, compaction checkpoints, and artifacts in `~/.copilot/session-state/` for `--resume`.
- **D:** Incorrect. False: `#runSubagent` runs autonomously in its **own isolated context window** without pausing for user feedback, returning only the distilled result (`2.9`).

### Question 31 — `D` (Use GitHub Copilot features)

Correct answer: D (is correct). No — deleting `~/.copilot/session-state/` removes **local** copies only; if sessions were synced to your GitHub account, synced sessions are stored separately and must be deleted or hidden on GitHub.com. [Skill 2.7: Use GitHub Copilot CLI interactively and in sessions | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/how-tos/copilot-cli/cli-best-practices)]

- **A:** Incorrect. False: `@github/copilot` npm installs require **Node.js 22+**, prompt for explicit user permission before modifying files/running commands by default, and use OAuth `/login` (`2.5`, `2.8`).
- **B:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **C:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).
- **D:** Correct. Interactive Copilot CLI sessions (`2.7`) persist plans, compaction checkpoints, and artifacts in `~/.copilot/session-state/` for `--resume`.

### Question 32 — `C` (Use GitHub Copilot features)

Correct answer: C (is correct). Copilot CLI automatically redacts values stored in `GITHUB_TOKEN` and `COPILOT_GITHUB_TOKEN` by default (`use --secret-env-vars=VAR1,VAR2 to redact additional custom secrets`). [Skill 2.8: Generate scripts and manage files with GitHub Copilot CLI | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/enterprise-cloud@latest/copilot/reference/copilot-cli-reference/cli-config-dir-reference)]

- **A:** Incorrect. False: Copilot Content Exclusions apply strictly to **GitHub Copilot** features—they never restrict Git repository ACLs, Actions workflows, or `CodeQL` (`6.1`).
- **B:** Incorrect. False: the Copilot coding agent works on an isolated `copilot/*` branch, opens a **draft pull request**, respects branch protections, and requires human review (`2.9`, `2.10`).
- **C:** Correct. Copilot CLI file and script management (`2.8`) enforces explicit write/command approval, `--add-dir` path boundaries, and secret redaction (`GITHUB_TOKEN` redacted by default).
- **D:** Incorrect. False: `@github/copilot` npm installs require **Node.js 22+**, prompt for explicit user permission before modifying files/running commands by default, and use OAuth `/login` (`2.5`, `2.8`).

### Question 33 — `D` (Use GitHub Copilot features)

Correct answer: D (is correct). User-editable Copilot CLI preferences belong in `~/.copilot/settings.json` (`whereas config.json is managed automatically for auth/plugins/trusted folders, and permissions-config.json stores tool approval rules`). [Skill 2.8: Generate scripts and manage files with GitHub Copilot CLI | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/enterprise-cloud@latest/copilot/reference/copilot-cli-reference/cli-config-dir-reference)]

- **A:** Incorrect. False: `@github/copilot` npm installs require **Node.js 22+**, prompt for explicit user permission before modifying files/running commands by default, and use OAuth `/login` (`2.5`, `2.8`).
- **B:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Correct. Copilot CLI interactive slash commands and `~/.copilot/settings.json` (`2.6`, `2.8`) govern tool approvals and model selection (`config.json` is internal runtime state).

### Question 34 — `A` (Use GitHub Copilot features)

Correct answer: A (is correct). Registering the MCP server in `.vscode/mcp.json`, delegating broad endpoint cataloging to `#runSubagent`, applying multi-file edits + `pytest` in Agent Mode, and reviewing/`Keep`ing verified diffs optimizes accuracy and token usage. [Skill 2.9: Use Agent Mode, Copilot Edits, and MCP for enhanced development and workflows; manage Agent Sessions and delegate tasks to Sub-Agents for optimized context usage | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/customizing-copilot/extending-copilot-chat-with-mcp)]

- **A:** Correct. Correct order: register `.vscode/mcp.json` tools -> isolate noisy research via `#runSubagent` -> iterate edits/tests in Agent Mode -> inspect & `Keep` verified diffs.
- **B:** Incorrect. Incorrect: `.git/HEAD` is Git metadata (not `.vscode/mcp.json`), and diffs must be reviewed before commit.
- **C:** Incorrect. Incorrect: `Ask` mode cannot autonomously edit files or execute terminal loops, and `Keep` should follow diff & test verification.
- **D:** Incorrect. Incorrect: never commit secrets to `.github/copilot-instructions.md`, and `#runSubagent` runs autonomously in isolated context without pausing for user input.

### Question 35 — `D` (Use GitHub Copilot features)

Correct answer: D (is correct). Committing `.vscode/mcp.json` shares MCP server definitions across the team in VS Code (`using input variables like ${input:api_key} so credentials are prompted securely and never committed`). [Skill 2.9: Use Agent Mode, Copilot Edits, and MCP for enhanced development and workflows; manage Agent Sessions and delegate tasks to Sub-Agents for optimized context usage | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/customizing-copilot/extending-copilot-chat-with-mcp)]

- **A:** Incorrect. Only **Agent Mode** (or **Copilot CLI**, `2.2`, `2.9`) autonomously edits multiple files and runs terminal verification loops.
- **B:** Incorrect. False: `#runSubagent` runs autonomously in its **own isolated context window** without pausing for user feedback, returning only the distilled result (`2.9`).
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Correct. Agent Mode + MCP (`2.9`) connects Copilot to external tools/APIs via `.vscode/mcp.json` and iterates across edits and terminal runs autonomously.

### Question 36 — `A, D, F` (Use GitHub Copilot features)

Correct answers: A, D, and F (are correct). `Agent Sessions` unifies status and mid-run chat-editor steering across local/CLI/cloud agents, `#runSubagent` isolates research context (`with Agent Mode + .vscode/mcp.json`), and the cloud coding agent opens draft PRs from an ephemeral Actions sandbox. [Skill 2.9: Use Agent Mode, Copilot Edits, and MCP for enhanced development and workflows; manage Agent Sessions and delegate tasks to Sub-Agents for optimized context usage | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/customizing-copilot/extending-copilot-chat-with-mcp)]

- **A:** Correct. Agent Sessions and `#runSubagent` (`2.9`) provide unified multi-agent orchestration and isolated sub-agent context windows.
- **B:** Incorrect. Only **Agent Mode** (or **Copilot CLI**, `2.2`, `2.9`) autonomously edits multiple files and runs terminal verification loops.
- **C:** Incorrect. False: `#runSubagent` runs autonomously in its **own isolated context window** without pausing for user feedback, returning only the distilled result (`2.9`).
- **D:** Correct. Copilot coding agent (`2.9`) executes asynchronous repository tasks in an isolated cloud sandbox and opens a draft PR without merging autonomously.
- **E:** Incorrect. False: the Copilot coding agent works on an isolated `copilot/*` branch, opens a **draft pull request**, respects branch protections, and requires human review (`2.9`, `2.10`).
- **F:** Correct. Agent Mode + MCP (`2.9`) connects Copilot to external tools/APIs via `.vscode/mcp.json` and iterates across edits and terminal runs autonomously.

### Question 37 — `D` (Use GitHub Copilot features)

Correct answer: D (is correct). Enabling **`Review draft pull requests`** under Automatic Copilot Code Review causes Copilot to review draft PRs immediately rather than waiting until `Ready for review`. [Skill 2.10: Use Copilot for code review and coding assistance | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/how-tos/copilot-on-github/set-up-copilot/configure-code-review)]

- **A:** Incorrect. False: the Copilot coding agent works on an isolated `copilot/*` branch, opens a **draft pull request**, respects branch protections, and requires human review (`2.9`, `2.10`).
- **B:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **C:** Incorrect. Copilot Code Review (`1.4`, `2.10`) supplements—never replaces—required human pull-request approvals.
- **D:** Correct. Copilot Code Review (`2.10`) posts `Comment` reviews with `suggestion` blocks—never counting toward required human merge approvals.

### Question 38 — `A` (Use GitHub Copilot features)

Correct answer: A (is correct). Open the **`Reviewers`** menu in the right sidebar of pull request `#208` and select **`Copilot`** (`just like requesting a review from a teammate`). [Skill 2.10: Use Copilot for code review and coding assistance | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/how-tos/copilot-on-github/set-up-copilot/configure-code-review)]

- **A:** Correct. Copilot Code Review (`2.10`) posts `Comment` reviews with `suggestion` blocks—never counting toward required human merge approvals.
- **B:** Incorrect. Copilot User Management REST API (`2.15`) provisions seats, audits `last_activity_at` dormancy, and cancels seats cleanly.
- **C:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **D:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).

### Question 39 — `D` (Use GitHub Copilot features)

Correct answer: D (is correct). Creating `.github/instructions/sql.instructions.md` (`applyTo: "db/**/*.sql"`), merging to the default branch, enabling `Automatically request Copilot code review` in an Org Ruleset, and pairing with human PR approval enforces review standards cleanly. [Skill 2.11: Utilize Spaces, Spark, Pull Request summaries, and customizable review standards via instructions files | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/how-tos/copilot-on-github/customize-copilot/add-custom-instructions/add-repository-instructions)]

- **A:** Incorrect. Incorrect: custom instructions must be concise Markdown (`.instructions.md` / `copilot-instructions.md`), not binary PDFs.
- **B:** Incorrect. Incorrect: blocking Copilot Code Review in Enterprise `AI controls` disables it across all enterprise repositories.
- **C:** Incorrect. Incorrect: `excludeAgent: "code-review"` excludes Copilot Code Review from reading that file, and Copilot comments never satisfy required human approvals.
- **D:** Correct. Correct order: author path-scoped `.instructions.md` (`applyTo:`) -> merge to default branch -> enable automatic Copilot review via Ruleset -> pair with human approval.

### Question 40 — `D` (Use GitHub Copilot features)

Correct answer: D (is correct). **GitHub Spark** enables rapid creation, live previewing, managed KV data storage, and sharing of AI-powered full-stack micro-apps from natural language. [Skill 2.11: Utilize Spaces, Spark, Pull Request summaries, and customizable review standards via instructions files | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/how-tos/copilot-on-github/customize-copilot/add-custom-instructions/add-repository-instructions)]

- **A:** Incorrect. False: reusable Copilot Chat prompt files are Markdown files (`*.prompt.md`) stored in `.github/prompts/` (`with "chat.promptFiles": true`) and invoked on-demand (`2.12`).
- **B:** Incorrect. Copilot User Management REST API (`2.15`) provisions seats, audits `last_activity_at` dormancy, and cancels seats cleanly.
- **C:** Incorrect. Copilot Spaces (`2.11`) organize shareable, always-synced multi-repo project context so responses stay grounded in team architecture.
- **D:** Correct. GitHub Spark (`2.11`) accelerates full-stack micro-app prototyping and deployment directly from natural language and visual controls.

### Question 41 — `B, E` (Use GitHub Copilot features)

Correct answers: B and E (are correct). Create a shared **Copilot Space** bundling those repos/docs, and add `excludeAgent: "code-review"` alongside `applyTo:` in `.github/instructions/agent-build.instructions.md`. [Skill 2.11: Utilize Spaces, Spark, Pull Request summaries, and customizable review standards via instructions files | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/how-tos/copilot-on-github/customize-copilot/add-custom-instructions/add-repository-instructions)]

- **A:** Incorrect. `excludeAgent: "code-review"` (`2.11`) tells GitHub.com to omit that instruction file during Copilot Code Review.
- **B:** Correct. Path-scoped `.instructions.md` files (`2.11`) automatically inject targeted coding and review rules only when matching files are touched.
- **C:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).
- **D:** Incorrect. False: reusable Copilot Chat prompt files are Markdown files (`*.prompt.md`) stored in `.github/prompts/` (`with "chat.promptFiles": true`) and invoked on-demand (`2.12`).
- **E:** Correct. Copilot Spaces (`2.11`) organize shareable, always-synced multi-repo project context so responses stay grounded in team architecture.

### Question 42 — `D` (Use GitHub Copilot features)

Correct answer: D (is correct). Custom instruction files (`copilot-instructions.md` and matching `applyTo:` `.instructions.md`) apply **automatically** as background context on matching requests, whereas `.prompt.md` files execute **on demand** when invoked via `/new-fhir-route` (`or Chat: Run Prompt`). [Skill 2.12: Understand the limits, options, feedback, and commands of GitHub Copilot Chat; include prompt file reuse for consistent responses | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/how-tos/configure-custom-instructions-in-your-ide/add-repository-instructions-in-your-ide)]

- **A:** Incorrect. Copilot Audit Logs and Metrics API (`2.14`) separate security/compliance event logs from anonymized (`>=5`-user) adoption telemetry.
- **B:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).
- **C:** Incorrect. False: reusable Copilot Chat prompt files are Markdown files (`*.prompt.md`) stored in `.github/prompts/` (`with "chat.promptFiles": true`) and invoked on-demand (`2.12`).
- **D:** Correct. Workspace `.prompt.md` prompt files (`2.12`) standardize repeatable task prompts across VS Code and JetBrains teams.

### Question 43 — `A, B` (Use GitHub Copilot features)

Correct answers: A and B (are correct). `@github` queries GitHub-specific context (`issues, PRs, commits, web/Bing search where enabled`) while `@workspace` searches local project code, and `.github/prompts/*.prompt.md` defines slash-invocable task templates (`with model/agent/tools frontmatter`). [Skill 2.12: Understand the limits, options, feedback, and commands of GitHub Copilot Chat; include prompt file reuse for consistent responses | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/how-tos/configure-custom-instructions-in-your-ide/add-repository-instructions-in-your-ide)]

- **A:** Correct. Copilot Chat participants, slash commands, `#` context variables, and feedback ratings (`2.12`) focus intent and report quality signals.
- **B:** Correct. Workspace `.prompt.md` files (`2.12`) turn repeatable scaffolding, review, and migration workflows into version-controlled slash commands.
- **C:** Incorrect. False: reusable Copilot Chat prompt files are Markdown files (`*.prompt.md`) stored in `.github/prompts/` (`with "chat.promptFiles": true`) and invoked on-demand (`2.12`).
- **D:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **E:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).

### Question 44 — `C` (Use GitHub Copilot features)

Correct answer: C (is correct). Navigate to Enterprise **`AI controls -> Agents`** and enable **`Block Copilot cloud agent in all repositories owned by <ENTERPRISE>`** and/or **`Block Copilot code review in all enterprise repositories`** (`plus Org authorized-user review enforcement`). [Skill 2.13: Configure organization-wide policy management; enable Copilot Code Review policies and manage feature availability across IDEs and github.com | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/enterprise-cloud@latest/copilot/how-tos/administer-copilot/manage-for-enterprise/manage-agents/block-agentic-features)]

- **A:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **B:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **C:** Correct. Enterprise repository-level agent blocks (`2.13`) protect enterprise repos even when a contributor holds an external personal Copilot plan.
- **D:** Incorrect. Content Exclusions (`2.3`, `6.1`) are only enforced for seats governed under Copilot Business or Copilot Enterprise.

### Question 45 — `C` (Use GitHub Copilot features)

Correct answer: C (is correct). Filtering Organization or Enterprise Audit Logs by `category:copilot` (`or action:copilot.*`) surfaces seat provisioning (`copilot.cfb_seat_created`), policy changes, and content-exclusion updates. [Skill 2.14: Utilize audit log events | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/managing-copilot/managing-github-copilot-in-your-organization/reviewing-activity-related-to-github-copilot-in-your-organization/reviewing-audit-logs-for-copilot-business)]

- **A:** Incorrect. Per-seat dormancy audits (`2.14`, `2.15`) require `/copilot/billing/seats`, whereas `/copilot/metrics` aggregates anonymized adoption stats.
- **B:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).
- **C:** Correct. Copilot Audit Logs and Metrics API (`2.14`) separate security/compliance event logs from anonymized (`>=5`-user) adoption telemetry.
- **D:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).

### Question 46 — `C` (Use GitHub Copilot features)

Correct answer: C (is correct). Pending cancellation takes effect at the **end of the current billing cycle** (`Unless removed from the org entirely, in which case the freed paid seat slot can be reassigned during the remainder of the cycle without double-billing`). [Skill 2.15: Manage subscriptions using the REST API | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/rest/copilot/copilot-user-management)]

- **A:** Incorrect. Per-seat dormancy audits (`2.14`, `2.15`) require `/copilot/billing/seats`, whereas `/copilot/metrics` aggregates anonymized adoption stats.
- **B:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **C:** Correct. Copilot User Management REST API (`2.15`) provisions seats, audits `last_activity_at` dormancy, and cancels seats cleanly.
- **D:** Incorrect. Individual Copilot tiers (`2.1`, `2.15`) serve single accounts without Organization policy management or Org Content Exclusions.

### Question 47 — `B` (Understand GitHub Copilot data and architecture)

Correct answer: B (is correct). No — under Copilot Business and Enterprise commitments, neither GitHub nor underlying model-hosting partners retain or use your prompts or completions to train foundation models. [Skill 3.1: Explain data usage, flow, and sharing | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/managing-copilot/managing-copilot-as-an-individual-subscriber/managing-copilot-policies-as-an-individual-subscriber)]

- **A:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **B:** Correct. Copilot Business/Enterprise data handling (`3.1`) guarantees `TLS 1.2+` encryption and zero foundational-model training on customer code (`Free/Pro provide a training opt-out toggle`).
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).

### Question 48 — `C` (Understand GitHub Copilot data and architecture)

Correct answer: C (is correct). Data in transit is encrypted with **`TLS 1.2+`**, and persisted telemetry / chat history at rest is encrypted using strong **`AES-256`** storage encryption. [Skill 3.1: Explain data usage, flow, and sharing | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/managing-copilot/managing-copilot-as-an-individual-subscriber/managing-copilot-policies-as-an-individual-subscriber)]

- **A:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).
- **B:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **C:** Correct. Data flow architecture (`3.1`) separates operational/metrics telemetry from ephemeral prompt/completion payloads.
- **D:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).

### Question 49 — `C` (Understand GitHub Copilot data and architecture)

Correct answer: C (is correct). Personal Copilot Free/Pro accounts allow code-snippet retention for product/model improvements **unless opted out**, and lack Clarivance's Organization Content Exclusions and IP Indemnity. [Skill 3.1: Explain data usage, flow, and sharing | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/managing-copilot/managing-copilot-as-an-individual-subscriber/managing-copilot-policies-as-an-individual-subscriber)]

- **A:** Incorrect. Copilot User Management REST API (`2.15`) provisions seats, audits `last_activity_at` dormancy, and cancels seats cleanly.
- **B:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **C:** Correct. Individual privacy settings (`3.1`, `6.1`) govern optional snippet training on personal plans (`whereas Business/Enterprise disable code-snippet training by default`).
- **D:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).

### Question 50 — `B` (Understand GitHub Copilot data and architecture)

Correct answer: B (is correct). FIM passes line 22 as the **suffix** alongside lines 1–14 (`prefix`), allowing the model to bind its intermediate variable directly to `crcl_ml_min` so line 22 compiles seamlessly. [Skill 3.2: Describe input processing and prompt building | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/about-github-copilot/what-is-github-copilot)]

- **A:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **B:** Correct. Input processing and prompt building (`3.2`) combines cursor prefix + suffix (`FIM`), relevant open-tab snippets, and repository instructions.
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Incorrect. Copilot User Management REST API (`2.15`) provisions seats, audits `last_activity_at` dormancy, and cancels seats cleanly.

### Question 51 — `B` (Understand GitHub Copilot data and architecture)

Correct answer: B (is correct). Copilot **combines** applicable user-level, repository-wide (`copilot-instructions.md` / `AGENTS.md`), and path-matching `applyTo:` `.instructions.md` files (`deduplicating identical copies`), so keeping rules non-contradictory is important. [Skill 3.2: Describe input processing and prompt building | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/about-github-copilot/what-is-github-copilot)]

- **A:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **B:** Correct. Input processing and prompt building (`3.2`) combines cursor prefix + suffix (`FIM`), relevant open-tab snippets, and repository instructions.
- **C:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).
- **D:** Incorrect. False: reusable Copilot Chat prompt files are Markdown files (`*.prompt.md`) stored in `.github/prompts/` (`with "chat.promptFiles": true`) and invoked on-demand (`2.12`).

### Question 52 — `B, E` (Understand GitHub Copilot data and architecture)

Correct answers: B and E (are correct). Inline completions combine **FIM (`prefix + suffix`)** with Jacobi/Jaccard-scored snippets from open tabs, while `@workspace` uses **lexical + semantic embedding (`RAG`)** retrieval to select top chunks. [Skill 3.2: Describe input processing and prompt building | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/about-github-copilot/what-is-github-copilot)]

- **A:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **B:** Correct. Retrieval-augmented generation (`RAG`, `3.2`) selects the highest-relevance code slices that fit within the model's context token budget.
- **C:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).
- **D:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **E:** Correct. Fill-in-the-Middle (`FIM`, `3.2`) enables inline completions to align return types and variable names with surrounding downstream lines.

### Question 53 — `D` (Understand GitHub Copilot data and architecture)

Correct answer: D (is correct). The **Copilot cloud proxy's authentication & entitlement gate** rejects the request (`HTTP 401/403`) before any LLM inference runs, prompting the IDE to re-authenticate or check seat status. [Skill 3.3: Explain proxy filtering and post-processing | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use/copilot-chat-in-your-ide)]

- **A:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **B:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Correct. Proxy filtering and post-processing (`3.3`) enforces auth, RAI moderation, public-code duplication checks, and stop-token trimming.

### Question 54 — `C` (Understand GitHub Copilot data and architecture)

Correct answer: C (is correct). Proxy post-filtering includes classifiers/heuristics targeting **personally identifiable information (`PII`)** patterns (`such as emails, phone numbers, keys, or personal identifiers`). [Skill 3.3: Explain proxy filtering and post-processing | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use/copilot-chat-in-your-ide)]

- **A:** Incorrect. False: `@github/copilot` npm installs require **Node.js 22+**, prompt for explicit user permission before modifying files/running commands by default, and use OAuth `/login` (`2.5`, `2.8`).
- **B:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **C:** Correct. Proxy filtering and post-processing (`3.3`) enforces auth, RAI moderation, public-code duplication checks, and stop-token trimming.
- **D:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).

### Question 55 — `A, B` (Understand GitHub Copilot data and architecture)

Correct answers: A and B (are correct). Inbound/outbound **Responsible AI safety & prompt-injection filtering** and post-generation **`~150-character` public-code duplication filtering** (`plus stop-token trimming`). [Skill 3.3: Explain proxy filtering and post-processing | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use/copilot-chat-in-your-ide)]

- **A:** Correct. Cloud-proxy post-processing (`3.3`, `3.4`) enforces both RAI content safety and public-code matching policies prior to displaying ghost text.
- **B:** Correct. Proxy filtering and post-processing (`3.3`) enforces auth, RAI moderation, public-code duplication checks, and stop-token trimming.
- **C:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).
- **D:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **E:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).

### Question 56 — `C` (Understand GitHub Copilot data and architecture)

Correct answer: C (is correct). IDE gathers FIM prefix/suffix & open tabs (`minus Content Exclusions`) -> sends `TLS 1.2+` prompt to proxy & checks seat token -> proxy runs RAI filters, LLM & `~150+` char duplication check -> IDE renders ghost text & skips model training. [Skill 3.4: Visualize code suggestion lifecycle | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/paths/copilot/)]

- **A:** Incorrect. Incorrect: Copilot LLM inference and public-code duplication checks execute in the cloud proxy over authenticated TLS.
- **B:** Incorrect. Incorrect: inline completion sends scoped editor context over TLS, never runs tests on inference GPUs, and Business/Enterprise never trains base models on customer prompts.
- **C:** Correct. Correct order: IDE FIM/tab assembly (respecting exclusions) -> TLS proxy auth -> RAI + LLM + public-code filter -> ghost-text render & zero training retention.
- **D:** Incorrect. Incorrect: Content Exclusions block excluded paths from entering prompts, and prompts are never published to Gists.

### Question 57 — `D` (Understand GitHub Copilot data and architecture)

Correct answer: D (is correct). The IDE extension records a lightweight **dismissed/rejected suggestion engagement event** (`without storing the proprietary source code for model training on Business/Enterprise`), informing org acceptance-rate metrics. [Skill 3.4: Visualize code suggestion lifecycle | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/paths/copilot/)]

- **A:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **B:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **C:** Incorrect. False: the Copilot coding agent works on an isolated `copilot/*` branch, opens a **draft pull request**, respects branch protections, and requires human review (`2.9`, `2.10`).
- **D:** Correct. Code suggestion lifecycle (`3.4`) traces a completion from keystroke pause through IDE context assembly, cloud proxy inference/filtering, and ghost-text display.

### Question 58 — `D` (Understand GitHub Copilot data and architecture)

Correct answer: D (is correct). LLMs are bounded by their **pre-training knowledge cutoff** and can fabricate confident-sounding citations (**hallucinations**) when asked about ungrounded recent regulatory events. [Skill 3.5: Describe limitations of LLMs and Copilot | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use/copilot-coding-agent)]

- **A:** Incorrect. Copilot User Management REST API (`2.15`) provisions seats, audits `last_activity_at` dormancy, and cancels seats cleanly.
- **B:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Correct. LLM and Copilot limitations (`3.5`) explain why models hallucinate post-cutoff APIs, vary across runs, truncate overflow tokens, and need tests/MCP.

### Question 59 — `B` (Understand GitHub Copilot data and architecture)

Correct answer: B (is correct). Unless the target `models.py` / database schema is present in active prompt context (`or inspected via Agent Mode / MCP`), the LLM guesses foreign-key column names probabilistically without running Alembic. [Skill 3.5: Describe limitations of LLMs and Copilot | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use/copilot-coding-agent)]

- **A:** Incorrect. False: the Copilot coding agent works on an isolated `copilot/*` branch, opens a **draft pull request**, respects branch protections, and requires human review (`2.9`, `2.10`).
- **B:** Correct. LLM and Copilot limitations (`3.5`) explain why models hallucinate post-cutoff APIs, vary across runs, truncate overflow tokens, and need tests/MCP.
- **C:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).
- **D:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).

### Question 60 — `B` (Understand GitHub Copilot data and architecture)

Correct answer: B (is correct). No — LLMs enforce strict **input and output token ceilings**; split large migrations into single-router/single-endpoint tasks (`closing irrelevant tabs and clearing chat between modules`). [Skill 3.5: Describe limitations of LLMs and Copilot | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/responsible-use/copilot-coding-agent)]

- **A:** Incorrect. The proposed GitHub Copilot configuration or workflow violates at least one stated governance, privacy, or technical requirement. No — LLMs enforce strict **input and output token ceilings**; split large migrations into single-router/single-endpoint tasks (`closing irrelevant tabs and clearing chat between modules`).
- **B:** Correct. Clean editor tabs, `/clear` between topics, and `#runSubagent` isolation (`4.2`, `4.6`) prevent context confusion.
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).

### Question 61 — `C` (Apply prompt engineering and context crafting)

Correct answer: C (is correct). It defines **Role**, **Grounded Context (`#file:BundleSchema.json`, Python 3.12/Pydantic v2)**, **Explicit Validation Constraints**, and **Output Format**. [Skill 4.1: Describe prompt structure and context | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/copilot-chat/prompt-engineering-for-copilot-chat)]

- **A:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).
- **B:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **C:** Correct. Prompt structure (`4.1`) combines clear intent, grounded workspace context, explicit constraints, and expected output format.
- **D:** Incorrect. False: reusable Copilot Chat prompt files are Markdown files (`*.prompt.md`) stored in `.github/prompts/` (`with "chat.promptFiles": true`) and invoked on-demand (`2.12`).

### Question 62 — `D` (Apply prompt engineering and context crafting)

Correct answer: D (is correct). Docstrings immediately preceding the cursor act as high-weight local prompt instructions inside the FIM prefix, steering inline ghost text directly to the exact masking rule. [Skill 4.1: Describe prompt structure and context | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/copilot-chat/prompt-engineering-for-copilot-chat)]

- **A:** Incorrect. Copilot Audit Logs and Metrics API (`2.14`) separate security/compliance event logs from anonymized (`>=5`-user) adoption telemetry.
- **B:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **C:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **D:** Correct. In-editor context signals (`4.1`, `4.4`) anchor Fill-in-the-Middle inline completions without leaving the code buffer.

### Question 63 — `A` (Apply prompt engineering and context crafting)

Correct answer: A (is correct). `#selection` injects the active editor's currently highlighted code range directly into the Chat prompt (`avoiding ambiguity in long files`). [Skill 4.2: Understand how context is determined | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/asking-github-copilot-questions-in-your-ide)]

- **A:** Correct. Context determination (`4.2`) controls which open tabs, `#` chat variables, workspace indexes, and path-matched instructions enter the prompt.
- **B:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).
- **C:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **D:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).

### Question 64 — `B` (Apply prompt engineering and context crafting)

Correct answer: B (is correct). No — modular `.instructions.md` files are **path-scoped** and injected only when Copilot is working with files matching their `applyTo:` glob (`saving context tokens on unrelated files`). [Skill 4.2: Understand how context is determined | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/asking-github-copilot-questions-in-your-ide)]

- **A:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **B:** Correct. Context determination (`4.2`) controls which open tabs, `#` chat variables, workspace indexes, and path-matched instructions enter the prompt.
- **C:** Incorrect. False: reusable Copilot Chat prompt files are Markdown files (`*.prompt.md`) stored in `.github/prompts/` (`with "chat.promptFiles": true`) and invoked on-demand (`2.12`).
- **D:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).

### Question 65 — `A, E` (Apply prompt engineering and context crafting)

Correct answers: A and E (are correct). Open `models/lab_order.py` and `repositories/base.py` (`closing unrelated React/Terraform tabs`) and attach `#file:` references (`plus path-matched .instructions.md rules`). [Skill 4.2: Understand how context is determined | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/asking-github-copilot-questions-in-your-ide)]

- **A:** Correct. Curating open tabs and `#file:` attachments (`4.2`, `4.4`) directly improves prompt signal-to-noise ratio.
- **B:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **C:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).
- **D:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **E:** Correct. Context determination (`4.2`) controls which open tabs, `#` chat variables, workspace indexes, and path-matched instructions enter the prompt.

### Question 66 — `D` (Apply prompt engineering and context crafting)

Correct answer: D (is correct). Provide **few-shot prompting** (`2–3 exact raw-code -> FhirOperationOutcome input/output pairs` using non-PHI synthetic examples) followed by the remaining codes to map. [Skill 4.3: Use zero-shot and few-shot prompting | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/copilot-chat/prompt-engineering-for-copilot-chat)]

- **A:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).
- **B:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **C:** Incorrect. False: mocking the unit under test or writing tautological assertions provides zero behavioral verification (`1.4`, `5.4`, `5.5`).
- **D:** Correct. Zero-shot vs few-shot prompting (`4.3`) reserves token-heavier exemplars for custom team patterns that general pretraining cannot infer.

### Question 67 — `B` (Apply prompt engineering and context crafting)

Correct answer: B (is correct). **One-shot prompting** (`a single exemplar`, between zero-shot `0` examples and few-shot `2+` examples) establishes structural formatting when one clear pattern suffices. [Skill 4.3: Use zero-shot and few-shot prompting | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/copilot-chat/prompt-engineering-for-copilot-chat)]

- **A:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **B:** Correct. Zero-shot vs few-shot prompting (`4.3`) reserves token-heavier exemplars for custom team patterns that general pretraining cannot infer.
- **C:** Incorrect. Copilot User Management REST API (`2.15`) provisions seats, audits `last_activity_at` dormancy, and cancels seats cleanly.
- **D:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).

### Question 68 — `D` (Apply prompt engineering and context crafting)

Correct answer: D (is correct). Public training corpora contain vast quantities of legacy SQLAlchemy 1.x `session.query()` code; stating explicit versioned APIs prevents pre-2.0 syntax drift. [Skill 4.4: Apply best practices for prompt crafting | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/best-practices-for-using-github-copilot)]

- **A:** Incorrect. Clean editor tabs, `/clear` between topics, and `#runSubagent` isolation (`4.2`, `4.6`) prevent context confusion.
- **B:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **C:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **D:** Correct. Prompt-crafting best practices (`4.4`) favor incremental decomposition, version pinning, and feedback-driven iteration.

### Question 69 — `B` (Apply prompt engineering and context crafting)

Correct answer: B (is correct). Attach `#file:middleware/correlation.py` (`grounding the missing interface`) and refine the constraint (`or edit your last prompt turn`) rather than repeating the same ungrounded question verbatim. [Skill 4.4: Apply best practices for prompt crafting | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/best-practices-for-using-github-copilot)]

- **A:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **B:** Correct. Prompt-crafting best practices (`4.4`) favor incremental decomposition, version pinning, and feedback-driven iteration.
- **C:** Incorrect. False: mocking the unit under test or writing tautological assertions provides zero behavioral verification (`1.4`, `5.4`, `5.5`).
- **D:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).

### Question 70 — `C` (Apply prompt engineering and context crafting)

Correct answer: C (is correct). Setting `"chat.promptFiles": true` + adding `.github/prompts/fhir-endpoint.prompt.md`, linking `#file:` exemplars in Git, invoking `/fhir-endpoint` with clean tabs, and running `/clear` before switching topics ensures consistency. [Skill 4.5: Explain prompt engineering principles | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/paths/gh-copilot-2/)]

- **A:** Incorrect. Incorrect: reusable prompt files end in `.prompt.md` under `.github/prompts/` (`whereas applyTo: belongs to *.instructions.md`).
- **B:** Incorrect. Incorrect: never embed secrets in repository prompt files, and one-word prompts lack actionable context.
- **C:** Correct. Correct order: create `.github/prompts/*.prompt.md` -> link few-shot exemplars -> invoke `/api` with clean tab context -> reset chat on topic switch.
- **D:** Incorrect. Incorrect: `.github/workflows/*.yml` defines Actions workflows (not `.github/prompts/*.prompt.md`), and stale tabs + long threads cause context drift.

### Question 71 — `B` (Apply prompt engineering and context crafting)

Correct answer: B (is correct). Concise, specific, imperative bullets perform far better because custom instructions share the finite prompt token window with code context on every request. [Skill 4.5: Explain prompt engineering principles | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/paths/gh-copilot-2/)]

- **A:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **B:** Correct. Prompt engineering principles (`4.5`) emphasize specificity, positive constraints, authoritative grounding, and reusable templates.
- **C:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).
- **D:** Incorrect. False: mocking the unit under test or writing tautological assertions provides zero behavioral verification (`1.4`, `5.4`, `5.5`).

### Question 72 — `C` (Apply prompt engineering and context crafting)

Correct answer: C (is correct). All prior turns in the **active chat history** remain part of the conversational context sent to the model, biasing turn 36 toward earlier Docker topics (`use /clear or New Chat instead`). [Skill 4.6: Describe prompt process flow and chat history usage | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/asking-github-copilot-questions-in-your-ide)]

- **A:** Incorrect. False: `#runSubagent` runs autonomously in its **own isolated context window** without pausing for user feedback, returning only the distilled result (`2.9`).
- **B:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **C:** Correct. Prompt process flow and chat history management (`4.6`) prevent context drift and token-window eviction across unrelated tasks.
- **D:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).

### Question 73 — `B, D` (Apply prompt engineering and context crafting)

Correct answers: B and D (are correct). Start a fresh chat (`/clear`) whenever switching between unrelated tasks, and delegate broad multi-file exploratory lookups to `#runSubagent` so main history stays focused. [Skill 4.6: Describe prompt process flow and chat history usage | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/asking-github-copilot-questions-in-your-ide)]

- **A:** Incorrect. Clean editor tabs, `/clear` between topics, and `#runSubagent` isolation (`4.2`, `4.6`) prevent context confusion.
- **B:** Correct. Prompt process flow and chat history management (`4.6`) prevent context drift and token-window eviction across unrelated tasks.
- **C:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **D:** Correct. Resetting chat history on task switches (`4.6`) avoids context confusion and token-window truncation.
- **E:** Incorrect. False: `#runSubagent` runs autonomously in its **own isolated context window** without pausing for user feedback, returning only the distilled result (`2.9`).

### Question 74 — `C` (Improve developer productivity with GitHub Copilot)

Correct answer: C (is correct). Use Copilot Edits / Agent Mode (`or /doc per router`) grounded on one fully documented exemplar router to populate `Field` descriptions and docstrings consistently, then verify `/openapi.json` schema generation. [Skill 5.1: Use Copilot for code generation, refactoring, and documentation | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/modules/developer-use-cases-for-ai-with-github-copilot/)]

- **A:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **B:** Incorrect. False: mocking the unit under test or writing tautological assertions provides zero behavioral verification (`1.4`, `5.4`, `5.5`).
- **C:** Correct. Code generation, refactoring, and documentation (`5.1`) accelerates boilerplate, structural cleanup, and API docs while preserving behavior.
- **D:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).

### Question 75 — `B` (Improve developer productivity with GitHub Copilot)

Correct answer: B (is correct). Ask Copilot Edits to extract pure domain validation (`DosageValidator`) and repository/storage port interfaces from the thin HTTP controller while keeping existing integration tests passing. [Skill 5.1: Use Copilot for code generation, refactoring, and documentation | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/modules/developer-use-cases-for-ai-with-github-copilot/)]

- **A:** Incorrect. False: reusable Copilot Chat prompt files are Markdown files (`*.prompt.md`) stored in `.github/prompts/` (`with "chat.promptFiles": true`) and invoked on-demand (`2.12`).
- **B:** Correct. Code generation, refactoring, and documentation (`5.1`) accelerates boilerplate, structural cleanup, and API docs while preserving behavior.
- **C:** Incorrect. Copilot User Management REST API (`2.15`) provisions seats, audits `last_activity_at` dormancy, and cancels seats cleanly.
- **D:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).

### Question 76 — `D` (Improve developer productivity with GitHub Copilot)

Correct answer: D (is correct). No — `Ask` mode only returns conversational text/code blocks without executing autonomous multi-file workspace edits or terminal test self-healing loops; use **Agent Mode** (`or Copilot CLI`). [Skill 5.1: Use Copilot for code generation, refactoring, and documentation | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/modules/developer-use-cases-for-ai-with-github-copilot/)]

- **A:** Incorrect. False: the Copilot coding agent works on an isolated `copilot/*` branch, opens a **draft pull request**, respects branch protections, and requires human review (`2.9`, `2.10`).
- **B:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **C:** Incorrect. The proposed GitHub Copilot configuration or workflow violates at least one stated governance, privacy, or technical requirement. No — `Ask` mode only returns conversational text/code blocks without executing autonomous multi-file workspace edits or terminal test self-healing loops; use **Agent Mode** (`or Copilot CLI`).
- **D:** Correct. Only **Agent Mode** (or **Copilot CLI**, `2.2`, `2.9`) autonomously edits multiple files and runs terminal verification loops.

### Question 77 — `C` (Improve developer productivity with GitHub Copilot)

Correct answer: C (is correct). Selecting the SQL query and invoking `/explain` breaks down the anchor member, recursive join, and cycle-termination guard without leaving the editor. [Skill 5.2: Accelerate learning and reduce context switching | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/copilot-chat/copilot-chat-cookbook)]

- **A:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).
- **B:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **C:** Correct. Accelerating learning and reducing context switching (`5.2`) keeps developers productive inside the IDE and terminal.
- **D:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).

### Question 78 — `A` (Improve developer productivity with GitHub Copilot)

Correct answer: A (is correct). The **Copilot Space** answers cross-repository architecture and ADR questions grounded in curated org repos/docs, while `@workspace` locates exact implementation files and call paths locally in the IDE. [Skill 5.2: Accelerate learning and reduce context switching | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/copilot-chat/copilot-chat-cookbook)]

- **A:** Correct. Accelerating learning and reducing context switching (`5.2`) keeps developers productive inside the IDE and terminal.
- **B:** Incorrect. Copilot User Management REST API (`2.15`) provisions seats, audits `last_activity_at` dormancy, and cancels seats cleanly.
- **C:** Incorrect. False: reusable Copilot Chat prompt files are Markdown files (`*.prompt.md`) stored in `.github/prompts/` (`with "chat.promptFiles": true`) and invoked on-demand (`2.12`).
- **D:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).

### Question 79 — `A` (Improve developer productivity with GitHub Copilot)

Correct answer: A (is correct). Mapping legacy behavior & invariants via `/explain` and `@workspace` -> building characterization & boundary unit tests (`/tests`) -> refactoring incrementally via Copilot Edits / Agent Mode -> re-running tests, `CodeQL` & benchmarks. [Skill 5.3: Generate sample data and modernize legacy code | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/tutorials/modernize-legacy-code)]

- **A:** Correct. Correct order: map legacy behavior -> lock behavior with characterization/edge-case tests -> refactor incrementally -> verify parity, security & performance.
- **B:** Incorrect. Incorrect: monolithic rewrites exceed LLM context windows and deleting failing tests destroys regression safety.
- **C:** Incorrect. Incorrect: always synthesize fake test data (`never real PII/PCI`) and replace SQL concatenation with parameterized queries.
- **D:** Incorrect. Incorrect: tautological assertions detect zero regressions; tests must assert real outputs and boundary conditions.

### Question 80 — `A` (Improve developer productivity with GitHub Copilot)

Correct answer: A (is correct). Attach ONLY the FHIR JSON Schema / Pydantic model (`zero real patient PHI`) and ask Copilot to write a seeded `Faker` / Python generator script producing 200 synthetic bundles. [Skill 5.3: Generate sample data and modernize legacy code | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/tutorials/modernize-legacy-code)]

- **A:** Correct. Sample data generation and legacy modernization (`5.3`) combine synthetic non-PII fixtures with test-backed incremental upgrades.
- **B:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **C:** Incorrect. False: mocking the unit under test or writing tautological assertions provides zero behavioral verification (`1.4`, `5.4`, `5.5`).
- **D:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).

### Question 81 — `B` (Improve developer productivity with GitHub Copilot)

Correct answer: B (is correct). Grounding Copilot on the authoritative `api-types.ts` contract ensures generated React hooks and form validators use exact field names and nullable types instead of guessing from untyped jQuery DOM selectors. [Skill 5.3: Generate sample data and modernize legacy code | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/tutorials/modernize-legacy-code)]

- **A:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).
- **B:** Correct. Sample data generation and legacy modernization (`5.3`) combine synthetic non-PII fixtures with test-backed incremental upgrades.
- **C:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **D:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).

### Question 82 — `C` (Improve developer productivity with GitHub Copilot)

Correct answer: C (is correct). Unit tests should mock/stub the HTTP transport (`e.g., respx / httpx.MockTransport` testing `200`, `429`, `503`, and malformed JSON), while integration tests run against an isolated local contract stub or `Testcontainers` service. [Skill 5.4: Generate unit and integration tests | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/modules/develop-unit-tests-using-github-copilot-tools/)]

- **A:** Incorrect. False: mocking the unit under test or writing tautological assertions provides zero behavioral verification (`1.4`, `5.4`, `5.5`).
- **B:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).
- **C:** Correct. Generating unit and integration tests (`5.4`) automates test scaffolding, dependency isolation, and parameterized coverage.
- **D:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).

### Question 83 — `B, C` (Improve developer productivity with GitHub Copilot)

Correct answers: B and C (are correct). Use `@pytest.mark.parametrize` with isolated I/O mocks for external services, and write characterization tests locking legacy clinical calculation outputs before refactoring. [Skill 5.4: Generate unit and integration tests | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://learn.microsoft.com/en-us/training/modules/develop-unit-tests-using-github-copilot-tools/)]

- **A:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).
- **B:** Correct. Characterization testing (`5.3`, `5.4`) guarantees legacy modernization preserves subtle business edge cases.
- **C:** Correct. Generating unit and integration tests (`5.4`) automates test scaffolding, dependency isolation, and parameterized coverage.
- **D:** Incorrect. False: mocking the unit under test or writing tautological assertions provides zero behavioral verification (`1.4`, `5.4`, `5.5`).
- **E:** Incorrect. False: the Copilot coding agent works on an isolated `copilot/*` branch, opens a **draft pull request**, respects branch protections, and requires human review (`2.9`, `2.10`).

### Question 84 — `B` (Improve developer productivity with GitHub Copilot)

Correct answer: B (is correct). Add assertions for leap-day `"2024-02-29"` vs invalid non-leap `"2023-02-29"`, future dates (`> today`), extreme historical ages, empty/whitespace strings, Unicode digits, and timezone-offset strings. [Skill 5.5: Identify edge cases and write assertions | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/copilot-chat/copilot-chat-cookbook)]

- **A:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **B:** Correct. Edge-case identification and assertion quality (`5.5`) ensures tests catch real boundary defects rather than inflating superficial coverage.
- **C:** Incorrect. False: mocking the unit under test or writing tautological assertions provides zero behavioral verification (`1.4`, `5.4`, `5.5`).
- **D:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).

### Question 85 — `B, C, E` (Improve developer productivity with GitHub Copilot)

Correct answers: B, C, and E (are correct). Assert exact boundary/error outcomes (`never tautological mocks`), lock legacy behavior with characterization tests prior to refactors, and confirm `CodeQL` Copilot Autofix security patches use parameterized APIs and pass CI. [Skill 5.5: Identify edge cases and write assertions | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/copilot-chat/copilot-chat-cookbook)]

- **A:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **B:** Correct. Characterization testing (`5.3`, `5.4`) guarantees legacy modernization preserves subtle business edge cases.
- **C:** Correct. Verified security remediation (`5.6`) confirms Autofix patches eliminate root-cause injection sinks without breaking callers.
- **D:** Incorrect. False: mocking the unit under test or writing tautological assertions provides zero behavioral verification (`1.4`, `5.4`, `5.5`).
- **E:** Correct. Edge-case identification and assertion quality (`5.5`) ensures tests catch real boundary defects rather than inflating superficial coverage.
- **F:** Incorrect. False: never place real PII/PHI/PCI data in prompts or repository instruction files; ask Copilot to generate schema-conforming **synthetic** fixtures instead (`1.3`, `5.3`).

### Question 86 — `A` (Improve developer productivity with GitHub Copilot)

Correct answer: A (is correct). Verify the Autofix removes `| safe` (`enabling context-aware HTML autoescaping`), confirm legitimate UI formatting still renders via unit/Playwright tests, and re-run `CodeQL` to confirm the alert closes. [Skill 5.6: Suggest security improvements and performance optimizations | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/code-security/code-scanning/managing-code-scanning-alerts/responsible-use-autofix-code-scanning)]

- **A:** Correct. Security and performance optimization (`5.6`) pairs Copilot/Autofix patches with profiler benchmarks and SAST re-scans.
- **B:** Incorrect. False: Copilot Content Exclusions apply strictly to **GitHub Copilot** features—they never restrict Git repository ACLs, Actions workflows, or `CodeQL` (`6.1`).
- **C:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **D:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).

### Question 87 — `D` (Improve developer productivity with GitHub Copilot)

Correct answer: D (is correct). Add eager loading (`selectinload(Encounter.practitioner)` / `joinedload`) so SQLAlchemy fetches encounters and practitioners in `1–2` queries instead of `N+1` round-trips. [Skill 5.6: Suggest security improvements and performance optimizations | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/code-security/code-scanning/managing-code-scanning-alerts/responsible-use-autofix-code-scanning)]

- **A:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **B:** Incorrect. False: mocking the unit under test or writing tautological assertions provides zero behavioral verification (`1.4`, `5.4`, `5.5`).
- **C:** Incorrect. False: vague one-word prompts combined with dozens of noisy tabs and stale chat history degrade relevance (`4.1`, `4.4`, `4.6`).
- **D:** Correct. Security and performance optimization (`5.6`) pairs Copilot/Autofix patches with profiler benchmarks and SAST re-scans.

### Question 88 — `A` (Configure privacy, content exclusions, and safeguards)

Correct answer: A (is correct). Adding `fnmatch` globs in `Content exclusion`, allowing `<=30 min` (`or reloading the IDE`) for policy sync, verifying the crossed-out Copilot icon + `copilot.content_exclusion_changed` audit log, and avoiding cross-file LSP hover leaks completes rollout. [Skill 6.1: Configure content exclusions and editor settings | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/managing-copilot/configuring-and-auditing-content-exclusion)]

- **A:** Correct. Correct order: configure YAML `fnmatch` globs -> allow `<=30 min` IDE sync -> verify crossed-out icon & audit log -> mind IDE LSP type-hover nuance.
- **B:** Incorrect. Incorrect: Repository admins CANNOT override or remove Organization-level Content Exclusions (`rules combine additively`), and sync takes `<=30 minutes`.
- **C:** Incorrect. Incorrect: `.gitignore` does not exclude already-tracked repository files from Copilot context.
- **D:** Incorrect. Incorrect: Content Exclusions require **Copilot Business or Enterprise**, use `fnmatch` globs, and govern Copilot context—not Git ACLs or Actions.

### Question 89 — `A` (Configure privacy, content exclusions, and safeguards)

Correct answer: A (is correct). No — `.github/copilot-instructions.md` can **never** override or weaken Repository or Organization **Content Exclusions**; excluded files remain blocked from Copilot prompts. [Skill 6.1: Configure content exclusions and editor settings | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/managing-copilot/configuring-and-auditing-content-exclusion)]

- **A:** Correct. Content Exclusion configuration (`6.1`) enforces additive Org + Repo `fnmatch` path exclusions across Business and Enterprise seats.
- **B:** Incorrect. False: Copilot Content Exclusions apply strictly to **GitHub Copilot** features—they never restrict Git repository ACLs, Actions workflows, or `CodeQL` (`6.1`).
- **C:** Incorrect. Content Exclusions (`2.3`, `6.1`) are only enforced for seats governed under Copilot Business or Copilot Enterprise.
- **D:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).

### Question 90 — `D` (Configure privacy, content exclusions, and safeguards)

Correct answer: D (is correct). Yes — Content Exclusions restrict **GitHub Copilot** from reading the file into AI context; they are NOT a Git repository access-control mechanism (`use separate private repositories to restrict human Git read access`). [Skill 6.1: Configure content exclusions and editor settings | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/managing-copilot/configuring-and-auditing-content-exclusion)]

- **A:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).
- **B:** Incorrect. False: Copilot Content Exclusions apply strictly to **GitHub Copilot** features—they never restrict Git repository ACLs, Actions workflows, or `CodeQL` (`6.1`).
- **C:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **D:** Correct. Content Exclusion scope limits (`2.3`, `6.1`) distinguish Copilot prompt blocking from IDE LSP type inference, Git ACLs, and CI scanners.

### Question 91 — `A` (Configure privacy, content exclusions, and safeguards)

Correct answer: A (is correct). No — `.gitignore` has no effect on files already tracked in Git and does not configure Copilot Content Exclusions; add `- "/config/vendor-signing.cfg"` in Repository or Organization Copilot Content Exclusion settings. [Skill 6.1: Configure content exclusions and editor settings | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/managing-copilot/configuring-and-auditing-content-exclusion)]

- **A:** Correct. Adding a tracked path to `.gitignore` (`6.1`) does NOT stop Copilot from reading that file in the IDE or on GitHub.com.
- **B:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).
- **C:** Incorrect. False: Copilot Content Exclusions apply strictly to **GitHub Copilot** features—they never restrict Git repository ACLs, Actions workflows, or `CodeQL` (`6.1`).
- **D:** Incorrect. The proposed GitHub Copilot configuration or workflow violates at least one stated governance, privacy, or technical requirement. No — `.gitignore` has no effect on files already tracked in Git and does not configure Copilot Content Exclusions; add `- "/config/vendor-signing.cfg"` in Repository or Organization Copilot Content Exclusion settings.

### Question 92 — `B` (Configure privacy, content exclusions, and safeguards)

Correct answer: B (is correct). GitHub claims **zero ownership** over code suggestions or customer outputs; Clarivance retains full rights and ownership of the code its engineers author with Copilot. [Skill 6.2: Describe ownership and limitations of outputs | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/about-github-copilot/plans-for-github-copilot)]

- **A:** Incorrect. Content Exclusions (`2.3`, `6.1`) are only enforced for seats governed under Copilot Business or Copilot Enterprise.
- **B:** Correct. Output ownership and IP Indemnity (`6.2`) require Business/Enterprise licensing with the public-code duplication filter enabled (`Block`).
- **C:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **D:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).

### Question 93 — `A` (Configure privacy, content exclusions, and safeguards)

Correct answer: A (is correct). No — disabling the public-code duplication filter (`setting it to Allow`) removes Copilot IP Indemnity coverage for unfiltered suggestions; keep production orgs locked to **`Block`**. [Skill 6.2: Describe ownership and limitations of outputs | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/about-github-copilot/plans-for-github-copilot)]

- **A:** Correct. Enabling `Block` on public-code duplication (`6.2`, `6.3`) is a mandatory condition for GitHub Copilot IP Indemnity protection.
- **B:** Incorrect. The proposed GitHub Copilot configuration or workflow violates at least one stated governance, privacy, or technical requirement. No — disabling the public-code duplication filter (`setting it to Allow`) removes Copilot IP Indemnity coverage for unfiltered suggestions; keep production orgs locked to **`Block`**.
- **C:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **D:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).

### Question 94 — `A` (Configure privacy, content exclusions, and safeguards)

Correct answer: A (is correct). Copilot's duplication filter checks inline text overlap (`~150+` chars), whereas importing an AGPL-3.0 or commercial library via `pyproject.toml`/`package.json` introduces dependency license obligations that require SCA governance. [Skill 6.2: Describe ownership and limitations of outputs | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/about-github-copilot/plans-for-github-copilot)]

- **A:** Correct. Output ownership and IP Indemnity (`6.2`) require Business/Enterprise licensing with the public-code duplication filter enabled (`Block`).
- **B:** Incorrect. False: inline completions are probabilistic token predictions (`non-deterministic`) and are NOT compiled or formally verified prior to rendering (`1.1`, `3.5`).
- **C:** Incorrect. False: Copilot Business and Enterprise **never** use customer prompts or suggestions to train shared foundational models (`3.1`).
- **D:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).

### Question 95 — `B` (Configure privacy, content exclusions, and safeguards)

Correct answer: B (is correct). Code Referencing logs links to the matching public files/commits along with each repository's detected license (`and explicitly flags repositories with unknown/missing licenses, which carry default all-rights-reserved risk`). [Skill 6.3: Enable suggestions matching public code filtering | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/finding-public-code-that-matches-github-copilot-suggestions)]

- **A:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **B:** Correct. Public-code duplication filtering and Code Referencing (`6.3`) either block `~150+` char verbatim public matches or surface repo/license provenance.
- **C:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **D:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).

### Question 96 — `B` (Configure privacy, content exclusions, and safeguards)

Correct answer: B (is correct). No — when an Enterprise enforces `Block` (`rather than No policy`), child Organizations inherit the locked `Block` policy and cannot relax it to `Allow`. [Skill 6.3: Enable suggestions matching public code filtering | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/finding-public-code-that-matches-github-copilot-suggestions)]

- **A:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **B:** Correct. Public-code duplication filtering and Code Referencing (`6.3`) either block `~150+` char verbatim public matches or surface repo/license provenance.
- **C:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **D:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).

### Question 97 — `B, C` (Configure privacy, content exclusions, and safeguards)

Correct answers: B and C (are correct). Setting `Suggestions matching public code = Block` suppresses `~150+` char public matches (`preserving Business/Enterprise IP Indemnity`), whereas `Allow` surfaces repo/license matches in **Code Referencing** without IP Indemnity. [Skill 6.3: Enable suggestions matching public code filtering | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/using-github-copilot/finding-public-code-that-matches-github-copilot-suggestions)]

- **A:** Incorrect. False: `Allow` permits public-code matches (`logging licenses via Code Referencing`) and **voids** public-code IP Indemnity coverage; open-source licenses still govern matched code (`6.2`, `6.3`).
- **B:** Correct. Public-code duplication filtering and Code Referencing (`6.3`) either block `~150+` char verbatim public matches or surface repo/license provenance.
- **C:** Correct. Output ownership and IP Indemnity (`6.2`) require Business/Enterprise licensing with the public-code duplication filter enabled (`Block`).
- **D:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
- **E:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).

### Question 98 — `C` (Configure privacy, content exclusions, and safeguards)

Correct answer: C (is correct). Running **Collect Diagnostics / View GitHub Copilot Diagnostics** (`and inspecting the GitHub Copilot Output log channel`) reports auth status, seat entitlement, proxy settings, and HTTPS reachability checks to Copilot endpoints. [Skill 6.4: Resolve issues with suggestions and content exclusions | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/troubleshooting-github-copilot/troubleshooting-common-issues-with-github-copilot)]

- **A:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).
- **B:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **C:** Correct. Troubleshooting Copilot (`6.4`) checks multi-org policy precedence (`most restrictive wins`), Content Exclusion icons, filetype settings, and proxy/TLS trust.
- **D:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).

### Question 99 — `C` (Configure privacy, content exclusions, and safeguards)

Correct answer: C (is correct). No — Content Exclusions require **Copilot Business or Enterprise** governance; uninvited personal Copilot Free/Pro accounts do not receive Organization Content Exclusion policies (`protect sensitive code via repo access controls + Enterprise AI controls`). [Skill 6.4: Resolve issues with suggestions and content exclusions | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/troubleshooting-github-copilot/troubleshooting-common-issues-with-github-copilot)]

- **A:** Incorrect. The proposed GitHub Copilot configuration or workflow violates at least one stated governance, privacy, or technical requirement. No — Content Exclusions require **Copilot Business or Enterprise** governance; uninvited personal Copilot Free/Pro accounts do not receive Organization Content Exclusion policies (`protect sensitive code via repo access controls + Enterprise AI controls`).
- **B:** Incorrect. Individual Copilot tiers (`2.1`, `2.15`) serve single accounts without Organization policy management or Org Content Exclusions.
- **C:** Correct. Content Exclusions (`2.3`, `6.1`) are only enforced for seats governed under Copilot Business or Copilot Enterprise.
- **D:** Incorrect. False: `.github/copilot-instructions.md` provides natural-language coding guidance and can **never** bypass Organization or Repository Content Exclusions (`2.11`, `6.1`).

### Question 100 — `B, D` (Configure privacy, content exclusions, and safeguards)

Correct answers: B and D (are correct). Verify corporate firewall/SSL-inspection CA trust (`NODE_EXTRA_CA_CERTS` / OS keychain + `HTTPS 443` to `*.githubcopilot.com`), and check Copilot Diagnostics for expired GitHub OAuth tokens, disabled filetypes, or restrictive multi-org policies. [Skill 6.4: Resolve issues with suggestions and content exclusions | Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/gh-300 | Reference: GitHub Copilot Documentation (https://docs.github.com/en/copilot/troubleshooting-github-copilot/troubleshooting-common-issues-with-github-copilot)]

- **A:** Incorrect. False: GitHub Copilot performs LLM inference and public-code duplication filtering in GitHub's cloud service over `TLS 1.2+` (`3.2`–`3.4`).
- **B:** Correct. Network & SSL-proxy configuration (`6.4`) resolves connection blocks and certificate trust errors in corporate IDEs.
- **C:** Incorrect. False: Copilot Content Exclusions apply strictly to **GitHub Copilot** features—they never restrict Git repository ACLs, Actions workflows, or `CodeQL` (`6.1`).
- **D:** Correct. Troubleshooting Copilot (`6.4`) checks multi-org policy precedence (`most restrictive wins`), Content Exclusion icons, filetype settings, and proxy/TLS trust.
- **E:** Incorrect. False: across multiple organization policies, GitHub always enforces the **most restrictive** policy (`Block` overrides `Allow`; `Disabled` overrides `Enabled`, `6.4`).
