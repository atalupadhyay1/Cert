# Full-Length Mock Exam 5: Flash-Commerce Merge Queues, Monorepo Doc-Sync Agentic Workflows, and Executive DORA

100 original items · 100-minute recommended timing · Microsoft scaled passing score `700 / 1000` · October 13, 2026 AZ-401 blueprint.

> **Prerequisite & Beta Notice:** Earning `Microsoft Certified: Agentic DevOps Engineer Expert` requires passing **AZ-401** plus holding an active **GH-300 (`GitHub Copilot`)** or **AZ-104 (`Azure Administrator Associate`)** certification. Exam AZ-401 is currently in **public beta** through **November 9, 2026** (GA targeted **December 2026**), succeeding **Exam AZ-400** (retiring **February 1, 2027**).

| Official AZ-401 Functional Group | Published Weight | Questions |
|---|---:|---:|
| Design and implement processes and communications | 15–20% | 17 |
| Design and implement a source control strategy | 10–15% | 13 |
| Design and implement build and release pipelines | 35–40% | 38 |
| Design and implement a security and compliance plan | 15–20% | 16 |
| Implement an instrumentation strategy | 15–20% | 16 |

## Item-Type & Pattern Mix

- `84` `multiple-choice` items (`76` single-answer scenarios + `8` four-step `→` ordered sequence items), including `21` `____` YAML/JSON/Bicep/KQL/CLI completion items and `8` `Proposed solution:` evaluations.
- `16` `multi-select` items (`13` five-option `Select two.` + `3` six-option `Select three.`).
- `4` original enterprise Agentic DevOps case studies × `3` questions = `12` case items.

## Upload Choice

- **`case-embedded-set-5.csv` (recommended for randomized Udemy tests):** embeds the full scenario inside each case question (longest stem `564` chars) so question shuffling never orphans context.
- **`practice-set-5.csv`:** compact case stems (`Case study — <Name>: ...`) for sequential review alongside `04-resources/case-studies.md`.
- **`practice-set-5.md`:** full human-readable study key with rationales and Microsoft Learn / GitHub Docs references.

Microsoft reports AZ-401 on a `100–1000` scaled score (`700` to pass), which does not equal `70%` raw accuracy.
